import assert from 'node:assert/strict';
import { DIVERGENCE_EXPONENT, iteratedLimit, iterationLimit, shapeKnown } from '../src/engine/cycles';
import { model } from './helpers';

/*
 * Testing strategy for iterationLimit (the limit of repeating a cycle; the engine's use of it is in engine.test.ts)
 *
 * direction: up (lower bounds), down (upper bounds)
 * H near its fixed point: slope < 1 (geometric convergence: fast, slow), slope 0 (a plateau: reached in one lap), no
 *   fixed point (lower bounds: geometric or linear growth: infinite; upper bounds: down to 0)
 * start: improving, not improving (returns the start); H not evaluating (NaN) at some points
 * result: on the safe side of the fixed point (below it going up, above it going down), within 1e-9
 * iteratedLimit (maps of unknown shape): stops when a lap no longer improves, or after the given laps
 * shapeKnown: rows without \min, a \min without calls, a call under \min
 */

const close = (actual: number, expected: number, tol = 1e-9): boolean => Math.abs(actual - expected) <= tol;

describe('iteratedLimit', () => {
  it('repeats the lap until it stops improving, or up to the given number of laps', () => {
    assert.ok(close(iteratedLimit((y) => Math.max(1, y / 2), 3, -1), 1));
    assert.equal(iteratedLimit((y) => y + 1, 0, 1, 10), 10);
    assert.equal(iteratedLimit((y) => y, 2, 1), 2);
  });
});

describe('shapeKnown', () => {
  const rowWith = (fromTime: string) => model([{ id: 'r', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime }]).rowsById.get('r')!;
  it('accepts sums, products, powers, maxima; rejects a call under \\min', () => {
    assert.ok(shapeKnown([rowWith('$O(n T(n) + T(\\sqrt{n})^2)$'), rowWith('$O(\\max(n^2, T(n)))$')]));
    assert.ok(shapeKnown([rowWith('$O(\\min(n, m) \\cdot T(n))$')]), 'a \\min without calls is a constant factor');
    assert.ok(!shapeKnown([rowWith('$O(T(n))$'), rowWith('$O(\\min(n T(n), T(n)^2))$')]));
  });
});

describe('iterationLimit', () => {
  it('goes up to the nearest fixed point, from below', () => {
    const x = iterationLimit((y) => (y + 3) / 2, 2, 1);
    assert.ok(close(x, 3) && x <= 3, String(x));
    // Slow convergence (slope 0.999) costs no more: the fixed point is found by bisection, not by iterating.
    const slow = iterationLimit((y) => 0.999 * y + 0.003, 1, 1);
    assert.ok(close(slow, 3, 1e-6) && slow <= 3, String(slow));
    // A plateau is reached in one lap.
    assert.equal(iterationLimit((y) => Math.min(y + 1, 5), 1, 1), 5);
  });

  it('is infinite for lower bounds that grow without a fixed point', () => {
    assert.equal(iterationLimit((y) => 2 * y - 1, 1.5, 1), Infinity);
    assert.equal(iterationLimit((y) => y + 0.001, 0, 1), Infinity);
    // … but finite when a fixed point comes, however far: a plateau, or an improvement that keeps shrinking.
    assert.ok(close(iterationLimit((y) => Math.min(2 * y, 1000), 1, 1), 1000));
    const far = iterationLimit((y) => 0.999999 * y + 10, 1, 1);
    // (H(y) − y cancels to about 1e-9 near 1e7, so the fixed point is found to about 1e-3.)
    assert.ok(far <= 1e7 && far > 1e7 - 1e-2, String(far));
    assert.ok(DIVERGENCE_EXPONENT < 1e7);
  });

  it('goes down to the nearest fixed point, from above, and never below 0', () => {
    const x = iterationLimit((y) => Math.max(1, 0.5 * y + 0.5), 3, -1);
    assert.ok(close(x, 1) && x >= 1, String(x));
    const g = iterationLimit((y) => 0.5 * y + 0.5, 3, -1);
    assert.ok(close(g, 1) && g >= 1, String(g));
    assert.ok(close(iterationLimit((y) => 0.5 * y, 3, -1), 0));
    assert.ok(close(iterationLimit((y) => Math.max(0.4, y - 0.25), 3, -1), 0.4));
  });

  it('returns the start when H does not improve it, or does not evaluate', () => {
    assert.equal(iterationLimit((y) => y, 2, 1), 2);
    assert.equal(iterationLimit((y) => y - 1, 2, 1), 2, 'going the other way');
    assert.equal(iterationLimit(() => NaN, 2, -1), 2);
  });

  it('stays on the safe side where H stops evaluating', () => {
    // H improves up to 4 but does not evaluate beyond: the limit stays at most where it was seen to improve.
    const x = iterationLimit((y) => (y > 4 ? NaN : y + 0.5), 1, 1);
    assert.ok(x <= 4.5 && x >= 4, String(x));
  });
});
