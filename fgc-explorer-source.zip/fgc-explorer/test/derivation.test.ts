import assert from 'node:assert/strict';
import { analyze, boundDerivations, DerivationPath } from '../src/engine/analysis';
import { model, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for derivation paths (boundDerivations, lbPath, ubPath)
 *
 * lower bound: from a knob on the problem itself (the problem alone), along a chain of reductions (every problem and
 *   reduction of the chain), none
 * upper bound: from a knob on the problem itself, through reductions (a chain; a tree with several calls), alternatives
 *   (only the best one is on the path), none
 * regime: primary (default), a given one, an unknown key (primary); unknown problem
 */

const [A, B, C, D, E, F, G] = ['F / A', 'F / B', 'F / C', 'F / D', 'F / E', 'F / F', 'F / G'];
const rows: RowSpec[] = [
  { id: '1', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: '2', from: B, to: C, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  // Two ways to solve C: with D (better) or with E.
  { id: '3', from: C, to: D, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: '4', from: C, to: E, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  // An unrelated reduction into D
  { id: '5', from: A, to: D, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  // F calls G twice, on sparse and on dense instances.
  { id: '6', from: F, to: G, toTime: '$T(n, m)$', fromTime: '$O(T(n, n) + T(n, n^2))$' },
];
const plain = (p: DerivationPath | null): [string[], string[]] | null => (p ? [[...p.problems].sort(), [...p.rows].sort()] : null);

describe('boundDerivations', () => {
  const m = model(rows);
  const a = analyze(
    m,
    scenario([
      { problem: A, kind: 'LB', regime: 'n=1', exponent: 1.5 },
      { problem: D, kind: 'UB', regime: 'n=1', exponent: 2 },
      { problem: E, kind: 'UB', regime: 'n=1', exponent: 2.5 },
      { problem: G, kind: 'UB', formula: 'n m' },
    ]),
  );

  it('follows a lower bound back to its knob, through every reduction of the chain', () => {
    assert.deepEqual(plain(boundDerivations(a, C).lb), [[A, B, C], ['1', '2']]);
  });

  it('follows an upper bound down to its knobs, through the best reductions only', () => {
    assert.deepEqual(plain(boundDerivations(a, C).ub), [[C, D], ['3']]);
    assert.deepEqual(plain(boundDerivations(a, B).ub), [[B, C, D], ['2', '3']]);
    const f = boundDerivations(a, F);
    assert.deepEqual(plain(f.ub), [[F, G], ['6']]);
    const origin = f.regime!.ub!.origin;
    assert.equal(origin.kind === 'row' && origin.children.length, 2, 'a tree: two calls');
  });

  it('is the problem alone for a bound from a knob on the problem itself', () => {
    assert.deepEqual(plain(boundDerivations(a, A).lb), [[A], []]);
    assert.deepEqual(plain(boundDerivations(a, D).ub), [[D], []]);
  });

  it('has no path for a missing bound, and nothing for an unknown problem', () => {
    assert.equal(boundDerivations(a, G).lb, null);
    const none = boundDerivations(a, 'F / Nowhere');
    assert.deepEqual([none.regime, none.lb, none.ub], [null, null, null]);
    const d = boundDerivations(analyze(m, scenario([])), D);
    assert.deepEqual([d.lb, d.ub], [null, null]);
    assert.notEqual(d.regime, null);
  });

  it('uses the given regime, or the primary one when the key is unknown', () => {
    const primary = boundDerivations(a, C);
    assert.equal(boundDerivations(a, C, 'no such regime').regime, primary.regime);
    assert.equal(boundDerivations(a, C, primary.regime!.regime.key).regime, primary.regime);
    // With a second regime pinned, that regime's bounds and derivations are the ones given.
    const pinned = analyze(m, scenario([{ problem: G, kind: 'UB', formula: 'n m' }]), new Map([[G, ['n=1, m=2']]]));
    const g = pinned.summaries.get(G)!;
    const other = g.regimes.find((r) => r !== g.primary)!;
    assert.equal(g.regimes.length, 2);
    const d = boundDerivations(pinned, G, other.regime.key);
    assert.equal(d.regime, other);
    assert.deepEqual(plain(d.ub), [[G], []]);
  });
});
