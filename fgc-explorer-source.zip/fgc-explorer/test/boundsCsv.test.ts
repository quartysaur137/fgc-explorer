import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { initialBoundsCsv } from '../scripts/initialBounds';
import { mergeBounds, mergeKnobs, parseBoundKind, readBoundsCsv, unwrapOmega, writeBoundsCsv } from '../src/model/boundsCsv';
import { canonicalProblem, problemBoxes } from '../src/model/boxes';
import { initialScenario, Knob, validateConfig } from '../src/model/config';
import { buildModel, COL } from '../src/model/model';
import { CsvTable } from '../src/util/csv';
import { model as makeModel } from './helpers';

/*
 * Testing strategy for the bounds CSV
 *
 * columns: all required present (any order, extra ones ignored), some missing (nothing read)
 * Upper or Lower: Upper/Lower and synonyms, any case; unrecognized (row skipped)
 * Runtime: plain number (exponent; negative, zero for a lower bound), $...$ formula, bare formula, \Omega(...) around a
 *   lower bound, unparsable (row skipped), empty (row skipped)
 * Power: absent column, empty (1), a positive number with an exponent (2^{c·n^a}), 1 (left out), with a formula, not
 *   a positive number (row skipped)
 * Regime: given (valid, unparsable, parameter of another problem), missing (lower bound or exponent: main regime of
 *   a known problem; unknown problem: row skipped; upper-bound formula: every regime)
 * Problem: known (any case, family alias), unknown (warning; read anyway), empty (row skipped)
 * Bound ID: L…/U… in either case (canonical), unique, blank or repeated (new ones of the row's kind after the file's,
 *   avoiding reserved ids), of the other kind (a new one, with a warning), bare numbers of earlier versions (their place
 *   among the initial bounds, or new ones with a warning), other text; Enabled: blank, yes/no words, unrecognized
 *   (warning)
 * column names in any case; an unterminated quoted field (its row not read)
 * rows without a bound (no Upper or Lower, no Runtime): list their problem (known, unknown: warning, none: error), other
 *   cells ignored (warning); problems in order of first appearance, with or without bounds
 * writeBoundsCsv: round trip with readBoundsCsv (box by box, empty boxes as problem-only rows; a Power column only when
 *   a knob has a power other than 1; a problem without a family: blank Problem column); data/initial-bounds.csv
 *   matches the config's initial knobs and reads back as them
 * mergeKnobs / mergeBounds: replace (the file's boxes); add (same id replaced in place, others appended; current boxes
 *   first, then the file's new ones)
 */

const m = makeModel(
  [
    { id: '1', from: '3SUM / 3SUM', to: 'Geometry / GeomBase', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: '2', from: 'Graphs / APSP', to: 'Graphs / Negative Triangle', toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
    { id: '3', from: 'Satisfiability / CNF-SAT', to: '3SUM / 3SUM', toTime: '$T(n)$', fromTime: '$O(T(2^{n/2}))$' },
  ],
  {
    aliases: { Satisfiabilty: 'Satisfiability' },
    problems: {
      'Satisfiability / CNF-SAT': { params: ['n', 'm'], timeType: 'exp', regimes: ['n=log, m=polylog'] },
      'Graphs / APSP': { params: ['n', 'm'], regimes: ['n=1, m=2'] },
    },
  },
);

const HEADER = 'Problem,Variation,Bound ID,Upper or Lower,Runtime';
const read = (body: string, header = HEADER) => readBoundsCsv(`${header}\n${body}`, m);
const errorsOf = (r: ReturnType<typeof read>) => r.issues.filter((i) => i.level === 'error').map((i) => i.message);
const warningsOf = (r: ReturnType<typeof read>) => r.issues.filter((i) => i.level === 'warning').map((i) => i.message);

describe('readBoundsCsv', () => {
  it('finds columns by name in any order and ignores extra ones', () => {
    const r = read('"n^2",x1,Upper,3SUM,3SUM,whatever', 'Runtime,Bound ID,Upper or Lower,Problem,Variation,Comments');
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, [{ problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^2', id: 'x1', enabled: true }]);
  });

  it('finds columns in any case', () => {
    const r = read('3SUM,3SUM,U9,upper,n^2', 'problem,VARIATION,bound id,Upper Or Lower,runtime');
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, [{ problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^2', id: 'U9', enabled: true }]);
  });

  it('does not read the row that starts an unterminated quoted field (it holds the rest of the file)', () => {
    const r = read(['3SUM,3SUM,U1,Upper,n^2', '3SUM,3SUM,U2,Upper,"n^3', '3SUM,3SUM,U3,Upper,n'].join('\n'));
    assert.deepEqual(r.knobs.map((k) => k.id), ['U1']);
    assert.ok(errorsOf(r).some((e) => /unterminated quoted field/.test(e)), errorsOf(r).join('; '));
    assert.deepEqual(r.problems, ['3SUM / 3SUM']);
  });

  it("gives a row whose Bound ID is of the other kind a new one (it would replace another bound when adding)", () => {
    const r = read(['3SUM,3SUM,U17,Lower,1.5', 'Graphs,APSP,L3,Upper,n^3'].join('\n'));
    // (new IDs come after the file's: L4, U18)
    assert.deepEqual(r.knobs.map((k) => [k.id, k.kind]), [['L4', 'LB'], ['U18', 'UB']]);
    assert.equal(warningsOf(r).length, 2);
    assert.match(warningsOf(r)[0]!, /U17 is an upper bound's, but the row is a lower bound; it becomes L4/);
  });

  it('reads nothing when required columns are missing', () => {
    const r = readBoundsCsv('Problem,Variation,Runtime\n3SUM,3SUM,n^2', m);
    assert.deepEqual(r.missingColumns, ['Bound ID', 'Upper or Lower']);
    assert.deepEqual(r.knobs, []);
  });

  it('reads plain numbers as exponents and fills in the main regime', () => {
    const r = read(['3SUM,3SUM,h1,Lower,2', 'Graphs,APSP,h2,lower,3', 'Satisfiability,CNF-SAT,seth,LB,1', 'Graphs,APSP,a1,upper,2.9995'].join('\n'));
    assert.deepEqual(errorsOf(r), []);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.kind, k.exponent, k.regime]),
      [
        ['h1', 'LB', 2, 'n=1'],
        ['h2', 'LB', 3, 'n=1, m=2'],
        ['seth', 'LB', 1, 'n=log, m=polylog'],
        ['a1', 'UB', 2.9995, 'n=1, m=2'],
      ],
    );
  });

  it('reads the power of an exponent (running time 2^{c·n^a})', () => {
    const header = `${HEADER},Power`;
    const r = read(['Satisfiability,CNF-SAT,e1,LB,0.5,0.75', 'Satisfiability,CNF-SAT,e2,UB,1,', 'Satisfiability,CNF-SAT,e3,UB,1,1'].join('\n'), header);
    assert.deepEqual(errorsOf(r), []);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.exponent, k.power]),
      [
        ['e1', 0.5, 0.75],
        ['e2', 1, undefined],
        ['e3', 1, undefined],
      ],
    );
    const bad = read(['Satisfiability,CNF-SAT,f1,UB,$2^n$,0.5', 'Satisfiability,CNF-SAT,f2,LB,1,0', 'Satisfiability,CNF-SAT,f3,LB,1,x'].join('\n'), header);
    assert.deepEqual(bad.knobs, []);
    assert.equal(errorsOf(bad).length, 3);
    assert.match(errorsOf(bad)[0]!, /goes with a plain exponent/);
  });

  it('reads formulas with or without $...$; upper-bound formulas apply to every regime', () => {
    const r = read(['3SUM,3SUM,u1,Upper,$n^{1.9992}$', 'Graphs,APSP,u2,Upper,n \\cdot m + n^2 \\log n', 'Graphs,APSP,l1,Lower,$\\Omega(n^{3-o(1)})$'].join('\n'));
    assert.deepEqual(errorsOf(r), []);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.formula, k.regime]),
      [
        ['U1', 'n^{1.9992}', undefined],
        ['U2', 'n \\cdot m + n^2 \\log n', undefined],
        ['L1', 'n^{3-o(1)}', 'n=1, m=2'],
      ],
    );
  });

  it('skips rows with errors and says why', () => {
    const r = read(
      [
        '3SUM,3SUM,e1,Sideways,2', // kind
        '3SUM,3SUM,e2,Upper,', // no runtime
        '3SUM,3SUM,e3,Upper,n^{', // unparsable
        '3SUM,3SUM,e4,Lower,0', // zero lower bound
        '3SUM,3SUM,e5,Upper,-1', // negative exponent
        ',,e6,Upper,n', // no problem
        'Nowhere,Unknown,e7,Lower,2', // unknown problem: no main regime
        '3SUM,3SUM,ok,Upper,n^2',
      ].join('\n'),
    );
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['ok'],
    );
    const lines = new Set(r.issues.filter((i) => i.level === 'error').map((i) => i.line));
    assert.deepEqual([...lines], [2, 3, 4, 5, 6, 7, 8]);
  });

  it('checks regimes', () => {
    const r = read(['Graphs,APSP,r1,Lower,3,"n=1, m=2"', 'Graphs,APSP,r2,Lower,3,"n=1, q=2"', 'Graphs,APSP,r3,Lower,3,"n=fast"'].join('\n'), `${HEADER},Regime`);
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['r1'],
    );
    assert.equal(errorsOf(r).length, 2);
    assert.match(errorsOf(r)[0]!, /q is not a parameter/);
  });

  it('accepts unknown problems with a warning, and family aliases and any case for known ones', () => {
    const r = read(['Nowhere,Unknown,w1,Upper,n^2', 'satisfiabilty,cnf-sat,w2,Upper,2^n'].join('\n'));
    assert.deepEqual(errorsOf(r), []);
    assert.equal(warningsOf(r).length, 1);
    assert.deepEqual(
      r.knobs.map((k) => k.problem),
      ['Nowhere / Unknown', 'Satisfiability / CNF-SAT'],
    );
  });

  it("reads Enabled and Note, and gives rows with a blank or repeated Bound ID new ones after the file's", () => {
    const r = read(['3SUM,3SUM,,Upper,n^2,no,my note', '3SUM,3SUM,U4,Upper,n^2,off,', '3SUM,3SUM,u4,Upper,n^2,maybe,', '3SUM,3SUM,x,Upper,n,,'].join('\n'), `${HEADER},Enabled,Note`);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.enabled, k.note]),
      [
        ['U5', false, 'my note'],
        ['U4', false, undefined],
        ['U6', true, undefined],
        ['x', true, undefined],
      ],
    );
    assert.equal(warningsOf(r).length, 3);
  });

  it('reads the bare numbers of earlier versions as the IDs the initial bounds have now', () => {
    const r = read(['Graphs,APSP,3,Lower,3', '3SUM,3SUM,13,Upper,n^2', '3SUM,3SUM,40,Upper,n', 'Graphs,APSP,12,Lower,2', '3SUM,3SUM,5,Upper,n^3'].join('\n'));
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['L3', 'U4', 'U374', 'L12', 'U375'],
    );
    // (no initial upper bound had a number below 10)
    assert.deepEqual(warningsOf(r), ['Bound ID 5 becomes U375 (Bound IDs have a letter now: L… for lower bounds, U… for upper bounds)']);
  });

  it('lists the problems of rows without a bound, in order of first appearance', () => {
    const r = read(['Graphs,APSP,,,', '3SUM,3SUM,U1,Upper,n^2', 'Graphs,APSP,U2,Upper,n^3', 'Nowhere,Unknown,,,', '3SUM,3SUM,7,,', ',,8,,'].join('\n'));
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['U1', 'U2'],
    );
    assert.deepEqual(r.problems, ['Graphs / APSP', '3SUM / 3SUM', 'Nowhere / Unknown']);
    assert.deepEqual(
      r.issues.map((i) => [i.line, i.level]),
      [
        [5, 'warning'], // unknown problem
        [6, 'warning'], // Bound ID ignored
        [7, 'error'], // no problem (row skipped)
        [7, 'warning'], // Bound ID ignored
      ],
    );
    assert.match(r.issues[1]!.message, /only lists the problem \(Bound ID ignored\)/);
  });

  it('avoids reserved ids (the current knobs, when adding) for new ones', () => {
    const r = readBoundsCsv(`${HEADER}\n3SUM,3SUM,,Upper,n^2\n3SUM,3SUM,U2,Upper,n\n3SUM,3SUM,,Lower,2`, m, ['U1', 'U2', 'U33', 'L1']);
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['U34', 'U2', 'L2'],
    );
  });
});

describe('parseBoundKind and unwrapOmega', () => {
  it('recognizes upper and lower bounds', () => {
    assert.deepEqual(['Upper', 'UB', ' algorithm ', 'Lower', 'lower bound', 'Hypothesis', 'maybe'].map(parseBoundKind), ['UB', 'UB', 'UB', 'LB', 'LB', 'LB', null]);
  });

  it('unwraps a whole-formula \\Omega(...) only', () => {
    assert.equal(unwrapOmega('\\Omega(n^2)'), 'n^2');
    assert.equal(unwrapOmega('\\Omega\\left(n (\\log n)^2\\right)'), 'n (\\log n)^2');
    assert.equal(unwrapOmega('\\tilde{\\Omega}(n m)'), 'n m');
    assert.equal(unwrapOmega('\\Omega(n) + m'), '\\Omega(n) + m');
    assert.equal(unwrapOmega('n^2'), 'n^2');
  });
});

describe('writeBoundsCsv', () => {
  const config = (): string => readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8');
  const sheetCsv = (): string => readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');

  it('round-trips through readBoundsCsv', () => {
    const knobs: Knob[] = [
      { id: 'a', problem: '3SUM / 3SUM', kind: 'LB', regime: 'n=1', exponent: 2, enabled: true, note: 'with, a comma' },
      { id: 'b', problem: 'Graphs / APSP', kind: 'UB', formula: '\\min(n^3, n m)', enabled: false },
      { id: 'c', problem: 'Graphs / APSP', kind: 'UB', regime: 'n=1, m=1', exponent: 2, enabled: true },
    ];
    const r = readBoundsCsv(writeBoundsCsv(knobs, m), m);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, knobs);
    assert.deepEqual(r.problems, ['3SUM / 3SUM', 'Graphs / APSP']);
  });

  it('writes a problem without a family with a blank Problem column, and reads it back', () => {
    const table = new CsvTable(
      [COL.fromFamily, COL.fromVariation, COL.toFamily, COL.toVariation, COL.id, COL.toTime, COL.fromTime, COL.rt],
      [['3SUM', '3SUM', '', 'Lone', 'R1', '$T(n)$', '$O(T(n))$', '$O(n)$']],
    );
    const lone = buildModel(table, validateConfig({ version: 1 }).value);
    const knobs: Knob[] = [{ id: 'U1', problem: 'Lone', kind: 'UB', formula: 'n^2', enabled: true }];
    const text = writeBoundsCsv(knobs, lone);
    assert.match(text, /\r\n,Lone,U1,Upper,/);
    const r = readBoundsCsv(text, lone);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, knobs);
    assert.deepEqual(r.problems, ['Lone']);
  });

  it('writes a Power column only when a knob has a power other than 1', () => {
    const knobs: Knob[] = [
      { id: 'a', problem: 'Satisfiability / CNF-SAT', kind: 'LB', regime: 'n=log, m=polylog', exponent: 0.5, power: 0.75, enabled: true },
      { id: 'b', problem: 'Satisfiability / CNF-SAT', kind: 'UB', formula: '2^n \\cdot m', enabled: true },
    ];
    const text = writeBoundsCsv(knobs, m);
    assert.match(text, /^Problem,Variation,Bound ID,Upper or Lower,Runtime,Power,Regime,Enabled,Note\r\n/);
    assert.match(text, /,0\.5,0\.75,/);
    const r = readBoundsCsv(text, m);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, knobs);
    assert.doesNotMatch(writeBoundsCsv([knobs[1]!], m), /Power/);
    // tiny numbers in plain notation (not 5e-7), so that they read back
    const tiny: Knob[] = [{ id: 't', problem: 'Satisfiability / CNF-SAT', kind: 'UB', regime: 'n=log, m=polylog', exponent: 5e-7, power: 5e-7, enabled: true }];
    const t = writeBoundsCsv(tiny, m);
    assert.match(t, /,0\.0000005,0\.0000005,/);
    assert.deepEqual(readBoundsCsv(t, m).knobs, tiny);
  });

  it('writes box by box, empty boxes as rows without a bound', () => {
    const k = (id: string, problem: string): Knob => ({ id, problem, kind: 'UB', formula: 'n^2', enabled: true });
    const knobs = [k('U1', '3SUM / 3SUM'), k('U2', 'graphs / apsp'), k('U3', '3SUM / 3SUM')];
    const text = writeBoundsCsv(knobs, m, ['Graphs / APSP', 'Geometry / GeomBase']);
    assert.deepEqual(
      text.split('\r\n').slice(1, -1),
      ['Graphs,APSP,U2,Upper,$n^2$,,yes,', 'Geometry,GeomBase,,,,,,', '3SUM,3SUM,U1,Upper,$n^2$,,yes,', '3SUM,3SUM,U3,Upper,$n^2$,,yes,'],
    );
    const r = readBoundsCsv(text, m);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.problems, ['Graphs / APSP', 'Geometry / GeomBase', '3SUM / 3SUM']);
    assert.deepEqual(
      r.knobs.map((x) => [x.id, x.problem]),
      [
        ['U2', 'Graphs / APSP'],
        ['U1', '3SUM / 3SUM'],
        ['U3', '3SUM / 3SUM'],
      ],
    );
  });

  it('data/initial-bounds.csv encodes the initial knobs of the config (run `npm run bounds-sample` after changing them)', () => {
    const sample = readFileSync(new URL('../data/initial-bounds.csv', import.meta.url), 'utf8');
    assert.equal(sample, initialBoundsCsv(sheetCsv(), config()));
  });

  it('the sample reads back as exactly the initial scenario (knobs grouped by problem)', () => {
    const cfg = validateConfig(JSON.parse(config())).value;
    const initial = initialScenario(cfg);
    const boxes = problemBoxes(initial.problems, initial.knobs);
    const r = readBoundsCsv(readFileSync(new URL('../data/initial-bounds.csv', import.meta.url), 'utf8'), null);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.problems, boxes.map((b) => b.problem));
    assert.deepEqual(r.knobs, boxes.flatMap((b) => b.knobs));
  });
});

describe('mergeKnobs and mergeBounds', () => {
  const k = (id: string, exponent: number, problem = '3SUM / 3SUM'): Knob => ({ id, problem, kind: 'LB', regime: 'n=1', exponent, enabled: true });

  it('replaces everything, or updates by id and appends', () => {
    const current = [k('a', 1), k('b', 2)];
    const imported = [k('b', 9), k('c', 3)];
    assert.deepEqual(mergeKnobs(current, imported, true), imported);
    assert.deepEqual(mergeKnobs(current, imported, false), [k('a', 1), k('b', 9), k('c', 3)]);
  });

  it("takes the file's boxes when replacing, and appends its new boxes when adding", () => {
    const canonical = canonicalProblem(m);
    const current = { knobs: [k('a', 1, 'Graphs / APSP')], problems: ['Geometry / GeomBase'] };
    const imported = { knobs: [k('b', 2), k('c', 3, 'graphs / APSP')], problems: ['Satisfiability / CNF-SAT', '3SUM / 3SUM', 'Graphs / APSP'] };
    const replaced = mergeBounds(current, imported, true, canonical);
    assert.deepEqual(replaced.problems, ['Satisfiability / CNF-SAT', '3SUM / 3SUM', 'Graphs / APSP']);
    assert.deepEqual(
      replaced.knobs.map((x) => x.id),
      ['b', 'c'],
    );
    const added = mergeBounds(current, imported, false, canonical);
    assert.deepEqual(added.problems, ['Geometry / GeomBase', 'Graphs / APSP', 'Satisfiability / CNF-SAT', '3SUM / 3SUM']);
    assert.deepEqual(
      added.knobs.map((x) => x.id),
      ['a', 'b', 'c'],
    );
  });
});
