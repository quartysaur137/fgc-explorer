import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { initialBoundsCsv } from '../scripts/initialBounds';
import { mergeKnobs, parseBoundKind, readBoundsCsv, unwrapOmega, writeBoundsCsv } from '../src/model/boundsCsv';
import { initialScenario, Knob, validateConfig } from '../src/model/config';
import { model as makeModel } from './helpers';

/*
 * Testing strategy for the bounds CSV
 *
 * columns: all required present (any order, extra ones ignored), some missing (nothing read)
 * Upper or Lower: Upper/Lower and synonyms, any case; unrecognized (row skipped)
 * Runtime: plain number (exponent; negative, zero for a lower bound), $...$ formula, bare formula, \Omega(...) around a
 *   lower bound, unparsable (row skipped), empty (row skipped)
 * Regime: given (valid, unparsable, parameter of another problem), missing (lower bound or exponent: main regime of
 *   a known problem; unknown problem: row skipped; upper-bound formula: every regime)
 * Problem: known (any case, family alias), unknown (warning; read anyway), empty (row skipped)
 * Bound ID: unique, blank or repeated (new numbers after the file's, avoiding reserved ids), non-numeric; Enabled: blank,
 *   yes/no words, unrecognized (warning)
 * writeBoundsCsv: round trip with readBoundsCsv; data/initial-bounds.csv matches the config's initial knobs
 * mergeKnobs: replace; add (same id replaced in place, others appended)
 */

const m = makeModel(
  [
    { id: '1', from: '3SUM / 3SUM', to: 'Geometry / GeomBase', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: '2', from: 'Graphs / APSP', to: 'Graphs / Negative Triangle', toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
    { id: '3', from: 'Satisfiability / CNF-SAT', to: '3SUM / 3SUM', toTime: '$T(n)$', fromTime: '$O(T(2^{n/2}))$' },
  ],
  {
    aliases: { Satisfiabilty: 'Satisfiability' },
    problems: {
      'Satisfiability / CNF-SAT': { params: ['n', 'm'], timeType: 'exp', regimes: ['n=log, m=polylog'] },
      'Graphs / APSP': { params: ['n', 'm'], regimes: ['n=1, m=2'] },
    },
  },
);

const HEADER = 'Problem,Variation,Bound ID,Upper or Lower,Runtime';
const read = (body: string, header = HEADER) => readBoundsCsv(`${header}\n${body}`, m);
const errorsOf = (r: ReturnType<typeof read>) => r.issues.filter((i) => i.level === 'error').map((i) => i.message);
const warningsOf = (r: ReturnType<typeof read>) => r.issues.filter((i) => i.level === 'warning').map((i) => i.message);

describe('readBoundsCsv', () => {
  it('finds columns by name in any order and ignores extra ones', () => {
    const r = read('"n^2",x1,Upper,3SUM,3SUM,whatever', 'Runtime,Bound ID,Upper or Lower,Problem,Variation,Comments');
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, [{ problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^2', id: 'x1', enabled: true }]);
  });

  it('reads nothing when required columns are missing', () => {
    const r = readBoundsCsv('Problem,Variation,Runtime\n3SUM,3SUM,n^2', m);
    assert.deepEqual(r.missingColumns, ['Bound ID', 'Upper or Lower']);
    assert.deepEqual(r.knobs, []);
  });

  it('reads plain numbers as exponents and fills in the main regime', () => {
    const r = read(['3SUM,3SUM,h1,Lower,2', 'Graphs,APSP,h2,lower,3', 'Satisfiability,CNF-SAT,seth,LB,1', 'Graphs,APSP,a1,upper,2.9995'].join('\n'));
    assert.deepEqual(errorsOf(r), []);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.kind, k.exponent, k.regime]),
      [
        ['h1', 'LB', 2, 'n=1'],
        ['h2', 'LB', 3, 'n=1, m=2'],
        ['seth', 'LB', 1, 'n=log, m=polylog'],
        ['a1', 'UB', 2.9995, 'n=1, m=2'],
      ],
    );
  });

  it('reads formulas with or without $...$; upper-bound formulas apply to every regime', () => {
    const r = read(['3SUM,3SUM,u1,Upper,$n^{1.9992}$', 'Graphs,APSP,u2,Upper,n \\cdot m + n^2 \\log n', 'Graphs,APSP,l1,Lower,$\\Omega(n^{3-o(1)})$'].join('\n'));
    assert.deepEqual(errorsOf(r), []);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.formula, k.regime]),
      [
        ['u1', 'n^{1.9992}', undefined],
        ['u2', 'n \\cdot m + n^2 \\log n', undefined],
        ['l1', 'n^{3-o(1)}', 'n=1, m=2'],
      ],
    );
  });

  it('skips rows with errors and says why', () => {
    const r = read(
      [
        '3SUM,3SUM,e1,Sideways,2', // kind
        '3SUM,3SUM,e2,Upper,', // no runtime
        '3SUM,3SUM,e3,Upper,n^{', // unparsable
        '3SUM,3SUM,e4,Lower,0', // zero lower bound
        '3SUM,3SUM,e5,Upper,-1', // negative exponent
        ',,e6,Upper,n', // no problem
        'Nowhere,Unknown,e7,Lower,2', // unknown problem: no main regime
        '3SUM,3SUM,ok,Upper,n^2',
      ].join('\n'),
    );
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['ok'],
    );
    const lines = new Set(r.issues.filter((i) => i.level === 'error').map((i) => i.line));
    assert.deepEqual([...lines], [2, 3, 4, 5, 6, 7, 8]);
  });

  it('checks regimes', () => {
    const r = read(['Graphs,APSP,r1,Lower,3,"n=1, m=2"', 'Graphs,APSP,r2,Lower,3,"n=1, q=2"', 'Graphs,APSP,r3,Lower,3,"n=fast"'].join('\n'), `${HEADER},Regime`);
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['r1'],
    );
    assert.equal(errorsOf(r).length, 2);
    assert.match(errorsOf(r)[0]!, /q is not a parameter/);
  });

  it('accepts unknown problems with a warning, and family aliases and any case for known ones', () => {
    const r = read(['Nowhere,Unknown,w1,Upper,n^2', 'satisfiabilty,cnf-sat,w2,Upper,2^n'].join('\n'));
    assert.deepEqual(errorsOf(r), []);
    assert.equal(warningsOf(r).length, 1);
    assert.deepEqual(
      r.knobs.map((k) => k.problem),
      ['Nowhere / Unknown', 'Satisfiability / CNF-SAT'],
    );
  });

  it("reads Enabled and Note, and numbers rows with a blank or repeated Bound ID after the file's numbers", () => {
    const r = read(['3SUM,3SUM,,Upper,n^2,no,my note', '3SUM,3SUM,4,Upper,n^2,off,', '3SUM,3SUM,4,Upper,n^2,maybe,', '3SUM,3SUM,x,Upper,n,,'].join('\n'), `${HEADER},Enabled,Note`);
    assert.deepEqual(
      r.knobs.map((k) => [k.id, k.enabled, k.note]),
      [
        ['5', false, 'my note'],
        ['4', false, undefined],
        ['6', true, undefined],
        ['x', true, undefined],
      ],
    );
    assert.equal(warningsOf(r).length, 3);
  });

  it('avoids reserved ids (the current knobs, when adding) for new numbers', () => {
    const r = readBoundsCsv(`${HEADER}\n3SUM,3SUM,,Upper,n^2\n3SUM,3SUM,2,Upper,n`, m, ['1', '2', '33']);
    assert.deepEqual(
      r.knobs.map((k) => k.id),
      ['34', '2'],
    );
  });
});

describe('parseBoundKind and unwrapOmega', () => {
  it('recognizes upper and lower bounds', () => {
    assert.deepEqual(['Upper', 'UB', ' algorithm ', 'Lower', 'lower bound', 'Hypothesis', 'maybe'].map(parseBoundKind), ['UB', 'UB', 'UB', 'LB', 'LB', 'LB', null]);
  });

  it('unwraps a whole-formula \\Omega(...) only', () => {
    assert.equal(unwrapOmega('\\Omega(n^2)'), 'n^2');
    assert.equal(unwrapOmega('\\Omega\\left(n (\\log n)^2\\right)'), 'n (\\log n)^2');
    assert.equal(unwrapOmega('\\tilde{\\Omega}(n m)'), 'n m');
    assert.equal(unwrapOmega('\\Omega(n) + m'), '\\Omega(n) + m');
    assert.equal(unwrapOmega('n^2'), 'n^2');
  });
});

describe('writeBoundsCsv', () => {
  const config = (): string => readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8');
  const sheetCsv = (): string => readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');

  it('round-trips through readBoundsCsv', () => {
    const knobs: Knob[] = [
      { id: 'a', problem: '3SUM / 3SUM', kind: 'LB', regime: 'n=1', exponent: 2, enabled: true, note: 'with, a comma' },
      { id: 'b', problem: 'Graphs / APSP', kind: 'UB', formula: '\\min(n^3, n m)', enabled: false },
      { id: 'c', problem: 'Graphs / APSP', kind: 'UB', regime: 'n=1, m=1', exponent: 2, enabled: true },
    ];
    const r = readBoundsCsv(writeBoundsCsv(knobs, m), m);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, knobs);
  });

  it('data/initial-bounds.csv encodes the initial knobs of the config (run `npm run bounds-sample` after changing them)', () => {
    const sample = readFileSync(new URL('../data/initial-bounds.csv', import.meta.url), 'utf8');
    assert.equal(sample, initialBoundsCsv(sheetCsv(), config()));
  });

  it('the sample reads back as exactly the initial scenario', () => {
    const cfg = validateConfig(JSON.parse(config())).value;
    const r = readBoundsCsv(readFileSync(new URL('../data/initial-bounds.csv', import.meta.url), 'utf8'), null);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(r.knobs, initialScenario(cfg).knobs);
  });
});

describe('mergeKnobs', () => {
  const k = (id: string, exponent: number): Knob => ({ id, problem: '3SUM / 3SUM', kind: 'LB', regime: 'n=1', exponent, enabled: true });

  it('replaces everything, or updates by id and appends', () => {
    const current = [k('a', 1), k('b', 2)];
    const imported = [k('b', 9), k('c', 3)];
    assert.deepEqual(mergeKnobs(current, imported, true), imported);
    assert.deepEqual(mergeKnobs(current, imported, false), [k('a', 1), k('b', 9), k('c', 3)]);
  });
});
