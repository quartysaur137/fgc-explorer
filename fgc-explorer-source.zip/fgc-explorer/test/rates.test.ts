import assert from 'node:assert/strict';
import { analyze, Analysis, formulaRate, rowUsable, statusOf } from '../src/engine/analysis';
import * as G from '../src/growth/growth';
import { parseExpr } from '../src/math/parser';
import { Regime } from '../src/model/regime';
import { explainLower, LBFact } from '../src/engine/lower';
import { constantEnv } from '../src/engine/rowEval';
import { UBFact } from '../src/engine/upper';
import { validateKnobSpec } from '../src/model/config';
import { model, near, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for running times 2^{c·L^a} (L = log2 N; powers a other than 1) in propagation and statuses
 *
 * knobs: exponent with a power (LB, UB), formula with a power, invalid powers (≤ 0; with a formula)
 * LB propagation at power a: identity between exponential-time problems (kept), a call on an instance of another scale
 *   (coefficient scaled by s^a), a reduction slower than the bound (nothing, with the reason), a polylogarithmic
 *   reduction to a polynomial-scale problem (sub-polynomial bound 2^{c·log^a t}), a cycle that raises the bound without
 *   limit (∞ at power a); bounds of several powers at one regime (the larger power wins)
 * UB propagation: through an identity (kept), through rows whose own time or calls dominate, from a sub-polynomial and
 *   a quasi-polynomial target bound (power < 1, > 1); the best of several powers (the smaller power wins); a reduction
 *   that cannot beat a bound of smaller power (skipped, with its optimistic rate)
 * statuses across powers: conflict (UB power below LB power), gap (above), tight / conflict / gap at the same power
 * review regressions: powers computed in different ways (0.1·3 and 0.3) are one power; a log-dependent parameter's
 *   size is one class per key (same bounds whatever the order of the rows); formulas written for exponent knobs
 *   (Regime.timeFormula) evaluate to the knob's rate again, also for exponent 0 and with every decimal
 */

const S = 'SAT / S';
const S2 = 'SAT / S2';
const O = 'OV / O';
const Q = 'SS / Q';
const rows: RowSpec[] = [
  // S → S2 on the same instance (as CNF-SAT → MAX-CNF-SAT)
  { id: 'ss2', from: S, to: S2, toTime: '$T(n, m)$', fromTime: '$O(T(n, m))$', rt: '$O(1)$' },
  // split and list: the reduction itself takes 2^{n/2} (as CNF-SAT → OV)
  { id: 'so', from: S, to: O, toTime: '$T(n, d)$', fromTime: '$O(T(2^{n/2}, m))$', rt: '$O(2^{n/2} n m)$' },
  // a reduction of polylogarithmic cost to an instance with t = 2^{n/2} (as CNF-SAT → Subset Sum)
  { id: 'sq', from: S, to: Q, toTime: '$T(t)$', fromTime: '$O(T(2^{n/2}))$', rt: '$O(n m)$' },
];
const expTime = { params: ['n', 'm'], timeType: 'exp', regimes: ['n=log, m=polylog'] };
const m = model(rows, { problems: { [S]: expTime, [S2]: expTime, [O]: { regimes: ['n=1, d=polylog'] }, [Q]: { params: ['t'], regimes: ['t=1'] } } });
const SAT = 'n=log, m=polylog';
const [KS, KO, KQ] = ['n=E|m=L', 'n=p1|d=L', 't=p1'];

const lbAt = (a: Analysis, p: string, key: string): LBFact | undefined => a.lower.facts.get(p)?.get(key);
const ubAt = (a: Analysis, p: string, key: string): UBFact | null => a.summaries.get(p)?.regimes.find((r) => r.regime.key === key)?.ub ?? null;
const rate = (f: { power: number; exponent: number } | null | undefined): [number, number] | null => (f ? [f.power, f.exponent] : null);
const nearRate = (f: { power: number; exponent: number } | null | undefined, power: number, exponent: number): boolean =>
  f !== null && f !== undefined && f.power === power && near(f.exponent, exponent, 1e-7);

describe('lower bounds 2^{c·n^a}', () => {
  const a = analyze(m, scenario([{ problem: S, kind: 'LB', regime: SAT, exponent: 0.5, power: 0.75 }]));

  it('keep their power through reductions, the coefficient scaled by s^a', () => {
    assert.deepEqual(rate(lbAt(a, S, KS)), [0.75, 0.5]);
    assert.ok(nearRate(lbAt(a, S2, KS), 0.75, 0.5));
    // Q(N^{1/2}) ≥ 2^{0.5 L^{0.75}}, i.e. Q(t) ≥ 2^{0.5 · 2^{0.75} (log t)^{0.75}}
    assert.ok(nearRate(lbAt(a, Q, KQ), 0.75, 0.5 * 2 ** 0.75), JSON.stringify(rate(lbAt(a, Q, KQ))));
  });

  it('do not pass through a reduction that takes longer than the bound', () => {
    assert.equal(lbAt(a, O, KO), undefined);
    const opts = { settings: a.scenario.settings, constants: constantEnv(m, {}), usable: (r: (typeof m.rows)[number]) => rowUsable(r, a.scenario) };
    const v = explainLower(m, a.lower, O, a.summaries.get(O)!.primary!.regime, opts)[0]!.verdict;
    assert.ok(v.kind === 'fails' && /takes time 2\^\(0\.5n\), not less than the lower bound 2\^\(0\.5n\^0\.75\)/.test(v.reason), JSON.stringify(v));
  });

  it('of power 1 are better than those of a smaller power, whatever their coefficients', () => {
    const b = analyze(
      m,
      scenario([
        { problem: S, kind: 'LB', regime: SAT, exponent: 5, power: 0.75 },
        { problem: S, kind: 'LB', regime: SAT, exponent: 0.6 },
      ]),
    );
    assert.deepEqual(rate(lbAt(b, S, KS)), [1, 0.6]);
    assert.ok(nearRate(lbAt(b, S2, KS), 1, 0.6));
    // (and only that one passes through S → O, whose own time 2^{n/2} is below 2^{0.6 n})
    assert.ok(nearRate(lbAt(b, O, KO), 1, 1.2));
  });

  it('can be given as formulas', () => {
    const b = analyze(m, scenario([{ problem: S, kind: 'LB', regime: SAT, formula: '2^{n^{0.99}}' }]));
    assert.ok(nearRate(lbAt(b, S2, KS), 0.99, 1));
  });

  it('grow without limit around a cycle that shrinks the instance', () => {
    // A(n) ≤ B(n/2) and B(n) ≤ A(n): a bound 2^{c n^a} of A gives 2^{2^a c n^a} back to A, lap after lap.
    const [A, B] = ['X / A', 'X / B'];
    const cyc: RowSpec[] = [
      { id: 'ab', from: A, to: B, toTime: '$T(n, m)$', fromTime: '$O(T(n/2, m))$', rt: '$O(1)$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n, m)$', fromTime: '$O(T(n, m))$', rt: '$O(1)$' },
    ];
    const mc = model(cyc, { problems: { [A]: expTime, [B]: expTime } });
    const b = analyze(mc, scenario([{ problem: A, kind: 'LB', regime: SAT, exponent: 0.5, power: 0.75 }]));
    const f = lbAt(b, A, KS)!;
    assert.equal(f.exponent, Infinity);
    assert.equal(f.power, 0.75);
    assert.ok(b.lower.cycles.includes(f));
  });
});

describe('upper bounds 2^{c·n^a}', () => {
  it('pass back through reductions; the smaller power wins', () => {
    const a = analyze(
      m,
      scenario([
        { problem: S2, kind: 'UB', formula: '2^{0.4 n^{0.75}}' },
        { problem: O, kind: 'UB', formula: 'n^2 d' },
      ]),
    );
    // through S2: 2^{0.4 n^{0.75}}; through O: 2^{n} (better coefficient, larger power)
    assert.deepEqual(rate(ubAt(a, S, KS)), [0.75, 0.4]);
    const u = ubAt(a, S, KS)!;
    assert.ok(u.origin.kind === 'row' && u.origin.rowId === 'ss2');
  });

  it('come from sub- and quasi-polynomial bounds of polynomial-scale problems', () => {
    // Q(t) in 2^{√(log t)}: S in 2^{√(n/2)} = 2^{0.7071 n^{0.5}}
    const a = analyze(m, scenario([{ problem: Q, kind: 'UB', formula: '2^{\\sqrt{\\log t}}' }]));
    assert.ok(nearRate(ubAt(a, S, KS), 0.5, Math.SQRT1_2), JSON.stringify(rate(ubAt(a, S, KS))));
    // Q(t) in t^{log t} = 2^{log² t}: S in 2^{(n/2)²}
    const b = analyze(m, scenario([{ problem: Q, kind: 'UB', formula: 't^{\\log t}' }]));
    assert.ok(nearRate(ubAt(b, S, KS), 2, 0.25), JSON.stringify(rate(ubAt(b, S, KS))));
    assert.deepEqual(rate(ubAt(b, Q, KQ)), [2, 1]);
  });

  it('pass through a reduction whose own time is larger only at that time', () => {
    // O in polylog time: S still pays 2^{n/2} for the reduction itself
    const a = analyze(m, scenario([{ problem: O, kind: 'UB', formula: '\\log n' }]));
    assert.deepEqual(rate(ubAt(a, O, KO)), [0, 0]);
    assert.deepEqual(rate(ubAt(a, S, KS)), [1, 0.5]);
  });

  it('take exponent knobs with a power, and say which reductions cannot beat them', () => {
    const a = analyze(m, scenario([{ problem: S, kind: 'UB', regime: SAT, exponent: 0.1, power: 0.5 }]));
    assert.deepEqual(rate(ubAt(a, S, KS)), [0.5, 0.1]);
    const so = a.upperOverlay.explain(S, a.summaries.get(S)!.primary!.regime).find((x) => x.row.id === 'so')!.verdict;
    assert.ok(so.kind === 'skipped' && so.optimistic.power === 1 && near(so.optimistic.exponent, 0.5), JSON.stringify(so));
  });
});

describe('statuses across powers', () => {
  const at = (power: number, exponent: number): never => ({ power, exponent }) as never;

  it('compare powers first', () => {
    assert.equal(statusOf(at(1, 0.01), at(0.99, 100)), 'conflict', 'every 2^{c n^{0.99}} is below 2^{0.01 n}');
    assert.equal(statusOf(at(0.75, 0.5), at(1, 0)), 'gap', '2^{o(n)} is not below 2^{0.5 n^{0.75}}');
    assert.equal(statusOf(at(0.75, 0.5), at(0.75, 0.5)), 'tight');
    assert.equal(statusOf(at(0.75, 0.5), at(0.75, 0.4)), 'conflict');
    assert.equal(statusOf(at(0.75, 0.5), at(0.75, 0.6)), 'gap');
    assert.equal(statusOf(at(1, 2), at(0, 0)), 'conflict', 'polylogarithmic time');
  });

  it('show on the problems of a scenario', () => {
    const a = analyze(
      m,
      scenario([
        { problem: S, kind: 'LB', regime: SAT, exponent: 0.5, power: 0.75 },
        { problem: S2, kind: 'UB', formula: '2^{0.4 n^{0.75}} \\cdot m' },
      ]),
    );
    assert.equal(a.summaries.get(S)!.status, 'conflict');
    assert.equal(a.summaries.get(S2)!.status, 'conflict');
  });
});

describe('knob powers', () => {
  it('must be positive, and go with an exponent', () => {
    const errors: string[] = [];
    assert.equal(validateKnobSpec({ problem: S, kind: 'LB', regime: SAT, exponent: 1, power: 0 }, 'k', errors), null);
    assert.equal(validateKnobSpec({ problem: S, kind: 'UB', formula: '2^n', power: 0.5 }, 'k', errors), null);
    assert.equal(errors.length, 2);
    assert.deepEqual(validateKnobSpec({ problem: S, kind: 'LB', regime: SAT, exponent: 1, power: 0.5 }, 'k', []), { problem: S, kind: 'LB', regime: SAT, exponent: 1, power: 0.5 });
  });
});

describe('review regressions (rates)', () => {
  it('treats powers computed in different ways as one power', () => {
    // B's knob at power 0.3, A's From-time pays 2^{(n^{0.1})^3} = 2^{n^{0.30000000000000004}} on top of B
    const [A, B] = ['Y / A', 'Y / B'];
    const my = model([{ id: 'ab', from: A, to: B, toTime: '$T(n, m)$', fromTime: '$O(T(n, m) \\cdot 2^{(n^{0.1})^{3}})$', rt: '$O(m)$' }], {
      problems: { [A]: expTime, [B]: expTime },
    });
    const up = analyze(my, scenario([{ problem: B, kind: 'UB', regime: SAT, exponent: 5, power: 0.3 }]));
    assert.ok(nearRate(ubAt(up, A, KS), 0.3, 6), JSON.stringify(rate(ubAt(up, A, KS))));
    const low = analyze(my, scenario([{ problem: A, kind: 'LB', regime: SAT, exponent: 2, power: 0.3 }]));
    assert.ok(nearRate(lbAt(low, B, KS), 0.3, 1), JSON.stringify(rate(lbAt(low, B, KS))));
    assert.deepEqual(low.lower.inconsistencies, []);
  });

  it('gives a log-dependent parameter one class per key, whatever the order of the rows', () => {
    // P1 and P2 call Q(n, M) with M = 2√log n and 3√log n (key M=L for both); Q pays 2^M on top of R.
    const [P1, P2, Q2, R2] = ['A / P1', 'A / P2', 'A / Q', 'A / R'];
    const r1: RowSpec = { id: 'p1', from: P1, to: Q2, toTime: '$T(n, M)$', fromTime: '$O(T(n, 2\\sqrt{\\log n}))$', rt: '$O(1)$' };
    const r2: RowSpec = { id: 'p2', from: P2, to: Q2, toTime: '$T(n, M)$', fromTime: '$O(T(n, 3\\sqrt{\\log n}))$', rt: '$O(1)$' };
    const qr: RowSpec = { id: 'qr', from: Q2, to: R2, toTime: '$T(n)$', fromTime: '$O(T(n) \\cdot 2^{M})$', rt: '$O(1)$' };
    const c = { problems: { [P1]: { params: ['n'], regimes: ['n=1'] }, [P2]: { params: ['n'], regimes: ['n=1'] }, [R2]: { regimes: ['n=1'] } } };
    const results = [
      [r1, r2, qr],
      [r2, r1, qr],
    ].map((rs) => {
      const a = analyze(model(rs, c), scenario([{ problem: R2, kind: 'UB', regime: 'n=1', formula: '2^{\\sqrt{\\log n}}' }]));
      return [P1, P2].map((p) => rate(ubAt(a, p, 'n=p1')));
    });
    assert.deepEqual(results[0], results[1]);
    // M is (log N)^{O(1)} in Q's regime: 2^M has no useful bound, so neither do P1 and P2 (none is too small)
    assert.deepEqual(results[0], [null, null]);
  });

  it('writes formulas for exponent knobs that evaluate to their rate again', () => {
    const poly = Regime.fromGrowthMap(['n'], new Map([['n', G.poly(1)]]), new Set());
    const exp = Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.logClass(1, 1)], ['m', G.POLYLOG]]), new Set());
    const cases: Array<[Regime, number, number]> = [
      [poly, 1, 2.5],
      [poly, 1, 1.99999949],
      [poly, 1, 0],
      [poly, 2, 1],
      [poly, 0.75, 0.5],
      [poly, 0.75, 0],
      [exp, 1, 1],
      [exp, 1, 0.5],
      [exp, 1, 0],
      [exp, 0.75, 0.5],
      [exp, 0.75, 0],
      [exp, 0.9999996, 1],
      [exp, 1.0000004, 3],
      [exp, 0.3, 0.0000005],
    ];
    for (const [regime, power, exponent] of cases) {
      const formula = regime.timeFormula({ power, exponent })!;
      const back = formulaRate(parseExpr(formula), regime, new Map());
      assert.ok(G.compareRates(back, { power, exponent }, 1e-12) === 0, `${formula}: ${JSON.stringify(back)} for ${JSON.stringify({ power, exponent })}`);
    }
    assert.equal(exp.timeFormula({ power: 0.75, exponent: 0.5 }), '2^{0.5 n^{0.75}}');
    assert.equal(poly.timeFormula({ power: 0.75, exponent: 0 }), '2^{o(\\log^{0.75} n)}');
    assert.equal(exp.timeFormula(G.RATE_ZERO), null);
  });
});
