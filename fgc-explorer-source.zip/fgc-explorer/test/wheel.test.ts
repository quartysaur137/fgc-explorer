import assert from 'node:assert/strict';
import { wheelNotches } from '../src/ui/graph';

const ev = (deltaY: number, more: { deltaMode?: number; deltaX?: number; ctrlKey?: boolean } = {}) => ({ deltaMode: 0, deltaX: 0, ctrlKey: false, deltaY, ...more });

describe('wheelNotches (only mouse-wheel notches zoom faster than Cytoscape)', () => {
  it('counts the notches of a mouse wheel: whole steps of 100 pixels, or lines', () => {
    assert.equal(wheelNotches(ev(100)), 1);
    assert.equal(wheelNotches(ev(-100)), -1);
    assert.equal(wheelNotches(ev(200)), 2);
    assert.equal(wheelNotches(ev(120)), 1);
    assert.equal(wheelNotches(ev(3, { deltaMode: 1 })), 1);
    assert.equal(wheelNotches(ev(-6, { deltaMode: 1 })), -2);
  });

  it('leaves trackpad scrolling and pinching to Cytoscape', () => {
    for (const e of [ev(4), ev(-12), ev(37.5), ev(100.25), ev(100, { deltaX: 3 }), ev(100, { ctrlKey: true }), ev(1, { deltaMode: 2 }), ev(0)]) {
      assert.equal(wheelNotches(e), 0, JSON.stringify(e));
    }
  });
});
