import assert from 'node:assert/strict';
import { initialScenario, numberedIds, validateConfig, validateScenario } from '../src/model/config';
import { buildModel, findProblem } from '../src/model/model';
import { CsvTable } from '../src/util/csv';
import { model, RowSpec, sheet } from './helpers';

/*
 * Testing strategy for config validation and model construction
 *
 * validateConfig: valid config; wrong types dropped with errors (constants, problems, rows, free params of each type,
 *   initial knob groups, knobs); the old section name "presets"; never throws on non-objects
 * initialScenario: groups on / off, notes (group label or own), ids (numbered; the config's kept, repeated or invalid
 *   ones replaced), valid scenario; no groups
 * numberedIds: after the largest number, skipping ids in use; nothing taken
 * validateScenario: ids kept (text, number) or numbered (missing, repeated), exactly one of exponent/formula, LB needs
 *   a regime, settings defaults and range errors, box order (kept; blanks and repeats dropped; not an array; missing)
 * buildModel, problems: case-insensitive variations, whitespace in names, aliases, signature from To-time (majority,
 *   disagreement diagnostic), from config (source-only), inferred; static vs dynamic; log parameters; default regimes
 * buildModel, rows, partition on status: ok, skipped, no-formula, parse-error, dynamic, no-signature, arity,
 *   non-monotone, unknown-symbols; overrides; legend abbreviations (transitive, only when needed, config wins);
 *   RT unknown (no formula / undeclared symbols); requires; randomized; duplicate ids; missing columns
 */

describe('validateConfig', () => {
  it('accepts a valid config', () => {
    const v = validateConfig({
      version: 1,
      constants: { omega: { value: 2.37, min: 2, max: 3, label: 'ω' } },
      aliases: { Typo: 'Fixed' },
      problems: { 'A / B': { params: ['n'], logParams: [], timeType: 'exp', regimes: ['n=log'] } },
      rows: {
        '1': {
          free: [
            { name: 'k', type: 'int', values: [2, 3] },
            { name: 'delta', type: 'real', min: 0, max: '1/2' },
            { name: 't', type: 'size', base: 'n', min: 0, max: 1 },
            { name: 'c', type: 'fixed', value: null },
          ],
          defs: { N: '2^{n/2}' },
          from: 'O(T(n))',
          requires: 'm=2',
        },
      },
      initialKnobs: [
        { label: 'P', description: 'a $p$ hypothesis', knobs: [{ problem: 'A / B', kind: 'LB', regime: 'n=log', exponent: 1 }] },
        { label: 'Q', enabled: false, knobs: [{ problem: 'A / B', kind: 'UB', formula: '2^n', note: 'own note' }] },
      ],
    });
    assert.deepEqual(v.errors, []);
    assert.equal(v.value.rows['1']!.free!.length, 4);
    assert.deepEqual(
      v.value.initialKnobs.map((g) => [g.label, g.description, g.enabled, g.knobs.length]),
      [
        ['P', 'a $p$ hypothesis', true, 1],
        ['Q', undefined, false, 1],
      ],
    );
  });

  it('drops invalid entries and explains why', () => {
    const v = validateConfig({
      version: 2,
      constants: { omega: { value: 'x' } },
      problems: { 'A / B': { timeType: 'fast', params: 'n' } },
      rows: { '1': { free: [{ name: 'k', type: 'int', values: [] }, { name: 'x', type: 'weird' }] }, '2': 5 },
      initialKnobs: [{ label: 'P', enabled: 'no', knobs: [{ problem: 'A / B', kind: 'LB', exponent: 1 }] }, { knobs: [] }],
    });
    assert.ok(v.errors.length >= 10, v.errors.join('\n'));
    assert.equal(v.value.rows['1']!.free!.length, 0);
    assert.equal(v.value.rows['2'], undefined);
    assert.equal(v.value.initialKnobs.length, 1, 'a group without a label is dropped');
    assert.equal(v.value.initialKnobs[0]!.knobs.length, 0, 'LB knob without regime is dropped');
    assert.equal(validateConfig(null).errors.length, 1);
  });

  it('reads the old name "presets" as initialKnobs, with a note', () => {
    const v = validateConfig({
      version: 1,
      presets: [{ id: 'p', label: 'P', knobs: [{ problem: 'A / B', kind: 'UB', formula: 'n' }] }],
    });
    assert.equal(v.errors.length, 1);
    assert.match(v.errors[0]!, /renamed/);
    assert.deepEqual(
      v.value.initialKnobs.map((g) => [g.label, g.enabled, g.knobs.length]),
      [['P', true, 1]],
    );
  });
});

describe('initialScenario', () => {
  it('has every knob of every group, switched on or off as the group says', () => {
    const config = validateConfig({
      version: 1,
      initialKnobs: [
        { label: 'P', knobs: [{ problem: 'A / B', kind: 'LB', regime: 'n=1', exponent: 2 }, { problem: 'A / C', kind: 'UB', formula: 'n' }] },
        { label: 'Q', enabled: false, knobs: [{ problem: 'A / B', kind: 'UB', formula: 'n^3', note: 'own note' }] },
      ],
    }).value;
    const s = initialScenario(config);
    assert.deepEqual(
      s.knobs.map((k) => [k.problem, k.kind, k.enabled, k.note]),
      [
        ['A / B', 'LB', true, 'P'],
        ['A / C', 'UB', true, 'P'],
        ['A / B', 'UB', false, 'own note'],
      ],
    );
    assert.deepEqual(
      s.knobs.map((k) => k.id),
      ['1', '2', '3'],
      'numbered like Reduction IDs',
    );
    assert.deepEqual(s.constants, {});
    // Round trip: the scenario validator accepts it unchanged.
    assert.deepEqual(validateScenario(JSON.parse(JSON.stringify(s))), { value: s, errors: [] });
  });

  it('is empty when the config has no initial knobs', () => {
    assert.deepEqual(initialScenario(validateConfig({ version: 1 }).value).knobs, []);
  });

  it("keeps the config's Bound IDs and numbers the knobs without one after them", () => {
    const v = validateConfig({
      version: 1,
      initialKnobs: [
        {
          label: 'P',
          knobs: [
            { id: 7, problem: 'A / B', kind: 'UB', formula: 'n' },
            { problem: 'A / B', kind: 'UB', formula: 'n^2' },
            { id: '7', problem: 'A / C', kind: 'UB', formula: 'n' },
            { id: 'x9', problem: 'A / C', kind: 'UB', formula: 'n^3' },
            { id: [], problem: 'A / D', kind: 'UB', formula: 'n' },
          ],
        },
      ],
    });
    assert.equal(v.errors.length, 2, v.errors.join('\n'));
    assert.deepEqual(
      initialScenario(v.value).knobs.map((k) => k.id),
      ['7', '8', '9', 'x9', '10'],
    );
  });
});

describe('numberedIds', () => {
  it('counts up from the largest number taken, skipping ids in use', () => {
    const next = numberedIds(['3', 'x', '10', '12a']);
    assert.deepEqual([next(), next()], ['11', '12']);
    const fresh = numberedIds([]);
    assert.equal(fresh(), '1');
  });
});

describe('validateScenario', () => {
  it('numbers knobs without an id or with a repeated one and applies setting defaults', () => {
    const v = validateScenario({
      version: 1,
      knobs: [
        { problem: 'A / B', kind: 'UB', formula: 'n^2' },
        { id: 'x', problem: 'A / B', kind: 'UB', formula: 'n' },
        { id: 'x', problem: 'A / B', kind: 'UB', formula: 'n', enabled: false },
        { id: 4, problem: 'A / B', kind: 'UB', formula: 'n^3' },
      ],
      settings: { maxHopsLB: 3 },
    });
    assert.equal(v.errors.length, 1, v.errors.join('\n'));
    assert.match(v.errors[0]!, /knobs\[2\]\.id: x is used by an earlier knob/);
    assert.deepEqual(
      v.value.knobs.map((k) => [k.id, k.enabled]),
      [
        ['5', true],
        ['x', true],
        ['6', false],
        ['4', true],
      ],
    );
    assert.equal(v.value.settings.maxHopsLB, 3);
    assert.equal(v.value.settings.gridPoints, 9);
  });

  it('reads the box order (problems), dropping blanks and repeats', () => {
    const v = validateScenario({ version: 1, problems: ['A / B', ' ', 'A / B', ' C / D '] });
    assert.deepEqual(v.errors, []);
    assert.deepEqual(v.value.problems, ['A / B', 'C / D']);
    const bad = validateScenario({ version: 1, problems: 'A / B' });
    assert.equal(bad.errors.length, 1);
    assert.deepEqual(bad.value.problems, []);
    assert.deepEqual(validateScenario({ version: 1 }).value.problems, []);
  });

  it('rejects knobs with both or neither of exponent/formula and bad settings', () => {
    const v = validateScenario({
      version: 1,
      knobs: [
        { problem: 'A / B', kind: 'UB', formula: 'n', exponent: 1 },
        { problem: 'A / B', kind: 'UB' },
        { problem: 'A / B', kind: 'XB', exponent: 1 },
      ],
      settings: { maxHopsLB: -1, unknownRT: 'maybe' },
    });
    assert.equal(v.value.knobs.length, 0);
    assert.ok(v.errors.length >= 5, v.errors.join('\n'));
    assert.equal(v.value.settings.maxHopsLB, 8);
  });
});

const ROWS: RowSpec[] = [
  { id: '1', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(2n))$' },
  { id: '2', from: 'Fam / b', to: 'Other  Fam / C', toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
  { id: '3', from: 'Fam / A', to: 'Fam / D', toTime: '$T_p(n), T_q(n)$', fromTime: '$O(T_p(n) + n T_q(n))$' },
  { id: '4', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '??' },
  { id: '5', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(n)$' },
  { id: '6', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(n, n))$' },
  { id: '7', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(n^3 / T(n))$' },
  { id: '8', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(X \\cdot T(n/X))$' },
  { id: '9', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(N))$ with $N = O(n^{1/k})$', rt: '$O(n \\cdot Y)$' },
  { id: '10', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(n))$', randomized: 'Yes' },
  { id: '10', from: 'Fam / A', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: '11', from: 'Typo / E', to: 'Fam / B', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
];

const CONFIG = {
  aliases: { Typo: 'Fam' },
  problems: { 'fam / a': { params: ['n'] } },
  rows: {
    '8': { free: [{ name: 'X', type: 'size', min: 0, max: 1 }] },
    '9': { free: [{ name: 'k', type: 'int', values: [2] }] },
    '1': { skip: 'testing' },
  },
};

describe('buildModel: problems', () => {
  const m = model(ROWS, CONFIG);

  it('merges variations case-insensitively, squashes whitespace and applies aliases', () => {
    assert.ok(m.problems.has('Fam / B'));
    assert.ok(!m.problems.has('Fam / b'));
    assert.ok(m.problems.has('Other Fam / C'));
    assert.ok(m.problems.has('Fam / E'), 'alias Typo → Fam');
    assert.equal(findProblem(m, ' other fam /  c ')?.id, 'Other Fam / C');
  });

  it('reads signatures from To-time cells, the config, or the formulas', () => {
    assert.deepEqual(m.problems.get('Fam / B')!.params, ['n']);
    assert.equal(m.problems.get('Fam / B')!.signatureSource, 'to-time');
    assert.equal(m.problems.get('Fam / A')!.signatureSource, 'config');
    assert.equal(m.problems.get('Fam / E')!.signatureSource, 'inferred');
    assert.deepEqual(m.problems.get('Fam / E')!.params, ['n']);
    assert.equal(m.problems.get('Fam / D')!.isStatic, false);
    assert.deepEqual(m.problems.get('Other Fam / C')!.regimeSpecs, ['n=1, m=1']);
  });

  it('reports disagreeing signatures', () => {
    const m2 = model([
      { id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
      { id: '2', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
      { id: '3', from: 'F / A', to: 'F / B', toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$' },
    ]);
    assert.deepEqual(m2.problems.get('F / B')!.params, ['n']);
    assert.ok(m2.diagnostics.some((d) => /disagree/.test(d.message)));
    assert.equal(m2.rowsById.get('3')!.status, 'arity');
  });
});

describe('buildModel: rows', () => {
  const m = model(ROWS, CONFIG);
  const status = (id: string): string => m.rowsById.get(id)!.status;

  it('assigns each status', () => {
    assert.equal(status('1'), 'skipped');
    assert.equal(status('2'), 'ok');
    assert.equal(status('3'), 'dynamic');
    assert.equal(status('4'), 'no-formula');
    assert.equal(status('5'), 'parse-error');
    assert.equal(status('6'), 'arity');
    assert.equal(status('7'), 'non-monotone');
    assert.equal(status('8'), 'ok');
    assert.equal(status('9'), 'ok');
  });

  it('flags undeclared symbols and unknown RTs', () => {
    const m2 = model([{ id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(n/X))$', rt: '$O(Y)$' }], {
      problems: { 'F / A': { params: ['n'] } },
    });
    const r = m2.rowsById.get('1')!;
    assert.equal(r.status, 'unknown-symbols');
    assert.ok(r.messages.some((x) => /X/.test(x)));
    assert.equal(r.rt, null);
  });

  it('uses legend abbreviations only when needed and lets the config win', () => {
    const r = m.rowsById.get('9')!;
    assert.deepEqual(
      r.defs.map((d) => [d.name, d.origin]),
      [['N', 'legend']],
    );
    assert.equal(r.rt, null, 'RT uses an undeclared symbol');
    const m2 = model([{ id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(N))$ with $N = n^2$ and $Z = 5$' }], {
      problems: { 'F / A': { params: ['n'] } },
      rows: { '1': { defs: { N: 'n^3' } } },
    });
    assert.deepEqual(
      m2.rowsById.get('1')!.defs.map((d) => [d.name, d.origin, d.tex]),
      [['N', 'config', 'n^3']],
    );
  });

  it('counts an unknown randomized flag as randomized and lets free parameters win over config definitions', () => {
    const m2 = model([{ id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(n/X))$', randomized: '?' }], {
      problems: { 'F / A': { params: ['n'] } },
      rows: { '1': { free: [{ name: 'X', type: 'size', min: 0, max: 1 }], defs: { X: 'n' } } },
    });
    const r = m2.rowsById.get('1')!;
    assert.equal(r.randomized, true);
    assert.equal(r.status, 'ok');
    assert.deepEqual(r.defs, []);
    assert.ok(r.messages.some((x) => /ignored/.test(x)));
  });

  it('renames duplicate ids and reads the randomized flag', () => {
    assert.ok(m.rowsById.has('10'));
    assert.ok(m.rowsById.has('10#2'));
    assert.equal(m.rowsById.get('10')!.randomized, true);
    assert.equal(m.rowsById.get('10#2')!.randomized, false);
  });

  it('parses requirements and overrides', () => {
    const m2 = model([{ id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(\\sum_j T(n_j))$' }], {
      problems: { 'F / A': { params: ['n', 'm'] } },
      rows: { '1': { from: 'O(T(n))', requires: 'm=2' } },
    });
    const r = m2.rowsById.get('1')!;
    assert.equal(r.status, 'ok');
    assert.ok(r.fromOverridden);
    assert.equal(r.requires?.get('m')?.kind, 'poly');
  });

  it('ignores annotations written for other problems', () => {
    const m2 = model([{ id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(n/X))$' }], {
      problems: { 'F / A': { params: ['n'] } },
      rows: { '1': { match: { from: 'F / Z', to: 'F / B' }, free: [{ name: 'X', type: 'size', min: 0, max: 1 }] } },
    });
    assert.equal(m2.rowsById.get('1')!.status, 'unknown-symbols');
    assert.ok(m2.diagnostics.some((d) => /annotation ignored/.test(d.message)));
    const m3 = model([{ id: '1', from: 'F / A', to: 'F / B', toTime: '$T(n)$', fromTime: '$O(T(n/X))$' }], {
      problems: { 'F / A': { params: ['n'] } },
      rows: { '1': { match: { from: 'f / a', to: 'F /  B' }, free: [{ name: 'X', type: 'size', min: 0, max: 1 }] } },
    });
    assert.equal(m3.rowsById.get('1')!.status, 'ok');
  });

  it('reports missing columns', () => {
    const v = validateConfig({ version: 1 });
    const m2 = buildModel(new CsvTable(['From (Problem)'], [['x']]), v.value);
    assert.ok(m2.diagnostics.some((d) => d.level === 'error' && /Reduction ID/.test(d.message)));
    assert.equal(sheet([]).rowCount, 0);
  });
});
