import assert from 'node:assert/strict';
import * as G from '../src/growth/growth';
import { EvalError } from '../src/growth/growth';
import { formatParamSpec, formatRegimeSpec, parseParamSpec, parseRegimeSpec, Regime, regimeNumberText, SpecError, upgradeRoundedSpec } from '../src/model/regime';
import { near } from './helpers';

/*
 * Testing strategy for regimes
 *
 * parseParamSpec: number, fraction, log, log:c, polylog (also sub), subpoly, const, const:v, const:?, const:[list], poly,
 *   poly:μ;
 *   errors: nonpositive, unknown word, bad list
 * parseRegimeSpec: several entries, commas inside lists, duplicates, missing "=", empty name
 * formatParamSpec / formatRegimeSpec: round trip, exactly (1/3 written 1/3, other values with every digit)
 * regimeNumberText: short decimals, the simplest fraction that rounds up to a stored value, else 6 decimals (each reads
 *   back as the same regime); upgradeRoundedSpec: 6-decimal numbers of earlier versions near simple fractions (in
 *   exponents, constants and lists), others unchanged
 * Regime.normalize, partition on normalizer: first non-log-dependent polynomial parameter (with exponent ≠ 1, after a
 *   log-dependent or constant one), exponential scale (log parameter with coefficient), degenerate;
 *   clamping of negative exponents and sub-1 constants; errors for unknown/superpolynomial sizes (also 2^{c·L^a},
 *   a > 1); sub-polynomial sizes 2^{c·L^a}, a < 1 (N^{o(1)}, key S; polylog for log-dependent parameters); coefficients
 *   of log classes other than c·L dropped
 * key: polynomial exponents, E, L, constants (known/unknown), log-dependent classes C/L/P; growths that round to one key
 *   are equal (so a key stands for one regime whatever the order of the search); rounding is upward (1/3 → 0.333334,
 *   4e-7 → 0.000001) after ignoring floating-point noise (0.1·3 → 0.3, 1e-10 → N^{o(1)})
 * contains: per-parameter order (valued constant < unspecified constant < polylog < N^{o(1)} < N^x by x; C < L < P
 *   for log-dependent ones); two values of a constant not compared; every parameter at most; other normalizer,
 *   exponential scale or parameters not compared
 * satisfies: each spec kind, tolerance (also for exponents rounded up), unknown parameter; log/polylog/subpoly are
 *   upper bounds (constants satisfy them, polynomial log-dependent parameters do not)
 * describeTex / timeTex: smoke tests
 */

describe('parseParamSpec', () => {
  it('parses each growth form', () => {
    assert.deepEqual(parseParamSpec('2'), { kind: 'poly', exp: 2 });
    assert.deepEqual(parseParamSpec(' 4/3 '), { kind: 'poly', exp: 4 / 3 });
    assert.deepEqual(parseParamSpec('log'), { kind: 'log', coef: 1 });
    assert.deepEqual(parseParamSpec('log:0.5'), { kind: 'log', coef: 0.5 });
    assert.deepEqual(parseParamSpec('polylog'), { kind: 'polylog' });
    assert.deepEqual(parseParamSpec('subpoly'), { kind: 'subpoly' });
    assert.deepEqual(parseParamSpec('sub'), { kind: 'polylog' }, 'an old name');
    assert.deepEqual(parseParamSpec('const'), { kind: 'const', values: [null] });
    assert.deepEqual(parseParamSpec('const:3'), { kind: 'const', values: [3] });
    assert.deepEqual(parseParamSpec('const:[3, 4,?]'), { kind: 'const', values: [3, 4, null] });
    assert.deepEqual(parseParamSpec('poly'), { kind: 'logdep' });
  });

  it('rejects malformed specs', () => {
    for (const s of ['0', '-1', 'big', 'log:-1', 'const:[1,2', 'const:[]', 'polylog:2', 'subpoly:1', '1/0', 'poly:2']) {
      assert.throws(() => parseParamSpec(s), SpecError, s);
    }
  });
});

describe('parseRegimeSpec / format', () => {
  it('parses several entries and round-trips', () => {
    const m = parseRegimeSpec('n=1, m=2, M=poly, k=const:[3,4]');
    assert.deepEqual([...m.keys()], ['n', 'm', 'M', 'k']);
    assert.equal(formatRegimeSpec(m), 'n=1, m=2, M=poly, k=const:[3,4]');
    assert.equal(formatParamSpec(parseParamSpec('log:2')), 'log:2');
    assert.equal(parseRegimeSpec('').size, 0);
  });

  it('writes specs that read back exactly, and regimes as specs that name them again', () => {
    assert.equal(formatRegimeSpec(parseRegimeSpec('m=1/3, k=const:[2/3,0.25]')), 'm=1/3, k=const:[2/3,0.25]');
    assert.equal(formatParamSpec({ kind: 'poly', exp: Math.SQRT2 }), String(Math.SQRT2));
    const at = (m: number): Regime => Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.poly(1)], ['m', G.poly(m)]]), new Set());
    const stored = (r: Regime): number => (r.growthOf('m') as { exp: number }).exp;
    const read = (text: string): number => (parseParamSpec(text) as { exp: number }).exp;
    for (const m of [15 / 7, 1 / 3, 0.5, 2, Math.SQRT2, 6 / 13, 0.4615384]) {
      const text = regimeNumberText(stored(at(m)));
      assert.equal(at(read(text)).key, at(m).key, `${m}: ${text}`);
    }
    assert.equal(regimeNumberText(2.142858), '15/7');
    assert.equal(regimeNumberText(0.5), '0.5');
    assert.equal(regimeNumberText(1.414214), '1.414214');
  });

  it('turns the rounded exponents of earlier versions into the fractions they were', () => {
    assert.equal(upgradeRoundedSpec('U=1, N=2.142857, s=const, q=3.785714'), 'U=1, N=15/7, s=const, q=53/14');
    assert.equal(upgradeRoundedSpec('n=1, m=0.333333, k=const:[0.666667,3]'), 'n=1, m=1/3, k=const:[2/3,3]');
    assert.equal(upgradeRoundedSpec('n=1, m=1.414214, M=poly'), 'n=1, m=1.414214, M=poly', 'no simple fraction nearby');
    assert.equal(upgradeRoundedSpec('n=1, m=0.5, d=polylog'), 'n=1, m=0.5, d=polylog', 'short decimals stay');
  });

  it('rejects duplicates and malformed entries', () => {
    assert.throws(() => parseRegimeSpec('n=1, n=2'), SpecError);
    assert.throws(() => parseRegimeSpec('n'), SpecError);
    assert.throws(() => parseRegimeSpec('=1'), SpecError);
  });
});

describe('Regime.normalize', () => {
  const none = new Set<string>();

  it('normalizes by the first growing non-log-dependent parameter', () => {
    const r = Regime.normalize(['M', 'n', 'm'], [G.poly(4), G.poly(0.5), G.poly(1)], new Set(['M']));
    assert.equal(r.kind, 'ok');
    if (r.kind !== 'ok') return;
    assert.equal(r.scale, 0.5);
    assert.equal(r.regime.normalizerName, 'n');
    assert.equal(r.regime.key, 'M=P|n=p1|m=p2');
    // polynomial log-dependent parameters are evaluated at a fixed representative exponent
    assert.deepEqual(r.regime.growthOf('M'), G.poly(3));
  });

  it('skips constant and polylogarithmic parameters when choosing the normalizer', () => {
    const r = Regime.normalize(['k', 'd', 'n'], [G.constant(3), G.logClass(2), G.poly(2)], none);
    assert.ok(r.kind === 'ok' && r.regime.key === 'k=c3|d=L|n=p1' && r.scale === 2);
  });

  it('uses an exponential scale when no parameter is polynomial', () => {
    const r = Regime.normalize(['n', 'm'], [G.logClass(1, 2), G.logClass(Infinity)], none);
    assert.equal(r.kind, 'ok');
    if (r.kind !== 'ok') return;
    assert.equal(r.scale, 2);
    assert.ok(r.regime.expScale);
    assert.equal(r.regime.key, 'n=E|m=L');
    assert.deepEqual(r.regime.growthOf('n'), G.logClass(1, 1));
  });

  it('reports degenerate instances', () => {
    assert.equal(Regime.normalize(['n', 'd'], [G.constant(5), G.logClass(1, null)], none).kind, 'degenerate');
    assert.equal(Regime.normalize(['n'], [G.poly(-1)], none).kind, 'degenerate');
  });

  it('clamps sizes below 1 and keeps unknown constants', () => {
    const r = Regime.normalize(['n', 'k', 'c'], [G.poly(1), G.poly(-0.5), G.constant(0.5)], none);
    assert.ok(r.kind === 'ok' && r.regime.key === 'n=p1|k=c?|c=c?');
  });

  it('rejects unknown or superpolynomial sizes', () => {
    assert.throws(() => Regime.normalize(['n', 'm'], [G.poly(1), G.POLY_UNKNOWN], none), EvalError);
    assert.throws(() => Regime.normalize(['n'], [G.SUPER], none), EvalError);
    assert.throws(() => Regime.normalize(['n', 'M'], [G.poly(1), G.SUPER], new Set(['M'])), EvalError);
    const ok = Regime.normalize(['n', 'M'], [G.poly(1), G.POLY_UNKNOWN], new Set(['M']));
    assert.ok(ok.kind === 'ok' && ok.regime.key === 'n=p1|M=P');
    assert.throws(() => Regime.normalize(['n', 'm'], [G.poly(1), G.qpoly(2, 1)], none), EvalError, 'quasi-polynomial');
  });

  it('keeps sub-polynomial sizes apart from polylogarithmic ones', () => {
    const r = Regime.normalize(['n', 'd', 'e', 'M'], [G.poly(1), G.qpoly(0.5, 3), G.logClass(0.5, 2), G.qpoly(0.5, 1)], new Set(['M']));
    assert.ok(r.kind === 'ok');
    if (r.kind !== 'ok') return;
    assert.equal(r.regime.key, 'n=p1|d=S|e=L|M=L');
    assert.deepEqual(r.regime.growthOf('d'), G.SUBPOLY, '2^{3√L} is N^{o(1)}');
    assert.deepEqual(r.regime.growthOf('e'), G.POLYLOG, 'one growth per key: every polylogarithmic size is (log N)^{O(1)}');
    assert.deepEqual(r.regime.growthOf('M'), G.POLYLOG, 'log M is polylogarithmic');
    assert.ok(r.regime.satisfies(parseRegimeSpec('d=subpoly, e=subpoly')), 'polylog is sub-polynomial too');
    assert.ok(!r.regime.satisfies(parseRegimeSpec('d=polylog')));
    assert.ok(r.regime.satisfies(parseRegimeSpec('e=polylog')));
    // floating-point noise around 0 is N^{o(1)} too; a tiny exponent is rounded up (it is polynomial)
    const t = Regime.normalize(['n', 'c'], [G.poly(1), G.poly(1e-10)], none);
    assert.ok(t.kind === 'ok' && t.regime.key === 'n=p1|c=S');
    const u = Regime.normalize(['n', 'c'], [G.poly(1), G.poly(4e-7)], none);
    assert.ok(u.kind === 'ok' && u.regime.key === 'n=p1|c=p0.000001');
    const s = Regime.fromGrowthMap(['n', 'd'], new Map([['n', G.poly(1)], ['d', G.SUBPOLY]]), none);
    assert.equal(s.key, 'n=p1|d=S');
    assert.match(s.describeTex(), /d = n\^\{o\(1\)\}/);
  });

  it('rounds growths up as the key does, so that one key stands for one regime', () => {
    const at = (m: number, k: number) => Regime.normalize(['n', 'm', 'k', 'M'], [G.poly(1), G.poly(m), G.constant(k), G.constant(2)], new Set(['M']));
    const a = at(1.0000021, 3.0000000001);
    const b = at(1.000003, 3);
    assert.ok(a.kind === 'ok' && b.kind === 'ok');
    if (a.kind !== 'ok' || b.kind !== 'ok') return;
    assert.equal(a.regime.key, b.regime.key);
    assert.deepEqual(a.regime.growths, b.regime.growths);
    assert.deepEqual(a.regime.growthOf('M'), G.constant(null), 'a log-dependent constant is one class');
    // Up, so that the regime's sizes are at least the exact ones (bounds derived there stay sound): 1/3 is 0.333334,
    // while floating-point noise is ignored (0.1 * 3 is 0.3).
    const third = Regime.normalize(['n', 'm'], [G.poly(1), G.poly(1 / 3)], new Set());
    assert.ok(third.kind === 'ok' && third.regime.key === 'n=p1|m=p0.333334');
    assert.ok(third.kind === 'ok' && third.regime.satisfies(parseRegimeSpec('m=0.333333')) && third.regime.satisfies(parseRegimeSpec('m=1/3')));
    const tenths = Regime.normalize(['n', 'm'], [G.poly(1), G.poly(0.1 * 3)], new Set());
    assert.ok(tenths.kind === 'ok' && tenths.regime.key === 'n=p1|m=p0.3');
    // (the scale is not rounded: it values the calls)
    const s = Regime.normalize(['n', 'm'], [G.poly(1.0000001), G.poly(2)], new Set());
    assert.ok(s.kind === 'ok' && s.scale === 1.0000001);
  });

  it('encodes log-dependent classes', () => {
    const key = (g: G.Growth): string => {
      const r = Regime.normalize(['n', 'M'], [G.poly(1), g], new Set(['M']));
      return r.kind === 'ok' ? r.regime.key : 'degenerate';
    };
    assert.equal(key(G.constant(1)), 'n=p1|M=C');
    assert.equal(key(G.logClass(2)), 'n=p1|M=L');
    assert.equal(key(G.poly(7)), 'n=p1|M=P');
  });
});

describe('Regime.contains', () => {
  const at = (m: G.Growth, k: G.Growth = G.constant(3), M: G.Growth = G.poly(3)): Regime =>
    Regime.fromGrowthMap(['n', 'm', 'k', 'M'], new Map([['n', G.poly(1)], ['m', m], ['k', k], ['M', M]]), new Set(['M']));

  it('orders each parameter: a constant with a value, an unspecified constant, polylog, N^{o(1)}, N^x by x', () => {
    assert.ok(at(G.poly(2)).contains(at(G.poly(1.5))));
    assert.ok(!at(G.poly(1.5)).contains(at(G.poly(2))));
    assert.ok(at(G.poly(0.5)).contains(at(G.SUBPOLY)));
    assert.ok(at(G.SUBPOLY).contains(at(G.logClass(1))));
    assert.ok(at(G.logClass(1)).contains(at(G.constant(null))));
    assert.ok(at(G.constant(null)).contains(at(G.constant(7))));
    assert.ok(!at(G.constant(7)).contains(at(G.constant(null))));
    assert.ok(at(G.poly(1)).contains(at(G.poly(1))), 'itself');
  });

  it('does not compare two values of a constant (a bound for k = 3 says nothing about k = 4)', () => {
    assert.ok(!at(G.poly(1), G.constant(4)).contains(at(G.poly(1), G.constant(3))));
    assert.ok(!at(G.poly(1), G.constant(3)).contains(at(G.poly(1), G.constant(4))));
    assert.ok(at(G.poly(1), G.constant(null)).contains(at(G.poly(1), G.constant(3))));
  });

  it('orders log-dependent classes C, L, P and needs every parameter to be at most', () => {
    assert.ok(at(G.poly(1), G.constant(3), G.poly(3)).contains(at(G.poly(1), G.constant(3), G.logClass(1))));
    assert.ok(at(G.poly(1), G.constant(3), G.logClass(1)).contains(at(G.poly(1), G.constant(3), G.constant(5))));
    assert.ok(!at(G.poly(1), G.constant(3), G.logClass(1)).contains(at(G.poly(1), G.constant(3), G.poly(3))));
    assert.ok(!at(G.poly(2), G.constant(3), G.logClass(1)).contains(at(G.poly(1), G.constant(3), G.poly(3))), 'M is larger');
    assert.ok(!at(G.poly(2)).contains(at(G.poly(1), G.constant(null))), 'k is larger');
  });

  it('compares only regimes measured by the same parameter on the same scale', () => {
    const none = new Set<string>();
    const byN = Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.poly(1)], ['m', G.poly(1)]]), none);
    const byM = Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.constant(5)], ['m', G.poly(1)]]), none);
    assert.equal(byM.key, 'n=c5|m=p1');
    assert.ok(!byN.contains(byM), 'times are in different units (n and m)');
    const exp = Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.logClass(1, 1)], ['m', G.logClass(1)]]), none);
    assert.ok(exp.expScale && !byN.contains(exp) && !exp.contains(byN));
    const other = Regime.fromGrowthMap(['n', 'q'], new Map([['n', G.poly(1)], ['q', G.poly(1)]]), none);
    assert.ok(!byN.contains(other), 'other parameters');
  });
});

describe('Regime.excess (how far a regime lies outside another: aims, lower.ts)', () => {
  const at = (m: G.Growth, k: G.Growth = G.constant(3), M: G.Growth = G.poly(3)): Regime =>
    Regime.fromGrowthMap(['n', 'm', 'k', 'M'], new Map([['n', G.poly(1)], ['m', m], ['k', k], ['M', M]]), new Set(['M']));

  it('is 0 inside, the sum of the exponents by which the parameters grow faster outside', () => {
    assert.equal(at(G.poly(2)).excess(at(G.poly(1.5))), 0);
    assert.equal(at(G.poly(1.5)).excess(at(G.poly(1.5))), 0);
    assert.ok(near(at(G.poly(1.5)).excess(at(G.poly(2))), 0.5));
    assert.ok(near(at(G.poly(0.25)).excess(at(G.poly(0.3))), 0.05));
    // a class above polylog or a constant counts as exponent 0, and at least 10⁻⁶
    assert.ok(near(at(G.logClass(1)).excess(at(G.poly(0.2))), 0.2));
    assert.ok(near(at(G.constant(null)).excess(at(G.logClass(1))), 1e-6, 1e-12));
  });

  it('is Infinity where no change of exponents brings it inside', () => {
    assert.equal(at(G.poly(1), G.constant(4)).excess(at(G.poly(1), G.constant(3))), Infinity, 'two values of k');
    assert.equal(at(G.poly(1), G.constant(3), G.logClass(1)).excess(at(G.poly(1), G.constant(3), G.poly(3))), Infinity, 'M in a larger class');
    const none = new Set<string>();
    const byN = Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.poly(1)], ['m', G.poly(1)]]), none);
    const byM = Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.constant(5)], ['m', G.poly(1)]]), none);
    assert.equal(byN.excess(byM), Infinity, 'another main parameter');
  });
});

describe('Regime.satisfies / display', () => {
  const r = Regime.fromGrowthMap(
    ['n', 'm', 'M', 'k', 'd'],
    new Map([
      ['n', G.poly(1)],
      ['m', G.poly(1.5)],
      ['M', G.poly(3)],
      ['k', G.constant(3)],
      ['d', G.logClass(1, null)],
    ]),
    new Set(['M']),
  );

  it('checks requirements per parameter', () => {
    assert.ok(r.satisfies(parseRegimeSpec('m=3/2')));
    assert.ok(r.satisfies(parseRegimeSpec('m=1.5000001')));
    assert.ok(!r.satisfies(parseRegimeSpec('m=2')));
    assert.ok(r.satisfies(parseRegimeSpec('M=poly, k=const:[2,3], d=log')));
    assert.ok(r.satisfies(parseRegimeSpec('k=const')));
    assert.ok(!r.satisfies(parseRegimeSpec('k=const:4')));
    assert.ok(!r.satisfies(parseRegimeSpec('x=1')));
    const third = Regime.fromGrowthMap(['n', 'k'], new Map([['n', G.poly(1)], ['k', G.constant(4 / 3)]]), new Set());
    assert.ok(third.satisfies(parseRegimeSpec('k=const:4/3')), 'a constant rounded up still matches its spec');
  });

  it('reads log, polylog and subpoly as upper bounds (constants satisfy them)', () => {
    assert.ok(r.satisfies(parseRegimeSpec('k=polylog')), 'a constant is polylogarithmic');
    assert.ok(r.satisfies(parseRegimeSpec('k=log')));
    assert.ok(r.satisfies(parseRegimeSpec('k=subpoly, d=subpoly')));
    assert.ok(!r.satisfies(parseRegimeSpec('m=polylog')));
    assert.ok(!r.satisfies(parseRegimeSpec('M=polylog')), 'a polynomial log-dependent parameter is not polylogarithmic');
    const small = Regime.fromGrowthMap(['n', 'M'], new Map([['n', G.poly(1)], ['M', G.constant(5)]]), new Set(['M']));
    assert.ok(small.satisfies(parseRegimeSpec('M=polylog')), 'constant weights are polylogarithmic weights');
    assert.ok(!small.satisfies(parseRegimeSpec('M=poly')));
  });

  it('describes itself', () => {
    assert.match(r.describeTex(), /m = n\^\{1\.5\}/);
    const at = (exponent: number, power = 1): G.Rate => ({ power, exponent });
    assert.equal(r.timeTex(at(2)), 'n^{2}');
    assert.equal(r.timeTex(at(0)), 'n^{o(1)}');
    assert.equal(r.timeTex(G.RATE_ZERO), '\\text{polylog}(n)');
    assert.equal(r.timeTex(at(1, 2)), '2^{\\log^{2} n}', 'quasi-polynomial');
    assert.equal(r.timeTex(at(0.5, 0.5)), '2^{0.5\\,\\log^{0.5} n}');
    const e = Regime.normalize(['n'], [G.logClass(1, 1)], new Set());
    assert.ok(e.kind === 'ok');
    assert.equal(e.regime.timeTex(at(0.5)), '2^{0.5n}');
    assert.equal(e.regime.timeTex(at(1)), '2^{n}', 'no factor 1');
    assert.equal(e.regime.timeTex(at(0.5, 0.75)), '2^{0.5\\,n^{0.75}}');
    assert.equal(e.regime.timeTex(at(1, 0.99)), '2^{n^{0.99}}');
    assert.equal(e.regime.timeTex(at(Infinity, 0.5)), '2^{\\omega(n^{0.5})}');
    assert.equal(e.regime.timeTex(G.RATE_ZERO), '\\text{poly}(n)');
  });

  it('requires a growth for every parameter', () => {
    assert.throws(() => Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.poly(1)]]), new Set()), SpecError);
    assert.throws(() => Regime.fromGrowthMap(['n'], new Map([['n', G.constant(2)]]), new Set()), SpecError);
  });
});
