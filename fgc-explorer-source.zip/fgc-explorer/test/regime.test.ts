import assert from 'node:assert/strict';
import * as G from '../src/growth/growth';
import { EvalError } from '../src/growth/growth';
import { formatParamSpec, formatRegimeSpec, parseParamSpec, parseRegimeSpec, Regime, SpecError } from '../src/model/regime';

/*
 * Testing strategy for regimes
 *
 * parseParamSpec: number, fraction, log, log:c, polylog, const, const:v, const:?, const:[list], poly, poly:μ;
 *   errors: nonpositive, unknown word, bad list
 * parseRegimeSpec: several entries, commas inside lists, duplicates, missing "=", empty name
 * formatParamSpec / formatRegimeSpec: round trip
 * Regime.normalize, partition on normalizer: first non-log-dependent polynomial parameter (with exponent ≠ 1, after a
 *   log-dependent or constant one), exponential scale (log parameter with coefficient), degenerate;
 *   clamping of negative exponents and sub-1 constants; errors for unknown/superpolynomial sizes
 * key: polynomial exponents, E, L, constants (known/unknown), log-dependent classes C/L/P
 * satisfies: each spec kind, tolerance, unknown parameter
 * describeTex / timeTex: smoke tests
 */

describe('parseParamSpec', () => {
  it('parses each growth form', () => {
    assert.deepEqual(parseParamSpec('2'), { kind: 'poly', exp: 2 });
    assert.deepEqual(parseParamSpec(' 4/3 '), { kind: 'poly', exp: 4 / 3 });
    assert.deepEqual(parseParamSpec('log'), { kind: 'log', coef: 1 });
    assert.deepEqual(parseParamSpec('log:0.5'), { kind: 'log', coef: 0.5 });
    assert.deepEqual(parseParamSpec('polylog'), { kind: 'polylog' });
    assert.deepEqual(parseParamSpec('const'), { kind: 'const', values: [null] });
    assert.deepEqual(parseParamSpec('const:3'), { kind: 'const', values: [3] });
    assert.deepEqual(parseParamSpec('const:[3, 4,?]'), { kind: 'const', values: [3, 4, null] });
    assert.deepEqual(parseParamSpec('poly'), { kind: 'logdep' });
  });

  it('rejects malformed specs', () => {
    for (const s of ['0', '-1', 'big', 'log:-1', 'const:[1,2', 'const:[]', 'polylog:2', '1/0', 'poly:2']) {
      assert.throws(() => parseParamSpec(s), SpecError, s);
    }
  });
});

describe('parseRegimeSpec / format', () => {
  it('parses several entries and round-trips', () => {
    const m = parseRegimeSpec('n=1, m=2, M=poly, k=const:[3,4]');
    assert.deepEqual([...m.keys()], ['n', 'm', 'M', 'k']);
    assert.equal(formatRegimeSpec(m), 'n=1, m=2, M=poly, k=const:[3,4]');
    assert.equal(formatParamSpec(parseParamSpec('log:2')), 'log:2');
    assert.equal(parseRegimeSpec('').size, 0);
  });

  it('rejects duplicates and malformed entries', () => {
    assert.throws(() => parseRegimeSpec('n=1, n=2'), SpecError);
    assert.throws(() => parseRegimeSpec('n'), SpecError);
    assert.throws(() => parseRegimeSpec('=1'), SpecError);
  });
});

describe('Regime.normalize', () => {
  const none = new Set<string>();

  it('normalizes by the first growing non-log-dependent parameter', () => {
    const r = Regime.normalize(['M', 'n', 'm'], [G.poly(4), G.poly(0.5), G.poly(1)], new Set(['M']));
    assert.equal(r.kind, 'ok');
    if (r.kind !== 'ok') return;
    assert.equal(r.scale, 0.5);
    assert.equal(r.regime.normalizerName, 'n');
    assert.equal(r.regime.key, 'M=P|n=p1|m=p2');
    // polynomial log-dependent parameters are evaluated at a fixed representative exponent
    assert.deepEqual(r.regime.growthOf('M'), G.poly(3));
  });

  it('skips constant and polylogarithmic parameters when choosing the normalizer', () => {
    const r = Regime.normalize(['k', 'd', 'n'], [G.constant(3), G.logClass(2), G.poly(2)], none);
    assert.ok(r.kind === 'ok' && r.regime.key === 'k=c3|d=L|n=p1' && r.scale === 2);
  });

  it('uses an exponential scale when no parameter is polynomial', () => {
    const r = Regime.normalize(['n', 'm'], [G.logClass(1, 2), G.logClass(Infinity)], none);
    assert.equal(r.kind, 'ok');
    if (r.kind !== 'ok') return;
    assert.equal(r.scale, 2);
    assert.ok(r.regime.expScale);
    assert.equal(r.regime.key, 'n=E|m=L');
    assert.deepEqual(r.regime.growthOf('n'), G.logClass(1, 1));
  });

  it('reports degenerate instances', () => {
    assert.equal(Regime.normalize(['n', 'd'], [G.constant(5), G.logClass(1, null)], none).kind, 'degenerate');
    assert.equal(Regime.normalize(['n'], [G.poly(-1)], none).kind, 'degenerate');
  });

  it('clamps sizes below 1 and keeps unknown constants', () => {
    const r = Regime.normalize(['n', 'k', 'c'], [G.poly(1), G.poly(-0.5), G.constant(0.5)], none);
    assert.ok(r.kind === 'ok' && r.regime.key === 'n=p1|k=c?|c=c?');
  });

  it('rejects unknown or superpolynomial sizes', () => {
    assert.throws(() => Regime.normalize(['n', 'm'], [G.poly(1), G.POLY_UNKNOWN], none), EvalError);
    assert.throws(() => Regime.normalize(['n'], [G.SUPER], none), EvalError);
    assert.throws(() => Regime.normalize(['n', 'M'], [G.poly(1), G.SUPER], new Set(['M'])), EvalError);
    const ok = Regime.normalize(['n', 'M'], [G.poly(1), G.POLY_UNKNOWN], new Set(['M']));
    assert.ok(ok.kind === 'ok' && ok.regime.key === 'n=p1|M=P');
  });

  it('encodes log-dependent classes', () => {
    const key = (g: G.Growth): string => {
      const r = Regime.normalize(['n', 'M'], [G.poly(1), g], new Set(['M']));
      return r.kind === 'ok' ? r.regime.key : 'degenerate';
    };
    assert.equal(key(G.constant(1)), 'n=p1|M=C');
    assert.equal(key(G.logClass(2)), 'n=p1|M=L');
    assert.equal(key(G.poly(7)), 'n=p1|M=P');
  });
});

describe('Regime.satisfies / display', () => {
  const r = Regime.fromGrowthMap(
    ['n', 'm', 'M', 'k', 'd'],
    new Map([
      ['n', G.poly(1)],
      ['m', G.poly(1.5)],
      ['M', G.poly(3)],
      ['k', G.constant(3)],
      ['d', G.logClass(1, null)],
    ]),
    new Set(['M']),
  );

  it('checks requirements per parameter', () => {
    assert.ok(r.satisfies(parseRegimeSpec('m=3/2')));
    assert.ok(r.satisfies(parseRegimeSpec('m=1.5000001')));
    assert.ok(!r.satisfies(parseRegimeSpec('m=2')));
    assert.ok(r.satisfies(parseRegimeSpec('M=poly, k=const:[2,3], d=log')));
    assert.ok(r.satisfies(parseRegimeSpec('k=const')));
    assert.ok(!r.satisfies(parseRegimeSpec('k=const:4')));
    assert.ok(!r.satisfies(parseRegimeSpec('x=1')));
  });

  it('describes itself', () => {
    assert.match(r.describeTex(), /m = n\^\{1\.5\}/);
    assert.equal(r.timeTex(2), 'n^{2}');
    const e = Regime.normalize(['n'], [G.logClass(1, 1)], new Set());
    assert.ok(e.kind === 'ok' && e.regime.timeTex(0.5) === '2^{0.5n}');
  });

  it('requires a growth for every parameter', () => {
    assert.throws(() => Regime.fromGrowthMap(['n', 'm'], new Map([['n', G.poly(1)]]), new Set()), SpecError);
    assert.throws(() => Regime.fromGrowthMap(['n'], new Map([['n', G.constant(2)]]), new Set()), SpecError);
  });
});
