import assert from 'node:assert/strict';
import { evaluate, evaluateFormula } from '../src/growth/evaluate';
import * as G from '../src/growth/growth';
import { EvalError, Growth } from '../src/growth/growth';
import { parseExpr, parseFormula } from '../src/math/parser';

/*
 * Testing strategy for evaluate / evaluateFormula
 *
 * partition on construct: num, var (bound / unbound), add with subtraction, neg, mul, div, pow, call (handler / no
 *   handler), apply (variable product / named function / unknown), each func, each bound kind, sums (constant range,
 *   log range with known / unknown coefficient, unbounded, polynomial range)
 * partition on environment: polynomial regimes (n = N), exponential scale (n = log2 N), constants
 * evaluateFormula: first alternative evaluates / falls back to a later one / none evaluates
 * Expected values are computed by hand from SPEC §5.
 */

const env = (entries: Record<string, Growth>): Map<string, Growth> => new Map(Object.entries(entries));
const poly = { n: G.poly(1), m: G.poly(2), M: G.poly(3), d: G.logClass(1, null), k: G.constant(3) };
const ex = (src: string, e: Record<string, Growth> = poly, onCall?: (fn: string, a: readonly Growth[]) => Growth): number =>
  G.exponentOf(evaluate(parseExpr(src), { env: env(e), ...(onCall ? { onCall } : {}) }));

describe('evaluate: arithmetic', () => {
  it('evaluates polynomial expressions', () => {
    assert.equal(ex('n^2 + m'), 2);
    assert.equal(ex('n \\cdot m / n'), 2);
    assert.equal(ex('(n - 1)(3n + 3)'), 2);
    assert.equal(ex('n^{1/k}'), 1 / 3);
    assert.equal(ex('n^{3-1/k}/\\log n'), 3 - 1 / 3);
    assert.equal(ex('\\sqrt{n} + n^{0.4}'), 0.5);
    assert.equal(ex('\\max(n, m^{1/4})'), 1);
    assert.equal(ex('\\min(n^2, m n)'), 2);
  });

  it('ignores logs and constants and handles o(1) / \\Omega(1) in exponents', () => {
    assert.equal(ex('n \\log^{O(1)} M'), 1);
    assert.ok(Math.abs(ex('n^{1+o(1)}') - 1) < 1e-9);
    assert.ok(Math.abs(ex('n^{2-\\Omega(1)}') - 2) < 1e-6 && ex('n^{2-\\Omega(1)}') < 2);
    assert.equal(ex('\\tilde{O}(n^{1.5})'), 1.5);
    assert.equal(ex('2^{O(\\sqrt{\\log n})} \\cdot n'), 1);
    assert.equal(ex('n \\cdot \\alpha(n)'), 1);
  });

  it('evaluates exponentials of logarithmic quantities', () => {
    const sat = { n: G.logClass(1, 1), m: G.logClass(Infinity), delta: G.constant(0.3) };
    assert.equal(ex('2^{n/2} \\cdot m', sat), 0.5);
    assert.equal(ex('2^{(1-\\delta)n}', sat), 0.7);
    assert.equal(ex('2^{n/2+1} + 3m', sat), 0.5);
    assert.equal(ex('2^{an}', { ...sat, a: G.constant(0.25) }), 0.25);
    assert.equal(ex('4^{\\log n}'), 2);
  });

  it('treats x(y) as a product when x is a variable', () => {
    assert.equal(ex('n(\\lfloor \\log t \\rfloor + 1)', { ...poly, t: G.poly(2) }), 1);
    assert.throws(() => ex('f(n)'), EvalError);
  });

  it('evaluates binomials, ceilings and floors of constants exactly', () => {
    const g = evaluate(parseExpr('\\binom{\\lambda}{2}'), { env: env({ lambda: G.constant(4) }) });
    assert.deepEqual(g, G.constant(6));
    const h = evaluate(parseExpr('\\lfloor k/2 \\rfloor + 1'), { env: env({ k: G.constant(5) }) });
    assert.deepEqual(h, G.constant(3));
  });

  it('fails on unknown symbols, \\deg, oracle calls without handler and exponents of unknown size', () => {
    assert.throws(() => ex('x + 1'), EvalError);
    assert.throws(() => ex('\\deg(v)'), EvalError);
    assert.throws(() => ex('T(n)'), EvalError);
    assert.throws(() => ex('n^{O(1)}'), EvalError);
    assert.throws(() => ex('o(n)'), EvalError);
  });

  it('rejects the ambiguous \\omega(...) and keeps O(0) = 0', () => {
    assert.throws(() => ex('n^{\\omega(1)}', { ...poly, omega: G.constant(2.37) }), EvalError);
    assert.deepEqual(evaluate(parseExpr('1/3 + O(\\gamma)'), { env: env({ gamma: G.constant(0) }) }), G.constant(1 / 3));
  });

  it('treats O(constant) as an unknown constant', () => {
    assert.deepEqual(evaluate(parseExpr('O(1)'), { env: env(poly) }), G.constant(null));
    assert.deepEqual(evaluate(parseExpr('2^{O(k)}'), { env: env(poly) }), G.constant(null));
    assert.deepEqual(evaluate(parseExpr('\\log^{O(1)} n'), { env: env(poly) }), G.POLYLOG);
  });
});

describe('evaluate: oracle calls and sums', () => {
  const callWorth = (x: number) => (_fn: string, args: readonly Growth[]): Growth => G.poly(G.exponentOf(args[0]!) * x || 1e-300);

  it('passes argument classes to the handler', () => {
    const seen: number[] = [];
    ex('n \\cdot T(O(n^{1/3}), m)', poly, (_fn, args) => {
      seen.push(G.exponentOf(args[0]!), G.exponentOf(args[1]!));
      return G.poly(1);
    });
    assert.deepEqual(seen, [1 / 3, 2]);
  });

  it('evaluates sums over constant ranges exactly', () => {
    assert.equal(ex('\\sum_{i=1}^{3} n^i'), 3);
    assert.throws(() => ex('\\sum_{i=1}^{100} n'), EvalError);
  });

  it('evaluates sums over logarithmic ranges as their largest term', () => {
    // sum_{i=0}^{log n} 4^i T(n/2^i) with T(x) = x^c has exponent max(c, 2)
    for (const c of [1, 1.5, 2, 3]) {
      const v = ex('\\sum_{i=0}^{\\log n} 4^i \\cdot T(n/2^i)', poly, (_fn, args) => {
        const e = G.exponentOf(args[0]!);
        return e <= 0 ? G.constant(1) : G.poly(e * c);
      });
      assert.ok(Math.abs(v - Math.max(c, 2)) < 1e-6, `c=${c}: ${v}`);
    }
  });

  it('handles sums up to O(log n) when the hidden constant does not matter', () => {
    // min(8^i, t) * T(m (1/4)^i) with t = n, m = n^2, T(x) = x and i = θ log2 n: the term exponent is
    // min(3θ, 1) + max(2 - 2θ, 0), maximal (7/3) at θ = 1/3, and constant once m (1/4)^i < 1.
    const v = ex('\\sum_{i=0}^{O(\\log m)} \\min(8^i, O(t)) \\cdot T(O(m \\cdot (1/4)^i))', { ...poly, t: G.poly(1) }, (_fn, args) => {
      const a = args[0]!;
      return a.kind === 'poly' && a.exp > 0 ? G.poly(a.exp) : G.constant(1);
    });
    assert.ok(Math.abs(v - 7 / 3) < 1e-3, String(v));
    // 8^i alone keeps growing with the hidden constant: not evaluable
    assert.throws(() => ex('\\sum_{i=0}^{O(\\log n)} 8^i'), EvalError);
  });

  it('rejects unbounded and polynomially long sums', () => {
    assert.throws(() => ex('\\sum_v T(n)', poly, callWorth(1)), EvalError);
    assert.throws(() => ex('\\sum_{i=1}^{n} 1'), EvalError);
  });
});

describe('evaluateFormula', () => {
  it('uses the first alternative that evaluates', () => {
    const f = parseFormula('O(\\sum_v T(\\deg(v))) \\subseteq O(n \\cdot T(n))');
    const r = evaluateFormula(f, { env: env(poly), onCall: () => G.poly(2) });
    assert.equal(r.alternative, 1);
    assert.equal(G.exponentOf(r.value), 3);
  });

  it('throws when no alternative evaluates', () => {
    assert.throws(() => evaluateFormula(parseFormula('O(x) \\subseteq O(y)'), { env: env(poly) }), EvalError);
  });
});

describe('evaluate: running times 2^{c·n^a}', () => {
  // CNF-SAT's regime: n = log2 N, m = poly(n)
  const sat = { n: G.logClass(1, 1), m: G.POLYLOG };
  const rate = (src: string, e: Record<string, Growth> = sat): G.Rate => G.rateOf(evaluate(parseExpr(src), { env: env(e) }));

  it('reads the constant factor and the power of n in the exponent', () => {
    assert.deepEqual(rate('2^{0.5 n^{0.75}}'), { power: 0.75, exponent: 0.5 });
    assert.deepEqual(rate('2^{n^{0.99}} \\cdot m'), { power: 0.99, exponent: 1 });
    assert.deepEqual(rate('\\tilde{O}(2^{0.5 n^{0.75}})'), { power: 0.75, exponent: 0.5 });
    assert.deepEqual(rate('2^{(2n)^{0.5}}'), { power: 0.5, exponent: Math.SQRT2 });
    assert.deepEqual(rate('2^{n^{0.5} \\cdot n^{0.25}} + 2^{n^{0.5}}'), { power: 0.75, exponent: 1 });
    assert.deepEqual(rate('2^{n} \\cdot m'), { power: 1, exponent: 1 });
    assert.deepEqual(rate('2^{n^{2}}'), { power: 2, exponent: 1 });
  });

  it('hides unknown coefficients in O(·)', () => {
    assert.deepEqual(rate('2^{O(n^{0.5})}'), { power: 1, exponent: 0 }, 'only 2^{o(n)} is known');
    assert.equal(ex('2^{O(\\sqrt{\\log n})} \\cdot n'), 1);
  });

  it('gives quasi-polynomial times at polynomial regimes', () => {
    assert.deepEqual(rate('n^{\\log n}', poly), { power: 2, exponent: 1 });
    assert.deepEqual(rate('2^{\\sqrt{\\log n}} \\cdot n', poly), { power: 1, exponent: 1 });
    assert.deepEqual(rate('2^{\\sqrt{\\log n}}', poly), { power: 0.5, exponent: 1 });
  });

  it('finds the largest term of a sum by its rate, and among terms of rate zero by their order', () => {
    // terms 2^{√i} with i up to log2 n: the last one, 2^{√(log n)}, is the largest
    assert.deepEqual(rate('\\sum_{i=0}^{\\log n} 2^{\\sqrt{i}}', poly), { power: 0.5, exponent: 1 });
    // \sum_{i ≤ n} i is Θ(n²) at CNF-SAT's scale, so 2 to its power has no useful bound
    assert.deepEqual(evaluate(parseExpr('\\sum_{i=0}^{n} i'), { env: env(sat) }), G.logClass(2));
    assert.deepEqual(evaluate(parseExpr('2^{\\sum_{i=1}^{n} i}'), { env: env(sat) }), G.SUPER);
  });

  it('reads o(·) as an infinitesimal multiple', () => {
    assert.deepEqual(evaluate(parseExpr('n^{o(1)}'), { env: env(poly) }), G.SUBPOLY);
    assert.deepEqual(rate('2^{o(n)}'), { power: 1, exponent: 0 });
    assert.deepEqual(rate('2^{o(n^{0.75})}'), { power: 0.75, exponent: 0 });
    assert.deepEqual(rate('2^{o(\\log^{0.75} n)}', poly), { power: 0.75, exponent: 0 });
    assert.throws(() => evaluate(parseExpr('o(n)'), { env: env(poly) }), EvalError);
  });
});
