import assert from 'node:assert/strict';
import { analyze } from '../src/engine/analysis';
import { FocusLink, keptAround, selectionDerivations } from '../src/ui/focus';
import { clickSelect, isAdditive, Selection, SelectionItem, withRegime } from '../src/ui/selection';
import { model, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for the selection and the focus modes
 *
 * clickSelect, partition on: selection (empty, one item, several), item (selected or not), additive (no: the item
 *   alone, keeping its regime; yes: added at the end, or removed)
 * isAdditive: no event, plain, Shift, Ctrl, ⌘
 * withRegime: set, cleared, other items unchanged
 * keptAround, partition on: mode (neighbours, lineage), selected items (problem, reduction, both, none, unknown
 *   reduction), graph shape (chain, branches that do not lead to the selection, cycle)
 * selectionDerivations: problems only (reductions ignored), union over the selection, regime of an item
 */

const P = (id: string, regime?: string): SelectionItem => (regime === undefined ? { kind: 'problem', id } : { kind: 'problem', id, regime });
const R = (id: string): SelectionItem => ({ kind: 'row', id });

describe('clickSelect', () => {
  it('selects the item alone on a plain click', () => {
    assert.deepEqual(clickSelect([], P('a'), false), [P('a')]);
    assert.deepEqual(clickSelect([P('a'), R('1')], R('2'), false), [R('2')]);
    const one: Selection = [P('a', 'n=p1')];
    assert.equal(clickSelect(one, P('a'), false), one, 'unchanged (regime kept)');
    assert.deepEqual(clickSelect([R('1'), P('a', 'n=p1')], P('a'), false), [P('a', 'n=p1')]);
  });

  it('adds or removes the item on an additive click', () => {
    assert.deepEqual(clickSelect([P('a')], R('1'), true), [P('a'), R('1')]);
    assert.deepEqual(clickSelect([P('a'), R('1'), P('b')], R('1'), true), [P('a'), P('b')]);
    assert.deepEqual(clickSelect([P('a')], P('a'), true), []);
  });

  it('recognizes additive clicks', () => {
    assert.deepEqual(
      [undefined, {}, { shiftKey: true }, { ctrlKey: true }, { metaKey: true }].map(isAdditive),
      [false, false, true, true, true],
    );
  });

  it('sets and clears the regime of one problem', () => {
    const s: Selection = [P('a'), P('b', 'x')];
    assert.deepEqual(withRegime(s, 'a', 'y'), [P('a', 'y'), P('b', 'x')]);
    assert.deepEqual(withRegime(s, 'b', undefined), [P('a'), P('b')]);
  });
});

describe('keptAround', () => {
  // a → b → c → d, x → b, c → y, d → b (cycle b → c → d → b), z isolated
  const links: FocusLink[] = [
    ['1', 'a', 'b'],
    ['2', 'b', 'c'],
    ['3', 'c', 'd'],
    ['4', 'x', 'b'],
    ['5', 'c', 'y'],
    ['6', 'd', 'b'],
    ['7', 'a', 'z'],
  ].map(([id, source, target]) => ({ id: id!, source: source!, target: target! }));
  const sorted = (k: { problems: ReadonlySet<string>; rows: ReadonlySet<string> }): [string[], string[]] => [[...k.problems].sort(), [...k.rows].sort()];

  it('keeps the neighbours of problems and the ends of reductions', () => {
    assert.deepEqual(sorted(keptAround('neighbours', [P('c')], links)), [
      ['b', 'c', 'd', 'y'],
      ['2', '3', '5'],
    ]);
    assert.deepEqual(sorted(keptAround('neighbours', [R('4'), P('z')], links)), [
      ['a', 'b', 'x', 'z'],
      ['4', '7'],
    ]);
    assert.deepEqual(sorted(keptAround('neighbours', [], links)), [[], []]);
    assert.deepEqual(sorted(keptAround('neighbours', [R('99')], links)), [[], []]);
  });

  it('keeps all ancestors and descendants and the reductions between them', () => {
    // y: ancestors c, b, d (cycle), a, x; no descendants.
    assert.deepEqual(sorted(keptAround('lineage', [P('y')], links)), [
      ['a', 'b', 'c', 'd', 'x', 'y'],
      ['1', '2', '3', '4', '5', '6'],
    ]);
    // a: no ancestors; descendants everything but x (z included).
    assert.deepEqual(sorted(keptAround('lineage', [P('a')], links)), [
      ['a', 'b', 'c', 'd', 'y', 'z'],
      ['1', '2', '3', '5', '6', '7'],
    ]);
  });

  it("keeps a reduction's source's ancestors and its target's descendants", () => {
    // 4: x → b. Ancestors of x: none. Descendants of b: c, d, y (and b, via the cycle).
    assert.deepEqual(sorted(keptAround('lineage', [R('4')], links)), [
      ['b', 'c', 'd', 'x', 'y'],
      ['2', '3', '4', '5', '6'],
    ]);
  });
});

describe('selectionDerivations', () => {
  const [A, B, C] = ['F / A', 'F / B', 'F / C'];
  const rows: RowSpec[] = [
    { id: '1', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: '2', from: B, to: C, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  ];
  const a = analyze(
    model(rows),
    scenario([
      // (above the reductions' own linear time, so that it propagates)
      { problem: A, kind: 'LB', regime: 'n=1', exponent: 1.5 },
      { problem: C, kind: 'UB', regime: 'n=1', exponent: 2 },
    ]),
  );
  const sorted = (k: { problems: ReadonlySet<string>; rows: ReadonlySet<string> }): [string[], string[]] => [[...k.problems].sort(), [...k.rows].sort()];

  it('unites the derivations of the selected problems and ignores reductions', () => {
    const d = selectionDerivations([P(B), R('1')], a);
    assert.deepEqual(sorted(d.lb), [[A, B], ['1']]);
    assert.deepEqual(sorted(d.ub), [[B, C], ['2']]);
    const two = selectionDerivations([P(A), P(C)], a);
    assert.deepEqual(sorted(two.lb), [[A, B, C], ['1', '2']]);
    assert.deepEqual(sorted(two.ub), [[A, B, C], ['1', '2']]);
  });

  it("uses an item's regime, falling back to the primary one", () => {
    const d = selectionDerivations([P(B, 'no such regime')], a);
    assert.deepEqual(sorted(d.lb), [[A, B], ['1']]);
  });
});
