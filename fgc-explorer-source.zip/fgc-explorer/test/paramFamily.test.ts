import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { analyze, Analysis } from '../src/engine/analysis';
import { initialScenario, validateConfig } from '../src/model/config';
import { buildModel } from '../src/model/model';
import { boundsLine } from '../src/ui/format';
import { affineExponent, paramFamily, problemBoundsLine, valuesText } from '../src/ui/paramFamily';
import { CsvTable } from '../src/util/csv';
import { scenario } from './helpers';

/*
 * Testing strategy for the bounds line of problems with a constant parameter in the exponent (src/ui/paramFamily.ts)
 *
 * valuesText: one value, runs of two and of three or more, gaps, non-integers; compact (runs of two, no spaces, more
 * than four items elided). affineExponent: slopes 1, 2, 1/2, ω/3 (with ω given, and without it: none), an intercept
 * (positive, negative), a constant, points not on a line, fewer than three points, a slope that is no simple fraction.
 * On the real sheet: a symbolic line (k-OV under SETH, both bounds; k-Clique, an upper bound only; Klee's measure problem
 * in d; Zero-Weight and Min-Weight k-Clique, a lower bound that does not grow with k), statuses when a bound is missing at
 * some values or is no simple function (k-AP Detection), also when only whether there is a bound changes (Min-Weight
 * k-Cycle without row R465: n^3 at every k, a lower bound at k = 3 only), compact forms for the graph, a parameter whose
 * values all give the same bounds (no family: Min-Weight k-Cycle with R465), problems without such a parameter (the
 * first regime's line), and the line following the scenario (the k-Clique hypothesis).
 */

describe('valuesText', () => {
  it('writes runs of consecutive values as ranges', () => {
    assert.equal(valuesText([3]), '3');
    assert.equal(valuesText([3, 4]), '3, 4');
    assert.equal(valuesText([6, 3, 4, 5]), '3–6');
    assert.equal(valuesText([2, 3, 4, 5, 6, 8]), '2–6, 8');
    assert.equal(valuesText([4, 5, 6, 9, 12, 30, 300]), '4–6, 9, 12, 30, 300');
    assert.equal(valuesText([0.5, 1.5]), '0.5, 1.5');
  });

  it('is shorter in compact form', () => {
    assert.equal(valuesText([3, 4]), '3, 4');
    assert.equal(valuesText([3, 4], true), '3–4');
    assert.equal(valuesText([3, 6], true), '3,6');
    assert.equal(valuesText([2, 3, 4, 5, 6, 8], true), '2–6,8');
    assert.equal(valuesText([6, 7, 8, 9, 11, 13, 17, 21], true), '6…21');
  });
});

describe('affineExponent', () => {
  const omega = 2.371552;
  it('recognizes simple fractions and fractions of ω', () => {
    assert.equal(affineExponent([2, 3, 4], [2, 3, 4], 'k'), 'k');
    assert.equal(affineExponent([2, 3, 4], [4, 6, 8], 'k'), '2k');
    assert.equal(affineExponent([2, 3, 4, 5, 6], [1, 1.5, 2, 2.5, 3], 'd'), 'd/2');
    assert.equal(affineExponent([3, 4, 5, 6], [3, 4, 5, 6].map((k) => (omega * k) / 3), 'k', omega), 'ωk/3');
    assert.equal(affineExponent([3, 4, 5, 6], [3, 4, 5, 6].map((k) => (omega * k) / 3), 'k'), null, 'ω not given');
    assert.equal(affineExponent([2, 3, 4], [3, 4, 5], 'd'), 'd + 1');
    assert.equal(affineExponent([2, 3, 4], [1, 2, 3], 'k'), 'k − 1');
    assert.equal(affineExponent([4, 5, 6], [2, 2, 2], 'k'), '2');
  });

  it('gives up on points off a line, too few points and unusual slopes', () => {
    assert.equal(affineExponent([3, 4, 5, 6], [2.3716, 3.25, 4.0856, 4.7431], 'k'), null);
    assert.equal(affineExponent([3, 4], [3, 4], 'k'), null);
    assert.equal(affineExponent([2, 3, 4], [2, 2.7, 3.4], 'k'), null);
    assert.equal(affineExponent([2, 3, 4], [2, 3, Infinity], 'k'), null);
  });
});

describe('the bounds line of problems with a constant parameter in the exponent (real sheet)', function () {
  this.timeout(60000);
  const csv = readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');
  const config = validateConfig(JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'))).value;
  const model = buildModel(CsvTable.fromText(csv).table, config);
  const a = analyze(model, initialScenario(config));
  const line = (x: Analysis, p: string, compact = false): string => problemBoundsLine(x, x.summaries.get(p)!, compact);

  it('shows the bounds as functions of the parameter when every value gives the same simple one', () => {
    // SETH: k-OV needs n^{k-o(1)}, and the trivial algorithm takes n^k d
    assert.equal(line(a, 'Orthogonal Vectors / k-OV'), '≥ n^k  ≤ n^k  (k = 2–6, 8)');
    assert.equal(line(a, 'Orthogonal Vectors / k-OV', true), '≥ n^k  ≤ n^k');
    assert.equal(line(a, "Geometric Covering Problems / Klee's Measure Problem"), '≤ N^(d/2)  (d = 2–6)');
    assert.equal(line(a, 'Clique / 3-Uniform k-Hyperclique'), '≤ n^k  (k = 4–6, 9, 12, 30, 300)');
    // the APSP and 3SUM hypotheses give n^3 at k = 3, carried to every k (R463, R464; Max-Weight by negation)
    assert.equal(line(a, 'Clique / Zero-Weight k-Clique'), '≥ n^3  ≤ n^k  (k = 3–6)');
    assert.equal(line(a, 'Clique / Zero-Weight k-Clique', true), '≥ n^3  ≤ n^k');
    assert.equal(line(a, 'Clique / Min-Weight k-Clique', true), '≥ n^3  ≤ n^k');
    assert.equal(line(a, 'Clique / Max-Weight k-Clique', true), '≥ n^3  ≤ n^k');
  });

  it('shows the status at each value otherwise, not the bounds of one value', () => {
    // without the rows from k to k + 1: a lower bound at k = 3 only (Exact Triangle), the trivial n^k everywhere; and
    // n^3 at every k, but a lower bound at k = 3 only
    const init = initialScenario(config);
    const noPad = analyze(model, { ...init, settings: { ...init.settings, disabledRows: ['R463', 'R464', 'R465'] } });
    assert.equal(line(noPad, 'Clique / Zero-Weight k-Clique'), 'k = 3: tight · k = 4–6: upper bound');
    assert.equal(line(noPad, 'Clique / Zero-Weight k-Clique', true), 'k=3 tight · 4–6 UB');
    assert.equal(line(noPad, 'Clique / Min-Weight k-Clique', true), 'k=3 tight · 4–6 UB');
    assert.equal(line(noPad, 'Graph Cycles / Min-Weight k-Cycle', true), 'k=3 tight · 4–6 UB');
    // near-linear at k = 3 (FFT), quadratic from k = 4: no single formula
    assert.equal(line(a, 'k-AP Detection'), 'k = 3–6: upper bound');
    // n^{ωk/3} where 3 divides k, rectangular matrix multiplication at k = 4, 5 (U14, U341, U342)
    assert.equal(line(a, 'Clique / k-Clique'), 'k = 3–6: upper bound');
    assert.ok(boundsLine(a.summaries.get('Clique / Zero-Weight k-Clique')!.primary).includes('n^3'), 'what the first regime alone shows');
  });

  it('follows the scenario', () => {
    const groups = (...labels: string[]) => scenario(config.initialKnobs.filter((g) => labels.includes(g.label)).flatMap((g) => g.knobs));
    const mw = analyze(model, groups('Min-Weight k-Clique hypothesis', 'Known algorithms'));
    assert.equal(line(mw, 'Clique / Min-Weight k-Clique'), '≥ n^k  ≤ n^k  (k = 3–6)');
    // (the k-Clique hypothesis meets n^{ωk/3} where 3 divides k; at k = 4, 5 the textbook algorithms are n^k)
    const kc = analyze(model, groups('k-Clique hypothesis', 'Known algorithms'));
    assert.equal(line(kc, 'Clique / k-Clique'), 'k = 3, 6: tight · k = 4, 5: gap');
    const kap = analyze(model, scenario(config.initialKnobs.filter((g) => ['k-AP hypothesis', 'Trivial algorithms', 'Best known algorithms'].includes(g.label)).flatMap((g) => g.knobs)));
    assert.equal(line(kap, 'k-AP Detection', true), 'k=3 UB · 4–6 tight');
  });

  it('keeps the first regime’s line for other problems, and where every value of a parameter gives the same bounds', () => {
    // (Min-Weight k-Cycle: n^3 at every k on dense graphs, with R465)
    for (const p of ['Orthogonal Vectors / OV', '3SUM / 3SUM', 'Graph Triangle Problems / Lopsided All-Edges Sparse Triangle', 'Graph Cycles / Min-Weight k-Cycle']) {
      const s = a.summaries.get(p)!;
      assert.equal(paramFamily(a, s), null, p);
      assert.equal(line(a, p), boundsLine(s.primary), p);
    }
    // Edit distance has regimes for several alphabet sizes, with the same exponents
    const ed = a.summaries.get('String Similarity / Edit Distance')!;
    assert.ok(ed.regimes.filter((r) => r.regime.key.includes('sigma=c')).length >= 2);
    assert.equal(paramFamily(a, ed), null);
  });
});
