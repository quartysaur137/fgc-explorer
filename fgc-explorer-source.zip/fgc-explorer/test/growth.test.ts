import assert from 'node:assert/strict';
import * as G from '../src/growth/growth';
import { EvalError, Growth } from '../src/growth/growth';
import { AssertionError } from '../src/util/assert';

/*
 * Testing strategy for the growth algebra
 *
 * Kinds: const (known / unknown value), log (pow 0, (0,1), 1, >1 — each with/without coef —, ∞), qpoly (pow < 1,
 *   pow > 1, N^{o(1)}), poly (e<0, e>0), polyUnknown, super.
 * add / max / min: pairs across kinds (different rank, same rank), same-rank combination of values/coefs,
 *   polyUnknown vs poly (incomparable)
 * sub: smaller subtrahend, exact constants and log coefficients, equal poly order, larger subtrahend (error)
 * mul / div / inv: each kind × const, poly × poly (incl. cancellation to N^{o(1)}), log × log, zero, super
 * power: known constant exponent × each kind; unknown constant exponent × each kind; growing exponent with constant base
 *   (4^i, (0.27)^i) and with growing base
 * exp2 / log2: each kind, errors
 * ceil / floor / binom / inverseAckermann: constants and growing values
 * exponentOf: each kind (polyUnknown throws)
 * qpoly (2^{c·L^a}): from exp2 of c·L^p (known / unknown / negative c, p < 1, p > 1, p = 0), n^{log n}; order against
 *   each kind (incl. polyUnknown, both sides of power 1, coefficient 0); sums and products (same / other powers,
 *   polynomial and rate-zero factors); powers, log2, inv
 * rates: rateOf (each kind), rateGrowth (each power class, with a scale), compareRates (power first, tolerance),
 *   exponentAtPower (same / larger / smaller power, power 1 = exponentOf)
 * Rep invariant: constructors reject invalid representations.
 */

const C = G.constant;
const P = G.poly;
const L = G.logClass;
const exp = (g: Growth): number => G.exponentOf(g);

describe('growth constructors and rep', () => {
  it('normalizes zero exponents and zero log coefficients', () => {
    assert.deepEqual(P(0), G.SUBPOLY);
    assert.deepEqual(L(1, 0), C(0));
    assert.deepEqual(L(2, 0), C(0));
    const coef = (g: Growth): number | null => (g as { coef: number | null }).coef;
    assert.equal(coef(L(2, 5)), 5, 'kept for every finite power');
    assert.equal(coef(L(Infinity, 5)), null);
    assert.equal(coef(L(0, 5)), null);
    assert.deepEqual(L(1 + 1e-12, 2), L(1, 2), 'a power within 1e-9 of 1 is 1');
    assert.deepEqual(G.qpoly(0.1 * 3, 1), G.qpoly(0.3, 1), 'powers are rounded to 12 decimals');
    assert.deepEqual(P(1e-12), G.SUBPOLY, 'an infinitesimal exponent');
  });

  it('rejects invalid representations and overflow', () => {
    assert.throws(() => P(Infinity), EvalError);
    assert.throws(() => C(NaN), EvalError);
    assert.throws(() => C(Infinity), EvalError);
    assert.throws(() => G.mul(C(1e200), C(1e200)), EvalError);
    assert.throws(() => L(-1), AssertionError);
  });
});

describe('add / max / min', () => {
  it('takes the dominant class', () => {
    assert.deepEqual(G.add(P(2), P(1)), P(2));
    assert.deepEqual(G.add(C(3), P(0.5)), P(0.5));
    assert.deepEqual(G.add(P(-1), C(2)), C(2));
    assert.deepEqual(G.add(L(1, 2), C(7)), L(1, 2));
    assert.deepEqual(G.add(L(2), L(1, 3)), L(2));
    assert.deepEqual(G.add(G.SUPER, P(5)), G.SUPER);
  });

  it('combines equal classes', () => {
    assert.deepEqual(G.add(C(2), C(3)), C(5));
    assert.deepEqual(G.add(C(2), C(null)), C(null));
    assert.deepEqual(G.add(L(1, 0.5), L(1, 0.25)), L(1, 0.75));
    assert.deepEqual(G.max(L(1, 0.5), L(1, 0.25)), L(1, 0.5));
    assert.deepEqual(G.max(C(2), C(3)), C(3));
    assert.deepEqual(G.min(C(2), C(3)), C(2));
    assert.deepEqual(G.min(C(null), C(3)), C(3));
    assert.deepEqual(G.min(L(1, null), L(1, 2)), L(1, 2));
  });

  it('treats polyUnknown as incomparable with positive polynomials', () => {
    assert.deepEqual(G.add(P(2), G.POLY_UNKNOWN), G.POLY_UNKNOWN);
    assert.deepEqual(G.max(G.POLY_UNKNOWN, P(1)), G.POLY_UNKNOWN);
    assert.deepEqual(G.min(G.POLY_UNKNOWN, P(1)), P(1));
    assert.deepEqual(G.add(G.POLY_UNKNOWN, C(1)), G.POLY_UNKNOWN);
    assert.equal(G.compare(G.POLY_UNKNOWN, P(1)), null);
  });
});

describe('signed quantities (exponents of 2)', () => {
  it('orders negative quantities below positive ones and computes exactly', () => {
    assert.deepEqual(G.max(C(5), L(1, -2)), C(5));
    assert.deepEqual(G.min(C(5), L(1, -2)), L(1, -2));
    assert.deepEqual(G.add(C(-2), C(3)), C(1));
    assert.deepEqual(G.sub(C(1), C(-2)), C(3));
    assert.deepEqual(G.add(C(0), P(-1)), P(-1));
    assert.deepEqual(G.add(L(1, -1), L(1, 3)), L(1, 2));
    assert.deepEqual(G.exp2(G.max(C(5), L(1, -2))), C(32));
  });
});

describe('sub / negate', () => {
  it('handles differences', () => {
    assert.deepEqual(G.sub(P(1), C(1)), P(1));
    assert.deepEqual(G.sub(C(1), C(0.25)), C(0.75));
    assert.deepEqual(G.sub(L(1, 1), L(1, 0.25)), L(1, 0.75));
    assert.deepEqual(G.sub(P(1), P(1)), P(1));
    assert.deepEqual(G.sub(C(1), P(-1)), C(1));
    assert.throws(() => G.sub(C(1), P(1)), EvalError);
  });

  it('negates constants and log quantities only', () => {
    assert.deepEqual(G.negate(C(2)), C(-2));
    assert.deepEqual(G.negate(L(1, 2)), L(1, -2));
    assert.throws(() => G.negate(P(1)), EvalError);
  });
});

describe('mul / inv / div', () => {
  it('multiplies classes', () => {
    assert.deepEqual(G.mul(P(1), P(0.5)), P(1.5));
    assert.deepEqual(G.mul(P(1), P(-1)), G.SUBPOLY);
    assert.deepEqual(G.mul(P(2), L(1, 3)), P(2));
    assert.deepEqual(G.mul(C(0.5), L(1, 1)), L(1, 0.5));
    assert.deepEqual(G.mul(C(null), L(1, 1)), L(1, null));
    assert.deepEqual(G.mul(L(1, 1), L(1, 2)), L(2, 2));
    assert.deepEqual(G.mul(L(1), L(1, 2)), L(2));
    assert.deepEqual(G.mul(C(0), G.SUPER), C(0));
    assert.deepEqual(G.mul(G.SUPER, C(2)), G.SUPER);
    assert.deepEqual(G.mul(G.POLY_UNKNOWN, P(1)), G.POLY_UNKNOWN);
    assert.throws(() => G.mul(C(-1), L(2)), EvalError);
  });

  it('inverts classes', () => {
    assert.deepEqual(G.inv(P(2)), P(-2));
    assert.deepEqual(G.inv(C(4)), C(0.25));
    assert.deepEqual(G.inv(L(1, 1)), C(null));
    assert.throws(() => G.inv(C(0)), EvalError);
    assert.deepEqual(G.div(P(1), L(0)), P(1));
  });
});

describe('power / exp2 / log2', () => {
  it('raises to known constant powers', () => {
    assert.deepEqual(G.power(P(2), C(0.5)), P(1));
    assert.deepEqual(G.power(C(3), C(2)), C(9));
    assert.deepEqual(G.power(L(1, 2), C(1)), L(1, 2));
    assert.deepEqual(G.power(L(1, 2), C(0.5)), L(0.5, Math.SQRT2));
    assert.deepEqual(G.power(L(1), C(-1)), C(null));
    assert.deepEqual(G.power(P(5), C(0)), C(1));
    assert.throws(() => G.power(C(-2), C(0.5)), EvalError);
  });

  it('raises to unknown constant powers', () => {
    assert.deepEqual(G.power(P(1), C(null)), G.POLY_UNKNOWN);
    assert.deepEqual(G.power(P(-1), C(null)), C(null));
    assert.deepEqual(G.power(L(1), C(null)), G.POLYLOG);
    assert.deepEqual(G.power(C(2), C(null)), C(null));
  });

  it('raises constants to growing exponents', () => {
    // 4^i with i = 0.5 log2 N is N^1
    assert.deepEqual(G.power(C(4), L(1, 0.5)), P(1));
    // 0.25^i with i = log2 N is N^-2
    assert.deepEqual(G.power(C(0.25), L(1, 1)), P(-2));
    assert.deepEqual(G.power(C(2), P(1)), G.SUPER);
    // n^{log n} = 2^{log² n}
    assert.deepEqual(G.power(P(1), L(1, 1)), G.qpoly(2, 1));
    assert.deepEqual(G.power(L(1, 1), L(1, 1)), G.SUPER);
  });

  it('computes exp2 of each kind', () => {
    assert.deepEqual(G.exp2(C(3)), C(8));
    assert.deepEqual(G.exp2(L(1, 0.5)), P(0.5));
    assert.deepEqual(G.exp2(L(1, null)), G.POLY_UNKNOWN);
    assert.deepEqual(G.exp2(L(0.5)), G.SUBPOLY);
    assert.deepEqual(G.exp2(L(2)), G.SUPER);
    assert.deepEqual(G.exp2(P(1)), G.SUPER);
    assert.deepEqual(G.exp2(P(-1)), C(1));
    assert.throws(() => G.exp2(C(5000)), EvalError);
  });

  it('computes log2 of each kind', () => {
    assert.deepEqual(G.log2(P(3)), L(1, 3));
    assert.deepEqual(G.log2(C(8)), C(3));
    assert.deepEqual(G.log2(L(1, 1)), L(0));
    assert.deepEqual(G.log2(G.POLY_UNKNOWN), L(1, null));
    assert.throws(() => G.log2(C(0)), EvalError);
    assert.throws(() => G.log2(G.SUPER), EvalError);
  });
});

describe('ceil / floor / binom / inverseAckermann', () => {
  it('is exact on known constants, rounds vanishing quantities, and is the identity otherwise', () => {
    assert.deepEqual(G.ceil(P(-0.5)), C(1));
    assert.deepEqual(G.floor(P(-0.5)), C(0));
    assert.deepEqual(G.ceil(C(2.5)), C(3));
    assert.deepEqual(G.ceil(C(3)), C(3));
    assert.deepEqual(G.floor(C(2.5)), C(2));
    assert.deepEqual(G.ceil(P(1)), P(1));
    assert.deepEqual(G.binom(C(5), C(2)), C(10));
    assert.deepEqual(G.binom(P(1), C(2)), P(2));
    assert.throws(() => G.binom(P(1), P(1)), EvalError);
    assert.deepEqual(G.inverseAckermann(P(1)), L(0));
    assert.deepEqual(G.inverseAckermann(C(7)), C(null));
  });
});

describe('exponentOf / describe', () => {
  it('extracts exponents', () => {
    assert.equal(exp(P(1.5)), 1.5);
    assert.equal(exp(C(3)), 0);
    assert.equal(exp(L(2)), 0);
    assert.equal(exp(G.SUPER), Infinity);
    assert.throws(() => exp(G.POLY_UNKNOWN), EvalError);
  });

  it('describes classes', () => {
    assert.equal(G.describe(P(1.5)), 'N^1.5');
    assert.equal(G.describe(L(1, 0.5)), '0.5·log₂N');
    assert.equal(G.formatNumber(2.0000001), '2');
    assert.equal(G.formatNumber(Infinity), '∞');
  });
});

describe('classes 2^{c·L^a} (qpoly)', () => {
  const Q = G.qpoly;

  it('arise as 2 to the power c·L^p', () => {
    // 2^{0.5 n^{0.75}} with n = log2 N
    assert.deepEqual(G.exp2(G.mul(C(0.5), G.power(L(1, 1), C(0.75)))), Q(0.75, 0.5));
    assert.deepEqual(G.exp2(L(2, 1)), Q(2, 1));
    assert.deepEqual(G.exp2(L(0.5)), G.SUBPOLY, '2^{O(√L)} is N^{o(1)}');
    assert.deepEqual(G.exp2(L(2)), G.SUPER, '2^{O(L²)}: no useful bound');
    assert.deepEqual(G.exp2(L(0.5, -1)), C(null), 'vanishing');
    assert.deepEqual(G.exp2(L(0)), G.POLYLOG, 'rate zero');
    assert.deepEqual(Q(1, 3), P(3));
    assert.deepEqual(Q(1, 0), G.SUBPOLY);
    assert.deepEqual(Q(0.5, -1), C(null));
    assert.throws(() => Q(0, 1), EvalError);
  });

  it('are ordered by power, then coefficient', () => {
    assert.equal(G.compare(Q(0.9, 100), P(0.001)), -1, 'below every polynomial');
    assert.equal(G.compare(Q(0.9, 100), G.SUBPOLY), -1, 'N^{o(1)} contains it');
    assert.equal(G.compare(G.POLYLOG, Q(0.1, 0.1)), -1, 'above rate zero');
    assert.equal(G.compare(Q(0.5, 2), Q(0.5, 1)), 1);
    assert.equal(G.compare(Q(0.5, 1), Q(0.6, 0)), -1);
    assert.equal(G.compare(Q(1.1, 0.01), P(1000)), 1, 'above every polynomial');
    assert.equal(G.compare(Q(2, 1), G.SUPER), -1);
    assert.equal(G.compare(Q(0.5, 1), G.POLY_UNKNOWN), -1);
    assert.equal(G.compare(G.POLY_UNKNOWN, Q(2, 0)), -1, 'N^{O(1)} ⊆ 2^{o(L²)}');
    assert.equal(G.compare(G.POLY_UNKNOWN, G.SUBPOLY), 1);
    // negative c·L^p (exponents of 2): −L is below −√L
    assert.equal(G.compare(L(1, -1), L(0.5, -1)), -1);
    assert.equal(G.compare(L(1, 1), L(0.5, 1)), 1);
  });

  it('add, multiply and take powers', () => {
    assert.deepEqual(G.max(Q(0.5, 1), Q(0.5, 2)), Q(0.5, 2));
    assert.deepEqual(G.add(Q(0.75, 1), L(1, 3)), Q(0.75, 1));
    assert.deepEqual(G.add(L(0.5, 1), L(0.5, 2)), L(0.5, 3), 'exact on equal powers');
    assert.deepEqual(G.sub(L(1, 1), L(0.5, 1)), L(1, 1));
    // √n − n·log2(1/2) = √n + n
    assert.deepEqual(G.sub(L(0.5, 1), L(1, -1)), L(1, 1), 'subtracting a negative quantity adds it');
    assert.deepEqual(G.sub(P(1), C(-2)), P(1));
    assert.deepEqual(G.mul(Q(0.5, 1), Q(0.5, 2)), Q(0.5, 3));
    assert.deepEqual(G.mul(Q(0.3, 5), Q(0.1 * 3, 1)), Q(0.3, 6), 'one power, however computed');
    assert.deepEqual(G.mul(Q(0.5, 1), Q(0.75, 2)), Q(0.75, 2));
    assert.deepEqual(G.mul(Q(0.5, 1), P(1)), P(1), 'absorbed by polynomials');
    assert.deepEqual(G.mul(Q(0.5, 1), G.SUBPOLY), G.SUBPOLY);
    assert.deepEqual(G.mul(Q(2, 1), P(5)), Q(2, 1), 'absorbs polynomials');
    assert.deepEqual(G.mul(Q(2, 1), G.POLY_UNKNOWN), Q(2, 1));
    assert.deepEqual(G.mul(Q(0.5, 1), G.POLYLOG), Q(0.5, 1), 'polylogarithmic factors do not count');
    assert.deepEqual(G.mul(C(3), Q(0.5, 1)), Q(0.5, 1));
    assert.deepEqual(G.mul(C(-0.5), L(0.75, 1)), L(0.75, -0.5));
    assert.deepEqual(G.power(Q(0.5, 1), C(2)), Q(0.5, 2));
    assert.deepEqual(G.power(Q(0.5, 1), C(null)), G.SUBPOLY);
    assert.deepEqual(G.power(Q(2, 1), C(null)), G.SUPER);
    assert.deepEqual(G.power(Q(0.5, 1), C(-1)), C(null));
    assert.deepEqual(G.power(C(4), L(0.5, 1)), Q(0.5, 2), '4^{√L} = 2^{2√L}');
    assert.deepEqual(G.inv(Q(0.5, 1)), C(null));
    assert.deepEqual(G.log2(Q(0.75, 0.5)), L(0.75, 0.5));
    assert.deepEqual(G.log2(G.SUBPOLY), L(1, null));
    assert.deepEqual(G.ceil(Q(0.5, 1)), Q(0.5, 1));
  });

  it('have exponent 0 below power 1 and ∞ above, and describe themselves', () => {
    assert.equal(exp(Q(0.5, 1)), 0);
    assert.equal(exp(G.SUBPOLY), 0);
    assert.equal(exp(Q(2, 1)), Infinity);
    assert.equal(G.describe(Q(0.75, 0.5)), '2^{0.5·log₂^0.75 N}');
    assert.equal(G.describe(G.SUBPOLY), 'N^{o(1)}');
  });
});

describe('rates', () => {
  const R = (power: number, exponent: number): G.Rate => ({ power, exponent });

  it('of each kind', () => {
    assert.deepEqual(G.rateOf(P(2)), R(1, 2));
    assert.deepEqual(G.rateOf(P(-1)), G.RATE_ZERO);
    assert.deepEqual(G.rateOf(C(3)), G.RATE_ZERO);
    assert.deepEqual(G.rateOf(L(2, 1)), G.RATE_ZERO);
    assert.deepEqual(G.rateOf(G.POLYLOG), G.RATE_ZERO);
    assert.deepEqual(G.rateOf(G.SUBPOLY), R(1, 0));
    assert.deepEqual(G.rateOf(G.qpoly(0.75, 0.5)), R(0.75, 0.5));
    assert.deepEqual(G.rateOf(G.SUPER), G.RATE_NONE);
    assert.throws(() => G.rateOf(G.POLY_UNKNOWN), EvalError);
  });

  it('of a time on an instance of size N^s', () => {
    assert.deepEqual(G.rateGrowth(R(1, 2), 0.5), P(1));
    assert.deepEqual(G.rateGrowth(R(1, 0), 2), G.SUBPOLY);
    // 2^{0.5·(2L)^{0.75}}
    assert.deepEqual(G.rateGrowth(R(0.75, 0.5), 2), G.qpoly(0.75, 0.5 * 2 ** 0.75));
    assert.deepEqual(G.rateGrowth(G.RATE_ZERO, 3), G.POLYLOG);
    assert.deepEqual(G.rateGrowth(G.RATE_NONE, 1), G.SUPER);
  });

  it('are compared power first', () => {
    assert.equal(G.compareRates(R(0.99, 100), R(1, 0.01), 1e-9), -1);
    assert.equal(G.compareRates(R(1, 2), R(1, 2 + 1e-12), 1e-9), 0);
    assert.equal(G.compareRates(R(1, 2), R(1 + 1e-12, 1), 1e-9), 1, 'powers within 1e-9 are equal');
    assert.equal(G.compareRates(G.RATE_ZERO, R(0.5, 0), 0), -1);
    assert.deepEqual(G.maxRate(R(0.5, 9), R(1, 0)), R(1, 0));
  });

  it('give exponents at a power', () => {
    assert.equal(G.exponentAtPower(G.qpoly(0.75, 0.5), 0.75), 0.5);
    assert.equal(G.exponentAtPower(P(2), 0.75), Infinity, 'grows faster');
    assert.equal(G.exponentAtPower(C(1), 0.75), 0, 'grows slower');
    assert.equal(G.exponentAtPower(P(-1), 1), -1, 'power 1 is exponentOf');
    assert.equal(G.exponentAtPower(G.qpoly(0.5, 3), 1), 0);
  });
});
