import assert from 'node:assert/strict';
import * as G from '../src/growth/growth';
import { EvalError, Growth } from '../src/growth/growth';
import { AssertionError } from '../src/util/assert';

/*
 * Testing strategy for the growth algebra
 *
 * Kinds: const (known / unknown value), log (pow 0, (0,1), 1 with/without coef, >1, ∞), poly (e<0, e>0),
 *   polyUnknown, super.
 * add / max / min: pairs across kinds (different rank, same rank), same-rank combination of values/coefs,
 *   polyUnknown vs poly (incomparable)
 * sub: smaller subtrahend, exact constants and log coefficients, equal poly order, larger subtrahend (error)
 * mul / div / inv: each kind × const, poly × poly (incl. cancellation to N^{o(1)}), log × log, zero, super
 * power: known constant exponent × each kind; unknown constant exponent × each kind; growing exponent with constant base
 *   (4^i, (0.27)^i) and with growing base
 * exp2 / log2: each kind, errors
 * ceil / floor / binom / inverseAckermann: constants and growing values
 * exponentOf: each kind (polyUnknown throws)
 * Rep invariant: constructors reject invalid representations.
 */

const C = G.constant;
const P = G.poly;
const L = G.logClass;
const exp = (g: Growth): number => G.exponentOf(g);

describe('growth constructors and rep', () => {
  it('normalizes zero exponents and zero log coefficients', () => {
    assert.deepEqual(P(0), G.SUBPOLY);
    assert.deepEqual(L(1, 0), C(0));
    assert.equal(L(2, 5).kind === 'log' && (L(2, 5) as { coef: number | null }).coef, null);
  });

  it('rejects invalid representations and overflow', () => {
    assert.throws(() => P(Infinity), EvalError);
    assert.throws(() => C(NaN), EvalError);
    assert.throws(() => C(Infinity), EvalError);
    assert.throws(() => G.mul(C(1e200), C(1e200)), EvalError);
    assert.throws(() => L(-1), AssertionError);
  });
});

describe('add / max / min', () => {
  it('takes the dominant class', () => {
    assert.deepEqual(G.add(P(2), P(1)), P(2));
    assert.deepEqual(G.add(C(3), P(0.5)), P(0.5));
    assert.deepEqual(G.add(P(-1), C(2)), C(2));
    assert.deepEqual(G.add(L(1, 2), C(7)), L(1, 2));
    assert.deepEqual(G.add(L(2), L(1, 3)), L(2));
    assert.deepEqual(G.add(G.SUPER, P(5)), G.SUPER);
  });

  it('combines equal classes', () => {
    assert.deepEqual(G.add(C(2), C(3)), C(5));
    assert.deepEqual(G.add(C(2), C(null)), C(null));
    assert.deepEqual(G.add(L(1, 0.5), L(1, 0.25)), L(1, 0.75));
    assert.deepEqual(G.max(L(1, 0.5), L(1, 0.25)), L(1, 0.5));
    assert.deepEqual(G.max(C(2), C(3)), C(3));
    assert.deepEqual(G.min(C(2), C(3)), C(2));
    assert.deepEqual(G.min(C(null), C(3)), C(3));
    assert.deepEqual(G.min(L(1, null), L(1, 2)), L(1, 2));
  });

  it('treats polyUnknown as incomparable with positive polynomials', () => {
    assert.deepEqual(G.add(P(2), G.POLY_UNKNOWN), G.POLY_UNKNOWN);
    assert.deepEqual(G.max(G.POLY_UNKNOWN, P(1)), G.POLY_UNKNOWN);
    assert.deepEqual(G.min(G.POLY_UNKNOWN, P(1)), P(1));
    assert.deepEqual(G.add(G.POLY_UNKNOWN, C(1)), G.POLY_UNKNOWN);
    assert.equal(G.compare(G.POLY_UNKNOWN, P(1)), null);
  });
});

describe('signed quantities (exponents of 2)', () => {
  it('orders negative quantities below positive ones and computes exactly', () => {
    assert.deepEqual(G.max(C(5), L(1, -2)), C(5));
    assert.deepEqual(G.min(C(5), L(1, -2)), L(1, -2));
    assert.deepEqual(G.add(C(-2), C(3)), C(1));
    assert.deepEqual(G.sub(C(1), C(-2)), C(3));
    assert.deepEqual(G.add(C(0), P(-1)), P(-1));
    assert.deepEqual(G.add(L(1, -1), L(1, 3)), L(1, 2));
    assert.deepEqual(G.exp2(G.max(C(5), L(1, -2))), C(32));
  });
});

describe('sub / negate', () => {
  it('handles differences', () => {
    assert.deepEqual(G.sub(P(1), C(1)), P(1));
    assert.deepEqual(G.sub(C(1), C(0.25)), C(0.75));
    assert.deepEqual(G.sub(L(1, 1), L(1, 0.25)), L(1, 0.75));
    assert.deepEqual(G.sub(P(1), P(1)), P(1));
    assert.deepEqual(G.sub(C(1), P(-1)), C(1));
    assert.throws(() => G.sub(C(1), P(1)), EvalError);
  });

  it('negates constants and log quantities only', () => {
    assert.deepEqual(G.negate(C(2)), C(-2));
    assert.deepEqual(G.negate(L(1, 2)), L(1, -2));
    assert.throws(() => G.negate(P(1)), EvalError);
  });
});

describe('mul / inv / div', () => {
  it('multiplies classes', () => {
    assert.deepEqual(G.mul(P(1), P(0.5)), P(1.5));
    assert.deepEqual(G.mul(P(1), P(-1)), G.SUBPOLY);
    assert.deepEqual(G.mul(P(2), L(1, 3)), P(2));
    assert.deepEqual(G.mul(C(0.5), L(1, 1)), L(1, 0.5));
    assert.deepEqual(G.mul(C(null), L(1, 1)), L(1, null));
    assert.deepEqual(G.mul(L(1, 1), L(1, 2)), L(2));
    assert.deepEqual(G.mul(C(0), G.SUPER), C(0));
    assert.deepEqual(G.mul(G.SUPER, C(2)), G.SUPER);
    assert.deepEqual(G.mul(G.POLY_UNKNOWN, P(1)), G.POLY_UNKNOWN);
    assert.throws(() => G.mul(C(-1), L(2)), EvalError);
  });

  it('inverts classes', () => {
    assert.deepEqual(G.inv(P(2)), P(-2));
    assert.deepEqual(G.inv(C(4)), C(0.25));
    assert.deepEqual(G.inv(L(1, 1)), C(null));
    assert.throws(() => G.inv(C(0)), EvalError);
    assert.deepEqual(G.div(P(1), L(0)), P(1));
  });
});

describe('power / exp2 / log2', () => {
  it('raises to known constant powers', () => {
    assert.deepEqual(G.power(P(2), C(0.5)), P(1));
    assert.deepEqual(G.power(C(3), C(2)), C(9));
    assert.deepEqual(G.power(L(1, 2), C(1)), L(1, 2));
    assert.deepEqual(G.power(L(1, 2), C(0.5)), L(0.5));
    assert.deepEqual(G.power(L(1), C(-1)), C(null));
    assert.deepEqual(G.power(P(5), C(0)), C(1));
    assert.throws(() => G.power(C(-2), C(0.5)), EvalError);
  });

  it('raises to unknown constant powers', () => {
    assert.deepEqual(G.power(P(1), C(null)), G.POLY_UNKNOWN);
    assert.deepEqual(G.power(P(-1), C(null)), C(null));
    assert.deepEqual(G.power(L(1), C(null)), G.SUBPOLY);
    assert.deepEqual(G.power(C(2), C(null)), C(null));
  });

  it('raises constants to growing exponents', () => {
    // 4^i with i = 0.5 log2 N is N^1
    assert.deepEqual(G.power(C(4), L(1, 0.5)), P(1));
    // 0.25^i with i = log2 N is N^-2
    assert.deepEqual(G.power(C(0.25), L(1, 1)), P(-2));
    assert.deepEqual(G.power(C(2), P(1)), G.SUPER);
    assert.deepEqual(G.power(P(1), L(1, 1)), G.SUPER);
  });

  it('computes exp2 of each kind', () => {
    assert.deepEqual(G.exp2(C(3)), C(8));
    assert.deepEqual(G.exp2(L(1, 0.5)), P(0.5));
    assert.deepEqual(G.exp2(L(1, null)), G.POLY_UNKNOWN);
    assert.deepEqual(G.exp2(L(0.5)), G.SUBPOLY);
    assert.deepEqual(G.exp2(L(2)), G.SUPER);
    assert.deepEqual(G.exp2(P(1)), G.SUPER);
    assert.deepEqual(G.exp2(P(-1)), C(1));
    assert.throws(() => G.exp2(C(5000)), EvalError);
  });

  it('computes log2 of each kind', () => {
    assert.deepEqual(G.log2(P(3)), L(1, 3));
    assert.deepEqual(G.log2(C(8)), C(3));
    assert.deepEqual(G.log2(L(1, 1)), L(0));
    assert.deepEqual(G.log2(G.POLY_UNKNOWN), L(1, null));
    assert.throws(() => G.log2(C(0)), EvalError);
    assert.throws(() => G.log2(G.SUPER), EvalError);
  });
});

describe('ceil / floor / binom / inverseAckermann', () => {
  it('is exact on known constants, rounds vanishing quantities, and is the identity otherwise', () => {
    assert.deepEqual(G.ceil(P(-0.5)), C(1));
    assert.deepEqual(G.floor(P(-0.5)), C(0));
    assert.deepEqual(G.ceil(C(2.5)), C(3));
    assert.deepEqual(G.ceil(C(3)), C(3));
    assert.deepEqual(G.floor(C(2.5)), C(2));
    assert.deepEqual(G.ceil(P(1)), P(1));
    assert.deepEqual(G.binom(C(5), C(2)), C(10));
    assert.deepEqual(G.binom(P(1), C(2)), P(2));
    assert.throws(() => G.binom(P(1), P(1)), EvalError);
    assert.deepEqual(G.inverseAckermann(P(1)), L(0));
    assert.deepEqual(G.inverseAckermann(C(7)), C(null));
  });
});

describe('exponentOf / describe', () => {
  it('extracts exponents', () => {
    assert.equal(exp(P(1.5)), 1.5);
    assert.equal(exp(C(3)), 0);
    assert.equal(exp(L(2)), 0);
    assert.equal(exp(G.SUPER), Infinity);
    assert.throws(() => exp(G.POLY_UNKNOWN), EvalError);
  });

  it('describes classes', () => {
    assert.equal(G.describe(P(1.5)), 'N^1.5');
    assert.equal(G.describe(L(1, 0.5)), '0.5·log₂N');
    assert.equal(G.formatNumber(2.0000001), '2');
    assert.equal(G.formatNumber(Infinity), '∞');
  });
});
