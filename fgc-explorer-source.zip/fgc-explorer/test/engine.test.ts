import assert from 'node:assert/strict';
import { analyze, Analysis, statusOf, ubPath } from '../src/engine/analysis';
import { lbChain, threshold } from '../src/engine/lower';
import { UpperBounds } from '../src/engine/upper';
import { model, near, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for propagation (lower.ts, upper.ts, analysis.ts) on synthetic sheets
 *
 * threshold: g(0) ≥ L, root inside, unbounded, superpolynomial values, flat pieces
 * LB propagation, partition on: chain length (1, 2, 12: no limit), cycles (neutral, raising the bound towards a finite
 *   limit, without limit), scale of the produced instance (≠ 1), RT (below / at the LB, unknown with each policy), free
 *   parameters (none, constant-key grid with refinement, key-changing grid, blocked boundary optimum), calls (single,
 *   several in one regime, several regimes, none → inconsistency), exponential-scale sources, sums, requires,
 *   disabled / randomized rows; an infinite lower bound (through a reduction: infinite)
 * UB evaluation: formula knobs (all regimes / filtered), exponent knobs (exact regime only), through rows (scale,
 *   RT dominates), chain length (12 through regimes of interest: no limit), detours through regimes not of interest
 *   (within / beyond maxDepthUB, pinned regimes count as listed), cycles (neutral, lowering the bound towards a limit),
 *   several calls in different regimes; the same bound for a problem wherever it is used (its own regime, or inside
 *   the derivation of another problem; asked for first or later; whatever the order of the rows in the sheet; at a
 *   regime of lower bounds only, before and after a lower bound changes); cycles through \min of calls (not convex: the
 *   limit is approached lap by lap, never jumped over)
 * analysis: statuses (conflict, tight, gap, lb, ub, none), knob issues (unknown problem, bad regime, dynamic problem,
 *   formula errors), const-list LB knobs with formulas, reuse of previous results
 */

const lbOf = (a: Analysis, problem: string, key: string): number | undefined => a.lower.facts.get(problem)?.get(key)?.exponent;
/** P0 → P1 → … → Pn, each solving the next on the same instance. */
const chainRows = (n: number): RowSpec[] =>
  Array.from({ length: n }, (_, i) => ({ id: `c${i}`, from: `L / P${i}`, to: `L / P${i + 1}`, toTime: '$T(n)$', fromTime: '$O(T(n))$' }));
const ubOf = (a: Analysis, problem: string, key: string): number | undefined =>
  a.summaries.get(problem)?.regimes.find((r) => r.regime.key === key)?.ub?.exponent;

describe('threshold', () => {
  it('finds the smallest x with g(x) ≥ L', () => {
    assert.equal(threshold((x) => 1 + x / 2, 1), 0);
    assert.ok(near(threshold((x) => 1 + x / 2, 2) as number, 2, 1e-8));
    assert.ok(near(threshold((x) => Math.max(x, 2), 2.5) as number, 2.5, 1e-8));
    assert.equal(threshold(() => 1, 2), 'unbounded');
    assert.ok(near(threshold((x) => (x > 10 ? Infinity : x), 3) as number, 3, 1e-8));
    assert.ok(near(threshold((x) => Math.min(x, 5) + Math.max(0, x - 7), 6) as number, 8, 1e-8));
  });
});

const A = 'F / A';
const B = 'F / B';
const C = 'F / C';
const base: RowSpec[] = [
  // A(n) via n calls on B instances of size sqrt(n): A ≤ n · T_B(√n)
  { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n \\cdot T(\\sqrt{n}))$', rt: '$O(n)$' },
  // B(n) → C(n, n^2), identity-like
  { id: 'bc', from: B, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$', rt: '$O(n^2)$' },
];
const cfg = { problems: { [A]: { params: ['n'] } } };

describe('lower-bound propagation', () => {
  it('propagates along a chain with scaling', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 3 }]));
    // 1 + x/2 ≥ 3 ⇒ x ≥ 4 for B; then C(n, n^2) ≥ 4 (RT n^2 < 4)
    assert.ok(near(lbOf(a, B, 'n=p1'), 4));
    assert.ok(near(lbOf(a, C, 'n=p1|m=p2'), 4));
    const chain = lbChain(a.lower.facts.get(C)!.get('n=p1|m=p2')!);
    assert.deepEqual(
      chain.map((f) => [f.problem, f.hops]),
      [
        [C, 2],
        [B, 1],
        [A, 0],
      ],
    );
  });

  it('is blocked when the reduction itself is too slow, and respects the unknown-RT policy', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: B, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.equal(lbOf(a, C, 'n=p1|m=p2'), undefined, 'RT n^2 is not below the LB 2');
    const rows: RowSpec[] = [{ ...base[1]!, rt: '??' }];
    const m = model(rows);
    assert.ok(near(lbOf(analyze(m, scenario([{ problem: B, kind: 'LB', regime: 'n=1', exponent: 2 }])), C, 'n=p1|m=p2'), 2));
    const blocked = analyze(m, scenario([{ problem: B, kind: 'LB', regime: 'n=1', exponent: 2 }], { unknownRT: 'block' }));
    assert.equal(lbOf(blocked, C, 'n=p1|m=p2'), undefined);
  });

  it('handles free parameters whose optimum is at a blocked boundary', () => {
    const rows: RowSpec[] = [{ id: 'x', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(X \\cdot T(n))$', rt: '$O(n^2/X)$' }];
    const m = model(rows, { ...cfg, rows: { x: { free: [{ name: 'X', type: 'size', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    const x = lbOf(a, B, 'n=p1')!;
    assert.ok(x < 2 && x > 2 - 1e-3, String(x));
  });

  it('keeps one fact per target regime when free parameters move the regime', () => {
    const rows: RowSpec[] = [{ id: 'x', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^{1+r}))$', rt: '$O(n)$' }];
    const m = model(rows, { ...cfg, rows: { x: { free: [{ name: 'r', type: 'real', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }], { gridPoints: 5 }));
    assert.deepEqual(
      [...a.lower.facts.get(C)!.keys()].sort(),
      ['n=p1|m=p1', 'n=p1|m=p1.25', 'n=p1|m=p1.5', 'n=p1|m=p1.75', 'n=p1|m=p2'],
    );
  });

  it('allows several calls in one target regime but not in several', () => {
    const rows: RowSpec[] = [
      { id: 'same', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n) + n \\cdot T(\\sqrt{n}))$' },
      { id: 'mixed', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n) + T(n, n^2))$' },
    ];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 3 }]));
    // max(x, 1 + x/2) ≥ 3 ⇒ x ≥ 3
    assert.ok(near(lbOf(a, B, 'n=p1'), 3));
    assert.equal(a.lower.facts.get(C), undefined);
  });

  it('records rows that would beat a lower bound without calling the target', () => {
    const rows: RowSpec[] = [{ id: 'x', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n \\cdot T(1))$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.equal(a.lower.inconsistencies.length, 1);
    assert.equal(a.lower.inconsistencies[0]!.rowId, 'x');
  });

  it('works with exponential-time sources', () => {
    const S = 'SAT / S';
    const O = 'OV / O';
    const rows: RowSpec[] = [{ id: 'so', from: S, to: O, toTime: '$T(n, d)$', fromTime: '$O(T(2^{n/2}, m))$', rt: '$O(2^{n/2} n m)$' }];
    const m = model(rows, { problems: { [S]: { params: ['n', 'm'], timeType: 'exp', regimes: ['n=log, m=polylog'] }, [O]: { regimes: ['n=1, d=polylog'] } } });
    const a = analyze(m, scenario([{ problem: S, kind: 'LB', regime: 'n=log, m=polylog', exponent: 1 }, { problem: O, kind: 'UB', formula: 'n^2 d' }]));
    assert.ok(near(lbOf(a, O, 'n=p1|d=L'), 2));
    assert.ok(near(ubOf(a, S, 'n=E|m=L'), 1));
    assert.equal(a.summaries.get(S)!.status, 'tight');
  });

  it('evaluates sums over logarithmic ranges', () => {
    const rows: RowSpec[] = [{ id: 's', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(\\sum_{i=0}^{\\log n} 4^i \\cdot T(n/2^i))$' }];
    const m = model(rows, cfg);
    assert.ok(near(lbOf(analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2.5 }])), B, 'n=p1'), 2.5, 1e-6));
    assert.equal(lbOf(analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1.5 }])), B, 'n=p1'), undefined);
  });

  it('respects requires, disabled and randomized rows', () => {
    const rows: RowSpec[] = [
      { id: 'r', from: C, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
      { id: 'q', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$', randomized: 'Yes' },
      { id: 'bc', from: B, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
    ];
    const m = model(rows, { ...cfg, rows: { r: { requires: 'm=2' } } });
    const lbC = (spec: string) => analyze(m, scenario([{ problem: C, kind: 'LB', regime: spec, exponent: 2 }]));
    assert.ok(near(lbOf(lbC('n=1, m=2'), B, 'n=p1'), 2));
    assert.equal(lbOf(lbC('n=1, m=1'), B, 'n=p1'), undefined);
    const knob = [{ problem: A, kind: 'LB' as const, regime: 'n=1', exponent: 2 }];
    assert.ok(near(lbOf(analyze(m, scenario(knob)), B, 'n=p1'), 2));
    assert.equal(lbOf(analyze(m, scenario(knob, { useRandomized: false })), B, 'n=p1'), undefined);
    assert.equal(lbOf(analyze(m, scenario(knob, { disabledRows: ['q'] })), B, 'n=p1'), undefined);
  });

  it('has no limit on the length of derivations', () => {
    const a = analyze(model(chainRows(12)), scenario([{ problem: 'L / P0', kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.ok(near(lbOf(a, 'L / P12', 'n=p1'), 2));
    assert.equal(a.lower.facts.get('L / P12')!.get('n=p1')!.hops, 12);
  });

  it('approaches the limit of a cycle through \\min lap by lap, without jumping over it', () => {
    // P(n) calls P(n) for min(n^{2/3} T(n)^{2/3}, T(n)^2/n^2): once around, L becomes max(L/2 + 1, 1.5L − 1), which
    // rises from 1 towards 2 and, above 2, would rise without limit: a fixed point that probes must not jump over.
    const m = model([
      { id: 'pp', from: A, to: A, toTime: '$T(n)$', fromTime: '$O(\\min(n^{2/3} T(n)^{2/3}, T(n)^2 / n^2))$', rt: '$O(1)$' },
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$O(1)$' },
    ]);
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1 }, { problem: B, kind: 'UB', formula: 'n^{2.5}' }]));
    const x = lbOf(a, A, 'n=p1')!;
    assert.ok(x <= 2 && x > 2 - 1e-6, String(x));
    assert.equal(a.summaries.get(B)!.status, 'gap', 'no false conflict with the n^2.5 algorithm');
  });

  it('replaces a bound that keeps rising around a cycle by the limit, finite or not', () => {
    // A(n) calls B on instances of size n^2 for T_B(n^2)/n^3 (synthetic), B(n) calls A(n): once around, a lower
    // bound L of A becomes (L + 3)/2, which rises towards 3 (less TOL per reduction: thresholds are found from below).
    const finite = model([
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n^2) / n^3)$', rt: '$O(1)$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$O(1)$' },
    ]);
    const a = analyze(finite, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    const fa = a.lower.facts.get(A)!.get('n=p1')!;
    assert.ok(near(fa.exponent, 3, 1e-8) && fa.exponent <= 3, String(fa.exponent));
    assert.ok(near(lbOf(a, B, 'n=p1'), 3, 1e-8));
    assert.equal(fa.origin.kind, 'cycle');
    assert.equal(a.lower.cycles.length, 1);
    assert.deepEqual(
      lbChain(fa).map((f) => [f.problem, f.origin.kind]),
      [
        [A, 'cycle'],
        [A, 'row'],
        [B, 'row'],
        [A, 'knob'],
      ],
    );
    // A(n) calls B on instances of size √n, B(n) calls A in time n·T_A(n): L becomes 2L − 1, without limit for L > 1.
    const divergent = model([
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(\\sqrt{n}))$', rt: '$O(1)$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n)$', fromTime: '$O(n \\cdot T(n))$', rt: '$O(1)$' },
      { id: 'bc', from: B, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$', rt: '$O(1)$' },
    ]);
    const d = analyze(divergent, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1.5 }]));
    assert.equal(lbOf(d, A, 'n=p1'), Infinity);
    assert.equal(lbOf(d, B, 'n=p1'), Infinity);
    assert.equal(lbOf(d, C, 'n=p1|m=p1'), Infinity, 'an infinite bound transfers through reductions');
    assert.deepEqual(d.lower.capped, []);
    // The superpolynomial bound also crosses calls under roots (√T: the From-time still grows without limit).
    const roots = model([
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(\\sqrt{n}))$', rt: '$O(1)$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n)$', fromTime: '$O(n \\cdot T(n))$', rt: '$O(1)$' },
      { id: 'bd', from: B, to: 'F / D', toTime: '$T(n)$', fromTime: '$O(\\sqrt{T(n)})$', rt: '$O(1)$' },
    ]);
    const r = analyze(roots, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1.5 }]));
    assert.equal(lbOf(r, 'F / D', 'n=p1'), Infinity);
    assert.deepEqual(r.lower.inconsistencies, []);
    // At L = 1 the cycle does not raise the bound (a fixed point): nothing changes.
    const fixed = analyze(divergent, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1 }]));
    assert.ok(near(lbOf(fixed, A, 'n=p1'), 1));
    assert.ok(near(lbOf(fixed, B, 'n=p1'), 2));
    assert.deepEqual(fixed.lower.cycles, []);
  });

  it('terminates on cycles', () => {
    const rows: RowSpec[] = [
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    ];
    const a = analyze(model(rows), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }, { problem: B, kind: 'UB', formula: 'n^{1.5}' }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 2));
    assert.ok(near(ubOf(a, A, 'n=p1'), 1.5));
    assert.equal(a.summaries.get(A)!.status, 'conflict');
  });
});

describe('upper-bound evaluation', () => {
  it('propagates backward with scaling and reduction runtime', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n \\cdot m' }]));
    // C(n, n^2) = n^3 ⇒ B ≤ max(3, RT 2) = 3 ⇒ A ≤ 1 + 3/2 = 2.5
    assert.ok(near(ubOf(a, B, 'n=p1'), 3));
    assert.ok(near(ubOf(a, A, 'n=p1'), 2.5));
    // RT dominates: C ≤ n ⇒ B ≤ max(1, 2) = 2
    const b = analyze(model(base, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n' }]));
    assert.ok(near(ubOf(b, B, 'n=p1'), 2));
  });

  it('applies exponent knobs only at their regime and formula knobs at matching regimes', () => {
    const m = model(base, { ...cfg, problems: { ...cfg.problems, [C]: { regimes: ['n=1, m=2', 'n=1, m=1'] } } });
    const a = analyze(
      m,
      scenario([
        { problem: C, kind: 'UB', regime: 'n=1, m=2', exponent: 2.5 },
        { problem: C, kind: 'UB', regime: 'm=1', formula: 'n^{1.2}' },
      ]),
    );
    assert.ok(near(ubOf(a, C, 'n=p1|m=p2'), 2.5));
    assert.ok(near(ubOf(a, C, 'n=p1|m=p1'), 1.2));
  });

  it('passes a knob on to the nodes that read its node before it was solved (deep chains)', () => {
    // Solving nests at most 120 deep; deeper nodes are solved afterwards, and the nodes that read them must learn
    // of their knobs then.
    const a = analyze(model(chainRows(125)), scenario([{ problem: 'L / P125', kind: 'UB', regime: 'n=1', exponent: 1.5 }]));
    for (const i of [0, 4, 5, 6, 124]) assert.ok(near(ubOf(a, `L / P${i}`, 'n=p1'), 1.5), `P${i}`);
  });

  it('has no limit on the length of derivations through listed regimes', () => {
    // P0 → P1 → … → P12, all at their listed regime n = 1: found even when no detour is allowed.
    const a = analyze(model(chainRows(12)), scenario([{ problem: 'L / P12', kind: 'UB', formula: 'n^{1.5}' }], { maxDepthUB: 0 }));
    for (let i = 0; i <= 12; i++) assert.ok(near(ubOf(a, `L / P${i}`, 'n=p1'), 1.5), `P${i}`);
    assert.equal(a.summaries.get('L / P0')!.primary!.ub!.steps, 12);
  });

  it('limits only detours through regimes that are not of interest', () => {
    // A(n) → C(n, n^2) → D(n, n^2) → E(n^2): C and D are configured at m = n only, so the derivation passes through
    // two regimes that are not of interest.
    const E = 'F / E';
    const D = 'F / D';
    const rows: RowSpec[] = [
      { id: 'ac', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
      { id: 'cd', from: C, to: D, toTime: '$T(n, m)$', fromTime: '$O(T(n, m))$' },
      { id: 'de', from: D, to: E, toTime: '$T(n)$', fromTime: '$O(T(m))$' },
    ];
    const m = model(rows);
    const knobs = [{ problem: E, kind: 'UB' as const, formula: 'n' }];
    assert.equal(ubOf(analyze(m, scenario(knobs, { maxDepthUB: 1 })), A, 'n=p1'), undefined);
    assert.ok(near(ubOf(analyze(m, scenario(knobs, { maxDepthUB: 2 })), A, 'n=p1'), 2));
    // A pinned regime is listed: through it, one detour is enough.
    const pinned = analyze(m, scenario(knobs, { maxDepthUB: 1 }), new Map([[D, ['n=1, m=2']]]));
    assert.ok(near(ubOf(pinned, A, 'n=p1'), 2));
  });

  it('gives a problem the same bound wherever it is used, asked for first or later', () => {
    // P0 → P1 → P2 → P3 (knob n^2) and P1 → Q (knob n^3): P1's bound inside P0's derivation is P1's own bound.
    const rows: RowSpec[] = [...chainRows(3), { id: 'q', from: 'L / P1', to: 'L / Q', toTime: '$T(n)$', fromTime: '$O(T(n))$' }];
    const m = model(rows);
    const knobs = [
      { problem: 'L / P3', kind: 'UB' as const, regime: 'n=1', exponent: 2 },
      { problem: 'L / Q', kind: 'UB' as const, regime: 'n=1', exponent: 3 },
    ];
    const a = analyze(m, scenario(knobs, { maxDepthUB: 0 }));
    const p0 = a.summaries.get('L / P0')!.primary!.ub!;
    const p1 = a.summaries.get('L / P1')!.primary!.ub!;
    assert.ok(near(p0.exponent, 2));
    assert.equal(p0.origin.kind === 'row' && p0.origin.children[0], p1, 'the very same bound');
    // Asking in another order (a solver of its own, P1 first) gives the same bounds.
    const knob = (id: string, problem: string, exponent: number) => ({ id, problem, exactKeys: new Set(['n=p1']), exponent, power: 1, formula: null, filter: null });
    const listed = new Set(['L / P0', 'L / P1', 'L / P2', 'L / P3', 'L / Q'].map((p) => `${p}#n=p1`));
    const opts = { settings: a.scenario.settings, constants: new Map(), usable: () => true };
    const solver = new UpperBounds(m, [knob('k1', 'L / P3', 2), knob('k2', 'L / Q', 3)], opts, listed);
    const regime = a.summaries.get('L / P1')!.primary!.regime;
    const q1 = solver.query('L / P1', regime)!;
    const q0 = solver.query('L / P0', regime)!;
    assert.ok(near(q1.exponent, 2) && near(q0.exponent, 2));
    assert.equal(q0.origin.kind === 'row' && q0.origin.children[0], q1);
  });

  it('approaches the limit of a falling cycle through \\min lap by lap', () => {
    // P(n) calls P(n) for min(n √T(n), T(n)^{3/2}/n): an upper bound U becomes min(1 + U/2, 1.5U − 1), which falls from
    // 3 towards 2; below 2 it would fall to 0, but nothing derives a bound below 2.
    const m = model([{ id: 'pp', from: A, to: A, toTime: '$T(n)$', fromTime: '$O(\\min(n \\sqrt{T(n)}, T(n)^{3/2} / n))$', rt: '$O(1)$' }]);
    const u = ubOf(analyze(m, scenario([{ problem: A, kind: 'UB', regime: 'n=1', exponent: 3 }])), A, 'n=p1')!;
    assert.ok(u >= 2 && u < 2 + 1e-6, String(u));
  });

  it('approaches the limit of a cycle through a floor lap by lap', () => {
    // T(n)/√n + n^{2.05}·⌊T(n)/n^2⌋^{0.1}: the floor switches a term on with a jump (neither convex nor concave).
    const m = model([
      { id: 'pp', from: A, to: A, toTime: '$T(n)$', fromTime: '$O(T(n)/n^{0.5} + n^{2.05} \\lfloor T(n)/n^2 \\rfloor^{0.1})$', rt: '$O(1)$' },
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$O(1)$' },
    ]);
    const u = ubOf(analyze(m, scenario([{ problem: A, kind: 'UB', regime: 'n=1', exponent: 4 }])), A, 'n=p1')!;
    assert.ok(u >= 19 / 9 - 1e-9 - 0.0555555556 && u < 2.0556, String(u));
    const l = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1 }, { problem: B, kind: 'UB', formula: 'n^3' }]));
    const x = lbOf(l, A, 'n=p1')!;
    assert.ok(x <= 2 + 1e-6 && x > 2 - 1e-6, String(x));
    assert.equal(l.summaries.get(B)!.status, 'gap');
  });

  it('lists the limits of cycles found at regimes that are not of interest', () => {
    // P (of interest) → A(n, n^2) ⇄ B(√n, √m) (with √n overhead): a falling cycle at a regime that is not of interest.
    const P = 'F / P';
    const m = model(
      [
        { id: 'pa', from: P, to: A, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$', rt: '$O(1)$' },
        { id: 'ab', from: A, to: B, toTime: '$T(n, m)$', fromTime: '$O(\\sqrt{n} \\cdot T(\\sqrt{n}, \\sqrt{m}))$', rt: '$O(1)$' },
        { id: 'ba', from: B, to: A, toTime: '$T(n, m)$', fromTime: '$O(T(n, m))$', rt: '$O(1)$' },
      ],
      { problems: { [P]: { params: ['n'] } } },
    );
    const a = analyze(m, scenario([{ problem: B, kind: 'UB', formula: 'n m' }]));
    assert.ok(near(ubOf(a, P, 'n=p1'), 1, 1e-9));
    assert.ok(a.upper.cycles.some((f) => f.regime.key === 'n=p1|m=p2'), a.upper.cycles.map((f) => f.regime.key).join());
  });

  it('gives the same bounds whatever the order of the rows, and keeps them when lower bounds change', () => {
    // maxDepthUB = 1. A (listed) → W(n, n^2) → X(n, n^3); C(n, n^2) (a regime of a lower bound only) → X(n, n^3) →
    // Y(n, n^4) (an algorithm n·m): C's bound comes from a search started at C's own regime.
    const [W, X, Y] = ['F / W', 'F / X', 'F / Y'];
    const rowsA: RowSpec[] = [
      { id: 'aw', from: A, to: W, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
      { id: 'wx', from: W, to: X, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' },
    ];
    const rowsC: RowSpec[] = [{ id: 'cx', from: C, to: X, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' }];
    const rowsX: RowSpec[] = [{ id: 'xy', from: X, to: Y, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' }];
    const config = { problems: { [A]: { params: ['n'] }, [C]: { params: ['n', 'm'] } } };
    const knobs = (lb: number) =>
      scenario(
        [
          { problem: Y, kind: 'UB', formula: 'n m' },
          { problem: C, kind: 'LB', regime: 'n=1, m=2', exponent: lb },
        ],
        { maxDepthUB: 1 },
      );
    const ubC = (a: Analysis) => ubOf(a, C, 'n=p1|m=p2');
    const first = model([...rowsA, ...rowsC, ...rowsX], config);
    const second = model([...rowsC, ...rowsX, ...rowsA], config);
    assert.ok(near(ubC(analyze(first, knobs(2))), 5));
    assert.ok(near(ubC(analyze(second, knobs(2))), 5));
    const a1 = analyze(second, knobs(2));
    const a2 = analyze(second, knobs(2.5), new Map(), a1);
    assert.equal(a2.upper, a1.upper, 'the search survives the change of the lower bound');
    assert.ok(near(ubC(a2), 5));
  });

  it('replaces a bound that keeps falling around a cycle by the limit', () => {
    // A(n) calls B on instances of size √n with √n overhead: U_A = 1/2 + U_B/2; B(n) calls A(n): U_B = U_A → 1.
    const m = model([
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(\\sqrt{n} \\cdot T(\\sqrt{n}))$', rt: '$O(1)$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$O(1)$' },
    ]);
    const a = analyze(m, scenario([{ problem: B, kind: 'UB', regime: 'n=1', exponent: 3 }]));
    const fb = a.summaries.get(B)!.primary!.ub!;
    assert.ok(near(fb.exponent, 1, 1e-9) && fb.exponent >= 1, String(fb.exponent));
    assert.ok(near(ubOf(a, A, 'n=p1'), 1, 1e-9));
    assert.equal(fb.origin.kind, 'cycle');
    assert.equal(a.upper.cycles.length, 1);
    // Its derivation shows one lap (B → A → B) and the knob it started from.
    assert.deepEqual([...ubPath(fb).problems].sort(), [A, B]);
    assert.deepEqual([...ubPath(fb).rows].sort(), ['ab', 'ba']);
  });

  it('values calls in different regimes separately', () => {
    const rows: RowSpec[] = [{ id: 'mixed', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n) + T(n, n^2))$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n m' }]));
    assert.ok(near(ubOf(a, A, 'n=p1'), 3));
  });
});

describe('analysis', () => {
  it('computes statuses', () => {
    const lb = { exponent: 2 } as never;
    const ub = (x: number) => ({ exponent: x }) as never;
    assert.equal(statusOf(lb, ub(1.5)), 'conflict');
    assert.equal(statusOf(lb, ub(2.00005)), 'tight');
    assert.equal(statusOf(lb, ub(2.5)), 'gap');
    assert.equal(statusOf(lb, null), 'lb');
    assert.equal(statusOf(null, ub(1)), 'ub');
    assert.equal(statusOf(null, null), 'none');
  });

  it('detects small improvements: conflicts and gaps near the boundary', () => {
    // Derived bounds err only on the safe side (lower bounds down, upper bounds up), so an upper bound below a lower
    // bound by more than floating-point noise is a real conflict, e.g. 3SUM in n^{1.9992} against the 3SUM hypothesis.
    const lb = { exponent: 2 } as never;
    const ub = (x: number) => ({ exponent: x }) as never;
    assert.equal(statusOf(lb, ub(1.9992)), 'conflict');
    assert.equal(statusOf(lb, ub(1.9999)), 'conflict');
    assert.equal(statusOf(lb, ub(2 - 1e-9)), 'tight', 'floating-point noise');
    assert.equal(statusOf(lb, ub(2 - 1e-6)), 'conflict', 'n^{2-Ω(1)}');
    assert.equal(statusOf(lb, ub(2)), 'tight');
    assert.equal(statusOf(lb, ub(2.0005)), 'gap');
  });

  it('reports knob issues without failing', () => {
    const m = model([...base, { id: 'd', from: A, to: 'F / D', toTime: '$T_p(n), T_q(n)$', fromTime: '$O(T_p(n))$' }], cfg);
    const a = analyze(
      m,
      scenario([
        { problem: 'F / Nope', kind: 'LB', regime: 'n=1', exponent: 2 },
        { problem: B, kind: 'LB', regime: 'q=1', exponent: 2 },
        { problem: B, kind: 'LB', regime: 'n=1', exponent: -1 },
        { problem: 'F / D', kind: 'UB', formula: 'n' },
        { problem: B, kind: 'UB', formula: 'n^{x}' },
        { problem: B, kind: 'UB', exponent: 1 },
      ]),
    );
    assert.deepEqual([...a.knobIssues.keys()], ['k1', 'k2', 'k3', 'k4', 'k5', 'k6']);
  });

  it('instantiates const-list LB knobs with formulas', () => {
    const K = 'G / K';
    const rows: RowSpec[] = [{ id: 'k', from: K, to: B, toTime: '$T(n)$', fromTime: '$O(T(n^{k/2}))$' }];
    const m = model(rows, { problems: { [K]: { params: ['n', 'k'] } } });
    const a = analyze(m, scenario([{ problem: K, kind: 'LB', regime: 'n=1, k=const:[3,4]', formula: 'n^{k}' }]));
    assert.deepEqual(
      [...a.lower.facts.get(K)!.values()].map((f) => [f.regime.key, f.exponent]),
      [
        ['n=p1|k=c3', 3],
        ['n=p1|k=c4', 4],
      ],
    );
    assert.ok(near(lbOf(a, B, 'n=p1'), 2));
  });

  it('reuses unchanged lower and upper results', () => {
    const m = model(base, cfg);
    const s1 = scenario([
      { problem: A, kind: 'LB', regime: 'n=1', exponent: 3 },
      { problem: C, kind: 'UB', formula: 'n m' },
    ]);
    const a1 = analyze(m, s1);
    const s2 = { ...s1, knobs: s1.knobs.map((k) => (k.kind === 'LB' ? { ...k, exponent: 2.9 } : k)) };
    const a2 = analyze(m, s2, new Map(), a1);
    assert.equal(a2.upper, a1.upper);
    assert.notEqual(a2.lower, a1.lower);
    assert.ok(near(lbOf(a2, B, 'n=p1'), 3.8));
  });

  it('shows pinned regimes', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n m' }]), new Map([[C, ['n=1, m=1.5']]]));
    assert.ok(near(ubOf(a, C, 'n=p1|m=p1.5'), 2.5));
    assert.equal(a.summaries.get(C)!.primary!.regime.key, 'n=p1|m=p1.5');
  });
});

describe('review regressions', () => {
  it('rounds vanishing ceilings up (row R161 in sparse graphs)', () => {
    const rows: RowSpec[] = [
      { id: 'c', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(\\lceil m/(nt) \\rceil \\cdot T(9n, m))$', rt: '$O(n)$' },
    ];
    const m = model(rows, { problems: { [A]: { params: ['n', 'm'] } }, rows: { c: { free: [{ name: 't', type: 'size', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1, m=1', exponent: 2.5 }]));
    assert.ok(near(lbOf(a, C, 'n=p1|m=p1'), 2.5), String(lbOf(a, C, 'n=p1|m=p1')));
  });

  it('refines between two grid points that give the same bound (a better one may lie between them)', () => {
    // Only r = 0.375 and r = 0.5 of the grid keep the reduction below n^2; both give 1.5, and r = 0.4375 gives 1.5625.
    const rows: RowSpec[] = [
      { id: 'w', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n^{\\max(r, 0.875-r)} \\cdot T(n))$', rt: '$O(n^{1+8\\max(r-0.4375, 0.4375-r)})$' },
    ];
    const m = model(rows, { ...cfg, rows: { w: { free: [{ name: 'r', type: 'real', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 1.5625, 1e-6), String(lbOf(a, B, 'n=p1')));
  });

  it('keeps dependent free-parameter ranges during refinement', () => {
    const rows: RowSpec[] = [{ id: 'd', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n^{2-a-b} \\cdot T(n))$', rt: '$O(n)$' }];
    const m = model(rows, {
      ...cfg,
      rows: { d: { free: [{ name: 'a', type: 'real', min: 0, max: 1 }, { name: 'b', type: 'real', min: 0, max: '1-a' }] } },
    });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 3 }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 2, 1e-6), String(lbOf(a, B, 'n=p1')));
  });

  it('finds thresholds for targets normalized by a slowly growing parameter', () => {
    const rows: RowSpec[] = [{ id: 's', from: A, to: C, toTime: '$T(u, n)$', fromTime: '$O(T(n^{0.01}, n))$', rt: '$O(n)$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.ok(near(lbOf(a, C, 'u=p1|n=p100'), 200, 1e-6));
    assert.equal(a.lower.inconsistencies.length, 0);
  });

  it('treats n^{2-Ω(1)} reduction runtimes as faster than n^2', () => {
    const rows: RowSpec[] = [{ id: 'o', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$n^{2-\\Omega(1)}$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 2));
  });

  it('reports overflowing knob formulas instead of crashing', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: B, kind: 'UB', formula: '10^{200} \\cdot 10^{200} \\cdot n^2' }]));
    assert.ok(a.knobIssues.size === 1 || ubOf(a, B, 'n=p1') === undefined);
  });
});
