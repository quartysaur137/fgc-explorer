import assert from 'node:assert/strict';
import { analyze, Analysis, statusOf } from '../src/engine/analysis';
import { lbChain, threshold } from '../src/engine/lower';
import { model, near, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for propagation (lower.ts, upper.ts, analysis.ts) on synthetic sheets
 *
 * threshold: g(0) ≥ L, root inside, unbounded, superpolynomial values, flat pieces
 * LB propagation, partition on: chain length (1, 2, cycle), scale of the produced instance (≠ 1), RT (below / at the
 *   LB, unknown with each policy), free parameters (none, constant-key grid with refinement, key-changing grid,
 *   blocked boundary optimum), calls (single, several in one regime, several regimes, none → inconsistency),
 *   exponential-scale sources, sums, requires, disabled / randomized rows, hop limit
 * UB evaluation: formula knobs (all regimes / filtered), exponent knobs (exact regime only), through rows (scale,
 *   RT dominates), depth limit, cycles, several calls in different regimes
 * analysis: statuses (conflict, tight, gap, lb, ub, none), knob issues (unknown problem, bad regime, dynamic problem,
 *   formula errors), const-list LB knobs with formulas, reuse of previous results
 */

const lbOf = (a: Analysis, problem: string, key: string): number | undefined => a.lower.facts.get(problem)?.get(key)?.exponent;
const ubOf = (a: Analysis, problem: string, key: string): number | undefined =>
  a.summaries.get(problem)?.regimes.find((r) => r.regime.key === key)?.ub?.exponent;

describe('threshold', () => {
  it('finds the smallest x with g(x) ≥ L', () => {
    assert.equal(threshold((x) => 1 + x / 2, 1), 0);
    assert.ok(near(threshold((x) => 1 + x / 2, 2) as number, 2, 1e-8));
    assert.ok(near(threshold((x) => Math.max(x, 2), 2.5) as number, 2.5, 1e-8));
    assert.equal(threshold(() => 1, 2), 'unbounded');
    assert.ok(near(threshold((x) => (x > 10 ? Infinity : x), 3) as number, 3, 1e-8));
    assert.ok(near(threshold((x) => Math.min(x, 5) + Math.max(0, x - 7), 6) as number, 8, 1e-8));
  });
});

const A = 'F / A';
const B = 'F / B';
const C = 'F / C';
const base: RowSpec[] = [
  // A(n) via n calls on B instances of size sqrt(n): A ≤ n · T_B(√n)
  { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n \\cdot T(\\sqrt{n}))$', rt: '$O(n)$' },
  // B(n) → C(n, n^2), identity-like
  { id: 'bc', from: B, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$', rt: '$O(n^2)$' },
];
const cfg = { problems: { [A]: { params: ['n'] } } };

describe('lower-bound propagation', () => {
  it('propagates along a chain with scaling', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 3 }]));
    // 1 + x/2 ≥ 3 ⇒ x ≥ 4 for B; then C(n, n^2) ≥ 4 (RT n^2 < 4)
    assert.ok(near(lbOf(a, B, 'n=p1'), 4));
    assert.ok(near(lbOf(a, C, 'n=p1|m=p2'), 4));
    const chain = lbChain(a.lower.facts.get(C)!.get('n=p1|m=p2')!);
    assert.deepEqual(
      chain.map((f) => [f.problem, f.hops]),
      [
        [C, 2],
        [B, 1],
        [A, 0],
      ],
    );
  });

  it('is blocked when the reduction itself is too slow, and respects the unknown-RT policy', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: B, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.equal(lbOf(a, C, 'n=p1|m=p2'), undefined, 'RT n^2 is not below the LB 2');
    const rows: RowSpec[] = [{ ...base[1]!, rt: '??' }];
    const m = model(rows);
    assert.ok(near(lbOf(analyze(m, scenario([{ problem: B, kind: 'LB', regime: 'n=1', exponent: 2 }])), C, 'n=p1|m=p2'), 2));
    const blocked = analyze(m, scenario([{ problem: B, kind: 'LB', regime: 'n=1', exponent: 2 }], { unknownRT: 'block' }));
    assert.equal(lbOf(blocked, C, 'n=p1|m=p2'), undefined);
  });

  it('handles free parameters whose optimum is at a blocked boundary', () => {
    const rows: RowSpec[] = [{ id: 'x', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(X \\cdot T(n))$', rt: '$O(n^2/X)$' }];
    const m = model(rows, { ...cfg, rows: { x: { free: [{ name: 'X', type: 'size', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    const x = lbOf(a, B, 'n=p1')!;
    assert.ok(x < 2 && x > 2 - 1e-3, String(x));
  });

  it('keeps one fact per target regime when free parameters move the regime', () => {
    const rows: RowSpec[] = [{ id: 'x', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^{1+r}))$', rt: '$O(n)$' }];
    const m = model(rows, { ...cfg, rows: { x: { free: [{ name: 'r', type: 'real', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }], { gridPoints: 5 }));
    assert.deepEqual(
      [...a.lower.facts.get(C)!.keys()].sort(),
      ['n=p1|m=p1', 'n=p1|m=p1.25', 'n=p1|m=p1.5', 'n=p1|m=p1.75', 'n=p1|m=p2'],
    );
  });

  it('allows several calls in one target regime but not in several', () => {
    const rows: RowSpec[] = [
      { id: 'same', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n) + n \\cdot T(\\sqrt{n}))$' },
      { id: 'mixed', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n) + T(n, n^2))$' },
    ];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 3 }]));
    // max(x, 1 + x/2) ≥ 3 ⇒ x ≥ 3
    assert.ok(near(lbOf(a, B, 'n=p1'), 3));
    assert.equal(a.lower.facts.get(C), undefined);
  });

  it('records rows that would beat a lower bound without calling the target', () => {
    const rows: RowSpec[] = [{ id: 'x', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n \\cdot T(1))$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.equal(a.lower.inconsistencies.length, 1);
    assert.equal(a.lower.inconsistencies[0]!.rowId, 'x');
  });

  it('works with exponential-time sources', () => {
    const S = 'SAT / S';
    const O = 'OV / O';
    const rows: RowSpec[] = [{ id: 'so', from: S, to: O, toTime: '$T(n, d)$', fromTime: '$O(T(2^{n/2}, m))$', rt: '$O(2^{n/2} n m)$' }];
    const m = model(rows, { problems: { [S]: { params: ['n', 'm'], timeType: 'exp', regimes: ['n=log, m=polylog'] }, [O]: { regimes: ['n=1, d=polylog'] } } });
    const a = analyze(m, scenario([{ problem: S, kind: 'LB', regime: 'n=log, m=polylog', exponent: 1 }, { problem: O, kind: 'UB', formula: 'n^2 d' }]));
    assert.ok(near(lbOf(a, O, 'n=p1|d=L'), 2));
    assert.ok(near(ubOf(a, S, 'n=E|m=L'), 1));
    assert.equal(a.summaries.get(S)!.status, 'tight');
  });

  it('evaluates sums over logarithmic ranges', () => {
    const rows: RowSpec[] = [{ id: 's', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(\\sum_{i=0}^{\\log n} 4^i \\cdot T(n/2^i))$' }];
    const m = model(rows, cfg);
    assert.ok(near(lbOf(analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2.5 }])), B, 'n=p1'), 2.5, 1e-6));
    assert.equal(lbOf(analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 1.5 }])), B, 'n=p1'), undefined);
  });

  it('respects requires, disabled and randomized rows, and the hop limit', () => {
    const rows: RowSpec[] = [
      { id: 'r', from: C, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
      { id: 'q', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$', randomized: 'Yes' },
      { id: 'bc', from: B, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
    ];
    const m = model(rows, { ...cfg, rows: { r: { requires: 'm=2' } } });
    const lbC = (spec: string) => analyze(m, scenario([{ problem: C, kind: 'LB', regime: spec, exponent: 2 }]));
    assert.ok(near(lbOf(lbC('n=1, m=2'), B, 'n=p1'), 2));
    assert.equal(lbOf(lbC('n=1, m=1'), B, 'n=p1'), undefined);
    const knob = [{ problem: A, kind: 'LB' as const, regime: 'n=1', exponent: 2 }];
    assert.ok(near(lbOf(analyze(m, scenario(knob)), B, 'n=p1'), 2));
    assert.equal(lbOf(analyze(m, scenario(knob, { useRandomized: false })), B, 'n=p1'), undefined);
    assert.equal(lbOf(analyze(m, scenario(knob, { disabledRows: ['q'] })), B, 'n=p1'), undefined);
    assert.equal(lbOf(analyze(m, scenario(knob, { maxHopsLB: 1 })), C, 'n=p1|m=p2'), undefined);
    assert.ok(near(lbOf(analyze(m, scenario(knob, { maxHopsLB: 2 })), C, 'n=p1|m=p2'), 2));
  });

  it('terminates on cycles', () => {
    const rows: RowSpec[] = [
      { id: 'ab', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
      { id: 'ba', from: B, to: A, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    ];
    const a = analyze(model(rows), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }, { problem: B, kind: 'UB', formula: 'n^{1.5}' }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 2));
    assert.ok(near(ubOf(a, A, 'n=p1'), 1.5));
    assert.equal(a.summaries.get(A)!.status, 'conflict');
  });
});

describe('upper-bound evaluation', () => {
  it('propagates backward with scaling and reduction runtime', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n \\cdot m' }]));
    // C(n, n^2) = n^3 ⇒ B ≤ max(3, RT 2) = 3 ⇒ A ≤ 1 + 3/2 = 2.5
    assert.ok(near(ubOf(a, B, 'n=p1'), 3));
    assert.ok(near(ubOf(a, A, 'n=p1'), 2.5));
    // RT dominates: C ≤ n ⇒ B ≤ max(1, 2) = 2
    const b = analyze(model(base, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n' }]));
    assert.ok(near(ubOf(b, B, 'n=p1'), 2));
  });

  it('applies exponent knobs only at their regime and formula knobs at matching regimes', () => {
    const m = model(base, { ...cfg, problems: { ...cfg.problems, [C]: { regimes: ['n=1, m=2', 'n=1, m=1'] } } });
    const a = analyze(
      m,
      scenario([
        { problem: C, kind: 'UB', regime: 'n=1, m=2', exponent: 2.5 },
        { problem: C, kind: 'UB', regime: 'm=1', formula: 'n^{1.2}' },
      ]),
    );
    assert.ok(near(ubOf(a, C, 'n=p1|m=p2'), 2.5));
    assert.ok(near(ubOf(a, C, 'n=p1|m=p1'), 1.2));
  });

  it('respects the depth limit', () => {
    const knobs = [{ problem: C, kind: 'UB' as const, formula: 'n m' }];
    assert.equal(ubOf(analyze(model(base, cfg), scenario(knobs, { maxDepthUB: 1 })), A, 'n=p1'), undefined);
    assert.ok(near(ubOf(analyze(model(base, cfg), scenario(knobs, { maxDepthUB: 2 })), A, 'n=p1'), 2.5));
  });

  it('values calls in different regimes separately', () => {
    const rows: RowSpec[] = [{ id: 'mixed', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(T(n, n) + T(n, n^2))$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n m' }]));
    assert.ok(near(ubOf(a, A, 'n=p1'), 3));
  });
});

describe('analysis', () => {
  it('computes statuses', () => {
    const lb = { exponent: 2 } as never;
    const ub = (x: number) => ({ exponent: x }) as never;
    assert.equal(statusOf(lb, ub(1.5)), 'conflict');
    assert.equal(statusOf(lb, ub(2.00005)), 'tight');
    assert.equal(statusOf(lb, ub(2.5)), 'gap');
    assert.equal(statusOf(lb, null), 'lb');
    assert.equal(statusOf(null, ub(1)), 'ub');
    assert.equal(statusOf(null, null), 'none');
  });

  it('detects small improvements: conflicts and gaps near the boundary', () => {
    // Derived bounds err only on the safe side (lower bounds down, upper bounds up), so an upper bound below a lower
    // bound by more than floating-point noise is a real conflict, e.g. 3SUM in n^{1.9992} against the 3SUM hypothesis.
    const lb = { exponent: 2 } as never;
    const ub = (x: number) => ({ exponent: x }) as never;
    assert.equal(statusOf(lb, ub(1.9992)), 'conflict');
    assert.equal(statusOf(lb, ub(1.9999)), 'conflict');
    assert.equal(statusOf(lb, ub(2 - 1e-9)), 'tight', 'floating-point noise');
    assert.equal(statusOf(lb, ub(2 - 1e-6)), 'conflict', 'n^{2-Ω(1)}');
    assert.equal(statusOf(lb, ub(2)), 'tight');
    assert.equal(statusOf(lb, ub(2.0005)), 'gap');
  });

  it('reports knob issues without failing', () => {
    const m = model([...base, { id: 'd', from: A, to: 'F / D', toTime: '$T_p(n), T_q(n)$', fromTime: '$O(T_p(n))$' }], cfg);
    const a = analyze(
      m,
      scenario([
        { problem: 'F / Nope', kind: 'LB', regime: 'n=1', exponent: 2 },
        { problem: B, kind: 'LB', regime: 'q=1', exponent: 2 },
        { problem: B, kind: 'LB', regime: 'n=1', exponent: -1 },
        { problem: 'F / D', kind: 'UB', formula: 'n' },
        { problem: B, kind: 'UB', formula: 'n^{x}' },
        { problem: B, kind: 'UB', exponent: 1 },
      ]),
    );
    assert.deepEqual([...a.knobIssues.keys()], ['k1', 'k2', 'k3', 'k4', 'k5', 'k6']);
  });

  it('instantiates const-list LB knobs with formulas', () => {
    const K = 'G / K';
    const rows: RowSpec[] = [{ id: 'k', from: K, to: B, toTime: '$T(n)$', fromTime: '$O(T(n^{k/2}))$' }];
    const m = model(rows, { problems: { [K]: { params: ['n', 'k'] } } });
    const a = analyze(m, scenario([{ problem: K, kind: 'LB', regime: 'n=1, k=const:[3,4]', formula: 'n^{k}' }]));
    assert.deepEqual(
      [...a.lower.facts.get(K)!.values()].map((f) => [f.regime.key, f.exponent]),
      [
        ['n=p1|k=c3', 3],
        ['n=p1|k=c4', 4],
      ],
    );
    assert.ok(near(lbOf(a, B, 'n=p1'), 2));
  });

  it('reuses unchanged lower and upper results', () => {
    const m = model(base, cfg);
    const s1 = scenario([
      { problem: A, kind: 'LB', regime: 'n=1', exponent: 3 },
      { problem: C, kind: 'UB', formula: 'n m' },
    ]);
    const a1 = analyze(m, s1);
    const s2 = { ...s1, knobs: s1.knobs.map((k) => (k.kind === 'LB' ? { ...k, exponent: 2.9 } : k)) };
    const a2 = analyze(m, s2, new Map(), a1);
    assert.equal(a2.upper, a1.upper);
    assert.notEqual(a2.lower, a1.lower);
    assert.ok(near(lbOf(a2, B, 'n=p1'), 3.8));
  });

  it('shows pinned regimes', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: C, kind: 'UB', formula: 'n m' }]), new Map([[C, ['n=1, m=1.5']]]));
    assert.ok(near(ubOf(a, C, 'n=p1|m=p1.5'), 2.5));
    assert.equal(a.summaries.get(C)!.primary!.regime.key, 'n=p1|m=p1.5');
  });
});

describe('review regressions', () => {
  it('rounds vanishing ceilings up (row 161 in sparse graphs)', () => {
    const rows: RowSpec[] = [
      { id: 'c', from: A, to: C, toTime: '$T(n, m)$', fromTime: '$O(\\lceil m/(nt) \\rceil \\cdot T(9n, m))$', rt: '$O(n)$' },
    ];
    const m = model(rows, { problems: { [A]: { params: ['n', 'm'] } }, rows: { c: { free: [{ name: 't', type: 'size', min: 0, max: 1 }] } } });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1, m=1', exponent: 2.5 }]));
    assert.ok(near(lbOf(a, C, 'n=p1|m=p1'), 2.5), String(lbOf(a, C, 'n=p1|m=p1')));
  });

  it('keeps dependent free-parameter ranges during refinement', () => {
    const rows: RowSpec[] = [{ id: 'd', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(n^{2-a-b} \\cdot T(n))$', rt: '$O(n)$' }];
    const m = model(rows, {
      ...cfg,
      rows: { d: { free: [{ name: 'a', type: 'real', min: 0, max: 1 }, { name: 'b', type: 'real', min: 0, max: '1-a' }] } },
    });
    const a = analyze(m, scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 3 }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 2, 1e-6), String(lbOf(a, B, 'n=p1')));
  });

  it('finds thresholds for targets normalized by a slowly growing parameter', () => {
    const rows: RowSpec[] = [{ id: 's', from: A, to: C, toTime: '$T(u, n)$', fromTime: '$O(T(n^{0.01}, n))$', rt: '$O(n)$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.ok(near(lbOf(a, C, 'u=p1|n=p100'), 200, 1e-6));
    assert.equal(a.lower.inconsistencies.length, 0);
  });

  it('treats n^{2-Ω(1)} reduction runtimes as faster than n^2', () => {
    const rows: RowSpec[] = [{ id: 'o', from: A, to: B, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$n^{2-\\Omega(1)}$' }];
    const a = analyze(model(rows, cfg), scenario([{ problem: A, kind: 'LB', regime: 'n=1', exponent: 2 }]));
    assert.ok(near(lbOf(a, B, 'n=p1'), 2));
  });

  it('reports overflowing knob formulas instead of crashing', () => {
    const a = analyze(model(base, cfg), scenario([{ problem: B, kind: 'UB', formula: '10^{200} \\cdot 10^{200} \\cdot n^2' }]));
    assert.ok(a.knobIssues.size === 1 || ubOf(a, B, 'n=p1') === undefined);
  });
});
