import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validateConfig } from '../src/model/config';
import { buildModel } from '../src/model/model';
import {
  BoxNode,
  compactLayout,
  CompactLayoutOptions,
  compactTowardCenter,
  hasOverlap,
  Link,
  orderMembers,
  packRows,
  placeNear,
  Rect,
  removeOverlaps,
  seededRandom,
} from '../src/ui/graphLayout';
import { CsvTable } from '../src/util/csv';

/*
 * Testing strategy for the compact graph layout
 *
 * orderMembers: linked members adjacent (BFS from the best connected), unlinked ones after, links leaving the group
 *   ignored, every member exactly once
 * packRows: one member, many; equal and unequal sizes; aspect ratio respected; members never closer than the gap
 * removeOverlaps: no overlap (unchanged), random overlapping rectangles, identical centers
 * placeNear: already free (unchanged), in a crowd (free afterwards, others untouched)
 * compactTowardCenter: stays overlap-free, does not grow the bounding box, keeps the left-to-right order
 * compactLayout: groups and singletons; links within and between units; determinism per seed; incremental layout
 *   (unchanged units stay exactly in place; nothing new: nothing moves); group boxes contain their members; empty and
 *   link-less graphs; the real sheet: no overlaps and a dense drawing
 */

const box = (id: string, group: string | null, w = 100, h = 40): BoxNode => ({ id, group, w, h });

/** Node rectangles of a layout (for overlap checks). */
function rectsOf(nodes: readonly BoxNode[], positions: ReadonlyMap<string, { x: number; y: number }>): Rect[] {
  return nodes.map((n) => ({ id: n.id, w: n.w, h: n.h, ...positions.get(n.id)! }));
}

function bounds(rects: readonly Rect[]): { w: number; h: number } {
  const x1 = Math.min(...rects.map((r) => r.x - r.w / 2));
  const x2 = Math.max(...rects.map((r) => r.x + r.w / 2));
  const y1 = Math.min(...rects.map((r) => r.y - r.h / 2));
  const y2 = Math.max(...rects.map((r) => r.y + r.h / 2));
  return { w: x2 - x1, h: y2 - y1 };
}

describe('orderMembers', () => {
  it('puts linked members next to each other, starting with the best connected', () => {
    const members = ['a', 'b', 'c', 'd', 'e'].map((id) => box(id, 'g'));
    const links: Link[] = [
      { source: 'd', target: 'b' },
      { source: 'd', target: 'e' },
      { source: 'b', target: 'outside' },
    ];
    assert.deepEqual(
      orderMembers(members, links).map((m) => m.id),
      ['d', 'b', 'e', 'a', 'c'],
    );
  });

  it('returns every member once even with cycles and self-links', () => {
    const members = ['x', 'y', 'z'].map((id) => box(id, 'g'));
    const links: Link[] = [
      { source: 'x', target: 'y' },
      { source: 'y', target: 'z' },
      { source: 'z', target: 'x' },
      { source: 'x', target: 'x' },
    ];
    assert.deepEqual(orderMembers(members, links).map((m) => m.id).sort(), ['x', 'y', 'z']);
  });
});

describe('packRows', () => {
  it('centers a single member', () => {
    const p = packRows([box('a', 'g', 80, 30)], 10, 1.6);
    assert.deepEqual([p.w, p.h], [80, 30]);
    assert.deepEqual(p.offsets.get('a'), { x: 0, y: 0 });
  });

  it('packs equal squares into a near-square grid for aspect 1', () => {
    const members = ['a', 'b', 'c', 'd'].map((id) => box(id, 'g', 50, 50));
    const p = packRows(members, 10, 1);
    assert.deepEqual([p.w, p.h], [110, 110]);
  });

  it('keeps members apart by the gap and inside the area', () => {
    const rnd = seededRandom(7);
    const members = Array.from({ length: 17 }, (_, i) => box(`m${i}`, 'g', 60 + 120 * rnd(), 30 + 40 * rnd()));
    for (const aspect of [0.5, 1.6, 4]) {
      const p = packRows(members, 12, aspect);
      const rects = rectsOf(members, p.offsets);
      assert.equal(hasOverlap(rects, 12 - 1e-6), false, `aspect ${aspect}`);
      for (const r of rects) {
        assert.ok(r.x - r.w / 2 >= -p.w / 2 - 1e-6 && r.x + r.w / 2 <= p.w / 2 + 1e-6);
        assert.ok(r.y - r.h / 2 >= -p.h / 2 - 1e-6 && r.y + r.h / 2 <= p.h / 2 + 1e-6);
      }
    }
    assert.ok(packRows(members, 12, 4).w > packRows(members, 12, 0.5).w, 'a wider aspect gives a wider area');
  });
});

describe('removeOverlaps', () => {
  it('leaves separated rectangles alone', () => {
    const rects: Rect[] = [
      { id: 'a', x: 0, y: 0, w: 10, h: 10 },
      { id: 'b', x: 30, y: 0, w: 10, h: 10 },
    ];
    removeOverlaps(rects, 5);
    assert.deepEqual(rects.map((r) => [r.x, r.y]), [[0, 0], [30, 0]]);
  });

  it('separates random overlapping rectangles, even with identical centers', () => {
    const rnd = seededRandom(3);
    const rects: Rect[] = Array.from({ length: 60 }, (_, i) => ({ id: `r${i}`, x: 200 * rnd(), y: 150 * rnd(), w: 20 + 80 * rnd(), h: 20 + 60 * rnd() }));
    rects.push({ id: 'same1', x: 50, y: 50, w: 30, h: 30 }, { id: 'same2', x: 50, y: 50, w: 30, h: 30 });
    removeOverlaps(rects, 8);
    assert.equal(hasOverlap(rects, 8 - 1e-6), false);
  });
});

describe('placeNear', () => {
  it('keeps a rectangle that is already free', () => {
    const r: Rect = { id: 'r', x: 100, y: 0, w: 10, h: 10 };
    placeNear(r, [{ id: 'o', x: 0, y: 0, w: 10, h: 10 }], 5);
    assert.deepEqual([r.x, r.y], [100, 0]);
  });

  it('finds the nearest free spot in a crowd without moving anyone else', () => {
    const rnd = seededRandom(5);
    const others: Rect[] = Array.from({ length: 50 }, (_, i) => ({ id: `o${i}`, x: 600 * rnd(), y: 400 * rnd(), w: 30 + 60 * rnd(), h: 20 + 40 * rnd() }));
    removeOverlaps(others, 10);
    const snapshot = others.map((o) => [o.x, o.y]);
    const r: Rect = { id: 'new', x: 300, y: 200, w: 120, h: 50 };
    placeNear(r, others, 10);
    assert.equal(hasOverlap([...others, r], 10 - 1e-6), false);
    assert.deepEqual(others.map((o) => [o.x, o.y]), snapshot);
  });
});

describe('compactTowardCenter', () => {
  it('shrinks a spread-out arrangement without creating overlaps', () => {
    const rnd = seededRandom(11);
    const rects: Rect[] = Array.from({ length: 40 }, (_, i) => ({ id: `r${i}`, x: 3000 * rnd(), y: 2000 * rnd(), w: 50 + 100 * rnd(), h: 30 + 50 * rnd() }));
    removeOverlaps(rects, 10);
    const before = bounds(rects);
    compactTowardCenter(rects, 10);
    const after = bounds(rects);
    assert.equal(hasOverlap(rects, 10 - 1e-6), false);
    assert.ok(after.w * after.h < 0.5 * before.w * before.h, `${after.w}×${after.h} vs ${before.w}×${before.h}`);
  });

  it('does not move rectangles that already touch at the center', () => {
    const rects: Rect[] = [
      { id: 'a', x: -15, y: 0, w: 20, h: 20 },
      { id: 'b', x: 15, y: 0, w: 20, h: 20 },
    ];
    compactTowardCenter(rects, 10);
    assert.deepEqual(rects.map((r) => r.x), [-15, 15]);
  });
});

describe('compactLayout', () => {
  const opts: CompactLayoutOptions = { gap: 12, groupPadding: 10, groupTitle: 24, aspect: 1.6, seed: 1 };
  const nodes: BoxNode[] = [
    ...['a1', 'a2', 'a3', 'a4', 'a5'].map((id) => box(id, 'A', 120, 50)),
    ...['b1', 'b2', 'b3'].map((id) => box(id, 'B', 90, 40)),
    box('s1', null, 140, 60),
    box('s2', null, 70, 40),
  ];
  const links: Link[] = [
    { source: 'a1', target: 'a2' },
    { source: 'a2', target: 'b1' },
    { source: 'b2', target: 's1' },
    { source: 's2', target: 'a5' },
  ];

  it('places every node without overlaps, members inside their group box', () => {
    const l = compactLayout(nodes, links, opts);
    assert.equal(l.positions.size, nodes.length);
    assert.equal(hasOverlap(rectsOf(nodes, l.positions), opts.gap - 1e-6), false);
    for (const n of nodes.filter((x) => x.group !== null)) {
      const b = l.groupBoxes.get(n.group!)!;
      const p = l.positions.get(n.id)!;
      assert.ok(p.x - n.w / 2 >= b.x1 && p.x + n.w / 2 <= b.x2 && p.y - n.h / 2 >= b.y1 && p.y + n.h / 2 <= b.y2, n.id);
    }
    assert.deepEqual([...l.units.keys()].sort(), ['g:A', 'g:B', 'n:s1', 'n:s2']);
  });

  it('is deterministic for a seed', () => {
    const a = compactLayout(nodes, links, opts);
    const b = compactLayout(nodes, links, opts);
    assert.deepEqual([...a.positions], [...b.positions]);
  });

  it('keeps unchanged units in place when problems are added', () => {
    const a = compactLayout(nodes, links, opts);
    // A new problem in group A (which grows) and a new problem on its own, linked to group B.
    const more = [...nodes, box('a6', 'A', 120, 50), box('s3', null, 80, 40)];
    const c = compactLayout(more, [...links, { source: 's3', target: 'b3' }], { ...opts, previous: a.units });
    assert.equal(c.positions.size, more.length);
    assert.equal(hasOverlap(rectsOf(more, c.positions), opts.gap - 1e-6), false);
    for (const id of ['b1', 'b2', 'b3', 's1', 's2']) assert.deepEqual(c.positions.get(id), a.positions.get(id), id);
    // Nothing new: nothing moves.
    const same = compactLayout(nodes, links, { ...opts, previous: a.units });
    assert.deepEqual([...same.positions], [...a.positions]);
  });

  it('handles an empty graph and a graph without links', () => {
    assert.equal(compactLayout([], [], opts).positions.size, 0);
    const lone = [box('x', null), box('y', null), box('z', 'G'), box('w', 'G')];
    assert.equal(hasOverlap(rectsOf(lone, compactLayout(lone, [], opts).positions), opts.gap - 1e-6), false);
  });

  it('draws the real sheet densely and without overlaps', function () {
    this.timeout(20000);
    const csv = readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');
    const config = validateConfig(JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'))).value;
    const model = buildModel(CsvTable.fromText(csv).table, config);
    const families = new Map<string, number>();
    for (const p of model.problems.values()) families.set(p.family, (families.get(p.family) ?? 0) + 1);
    // Rough label sizes (the app measures the text).
    const sheetNodes: BoxNode[] = [...model.problems.values()].map((p) => ({
      id: p.id,
      group: (families.get(p.family) ?? 0) >= 2 ? p.family : null,
      w: Math.min(200, Math.max(170, 8 * p.variation.length)) + 16,
      h: 17 * (1 + Math.ceil((8 * p.variation.length) / 182)) + 12,
    }));
    const l = compactLayout(
      sheetNodes,
      model.rows.map((r) => ({ source: r.source, target: r.target })),
      { ...opts, targetAspect: 1.6 },
    );
    const rects = rectsOf(sheetNodes, l.positions);
    assert.equal(hasOverlap(rects, opts.gap - 1e-6), false);
    const b = bounds(rects);
    const area = rects.reduce((s, r) => s + r.w * r.h, 0);
    // A plain force layout covers about 6 % of its drawing with problems.
    assert.ok(area / (b.w * b.h) > 0.25, `density ${(area / (b.w * b.h)).toFixed(3)}`);
  });
});
