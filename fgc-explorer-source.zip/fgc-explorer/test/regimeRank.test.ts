import assert from 'node:assert/strict';
import { analyze, RegimeOrigin, regimesFromSpec, Status } from '../src/engine/analysis';
import { compareKeys, lbRegimeKey, listedByItself, numberTier, RankedRegime, regimeNiceness, regimeRankKey, simpleDenominator } from '../src/engine/regimeRank';
import { model, near, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for the order of regimes (regimeRank.ts, and its use in analysis.ts)
 *
 * simpleDenominator: integers, halves, thirds stored rounded up (0.666667), 10/11, no simple fraction (π), beyond
 *   maxDen, infinite
 * numberTier: 0 whole (small and large), 1 halves / thirds / quarters up to 3, 2 fifths / sixths up to 4, 3 others
 *   (10/11; a half above 3)
 * regimeNiceness: the main parameter, classes (polylog, unspecified constant) and log-dependent parameters ignored;
 *   exponents and constants' values; worst tier, weight summed
 * regimeRankKey, partition on what decides: a conflict (even at an unusual regime, before a pinned one); pinned; niceness (whole and tier-1
 *   fractions together, before how much the bounds say: a gap at m = n^{3/2} before an upper bound at m = n^2);
 *   information (tight > gap > LB > UB > none); exact tier; origin (configured before lower bounds); hops; larger LB
 * lbRegimeKey: niceness before hops and size
 * listedByItself: configured / knob / pinned regimes; nice and unusual regimes of lower bounds
 * analysis: the primary regime and the status (the primary's: a gap at an unusual regime does not color a problem
 *   whose configured regime has only an upper bound; a conflict anywhere does), listed regimes (unusual ones only when
 *   another problem's listed bound is derived through them), reductions used counted for listed bounds only
 */

const G = 'G / P';
const gm = model([{ id: 'R1', from: G, to: G, toTime: '$T(n, m, k, M)$', fromTime: '$O(T(n, m, k, M))$' }], { problems: { [G]: { logParams: ['M'] } } });
const problem = gm.problems.get(G)!;
const regime = (spec: string) => regimesFromSpec(problem, spec)[0]!;

const ranked = (spec: string, status: Status, origins: RegimeOrigin[] = ['lb'], lb: { exponent: number; hops?: number } | null = { exponent: 2 }): RankedRegime => ({
  regime: regime(spec),
  lb: lb === null ? null : { power: 1, exponent: lb.exponent, hops: lb.hops ?? 1 },
  status,
  origins,
});
const order = (...xs: RankedRegime[]): string[] =>
  xs
    .map((x) => ({ x, key: regimeRankKey(x) }))
    .sort((a, b) => compareKeys(a.key, b.key))
    // (M, log-dependent, is polynomial in all of them)
    .map(({ x }) => `${x.regime.key.replace('|M=P', '')} ${x.status}`);

describe('simpleDenominator', () => {
  it('finds simple fractions, also when stored rounded up', () => {
    assert.deepEqual(
      [2, 1.5, 0.666667, 1.333334, 0.75, 0.909091].map((x) => simpleDenominator(x)),
      [1, 2, 3, 3, 4, 11],
    );
    assert.equal(simpleDenominator(Math.PI), Infinity);
    assert.equal(simpleDenominator(1 / 13), Infinity, 'beyond maxDen');
    assert.equal(simpleDenominator(1 / 13, 13), 13);
    assert.equal(simpleDenominator(Infinity), Infinity);
  });
});

describe('numberTier', () => {
  it('ranks whole numbers, simple fractions, fifths and sixths, and the rest', () => {
    assert.deepEqual(
      [1, 2, 32, 1.5, 0.666667, 2.75, 3, 1.2, 0.833334, 3.5, 0.909091, 11.5, 4.5].map(numberTier),
      [0, 0, 0, 1, 1, 1, 0, 2, 2, 2, 3, 3, 3],
    );
  });
});

describe('regimeNiceness', () => {
  it('reads exponents and constants, not the main parameter, classes or log-dependent parameters', () => {
    assert.deepEqual(regimeNiceness(regime('n=1, m=2, k=const:6, M=poly')), { tier: 0, weight: 0 });
    assert.deepEqual(regimeNiceness(regime('n=1, m=polylog, k=const, M=polylog')), { tier: 0, weight: 0 });
    assert.deepEqual(regimeNiceness(regime('n=1, m=1.5, k=const:2')), { tier: 1, weight: 1 });
    assert.deepEqual(regimeNiceness(regime('n=1, m=4/3, k=const:1.5')), { tier: 1, weight: 3 });
    assert.equal(regimeNiceness(regime('n=1, m=10/11')).tier, 3);
  });
});

describe('regimeRankKey', () => {
  it('puts conflicts first, even at unusual regimes, then pinned regimes', () => {
    assert.deepEqual(order(ranked('n=1, m=2', 'tight', ['config']), ranked('n=1, m=10/11', 'conflict'), ranked('n=1, m=1.2', 'none', ['pinned'], null)), [
      'n=p1|m=p0.909091|k=p1 conflict',
      'n=p1|m=p1.2|k=p1 none',
      'n=p1|m=p2|k=p1 tight',
    ]);
  });

  it('puts nice regimes before unusual ones, and among nice ones those whose bounds say more', () => {
    assert.deepEqual(
      order(
        ranked('n=1, m=10/11', 'tight', ['lb'], { exponent: 2.909091 }),
        ranked('n=1, m=2', 'ub', ['config'], null),
        ranked('n=1, m=1.5', 'gap'),
        ranked('n=1, m=1', 'lb'),
        ranked('n=1, m=1.2', 'tight'),
      ),
      ['n=p1|m=p1.5|k=p1 gap', 'n=p1|m=p1|k=p1 lb', 'n=p1|m=p2|k=p1 ub', 'n=p1|m=p1.2|k=p1 tight', 'n=p1|m=p0.909091|k=p1 tight'],
    );
  });

  it('breaks ties by tight before gap, whole numbers, configured regimes, fewer reductions and the larger bound', () => {
    assert.deepEqual(order(ranked('n=1, m=2', 'gap'), ranked('n=1, m=1.5', 'tight')), ['n=p1|m=p1.5|k=p1 tight', 'n=p1|m=p2|k=p1 gap']);
    assert.deepEqual(order(ranked('n=1, m=1.5', 'tight'), ranked('n=1, m=2', 'tight')), ['n=p1|m=p2|k=p1 tight', 'n=p1|m=p1.5|k=p1 tight']);
    assert.deepEqual(order(ranked('n=1, m=1', 'tight', ['lb']), ranked('n=1, m=2', 'tight', ['config'])), ['n=p1|m=p2|k=p1 tight', 'n=p1|m=p1|k=p1 tight']);
    assert.deepEqual(order(ranked('n=1, m=1', 'lb', ['lb'], { exponent: 2, hops: 3 }), ranked('n=1, m=2', 'lb', ['lb'], { exponent: 2, hops: 1 })), [
      'n=p1|m=p2|k=p1 lb',
      'n=p1|m=p1|k=p1 lb',
    ]);
    assert.deepEqual(order(ranked('n=1, k=const:3', 'lb', ['lb'], { exponent: 3 }), ranked('n=1, k=const:4', 'lb', ['lb'], { exponent: 4 })), [
      'n=p1|m=p1|k=c4 lb',
      'n=p1|m=p1|k=c3 lb',
    ]);
  });

  it('prefers a simple lower-bound exponent among regimes alike', () => {
    assert.deepEqual(order(ranked('n=1, k=const:21', 'gap', ['lb'], { exponent: 1.684211 }), ranked('n=1, k=const:8', 'gap', ['lb'], { exponent: 1 })), [
      'n=p1|m=p1|k=c8 gap',
      'n=p1|m=p1|k=c21 gap',
    ]);
  });
});

describe('lbRegimeKey', () => {
  it('ranks regimes of lower bounds by niceness before hops and size', () => {
    const f = (spec: string, exponent: number, hops: number) => ({ regime: regime(spec), power: 1, exponent, hops });
    const keys = [f('n=1, m=10/11', 3, 1), f('n=1, m=1.5', 2, 3), f('n=1, m=2', 2, 3)].map(lbRegimeKey);
    assert.deepEqual(
      [0, 1, 2].sort((a, b) => compareKeys(keys[a]!, keys[b]!)),
      [2, 1, 0],
    );
  });
});

describe('listedByItself', () => {
  it('lists configured, knob and pinned regimes, and nice regimes of lower bounds', () => {
    assert.ok(listedByItself(ranked('n=1, m=10/11', 'ub', ['config'])));
    assert.ok(listedByItself(ranked('n=1, m=10/11', 'ub', ['knob'])));
    assert.ok(listedByItself(ranked('n=1, m=10/11', 'none', ['pinned'], null)));
    assert.ok(listedByItself(ranked('n=1, m=4/3', 'lb')));
    assert.ok(!listedByItself(ranked('n=1, m=10/11', 'lb')));
    assert.ok(!listedByItself(ranked('n=1, m=1.2', 'lb')), 'fifths');
  });
});

describe('regimes in the analysis', () => {
  // A (n) reduces to P (n, m) at m = n^{10/11}, and P to Q (n); A also reduces to D (n, m) at m = n^{12/13}, a dead end
  // (A has an algorithm of its own, so that its upper bound does not come through D). D's configured regime m = n^{1/2}
  // does not contain m = n^{12/13}, so that no lower bound is lifted into it (that is tested in 'bounds between a
  // problem's own regimes').
  const A = 'F / A';
  const P = 'F / P';
  const Q = 'F / Q';
  const D = 'F / D';
  const rows: RowSpec[] = [
    { id: 'ap', from: A, to: P, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^{10/11}))$' },
    { id: 'pq', from: P, to: Q, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: 'ad', from: A, to: D, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^{12/13}))$' },
  ];
  const m = model(rows, { problems: { [A]: { params: ['n'] }, [D]: { regimes: ['n=1, m=1/2'] } } });
  const hypothesis = { problem: A, kind: 'LB' as const, regime: 'n=1', exponent: 3 };
  const algorithm = { problem: A, kind: 'UB' as const, formula: 'n^3' };

  it('shows a nice regime with only an upper bound rather than an unusual one with both, and colors by it', () => {
    const a = analyze(m, scenario([hypothesis, algorithm, { problem: D, kind: 'UB', formula: 'n^3 m' }]));
    const d = a.summaries.get(D)!;
    assert.deepEqual(
      d.regimes.map((s) => [s.regime.key, s.status, s.listed]),
      [
        ['n=p1|m=p0.5', 'ub', true],
        ['n=p1|m=p0.923077', 'gap', false],
      ],
    );
    assert.equal(d.status, 'ub', 'the status of the regime shown');
  });

  it('shows a conflict wherever it is, also when another regime is pinned', () => {
    const a = analyze(m, scenario([hypothesis, algorithm, { problem: D, kind: 'UB', formula: 'n^2' }]));
    const d = a.summaries.get(D)!;
    assert.equal(d.primary!.regime.key, 'n=p1|m=p0.923077');
    assert.equal(d.status, 'conflict');
    assert.ok(d.primary!.listed);
    // (a pinned regime inside m = n^{12/13}: lower bounds are not lifted into it)
    const pinned = analyze(m, scenario([hypothesis, algorithm, { problem: D, kind: 'UB', formula: 'n^2' }]), new Map([[D, ['n=1, m=1/3']]])).summaries.get(D)!;
    assert.deepEqual(
      pinned.regimes.slice(0, 2).map((s) => [s.regime.key, s.status]),
      [
        ['n=p1|m=p0.923077', 'conflict'],
        ['n=p1|m=p0.333334', 'ub'],
      ],
    );
    assert.equal(pinned.status, 'conflict');
  });

  it('lists an unusual regime that another listed bound is derived through', () => {
    const a = analyze(m, scenario([hypothesis, algorithm, { problem: D, kind: 'UB', formula: 'n^3 m' }]));
    const p = a.summaries.get(P)!.regimes.find((s) => s.regime.key === 'n=p1|m=p0.909091')!;
    assert.ok(p.listed, 'Q’s lower bound comes through it');
    assert.ok(near(a.summaries.get(Q)!.primary!.lb!.exponent, 3));
    // The reductions used by listed bounds only: ad leads to D's unlisted regime alone.
    assert.ok(a.rowUse.get('ap')!.lb > 0);
    assert.ok(a.rowUse.get('pq')!.lb > 0);
    assert.equal(a.rowUse.get('ad'), undefined);
  });
});
