import assert from 'node:assert/strict';
import { isDark, isTheme, Theme, toggleTheme } from '../src/ui/theme';

/*
 * Testing strategy for light and dark mode
 *
 * isDark and toggleTheme, partition on: theme (system, light, dark) × system setting (light, dark)
 * isTheme: the three themes, other values
 */

const THEMES: readonly Theme[] = ['system', 'light', 'dark'];

describe('theme', () => {
  it('is dark when chosen, or when following a dark system', () => {
    assert.deepEqual(
      THEMES.map((t) => [isDark(t, false), isDark(t, true)]),
      [
        [false, true],
        [false, false],
        [true, true],
      ],
    );
  });

  it('toggles to the other look, following the system when the system shows that look', () => {
    // system light: light ↔ dark (light is the system's)
    assert.equal(toggleTheme('system', false), 'dark');
    assert.equal(toggleTheme('dark', false), 'system');
    assert.equal(toggleTheme('light', false), 'dark');
    // system dark: dark ↔ light (dark is the system's)
    assert.equal(toggleTheme('system', true), 'light');
    assert.equal(toggleTheme('light', true), 'system');
    assert.equal(toggleTheme('dark', true), 'light');
    // every toggle changes what is shown
    for (const t of THEMES) for (const sys of [false, true]) assert.notEqual(isDark(toggleTheme(t, sys), sys), isDark(t, sys));
  });

  it('recognizes themes', () => {
    assert.deepEqual(
      ['system', 'light', 'dark', 'auto', true, undefined].map(isTheme),
      [true, true, true, false, false, false],
    );
  });
});
