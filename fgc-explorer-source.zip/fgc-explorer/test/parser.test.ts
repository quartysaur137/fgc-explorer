import assert from 'node:assert/strict';
import { freeIdentifiers, monotoneInCalls, oracleCalls, toTex } from '../src/math/ast';
import { legendDefinitions, mathSpans, primaryFormula } from '../src/math/cells';
import { tokenize } from '../src/math/lexer';
import { parseDefinition, ParseError, parseExpr, parseFormula, parseList } from '../src/math/parser';

/*
 * Testing strategy for the lexer, parser and cell helpers
 *
 * tokenize: numbers (int, decimal), letters, commands (multi-letter, single-char), \text{...}, spacing commands,
 *   ignored sizing commands, unicode operators, errors (lone backslash, unterminated \text)
 * parseExpr / parseFormula, partition on construct:
 *   sums/differences, unary minus, products (\cdot, juxtaposition, implicit before groups), division (left-assoc),
 *   powers (braced, single char, multi-digit split, Greek), subscripted identifiers, Greek letters, \text names, |S|,
 *   \hat, oracle calls (T, T_p), apply (n(...), \alpha(n)), bounds (O, o, \Theta, \Omega, \tilde{O}, O_k),
 *   functions (\log with/without parens/power/base, a variable followed by a parenthesis, \sqrt, \sqrt[k], \frac, \binom, \max, \min, \lceil, \lfloor,
 *   \deg, \text{poly}), sums (\sum_{i=0}^{hi}, \sum_v, \sum_{v \in V}), alternatives (\subseteq, \le, =)
 *   errors: unexpected token, unbalanced parentheses, double exponent, unsupported command
 * parseList: signatures with one and several functions
 * parseDefinition: identifier = alternatives; non-definitions return null
 * cells: math spans (escaped \$, empty, unmatched), primary formula, legend definitions with exclusions
 * ast queries: freeIdentifiers (sum index bound), oracleCalls, monotoneInCalls (each rejection reason), toTex
 * Every From-time / RT / To-time formula of the real sheet is covered by the integration tests.
 */

const roundTrip = (s: string): string => toTex(parseExpr(s));

describe('tokenize', () => {
  it('tokenizes numbers, letters, commands and text', () => {
    const t = tokenize('2.5n \\cdot \\text{nnz} \\, \\left( x \\right)');
    assert.deepEqual(
      t.map((x) => `${x.kind}:${x.text}`),
      ['num:2.5', 'letter:n', 'cmd:cdot', 'text:nnz', 'sym:(', 'letter:x', 'sym:)', 'eof:'],
    );
  });

  it('maps unicode operators and rejects malformed input', () => {
    assert.deepEqual(
      tokenize('n·m ≤ ε').map((x) => x.text),
      ['n', 'cdot', 'm', 'le', 'epsilon', ''],
    );
    assert.throws(() => tokenize('x\\'), ParseError);
    assert.throws(() => tokenize('\\text{abc'), ParseError);
  });
});

describe('parseExpr', () => {
  it('parses sums, differences and unary minus', () => {
    assert.equal(roundTrip('a + b - c'), 'a + b - c');
    assert.equal(roundTrip('-x + 1'), '-x + 1');
    assert.equal(roundTrip('n - 1'), 'n - 1');
  });

  it('parses products by juxtaposition and \\cdot, and left-associative division', () => {
    assert.equal(roundTrip('2nd'), '2 \\cdot n \\cdot d');
    assert.equal(roundTrip('mn/t'), 'm \\cdot n/t');
    assert.equal(roundTrip('n \\log n / \\log \\log n'), 'n \\cdot \\log(n)/\\log(\\log(n))');
    assert.equal(roundTrip('9(n - 1)(B + 2)'), '9 \\cdot (n - 1) \\cdot (B + 2)');
    assert.equal(roundTrip('n^2/X^3'), 'n^{2}/X^{3}');
  });

  it('parses powers, including single-character scripts', () => {
    assert.equal(roundTrip('2^{n/2}'), '2^{n/2}');
    assert.equal(roundTrip('n^23'), 'n^{2} \\cdot 3');
    assert.equal(roundTrip('n^\\delta'), 'n^{\\delta}');
    assert.equal(roundTrip('(1/4+\\gamma)^i'), '(1/4 + \\gamma)^{i}');
    assert.throws(() => parseExpr('n^2^3'), ParseError);
  });

  it('canonicalizes identifiers', () => {
    const ids = (s: string): string[] => [...freeIdentifiers(parseExpr(s))].sort();
    assert.deepEqual(ids('B_{\\text{med}} c_{\\epsilon} n_v \\varepsilon \\Delta'), ['B_med', 'Delta', 'c_epsilon', 'epsilon', 'n_v']);
    assert.deepEqual(ids('|S| + |\\Gamma| + \\hat{d} + \\text{nnz}'), ['hat_d', 'nnz', '|Gamma|', '|S|']);
  });

  it('parses oracle calls and applications', () => {
    const e = parseExpr('T_p(n, m) + T(2n)');
    assert.deepEqual(
      oracleCalls(e).map((c) => [c.fn, c.args.length]),
      [
        ['T_p', 2],
        ['T', 1],
      ],
    );
    assert.equal(parseExpr('n(\\lfloor \\log t \\rfloor + 1)').type, 'apply');
    assert.equal(parseExpr('\\alpha(n)').type, 'apply');
  });

  it('parses bounds', () => {
    for (const [src, kind] of [
      ['O(n)', 'O'],
      ['o(1)', 'o'],
      ['\\Theta(n)', 'Theta'],
      ['\\Omega(1)', 'Omega'],
      ['\\tilde{O}(n)', 'softO'],
      ['O_k(n)', 'Osub'],
      ['O_{k}(n)', 'Osub'],
    ] as const) {
      const e = parseExpr(src);
      assert.equal(e.type === 'bound' && e.kind, kind, src);
    }
  });

  it('parses functions', () => {
    assert.equal(roundTrip('\\log^2 n'), '\\log(n)^{2}');
    assert.equal(roundTrip('\\log^{O(1)} n'), '\\log(n)^{O(1)}');
    assert.equal(roundTrip('\\log(nM)'), '\\log(n \\cdot M)');
    assert.equal(roundTrip('\\log_4 n'), '\\log_{4}(n)');
    // a variable after \log is its whole argument when a parenthesis follows: \log n (n + m) is \log(n) · (n + m)
    assert.equal(roundTrip('n^{2.5} \\log n (n + m)'), 'n^{2.5} \\cdot \\log(n) \\cdot (n + m)');
    assert.equal(roundTrip('\\log^2 n (m)'), '\\log(n)^{2} \\cdot m');
    assert.equal(roundTrip('\\log_2 n(m)'), '\\log_{2}(n) \\cdot m');
    assert.equal(roundTrip('\\log T(n)'), '\\log(T(n))', 'an oracle call is still the argument');
    assert.equal(roundTrip('\\log \\alpha(n)'), '\\log(\\alpha(n))');
    assert.equal(roundTrip('\\sqrt{n}'), '\\sqrt{n}');
    assert.equal(roundTrip('\\sqrt[3]{n}'), '\\sqrt[3]{n}');
    assert.equal(roundTrip('\\frac{a}{b}'), 'a/b');
    assert.equal(roundTrip('\\binom{\\lambda}{2} M'), '\\binom{\\lambda}{2} \\cdot M');
    assert.equal(roundTrip('\\max(n, m)'), '\\max(n, m)');
    assert.equal(roundTrip('\\min\\{a, b\\}'), '\\min(a, b)');
    assert.equal(roundTrip('3\\lceil n^{1/3} \\rceil + 6'), '3 \\cdot \\lceil n^{1/3} \\rceil + 6');
    assert.equal(roundTrip('\\lfloor k/2 \\rfloor'), '\\lfloor k/2 \\rfloor');
    assert.equal(roundTrip('\\text{poly}(n)'), '\\text{poly}(n)');
    assert.equal(parseExpr('\\deg(v)').type, 'func');
  });

  it('parses sums with ranges, bare indices and index sets', () => {
    const s = parseExpr('\\sum_{i=0}^{\\log n} 4^i \\cdot T(n/2^i)');
    assert.equal(s.type, 'sum');
    if (s.type === 'sum') {
      assert.equal(s.index, 'i');
      assert.ok(s.lo && s.hi);
      assert.equal(s.body.type, 'mul');
    }
    const b = parseExpr('\\sum_v T(n_v)');
    assert.ok(b.type === 'sum' && b.index === 'v' && b.hi === null);
    const c = parseExpr('\\sum_{v \\in V} x + 1');
    assert.ok(c.type === 'add', 'the sum body stops at +');
    assert.deepEqual([...freeIdentifiers(parseExpr('\\sum_{i=0}^{k} i \\cdot n'))].sort(), ['k', 'n']);
  });

  it('reports errors with positions', () => {
    assert.throws(() => parseExpr('O(n'), (e: unknown) => e instanceof ParseError && e.pos === 3);
    assert.throws(() => parseExpr('n + )'), ParseError);
    assert.throws(() => parseExpr('\\foo(n)'), ParseError);
    assert.throws(() => parseExpr('\\#\\text{vars}'), ParseError);
    assert.throws(() => parseExpr('a = b'), ParseError, 'alternatives are not expressions');
  });
});

describe('parseFormula / parseList / parseDefinition', () => {
  it('splits alternatives on \\subseteq, \\le and =', () => {
    assert.equal(parseFormula('O(x) \\subseteq O(y) = O(z)').alternatives.length, 3);
    assert.equal(parseFormula('O(T(n))').alternatives.length, 1);
  });

  it('parses signatures', () => {
    const fns = parseList('T_p(n, m), T_u(n, m), T_q(n, m)');
    assert.equal(fns.length, 3);
    assert.equal(parseList('T(n, m, M, |S|, |T|)').length, 1);
  });

  it('parses definitions and rejects non-definitions', () => {
    const d = parseDefinition('\\lambda = k - \\lceil k/2 \\rceil + 1 = \\lfloor k/2 \\rfloor + 1');
    assert.ok(d !== null && d.name === 'lambda' && d.alternatives.length === 2);
    assert.equal(parseDefinition('n = \\#\\text{variables}'), null);
    assert.equal(parseDefinition('k \\geq 2'), null);
    assert.equal(parseDefinition('O(n) \\subseteq O(m)'), null);
    assert.equal(parseDefinition('n + 1 = m'), null);
  });
});

describe('cells', () => {
  it('finds math spans', () => {
    assert.deepEqual(
      mathSpans('a $x$ b \\$ $ y $ $$ $z').map((s) => s.tex),
      ['x', 'y'],
    );
    assert.equal(primaryFormula('$O(T(n))$; $n$ = size'), 'O(T(n))');
    assert.equal(primaryFormula('??'), null);
  });

  it('reads legend definitions after the first span, excluding given names', () => {
    const cell = '$O(T(N))$ with $N = O(m + 2^{n/2})$; $n = \\#\\text{vars}$, $m = O(n)$';
    assert.deepEqual(
      legendDefinitions(cell, new Set(['n', 'm'])).map((d) => d.name),
      ['N'],
    );
  });
});

describe('monotoneInCalls', () => {
  it('accepts monotone formulas', () => {
    for (const s of [
      'O(n^2 \\cdot T(n) + \\max(T(m), n))',
      '\\sqrt{T(n)}',
      '\\sum_{i=0}^{\\log n} 4^i T(n/2^i)',
      '(n/X) \\cdot T(X)',
      'O(\\log n \\cdot T(n))',
    ]) {
      assert.equal(monotoneInCalls(parseExpr(s)), null, s);
    }
  });

  it('rejects non-monotone positions', () => {
    for (const s of ['n - T(n)', 'n / T(n)', 'T(n)^{-1}', '2^{T(n)}', '\\log(T(n))', 'T(T(n))', '-T(n)', 'o(T(n))']) {
      assert.notEqual(monotoneInCalls(parseExpr(s)), null, s);
    }
  });
});
