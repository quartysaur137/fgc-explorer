import assert from 'node:assert/strict';
import { offscreenPointer, refAttrs } from '../src/ui/hover';

/*
 * Testing strategy for hover highlighting (the DOM part is covered by the e2e test)
 *
 * offscreenPointer, partition on the box: inside the view, partly inside (each side), outside (left, right, above,
 *   below, a corner); margins: smaller than the view, larger (then centered)
 * refAttrs: problem, reduction
 */

const W = 800;
const H = 600;
const box = (cx: number, cy: number, w = 40, h = 20) => ({ x1: cx - w / 2, y1: cy - h / 2, x2: cx + w / 2, y2: cy + h / 2 });

describe('offscreenPointer', () => {
  it('is null for a box that is (partly) in view', () => {
    assert.equal(offscreenPointer(box(400, 300), W, H, 50, 20), null);
    assert.equal(offscreenPointer(box(-10, 300), W, H, 50, 20), null, 'across the left edge');
    assert.equal(offscreenPointer(box(810, 300), W, H, 50, 20), null, 'across the right edge');
    assert.equal(offscreenPointer(box(400, 605), W, H, 50, 20), null, 'across the bottom edge');
  });

  it('puts the pointer at the edge nearest the box, pointing at it', () => {
    const right = offscreenPointer(box(1000, 300), W, H, 50, 20)!;
    assert.deepEqual([right.x, right.y, right.angle], [750, 300, 0]);
    const above = offscreenPointer(box(400, -200), W, H, 50, 20)!;
    assert.deepEqual([above.x, above.y], [400, 20]);
    assert.ok(Math.abs(above.angle + Math.PI / 2) < 1e-12, 'up');
    const corner = offscreenPointer(box(-100, 900), W, H, 50, 20)!;
    assert.deepEqual([corner.x, corner.y], [50, 580]);
    assert.ok(corner.angle > Math.PI / 2 && corner.angle < Math.PI, 'down and to the left');
  });

  it('centers the pointer along an axis that has no room for it', () => {
    const p = offscreenPointer(box(400, 900), 80, H, 50, 20)!;
    assert.equal(p.x, 40);
  });
});

describe('refAttrs', () => {
  it('marks references to problems and reductions', () => {
    assert.deepEqual(refAttrs({ kind: 'problem', id: '3SUM / 3SUM' }), { 'data-ref-problem': '3SUM / 3SUM' });
    assert.deepEqual(refAttrs({ kind: 'row', id: '13' }), { 'data-ref-row': '13' });
  });
});
