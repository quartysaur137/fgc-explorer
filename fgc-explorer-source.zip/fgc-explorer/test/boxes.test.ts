import assert from 'node:assert/strict';
import { boxOrder, canonicalProblem, problemBoxes } from '../src/model/boxes';
import { KnobSpec } from '../src/model/config';
import { model as makeModel } from './helpers';

/*
 * Testing strategy for problem boxes
 *
 * problemBoxes, partition on: problems listed (none, some, repeated, listed but without knobs), knobs (none, problems
 * listed or not, interleaved problems), names of one problem written differently (canonical key); order of boxes and of
 * knobs within a box
 * canonicalProblem: known problem (any case and spacing → its id), unknown (spaces squashed), no model
 */

const knob = (problem: string, exponent: number): KnobSpec => ({ problem, kind: 'UB', regime: 'n=1', exponent });

describe('problemBoxes', () => {
  it('has no boxes without problems and knobs', () => {
    assert.deepEqual(problemBoxes([], []), []);
  });

  it('orders boxes by the list, then by first knob, and keeps the knob order within a box', () => {
    const a1 = knob('A', 1);
    const b1 = knob('B', 1);
    const a2 = knob('A', 2);
    const c1 = knob('C', 1);
    const boxes = problemBoxes(['C', 'D', 'C'], [a1, b1, a2, c1]);
    assert.deepEqual(
      boxes.map((b) => [b.problem, b.knobs.map((k) => `${k.problem}${k.exponent}`)]),
      [
        ['C', ['C1']],
        ['D', []],
        ['A', ['A1', 'A2']],
        ['B', ['B1']],
      ],
    );
    assert.deepEqual(boxOrder(['C', 'D', 'C'], [a1, b1, a2, c1]), ['C', 'D', 'A', 'B']);
  });

  it('puts names of one problem in one box', () => {
    const canonical = (name: string): string => name.toLowerCase();
    const boxes = problemBoxes(['x / Y'], [knob('X / y', 1), knob('X / Y', 2)], canonical);
    assert.deepEqual(
      boxes.map((b) => [b.problem, b.knobs.length]),
      [['x / y', 2]],
    );
  });
});

describe('canonicalProblem', () => {
  const m = makeModel([{ id: '1', from: '3SUM / 3SUM', to: 'Geometry / GeomBase', toTime: '$T(n)$', fromTime: '$O(T(n))$' }]);

  it("gives a known problem's id, else the name with spaces squashed", () => {
    const canonical = canonicalProblem(m);
    assert.equal(canonical('3sum  /  3SUM'), '3SUM / 3SUM');
    assert.equal(canonical(' Nowhere  /  Unknown '), 'Nowhere / Unknown');
    assert.equal(canonicalProblem(null)('3sum  /  3SUM'), '3sum / 3SUM');
  });
});
