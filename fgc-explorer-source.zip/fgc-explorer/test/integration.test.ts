import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { analyze, Analysis } from '../src/engine/analysis';
import { primaryFormula } from '../src/math/cells';
import { parseFormula, parseList } from '../src/math/parser';
import { initialScenario, KnobSpec, validateConfig } from '../src/model/config';
import { buildModel, COL, Model } from '../src/model/model';
import { CsvTable } from '../src/util/csv';
import { near, scenario } from './helpers';

/*
 * Integration tests on the real sheet (data/FGC_Reductions_filled.csv) and the default config.
 *
 * Partitions: every formula cell parses; row-status counts do not regress; each hypothesis produces its textbook
 * consequences; upper bounds flow backward; conflicts are detected; known equivalences hold; the initial scenario is
 * consistent; the 2026 algorithms refute exactly the hypotheses they should.
 */

const csv = readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');
const configJson = JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'));

describe('real sheet', function () {
  this.timeout(60000);
  const { table } = CsvTable.fromText(csv);
  const config = validateConfig(configJson);
  const model: Model = buildModel(table, config.value);
  /** The knobs of the config's initial groups with these labels (all of them switched on). */
  const group = (...labels: string[]): KnobSpec[] => {
    const groups = config.value.initialKnobs.filter((g) => labels.includes(g.label));
    assert.equal(groups.length, labels.length, `initial knob groups ${labels.join(', ')}`);
    return groups.flatMap((g) => g.knobs);
  };
  const SETH = 'SETH';
  const H_3SUM = '3SUM hypothesis';
  const H_APSP = 'APSP hypothesis';
  const KNOWN = 'Known algorithms';
  const AVW = 'Alman & Vassilevska Williams 2026';
  const lb = (a: Analysis, problem: string, key: string): number | undefined => a.lower.facts.get(problem)?.get(key)?.exponent;
  const ub = (a: Analysis, problem: string, key: string): number | undefined =>
    a.summaries.get(problem)?.regimes.find((r) => r.regime.key === key)?.ub?.exponent;

  it('has a valid default config', () => {
    assert.deepEqual(config.errors, []);
    assert.deepEqual(
      model.diagnostics.filter((d) => d.level !== 'info').map((d) => d.message),
      [],
    );
  });

  it('parses every formula cell', () => {
    for (let i = 0; i < table.rowCount; i++) {
      for (const col of [COL.fromTime, COL.rt]) {
        const f = primaryFormula(table.get(i, col));
        if (f !== null) assert.doesNotThrow(() => parseFormula(f), `${table.get(i, COL.id)} ${col}: ${f}`);
      }
      const t = primaryFormula(table.get(i, COL.toTime));
      if (t !== null) assert.doesNotThrow(() => parseList(t), `${table.get(i, COL.id)} To-time: ${t}`);
    }
  });

  it('uses all rows that have a static formula', () => {
    const counts: Record<string, number> = {};
    for (const r of model.rows) counts[r.status] = (counts[r.status] ?? 0) + 1;
    assert.ok((counts.ok ?? 0) >= 238, JSON.stringify(counts));
    assert.equal(counts['unknown-symbols'] ?? 0, 0);
    assert.equal(counts['parse-error'] ?? 0, 0);
    assert.equal(counts['non-monotone'] ?? 0, 0);
    assert.equal(counts.arity ?? 0, 0);
  });

  it('SETH: OV, k-OV, edit distance, diameter, subset sum', () => {
    const a = analyze(model, scenario(group(SETH)));
    assert.ok(near(lb(a, 'Orthogonal Vectors / OV', 'n=p1|d=L'), 2));
    assert.ok(near(lb(a, 'Orthogonal Vectors / k-OV', 'n=p1|d=L|k=c3'), 3));
    assert.ok(near(lb(a, 'String Similarity / Edit Distance', 'n=p1|sigma=c7'), 2));
    assert.ok(near(lb(a, 'Longest Common Subsequence / Longest Common Subsequence', 'n=p1|m=p1|sigma=c2'), 2));
    assert.ok(near(lb(a, 'Graph Metrics / Diameter 2 vs 3', 'n=p1|m=p1'), 2));
    // Subset Sum: t^{1-o(1)} 2^{o(N)} (as ε → 0)
    assert.ok(near(lb(a, 'The Subset-Sum Problem / Subset Sum', 'N=L|t=p1'), 1, 1e-3));
  });

  it('3SUM: geometry and convolution', () => {
    const a = analyze(model, scenario(group(H_3SUM)));
    for (const p of ['Geometric Base / GeomBase', '3SUM / Convolution 3SUM', '3SUM / 3SUM\'']) {
      assert.ok(near(lb(a, p, 'n=p1|M=P'), 2), p);
    }
    for (const p of ['Geometric Incidence Problems / 3 Points on Line', 'Geometric Covering Problems / Strips Cover Box']) {
      assert.ok(near(lb(a, p, 'n=p1'), 2), p);
    }
  });

  it('APSP: dense Negative Triangle and the subcubic-equivalence class', () => {
    const a = analyze(model, scenario(group(H_APSP)));
    const dense = 'n=p1|m=p2|M=P';
    assert.ok(near(lb(a, 'Matrix Product / Distance Product', 'n=p1|M=P'), 3));
    for (const p of [
      'Graph Triangle Problems / Negative Triangle Detection',
      'Graph Metrics / Directed Radius',
      'Vertex Centrality / Betweenness Centrality (BC)',
      'Shortest Path (Directed graphs) / Replacement Paths Problem (RPP)',
      'Graph Cycles / Shortest Cycle',
    ]) {
      assert.ok(near(lb(a, p, dense), 3), p);
    }
  });

  it('known algorithms make the hypotheses tight', () => {
    const a = analyze(model, scenario(group(SETH, H_3SUM, H_APSP, KNOWN)));
    assert.equal(a.summaries.get('Boolean Satisfiability / CNF-SAT')!.status, 'tight');
    assert.equal(a.summaries.get('Orthogonal Vectors / OV')!.status, 'tight');
    assert.equal(a.summaries.get('3SUM / 3SUM')!.status, 'tight');
    assert.equal(a.summaries.get('Graph Triangle Problems / Negative Triangle Detection')!.status, 'tight');
    assert.ok(near(ub(a, 'Orthogonal Vectors / OV', 'n=p1|d=L'), 2));
  });

  it('upper bounds flow backward along reductions', () => {
    const a = analyze(model, scenario([{ problem: '3SUM / 3SUM', kind: 'UB', regime: 'n=1, M=poly', exponent: 1.9 }]));
    assert.ok(near(ub(a, "3SUM / 3SUM'", 'n=p1|M=P'), 1.9));
    assert.ok(near(ub(a, '3SUM / Convolution 3SUM', 'n=p1|M=P'), 1.9));
  });

  it('detects conflicts between hypotheses and algorithms', () => {
    const a = analyze(
      model,
      scenario([...group(H_APSP), { problem: 'Graph Triangle Problems / Negative Triangle Detection', kind: 'UB', formula: 'n^{2.9}' }]),
    );
    assert.equal(a.summaries.get('Graph Triangle Problems / Negative Triangle Detection')!.status, 'conflict');
    // APSP reduces to Negative Triangle, so APSP inherits the n^{2.9} algorithm and conflicts with its own hypothesis
    assert.equal(a.summaries.get('All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP')!.status, 'conflict');
  });

  const conflictsOf = (a: Analysis): string[] => [...a.summaries.values()].filter((s) => s.status === 'conflict').map((s) => s.problem.id);

  it('starts from a consistent initial scenario whose switched-off knobs are valid too', () => {
    const initial = initialScenario(config.value);
    assert.ok(initial.knobs.some((k) => !k.enabled), 'some initial knobs start switched off');
    const a = analyze(model, initial);
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    const all = analyze(model, { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) });
    assert.deepEqual([...all.knobIssues.values()], [], 'every initial knob refers to a problem, regime and formula that work');
  });

  it('finds no conflict between the classic hypotheses and the known algorithms', () => {
    // The hypotheses were believed consistent with the textbook algorithms: a conflict here means a bug in the engine,
    // the config annotations or a sheet formula (this caught an unsound simplification of row 316).
    const t0 = Date.now();
    const hypotheses = config.value.initialKnobs.filter((g) => g.knobs.every((k) => k.kind === 'LB')).map((g) => g.label);
    assert.ok(hypotheses.length >= 7, hypotheses.join(', '));
    const a = analyze(model, scenario(group(...hypotheses, KNOWN)));
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    assert.deepEqual(a.lower.inconsistencies, []);
    assert.ok(Date.now() - t0 < 30000);
  });

  describe('the Oct 2026 algorithms of Alman and Vassilevska Williams (arXiv:2610.06783)', () => {
    it('conflict with the 3SUM and APSP hypotheses throughout their classes', () => {
      const a = analyze(model, scenario(group(H_3SUM, H_APSP, KNOWN, AVW)));
      const conflicts = conflictsOf(a);
      for (const p of [
        '3SUM / 3SUM',
        '3SUM / Convolution 3SUM',
        'Geometric Base / GeomBase',
        'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP',
        'All-Pairs Shortest Paths (APSP) / Undirected, Weighted APSP',
        'Graph Triangle Problems / Negative Triangle Detection',
        'Graph Triangle Problems / Exact Triangle',
        'Graph Metrics / Directed Radius',
      ]) {
        assert.ok(conflicts.includes(p), p);
      }
    });

    it('leave SETH, OV, k-Clique and BMM consistent', () => {
      const a = analyze(model, scenario(group(SETH, 'OV hypothesis', 'k-Clique hypothesis', 'Combinatorial BMM hypothesis', KNOWN, AVW)));
      assert.deepEqual(conflictsOf(a), []);
    });

    it('give 3SUM in n^{1.99915} through Exact Triangle in n^{2.9983} (rows 53 and 60)', () => {
      // Convolution 3SUM in O(√n · T_ExactTriangle(√n)): 1/2 + 2.9983/2 = 1.99915, below the paper's stated 1.9992.
      const a = analyze(model, scenario(group(AVW)));
      assert.ok(near(ub(a, '3SUM / 3SUM', 'n=p1|M=P'), 1.99915, 1e-9));
    });
  });
});
