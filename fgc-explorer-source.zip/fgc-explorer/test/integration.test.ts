import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { analyze, Analysis, RegimeSummary, rowUsable } from '../src/engine/analysis';
import { explainLower, lbChain, LBFact } from '../src/engine/lower';
import { regimeNiceness } from '../src/engine/regimeRank';
import { constantEnv } from '../src/engine/rowEval';
import { UBFact, ubParts } from '../src/engine/upper';
import * as G from '../src/growth/growth';
import { primaryFormula } from '../src/math/cells';
import { parseFormula, parseList } from '../src/math/parser';
import { initialScenario, KnobSpec, Scenario, validateConfig } from '../src/model/config';
import { buildModel, COL, Model } from '../src/model/model';
import { CsvTable } from '../src/util/csv';
import { near, scenario } from './helpers';

/*
 * Integration tests on the real sheet (data/FGC_Reductions_filled.csv) and the default config.
 *
 * Partitions: every formula cell parses; row-status counts do not regress; each hypothesis produces its textbook
 * consequences; upper bounds flow backward; conflicts are detected; known equivalences hold; the initial scenario is
 * consistent; the trivial and best known algorithms are consistent with every hypothesis (the non-combinatorial one
 * conflicts with the combinatorial BMM hypothesis only); the 2026 algorithms refute exactly the hypotheses they
 * should; derivations take no detours; every
 * problem has its best bound, the same inside other derivations (no reduction gives a better one, whatever the length
 * of the derivation); a raised 3SUM hypothesis makes a cycle raise lower bounds without limit; every regime is within
 * its problem's limits of parameters.
 */

const csv = readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');
const configJson = JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'));

describe('real sheet', function () {
  this.timeout(60000);
  const { table } = CsvTable.fromText(csv);
  const config = validateConfig(configJson);
  const model: Model = buildModel(table, config.value);
  /** The knobs of the config's initial groups with these labels (all of them switched on). */
  const group = (...labels: string[]): KnobSpec[] => {
    const groups = config.value.initialKnobs.filter((g) => labels.includes(g.label));
    assert.equal(groups.length, labels.length, `initial knob groups ${labels.join(', ')}`);
    return groups.flatMap((g) => g.knobs);
  };
  /** SETH for CNF-SAT (the group was called "SETH" before format 11). */
  const SETH = 'Satisfiability Hypothesis';
  const H_3SUM = '3SUM hypothesis';
  const H_APSP = 'APSP hypothesis';
  const KNOWN = 'Known algorithms';
  const TRIVIAL = 'Trivial algorithms';
  const BEST = 'Best known algorithms';
  const NONCOMB = 'Non-combinatorial algorithms';
  const AVW = 'Alman & Vassilevska Williams 2026';
  const lb = (a: Analysis, problem: string, key: string): number | undefined => a.lower.facts.get(problem)?.get(key)?.exponent;
  const ub = (a: Analysis, problem: string, key: string): number | undefined =>
    a.summaries.get(problem)?.regimes.find((r) => r.regime.key === key)?.ub?.exponent;
  /** "problem#regime key" of every bound below an upper bound in its derivation tree. */
  const ubNodes = (f: UBFact): Set<string> => {
    const out = new Set<string>();
    const seen = new Set<UBFact>([f]);
    const walk = (g: UBFact): void => {
      for (const c of ubParts(g)) {
        if (seen.has(c)) continue;
        seen.add(c);
        out.add(`${c.problem}#${c.regime.key}`);
        walk(c);
      }
    };
    walk(f);
    return out;
  };

  it('has a valid default config', () => {
    assert.deepEqual(config.errors, []);
    assert.deepEqual(
      model.diagnostics.filter((d) => d.level !== 'info').map((d) => d.message),
      [],
    );
  });

  it('parses every formula cell', () => {
    for (let i = 0; i < table.rowCount; i++) {
      for (const col of [COL.fromTime, COL.rt]) {
        const f = primaryFormula(table.get(i, col));
        if (f !== null) assert.doesNotThrow(() => parseFormula(f), `${table.get(i, COL.id)} ${col}: ${f}`);
      }
      const t = primaryFormula(table.get(i, COL.toTime));
      if (t !== null) assert.doesNotThrow(() => parseList(t), `${table.get(i, COL.id)} To-time: ${t}`);
    }
  });

  it('uses all rows that have a static formula', () => {
    const counts: Record<string, number> = {};
    for (const r of model.rows) counts[r.status] = (counts[r.status] ?? 0) + 1;
    assert.ok((counts.ok ?? 0) >= 238, JSON.stringify(counts));
    assert.equal(counts['unknown-symbols'] ?? 0, 0);
    assert.equal(counts['parse-error'] ?? 0, 0);
    assert.equal(counts['non-monotone'] ?? 0, 0);
    assert.equal(counts.arity ?? 0, 0);
  });

  it('SETH: OV, k-OV, edit distance, diameter, subset sum', () => {
    const a = analyze(model, scenario(group(SETH)));
    assert.ok(near(lb(a, 'Orthogonal Vectors / OV', 'n=p1|d=L'), 2));
    assert.ok(near(lb(a, 'Orthogonal Vectors / k-OV', 'n=p1|d=L|k=c3'), 3));
    assert.ok(near(lb(a, 'String Similarity / Edit Distance', 'n=p1|sigma=c7'), 2));
    assert.ok(near(lb(a, 'Longest Common Subsequence / Longest Common Subsequence', 'n=p1|m=p1|sigma=c2'), 2));
    assert.ok(near(lb(a, 'Graph Metrics / Diameter 2 vs 3', 'n=p1|m=p1'), 2));
    // Subset Sum: t^{1-o(1)} 2^{o(N)} (as ε → 0)
    assert.ok(near(lb(a, 'The Subset-Sum Problem / Subset Sum', 'N=L|t=p1'), 1, 1e-3));
  });

  it('3SUM: geometry and convolution', () => {
    const a = analyze(model, scenario(group(H_3SUM)));
    for (const p of ['Geometric Base / GeomBase', '3SUM / Convolution 3SUM', '3SUM / 3SUM\'']) {
      assert.ok(near(lb(a, p, 'n=p1|M=P'), 2), p);
    }
    for (const p of ['Geometric Incidence Problems / 3 Points on Line', 'Geometric Covering Problems / Strips Cover Box']) {
      assert.ok(near(lb(a, p, 'n=p1'), 2), p);
    }
  });

  it('APSP: dense Negative Triangle and the subcubic-equivalence class', () => {
    const a = analyze(model, scenario(group(H_APSP)));
    const dense = 'n=p1|m=p2|M=P';
    assert.ok(near(lb(a, 'Matrix Product / Distance Product', 'n=p1|M=P'), 3));
    for (const p of [
      'Graph Triangle Problems / Negative Triangle Detection',
      'Graph Metrics / Directed Radius',
      'Vertex Centrality / Betweenness Centrality (BC)',
      'Shortest Path (Directed graphs) / Replacement Paths Problem (RPP)',
      'Graph Cycles / Shortest Cycle',
    ]) {
      assert.ok(near(lb(a, p, dense), 3), p);
    }
  });

  it('known algorithms make the hypotheses tight', () => {
    const a = analyze(model, scenario(group(SETH, H_3SUM, H_APSP, KNOWN)));
    assert.equal(a.summaries.get('Boolean Satisfiability / CNF-SAT')!.status, 'tight');
    assert.equal(a.summaries.get('Orthogonal Vectors / OV')!.status, 'tight');
    assert.equal(a.summaries.get('3SUM / 3SUM')!.status, 'tight');
    assert.equal(a.summaries.get('Graph Triangle Problems / Negative Triangle Detection')!.status, 'tight');
    assert.ok(near(ub(a, 'Orthogonal Vectors / OV', 'n=p1|d=L'), 2));
  });

  it('upper bounds flow backward along reductions', () => {
    const a = analyze(model, scenario([{ problem: '3SUM / 3SUM', kind: 'UB', regime: 'n=1, M=poly', exponent: 1.9 }]));
    assert.ok(near(ub(a, "3SUM / 3SUM'", 'n=p1|M=P'), 1.9));
    assert.ok(near(ub(a, '3SUM / Convolution 3SUM', 'n=p1|M=P'), 1.9));
  });

  it('detects conflicts between hypotheses and algorithms', () => {
    const a = analyze(
      model,
      scenario([...group(H_APSP), { problem: 'Graph Triangle Problems / Negative Triangle Detection', kind: 'UB', formula: 'n^{2.9}' }]),
    );
    assert.equal(a.summaries.get('Graph Triangle Problems / Negative Triangle Detection')!.status, 'conflict');
    // APSP reduces to Negative Triangle, so APSP inherits the n^{2.9} algorithm and conflicts with its own hypothesis
    assert.equal(a.summaries.get('All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP')!.status, 'conflict');
  });

  const conflictsOf = (a: Analysis): string[] => [...a.summaries.values()].filter((s) => s.status === 'conflict').map((s) => s.problem.id);

  it('starts from a consistent initial scenario whose switched-off knobs are valid too', () => {
    const initial = initialScenario(config.value);
    assert.ok(initial.knobs.some((k) => !k.enabled), 'some initial knobs start switched off');
    const a = analyze(model, initial);
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    const all = analyze(model, { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) });
    assert.deepEqual([...all.knobIssues.values()], [], 'every initial knob refers to a problem, regime and formula that work');
  });

  it('finds no conflict between the classic hypotheses and the known algorithms', () => {
    // The hypotheses were believed consistent with the textbook algorithms: a conflict here means a bug in the engine,
    // the config annotations or a sheet formula (this caught an unsound simplification of row R316).
    const t0 = Date.now();
    const hypotheses = config.value.initialKnobs.filter((g) => g.knobs.every((k) => k.kind === 'LB')).map((g) => g.label);
    assert.ok(hypotheses.length >= 7, hypotheses.join(', '));
    const a = analyze(model, scenario(group(...hypotheses, KNOWN)));
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    assert.deepEqual(a.lower.inconsistencies, []);
    assert.ok(Date.now() - t0 < 30000);
  });

  it('finds no conflict between the hypotheses and the trivial and best known algorithms', () => {
    // A conflict here means a wrong algorithm in the config, or a bug: tight pairs of bounds at regimes whose rounded
    // exponents differ from the exact ones (ST-Maximum Flow, Set Intersection) were conflicts before regimes were
    // rounded up.
    const t0 = Date.now();
    const hypotheses = config.value.initialKnobs.filter((g) => g.knobs.every((k) => k.kind === 'LB')).map((g) => g.label);
    const a = analyze(model, scenario(group(...hypotheses, KNOWN, TRIVIAL, BEST)));
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    assert.deepEqual(a.lower.inconsistencies, []);
    assert.ok(Date.now() - t0 < 30000);
    const statuses = (p: string): string[] => [...new Set(a.summaries.get(p)!.regimes.map((r) => r.status))].sort();
    assert.ok(statuses('Maximum Flow / ST-Maximum Flow').includes('tight'), statuses('Maximum Flow / ST-Maximum Flow').join());
    assert.ok(statuses('Set Intersection Problems / Set Intersection').includes('tight'));
    assert.equal(a.summaries.get('Boolean Satisfiability / CNF-SAT')!.status, 'tight');
  });

  it("conflicts with the combinatorial BMM hypothesis only through fast matrix multiplication (Valiant's parser, transitive closure)", () => {
    const hypotheses = config.value.initialKnobs.filter((g) => g.knobs.every((k) => k.kind === 'LB')).map((g) => g.label);
    const a = analyze(model, scenario(group(...hypotheses, KNOWN, TRIVIAL, BEST, NONCOMB)));
    assert.deepEqual(conflictsOf(a).sort(), [
      'CFG Problems / CFG Parsing',
      'Graph Triangle Problems / Combinatorial Triangle Detection',
      'Matrix Product / Combinatorial BMM',
      'Vertex Reachability / Transitive Closure',
    ]);
    const others = hypotheses.filter((h) => h !== 'Combinatorial BMM hypothesis');
    assert.deepEqual(conflictsOf(analyze(model, scenario(group(...others, KNOWN, TRIVIAL, BEST, NONCOMB)))), []);
  });

  it('derives the bounds of the rows added in Oct 2026 (R320–R365)', () => {
    const tight = (a: Analysis, p: string, key: string, x: number, tol = 1e-6): void => {
      assert.ok(near(lb(a, p, key), x, tol), `${p} LB at ${key}: ${lb(a, p, key)}`);
      assert.ok(near(ub(a, p, key), x, tol), `${p} UB at ${key}: ${ub(a, p, key)}`);
    };
    const seth = analyze(model, scenario(group(SETH, KNOWN, TRIVIAL, BEST)));
    // SETH -> unbalanced OV (R365) -> regular expressions (R332) and dynamic time warping (R8): (nm)^{1-o(1)}, tight
    tight(seth, 'Orthogonal Vectors / UOV', 'n=p1|m=p0.5|d=L', 1.5);
    tight(seth, 'Regular Expression Pattern Matching', 'n=p1|m=p0.5', 1.5);
    tight(seth, 'Dynamic Time Warping / Dynamic Time Warping', 'n=p1|m=p0.5|sigma=c5', 1.5);
    // SETH -> k-Dominating Set (R340): n^k for dense graphs, tight from k = 8 (Eisenbrand-Grandoni)
    tight(seth, 'k-Dominating Set', 'n=p1|m=p2|k=c8', 8);
    // SETH -> Bicriteria s,t-Path (R344): Joksch's O(Lm) is optimal
    tight(seth, 'Bicriteria s,t-Path', 'n=p1|m=p1|L=p1|C=p1', 2);
    tight(seth, 'Bicriteria s,t-Path', 'n=p1|m=p1|L=p3|C=p3', 4);
    // OV -> approximate close pair (R350) -> attention (R351): quadratic at entries Theta(sqrt(log n)), linear at constant ones
    tight(seth, 'Approximate Attention Computation', 'n=p1|d=L|B=L', 2);
    assert.ok(near(ub(seth, 'Approximate Attention Computation', 'n=p1|d=L|B=c?'), 1));
    // MAX-2-SAT through Max-Weight 3-Clique with small weights (R361): 2^{omega n/3}
    const omega = config.value.constants['omega']!.value;
    assert.ok(near(ub(seth, 'Boolean Satisfiability / MAX-2-SAT', 'n=E|m=L'), omega / 3, 1e-5));
    const all = config.value.initialKnobs.filter((g) => g.knobs.every((k) => k.kind === 'LB')).map((g) => g.label);
    const a = analyze(model, scenario(group(...all, KNOWN, TRIVIAL, BEST)));
    tight(a, 'Matrix-Vector Multiplication / OuMv', 'n=p1', 3); // OMv conjecture (R320)
    tight(a, 'Tree Edit Distance', 'n=p1|sigma=p1|M=P', 3); // APSP hypothesis (R334)
    tight(a, 'Graph Metrics / Undirected Radius', 'n=p1|m=p1|M=C', 2); // Hitting Set hypothesis (R342)
    tight(a, 'Global-Frechet Polyline Simplification', 'n=p1|d=L', 3); // ∀∀∃-OV hypothesis (R348)
    tight(a, 'Vertex Reachability / Transitive Closure', 'n=p1|m=p2', 3); // combinatorial BMM hypothesis (R356)
    tight(a, 'Dyck-2 s-t Reachability', 'n=p1|m=p2', 3); // combinatorial BMM hypothesis (R362)
    // Klee's measure problem in 3D: 3-uniform 300-hyperclique gives N^{300/201}, Chan's algorithm N^{1.5} (R355)
    assert.ok(near(lb(a, "Geometric Covering Problems / Klee's Measure Problem", 'N=p1|d=c3'), 300 / 201, 1e-5));
    assert.ok(near(ub(a, "Geometric Covering Problems / Klee's Measure Problem", 'N=p1|d=c3'), 1.5));
  });

  it('derives the bounds of the trivial reductions (R366–R431)', () => {
    const tight = (a: Analysis, p: string, key: string, x: number, tol = 1e-6): void => {
      assert.ok(near(lb(a, p, key), x, tol), `${p} LB at ${key}: ${lb(a, p, key)}`);
      assert.ok(near(ub(a, p, key), x, tol), `${p} UB at ${key}: ${ub(a, p, key)}`);
    };
    const a = analyze(model, initialScenario(config.value));
    // APSP hypothesis: Minimum Weight Triangle is Min-Weight 3-Clique (R370; Max-Weight by negation, R367) and a
    // 3-cycle (R373), which reduces to the Wiener index (R213)
    for (const p of ['Clique / Min-Weight k-Clique', 'Clique / Max-Weight k-Clique', 'Graph Cycles / Min-Weight k-Cycle']) tight(a, p, 'n=p1|m=p2|M=P|k=c3', 3);
    tight(a, 'Wiener Index / Undirected Wiener Index', 'n=p1|m=p2', 3);
    // integer inputs are real inputs (R387–R391); All-Edges Exact Triangle generalizes Exact Triangle (R384)
    tight(a, '3SUM / Real 3SUM', 'n=p1', 2);
    tight(a, 'All-Pairs Shortest Paths (APSP) / APSP on Directed Graphs with Real-Valued Weights', 'n=p1|m=p2', 3);
    tight(a, 'Graph Triangle Problems / Real Exact Triangle', 'n=p1|m=p2', 3);
    tight(a, 'Graph Triangle Problems / All-Edges Exact Triangle', 'n=p1|m=p2|M=P', 3);
    // SETH: Subset Sum is a 0-1 Knapsack (R423) and a Bicriteria s,t-Path instance (R424) with budgets of the size of
    // the target; LCS is 2-LCS (R427); edit distance is tree edit distance on paths (R428)
    tight(a, 'The Knapsack Problem / 0-1 Knapsack', 'n=L|t=p1|M=P', 1);
    tight(a, 'Bicriteria s,t-Path', 'n=L|m=L|L=p1|C=p1', 1);
    tight(a, 'Longest Common Subsequence / k-LCS', 'n=p1|k=c2|sigma=c3', 2);
    assert.ok(near(lb(a, 'Tree Edit Distance', 'n=p1|sigma=c7|M=C'), 2));
    // 2D Maximum Subarray is the case d = 2 (R425), and a Max-Weight Rectangle instance with n² points (R426)
    tight(a, 'Maximum Subarray Problem / dD Maximum Subarray', 'n=p1|M=P|d=c2', 3);
    assert.ok(near(lb(a, 'Geometric Covering Problems / Max-Weight Rectangle', 'N=p1|d=c2'), 1.5));
    // All-Pairs Maximum Flow is ST-Maximum Flow with S = T = V (R408)
    tight(a, 'Maximum Flow / ST-Maximum Flow', 'n=p1|m=p1|M=P||S|=p1||T|=p1', 3);
    // #All-Edges Monochromatic Triangle: the bounds of the decision version (R383) and its own algorithms (U420, U421)
    assert.ok(near(lb(a, 'Graph Triangle Problems / #All-Edges Monochromatic Triangle', 'n=p1|m=p2|c=p0.5'), 2.5));
    assert.ok(ub(a, 'Graph Triangle Problems / #All-Edges Monochromatic Triangle', 'n=p1|m=p2|c=p0.5')! <= 3 + 1e-9);
    // the k-Clique hypothesis through Nešetřil–Poljak (R369) at k = 3: triangle detection needs n^omega
    const omega = config.value.constants['omega']!.value;
    const kc = analyze(model, scenario(group('k-Clique hypothesis', KNOWN, TRIVIAL, BEST)));
    tight(kc, 'Graph Triangle Problems / Triangle Detection', 'n=p1|m=p2', omega);
    tight(kc, 'Clique / k-Clique', 'n=p1|m=p2|k=c6', 2 * omega);
  });

  it('derives the bounds of the rows added in Nov 2026 (R432–R465)', () => {
    const tight = (a: Analysis, p: string, key: string, x: number, tol = 1e-6): void => {
      assert.ok(near(lb(a, p, key), x, tol), `${p} LB at ${key}: ${lb(a, p, key)}`);
      assert.ok(near(ub(a, p, key), x, tol), `${p} UB at ${key}: ${ub(a, p, key)}`);
    };
    // The k-AP hypothesis (Fischer 2026) in place of 3SUM: k-GeomBase (R432; listed for k >= 4 only), the geometric
    // problems of Fischer's Theorem 1.4 (R435–R444) and those they reduce to, quadratic and tight; 3-uniform
    // 4-hyperclique through 4-AP Detection (R434, k = 4 only).
    const kap = analyze(model, scenario(group('k-AP hypothesis', KNOWN, TRIVIAL, BEST)));
    assert.deepEqual(conflictsOf(kap), []);
    for (const k of [4, 5, 6]) {
      tight(kap, 'k-AP Detection', `N=p1|k=c${k}`, 2);
      tight(kap, 'Geometric Base / k-GeomBase', `n=p1|M=p1|k=c${k}`, 2);
      tight(kap, 'Geometric Color-Spanning Problem / Smallest Color-Spanning Strip', `n=p1|k=c${k}`, 2);
    }
    const kgb = kap.summaries.get('Geometric Base / k-GeomBase')!;
    assert.deepEqual(kgb.regimes.map((r) => r.regime.key).sort(), ['n=p1|M=p1|k=c4', 'n=p1|M=p1|k=c5', 'n=p1|M=p1|k=c6']);
    tight(kap, 'Clique / 3-Uniform k-Hyperclique', 'n=p1|k=c4', 4);
    assert.equal(lb(kap, 'Clique / 3-Uniform k-Hyperclique', 'n=p1|k=c5'), undefined);
    for (const p of [
      'Geometric Separator Problems / Separator1',
      'Geometric Separator Problems / Separator2',
      'Geometric Covering Problems / Strips Cover Box',
      'Geometric Covering Problems / Strips Cover Triangle',
      'Geometric Covering Problems / Rectangles Cover Rectangle',
      'Geometric Covering Problems / Triangles Cover Triangle',
      'Geometric Visibility Problems / Visibility Between Segments',
      'Geometric Visibility Problems / Visibility From Infinity',
      'Motion Planning Problems / Planar Motion Planning',
      'Terrain Horizon Problems / All Distant Horizon Edges',
      'Stabbing and Avoiding Segments',
      'Double-Wedge Intersection',
    ]) {
      tight(kap, p, 'n=p1', 2);
    }
    // 3-AP by FFT: near-linear for k = 3
    assert.ok(near(ub(kap, 'k-AP Detection', 'N=p1|k=c3'), 1));
    // The initial scenario: 3SUM and APSP through Exact Triangle (R453, R456, R459) and through GeomBase (R39, R445).
    const LOP = 'Graph Triangle Problems / Lopsided All-Edges Sparse Triangle';
    const LOP_REGIME = 'n=p1|d=p0.055556|w=p1.972223';
    const a = analyze(model, initialScenario(config.value));
    tight(a, LOP, LOP_REGIME, 2);
    tight(a, 'Graph Triangle Problems / #Exact Triangle', 'n=p1|m=p2|M=P', 3);
    tight(a, 'Clique / Zero-Weight k-Clique', 'n=p1|m=p2|M=P|k=c3', 3);
    tight(a, 'Geometric Color-Spanning Problem / Smallest Color-Spanning Strip', 'n=p1|k=c3', 2);
    tight(a, 'Stabbing and Avoiding Segments', 'n=p1', 2);
    // k-GeomBase (k >= 4) has no lower bound without the k-AP hypothesis: 3SUM reaches it only at k = 3, i.e. GeomBase
    for (const k of [4, 5, 6]) {
      assert.equal(lb(a, 'Geometric Base / k-GeomBase', `n=p1|M=p1|k=c${k}`), undefined);
      assert.ok(near(ub(a, 'Geometric Base / k-GeomBase', `n=p1|M=p1|k=c${k}`), 2));
    }
    // From k to k + 1 (R463–R465, k = 3, 4, 5): the cubic bounds of k = 3 reach every listed k. Min-Weight k-Cycle
    // is cubic at every k on dense graphs (colour coding, U332); the cliques keep the trivial n^k above. Max-Weight
    // k-Clique by negation (R367); Weighted Depth through it (R277): N^{3/2} for every d >= 3, Chan's N^{d/2} above.
    for (const k of [4, 5, 6]) {
      for (const p of ['Clique / Min-Weight k-Clique', 'Clique / Max-Weight k-Clique', 'Clique / Zero-Weight k-Clique']) {
        assert.ok(near(lb(a, p, `n=p1|m=p2|M=P|k=c${k}`), 3), `${p} at k = ${k}`);
        assert.ok(near(ub(a, p, `n=p1|m=p2|M=P|k=c${k}`), k), `${p} at k = ${k}`);
      }
      tight(a, 'Graph Cycles / Min-Weight k-Cycle', `n=p1|m=p2|M=P|k=c${k}`, 3);
      assert.ok(near(lb(a, 'Geometric Covering Problems / Weighted Depth', `N=p1|d=c${k}`), 1.5));
      assert.ok(near(ub(a, 'Geometric Covering Problems / Weighted Depth', `N=p1|d=c${k}`), k / 2));
    }
    // (restricted to k = 3, 4, 5, the rows reach k = 6 and no further)
    for (const p of ['Clique / Min-Weight k-Clique', 'Clique / Zero-Weight k-Clique', 'Graph Cycles / Min-Weight k-Cycle']) {
      assert.deepEqual(a.summaries.get(p)!.regimes.filter((r) => /k=c(\d+)/.test(r.regime.key) && Number(/k=c(\d+)/.exec(r.regime.key)![1]) > 6).map((r) => r.regime.key), [], p);
    }
    // Multiple Local Alignment takes half as many strings as the clique has vertices (R118, even k only): k = 4, 6 give
    // 2 and 3 strings, k = 5 nothing (no 2.5 strings)
    const mla = a.summaries.get('Local Alignment / Multiple Local Alignment')!;
    assert.deepEqual(mla.regimes.filter((r) => /k=c\d+\.\d/.test(r.regime.key)).map((r) => r.regime.key), []);
    assert.ok(near(lb(a, 'Local Alignment / Multiple Local Alignment', 'n=p1|k=c3|sigma=p0.5'), 1.5));
    // The 2026 algorithms: the lopsided problem in n^{2 - 0.063/18} (U440) against the APSP hypothesis; the Zero-Weight
    // k-Clique hypothesis refuted where row R458 folds without loss (k = 3, 6); the k-Clique hypothesis through R462 not.
    const avw = analyze(model, scenario(group(H_APSP, 'Zero-Weight k-Clique hypothesis', 'k-Clique hypothesis', KNOWN, TRIVIAL, BEST, AVW)));
    assert.ok(near(ub(avw, LOP, LOP_REGIME), 2 - 0.063 / 18, 1e-6));
    assert.equal(avw.summaries.get(LOP)!.status, 'conflict');
    const zwc = avw.summaries.get('Clique / Zero-Weight k-Clique')!;
    assert.deepEqual(
      [3, 4, 5, 6].map((k) => zwc.regimes.find((r) => r.regime.key === `n=p1|m=p2|M=P|k=c${k}`)!.status),
      ['conflict', 'tight', 'tight', 'conflict'],
    );
    const omega = config.value.constants['omega']!.value;
    tight(avw, 'Clique / Zero-Weight k-Clique', 'n=p1|m=p2|M=C|k=c3', omega);
    tight(avw, 'Clique / Zero-Weight k-Clique', 'n=p1|m=p2|M=C|k=c6', 2 * omega);
  });

  it('states no trivial reduction twice', () => {
    // At most one row of type "Trivial…" per pair of problems, and no shortcut that a chain of trivial rows already
    // gives with the same parameters: Negative Triangle Detection → Distance Product follows from R374 and R376 (and
    // from R127 with R128), Positive → exact Betweenness Centrality from R400 and R401.
    const trivial = model.rows.filter((r) => /^trivial/i.test(table.get(r.index, COL.type).trim()));
    assert.ok(trivial.length >= 66);
    const pairs = new Map<string, string[]>();
    for (const r of trivial) pairs.set(`${r.source} → ${r.target}`, [...(pairs.get(`${r.source} → ${r.target}`) ?? []), r.id]);
    assert.deepEqual([...pairs].filter(([, ids]) => ids.length > 1), []);
    for (const pair of [
      'Graph Triangle Problems / Negative Triangle Detection → Matrix Product / Distance Product',
      'Vertex Centrality / Positive Betweenness Centrality → Vertex Centrality / Betweenness Centrality (BC)',
    ]) {
      assert.ok(!pairs.has(pair), pair);
      assert.ok(model.rows.every((r) => `${r.source} → ${r.target}` !== pair), pair);
    }
  });

  it('derives every bound without a detour (no problem at the same regime twice on a path)', () => {
    const initial = initialScenario(config.value);
    for (const s of [initial, { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) }]) {
      const a = analyze(model, s);
      const detours: string[] = [];
      const walk = (f: UBFact, path: readonly string[]): void => {
        const key = `${f.problem} @ ${f.regime.key}`;
        if (path.includes(key)) detours.push(`UB of ${path[0]}: ${[...path, key].join(' → ')}`);
        else if (f.origin.kind === 'row') f.origin.children.forEach((c) => walk(c, [...path, key]));
      };
      for (const summary of a.summaries.values()) {
        for (const r of summary.regimes) {
          if (r.ub) walk(r.ub, []);
          if (r.lb) {
            const keys = lbChain(r.lb).map((f) => `${f.problem} @ ${f.regime.key}`);
            if (new Set(keys).size < keys.length) detours.push(`LB: ${keys.join(' ← ')}`);
          }
        }
      }
      assert.deepEqual(detours, []);
    }
    // Diameter: its own algorithm (Dijkstra from every vertex) rather than the same bound through a reduction; without
    // it, straight from APSP, not through Reach Centrality and back.
    const own = analyze(model, initial).summaries.get('Graph Metrics / Diameter')!.primary!.ub!;
    assert.equal(own.steps, 0);
    const d = analyze(model, scenario(group(SETH, H_3SUM, H_APSP, KNOWN))).summaries.get('Graph Metrics / Diameter')!.primary!.ub!;
    assert.equal(d.steps, 1);
    assert.equal(d.origin.kind === 'row' && d.origin.children[0]!.problem, 'All-Pairs Shortest Paths (APSP) / Undirected, Weighted APSP');
  });

  /** The initial scenario with the knobs of these ids switched on. */
  const withKnobs = (...ids: string[]): Scenario => {
    const initial = initialScenario(config.value);
    return { ...initial, knobs: initial.knobs.map((k) => (ids.includes(k.id) ? { ...k, enabled: true } : k)) };
  };

  it('gives each problem its best bound, the same one inside other derivations', () => {
    const initial = initialScenario(config.value);
    const allOn = { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) };
    for (const s of [initial, allOn, withKnobs('U17')]) {
      const a = analyze(model, s);
      const opts = { settings: s.settings, constants: constantEnv(model, s.constants), usable: (r: (typeof model.rows)[number]) => rowUsable(r, s) };
      const issues: string[] = [];
      for (const summary of a.summaries.values()) {
        const r = summary.primary;
        if (!summary.problem.isStatic || r === null) continue;
        const at = `${summary.problem.id} @ ${r.regime.key}`;
        // No reduction gives a better bound than the one shown (whatever the length of its derivation).
        for (const { row, verdict } of a.upperOverlay.explain(summary.problem.id, r.regime)) {
          if (verdict.kind === 'weaker' && (r.ub === null || verdict.fact.exponent < r.ub.exponent - 1e-7)) issues.push(`UB of ${at} through ${row.id}: ${verdict.fact.exponent}`);
        }
        for (const { row, verdict } of explainLower(model, a.lower, summary.problem.id, r.regime, opts)) {
          if (verdict.kind === 'weaker' && (r.lb === null || verdict.fact.exponent > r.lb.exponent + 1e-7)) issues.push(`LB of ${at} through ${row.id}: ${verdict.fact.exponent}`);
        }
        // Inside a derivation, each problem has the bound it has on its own at that regime.
        const seen = new Set<UBFact>();
        const walk = (f: UBFact): void => {
          if (seen.has(f)) return;
          seen.add(f);
          for (const c of ubParts(f)) {
            const own = a.upperOverlay.known(c.problem, c.regime);
            if (own === undefined || own === null || Math.abs(own.exponent - c.exponent) > 1e-9) issues.push(`UB of ${at} uses ${c.problem} @ ${c.regime.key} ≤ ${c.exponent}, not ${own?.exponent}`);
            walk(c);
          }
        };
        if (r.ub) walk(r.ub);
        if (r.lb) {
          for (const f of lbChain(r.lb).slice(1)) {
            const own: LBFact | undefined = a.lower.facts.get(f.problem)?.get(f.regime.key);
            if (own === undefined || Math.abs(own.exponent - f.exponent) > 1e-9) issues.push(`LB of ${at} uses ${f.problem} @ ${f.regime.key} ≥ ${f.exponent}, not ${own?.exponent}`);
          }
        }
      }
      assert.deepEqual(issues, []);
    }
  });

  it('gives Unbounded Knapsack the bound of 0-1 Knapsack, and Superadditivity Testing that of (max,+) Upper Bound Testing (with the 3SUM algorithm of 2026)', () => {
    // 0-1 Knapsack gets 3SUM's n^{1.9992} through four reductions, losing a little in the (min,+) convolution step
    // (n^{1.9996}); Unbounded Knapsack reduces to it (row R205): five reductions. Superadditivity Testing is the Upper
    // Bound Testing instance (a, a, a) (row R422), which reaches 3SUM through rows R211 and R54: n^{1.9992} in three
    // reductions (before row R422 it went through Unbounded Knapsack, six reductions).
    const s = withKnobs('U17');
    assert.equal(s.knobs.find((k) => k.id === 'U17')!.problem, '3SUM / 3SUM');
    const a = analyze(model, s);
    const at = (p: string, key: string): UBFact => a.summaries.get(p)!.regimes.find((r) => r.regime.key === key)!.ub!;
    const k01 = at('The Knapsack Problem / 0-1 Knapsack', 'n=p1|t=p1|M=P');
    const uk = at('The Knapsack Problem / Unbounded Knapsack', 'n=p1|t=p1|M=P');
    const ubt = at('Convolution Problems / (max, +) Convolution Upper Bound Testing', 'n=p1|M=P');
    const sup = at('Convolution Problems / Superadditivity Testing', 'n=p1|M=P');
    assert.ok(k01.exponent < 2 - 1e-4, String(k01.exponent));
    assert.ok(near(uk.exponent, k01.exponent, 1e-9));
    assert.ok(near(sup.exponent, ubt.exponent, 1e-9) && sup.exponent < k01.exponent - 1e-4, `${sup.exponent} ${k01.exponent}`);
    assert.deepEqual([k01.steps, uk.steps, ubt.steps, sup.steps], [4, 5, 2, 3]);
    // Each derivation goes through the next problem's own derivation.
    assert.equal(uk.origin.kind === 'row' && uk.origin.children[0], k01);
    assert.equal(sup.origin.kind === 'row' && sup.origin.children[0], ubt);
  });

  it('raises lower bounds without limit through a cycle when the 3SUM hypothesis is above 2', () => {
    // Rows R65 and R68 (3SUM → Exact Weight 3-Star → 3SUM) turn a lower bound L of 3SUM into 1.5L − 1: a fixed point at
    // 2, repelling above (the hypothesis cannot be raised a little without contradicting polynomial-time algorithms).
    const initial = initialScenario(config.value);
    const raised = { ...initial, knobs: initial.knobs.map((k) => (k.problem === '3SUM / 3SUM' && k.kind === 'LB' ? { ...k, exponent: 2.05 } : k)) };
    const a = analyze(model, raised);
    for (const p of ['3SUM / 3SUM', 'Graph Subgraph Problems / Exact Weight 3-Star Detection', 'Graph Subgraph Problems / Exact Weight 3-Matching Detection']) {
      assert.equal(a.summaries.get(p)!.primary!.lb?.exponent, Infinity, p);
    }
    assert.ok(a.lower.cycles.some((f) => f.problem === '3SUM / 3SUM' && f.exponent === Infinity));
    assert.deepEqual(a.lower.capped, []);
    // At the hypothesis itself (2) the cycle changes nothing.
    assert.deepEqual(analyze(model, initial).lower.cycles, []);
  });

  it('shows nice regimes: whole-number or simple exponents first, unusual ones listed only when derivations use them', () => {
    const a = analyze(model, initialScenario(config.value));
    const nice = (s: RegimeSummary): boolean => regimeNiceness(s.regime).tier <= 1;
    for (const s of a.summaries.values()) {
      if (s.primary === null) continue;
      assert.equal(s.status, s.primary.status, s.problem.id);
      // The regime the graph shows reads nicely, unless none of the problem's regimes does.
      if (!nice(s.primary)) assert.ok(!s.regimes.some(nice), s.problem.id);
      assert.ok(s.primary.listed, s.problem.id);
    }
    // ST-Maximum Flow: tight at |S| = |T| = n on sparse graphs, n^3 (SETH through All-Pairs Maximum Flow, row R408);
    // before that row at one source (and before that 2.909091 at |S| = n^{10/11}, one of 129 regimes).
    const flow = a.summaries.get('Maximum Flow / ST-Maximum Flow')!;
    assert.equal(flow.primary!.regime.key, 'n=p1|m=p1|M=P||S|=p1||T|=p1');
    assert.ok(near(flow.primary!.lb!.exponent, 3) && near(flow.primary!.ub!.exponent, 3));
    const oneSource = flow.regimes.find((r) => r.regime.key === 'n=p1|m=p1|M=P||S|=c1||T|=p1')!;
    assert.ok(near(oneSource.lb!.exponent, 2) && near(oneSource.ub!.exponent, 2));
    // The problems with the most regimes (from reductions with free parameters) list a small part of them.
    for (const p of ['Set Intersection Problems / Set Intersection', 'Graph Triangle Problems / Triangle Listing', 'Maximum Flow / ST-Maximum Flow']) {
      const s = a.summaries.get(p)!;
      const listed = s.regimes.filter((r) => r.listed).length;
      assert.ok(s.regimes.length > 50 && listed < 30, `${p}: ${listed} of ${s.regimes.length}`);
    }
    // An unusual regime is listed only if another problem's listed bound is derived through it (or it is the first).
    for (const s of a.summaries.values()) {
      for (const r of s.regimes) {
        if (!r.listed || nice(r) || r.origins.some((o) => o !== 'lb') || r === s.primary) continue;
        const usedBy = [...a.summaries.values()].some(
          (t) =>
            t !== s &&
            t.regimes.some(
              (x) =>
                x.listed &&
                ((x.lb !== null && lbChain(x.lb).some((f) => f.problem === s.problem.id && f.regime.key === r.regime.key)) ||
                  (x.ub !== null && ubNodes(x.ub).has(`${s.problem.id}#${r.regime.key}`))),
            ),
        );
        assert.ok(usedBy, `${s.problem.id} ${r.regime.key}`);
      }
    }
  });

  it('keeps every regime within its problem’s limits (no graph with more than m·α triangles, …)', () => {
    const exponent = (g: G.Growth): number => (g.kind === 'poly' ? g.exp : 0);
    const withLimits = [...model.problems.values()].filter((p) => p.constraints.length > 0);
    assert.ok(withLimits.length >= 100, String(withLimits.length));
    const all = initialScenario(config.value);
    for (const sc of [all, { ...all, knobs: all.knobs.map((k) => ({ ...k, enabled: true })) }]) {
      const a = analyze(model, sc);
      for (const p of withLimits) {
        for (const s of a.summaries.get(p.id)?.regimes ?? []) {
          const e = new Map(s.regime.params.map((x, i) => [x, exponent(s.regime.growths[i]!)]));
          for (const c of p.constraints) {
            const limit = Math.max(...c.terms.map((t) => t.powers.reduce((sum, [x, k]) => sum + k * e.get(x)!, 0)));
            assert.ok(e.get(c.param)! <= limit + 2e-6, `${p.id} ${s.regime.key}: ${c.text}`);
          }
        }
      }
      // Triangle Listing at m = n^{1.5}: the arboricity is at most n^{3/4} (it was n), with n² triangles: tight. It is the
      // regime shown, unless the k-Clique hypothesis (switched off at first) makes listing one triangle of a dense graph
      // tight at n^omega (rows R369 and R289).
      const tl = a.summaries.get('Graph Triangle Problems / Triangle Listing')!;
      const sparse = tl.regimes.find((r) => r.regime.key === 'n=p1|m=p1.5|alpha=p0.75|t=p2')!;
      assert.ok(near(sparse.lb!.exponent, 2) && near(sparse.ub!.exponent, 2));
      if (sc === all) assert.equal(tl.primary!.regime.key, sparse.regime.key);
      assert.ok(tl.regimes.length < 100, String(tl.regimes.length));
    }
  });

  it('reads SETH as 2^{c·n^a}: kept by MAX-CNF-SAT, too strong for every other reduction, tight with such an algorithm', () => {
    const initial = initialScenario(config.value);
    const SAT = 'Boolean Satisfiability / CNF-SAT';
    const MAX = 'Boolean Satisfiability / MAX-CNF-SAT';
    // SETH (Bound ID L1) as "CNF-SAT needs 2^{0.5 n^{0.75}}"
    const eth = { ...initial, knobs: initial.knobs.map((k) => (k.id === 'L1' ? { ...k, exponent: 0.5, power: 0.75 } : k)) };
    const a = analyze(model, eth);
    for (const p of [SAT, MAX]) {
      const s = a.summaries.get(p)!.primary!;
      assert.ok(s.lb !== null && s.lb.power === 0.75 && near(s.lb.exponent, 0.5), p);
      assert.equal(s.status, 'gap', p);
    }
    // Every other lower bound from CNF-SAT would need a reduction faster than 2^{0.5 n^{0.75}}; none is (the one to
    // Subset Sum takes 2^{εn} for some ε > 0: row R256's ε = 0 is not a reduction).
    const fromSat: string[] = [];
    for (const [p, facts] of a.lower.facts) {
      if (p === SAT || p === MAX) continue;
      for (const f of facts.values()) if (lbChain(f).at(-1)!.problem === SAT) fromSat.push(`${p}#${f.regime.key}`);
    }
    assert.deepEqual(fromSat, []);
    // An algorithm in 2^{0.5 n^{0.75}} poly(n) makes it tight; MAX-CNF-SAT keeps its 2^n.
    const b = analyze(model, { ...eth, knobs: eth.knobs.map((k) => (k.id === 'U1' ? { ...k, formula: '2^{0.5 n^{0.75}} \\cdot m' } : k)) });
    assert.equal(b.summaries.get(SAT)!.status, 'tight');
    assert.equal(b.summaries.get(MAX)!.status, 'gap');
  });

  describe('the Oct 2026 algorithms of Alman and Vassilevska Williams (arXiv:2610.06783)', () => {
    it('conflict with the 3SUM and APSP hypotheses throughout their classes', () => {
      const a = analyze(model, scenario(group(H_3SUM, H_APSP, KNOWN, AVW)));
      const conflicts = conflictsOf(a);
      for (const p of [
        '3SUM / 3SUM',
        '3SUM / Convolution 3SUM',
        'Geometric Base / GeomBase',
        'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP',
        'All-Pairs Shortest Paths (APSP) / Undirected, Weighted APSP',
        'Graph Triangle Problems / Negative Triangle Detection',
        'Graph Triangle Problems / Exact Triangle',
        'Graph Metrics / Directed Radius',
      ]) {
        assert.ok(conflicts.includes(p), p);
      }
    });

    it('leave SETH, OV, k-Clique and BMM consistent', () => {
      const a = analyze(model, scenario(group(SETH, 'OV hypothesis', 'k-Clique hypothesis', 'Combinatorial BMM hypothesis', KNOWN, AVW)));
      assert.deepEqual(conflictsOf(a), []);
    });

    it('give 3SUM n^{1.998} through Real 3SUM (row R387), and n^{1.999125} through Exact Triangle (rows R53, R60) without the rows to the real-valued versions', () => {
      // Integer inputs are real inputs (rows R387–R391), so the Las Vegas algorithms for real inputs bound the integer
      // versions too.
      const a = analyze(model, scenario(group(AVW)));
      assert.ok(near(ub(a, '3SUM / 3SUM', 'n=p1|M=P'), 1.998, 1e-9));
      assert.ok(near(ub(a, 'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP', 'n=p1|m=p2|M=P'), 2.998, 1e-9));
      // Exact Triangle through the lopsided problem (row R453 with knob U440): n^{3 - 0.063/36} = n^{2.99825}, a little
      // below the paper's stated 2.9983; Convolution 3SUM in O(√n · T_ExactTriangle(√n)): 1/2 + 2.99825/2 = 1.999125.
      const b = analyze(model, scenario(group(AVW), { disabledRows: ['R387', 'R388', 'R389', 'R390', 'R391'] }));
      assert.ok(near(ub(b, 'Graph Triangle Problems / Exact Triangle', 'n=p1|m=p2|M=P'), 3 - 0.063 / 36, 1e-7));
      assert.ok(near(ub(b, '3SUM / 3SUM', 'n=p1|M=P'), 1.999125, 1e-7));
      // From the stated 2.9983 (knob U22) alone: 1.99915.
      const c = analyze(model, scenario(group(AVW), { disabledRows: ['R387', 'R388', 'R389', 'R390', 'R391', 'R453'] }));
      assert.ok(near(ub(c, '3SUM / 3SUM', 'n=p1|M=P'), 1.99915, 1e-9));
    });
  });

  describe('the Oct 2026 (min,+)-product of Saha and Ye (arXiv:2610.20297)', () => {
    const SY = 'Saha & Ye 2026';

    it('starts switched off', () => {
      assert.equal(config.value.initialKnobs.find((g) => g.label === SY)!.enabled, false);
    });

    it('conflicts with the APSP hypothesis throughout its class, including the problems the paper names', () => {
      const a = analyze(model, scenario(group(H_APSP, KNOWN, SY)));
      const conflicts = conflictsOf(a);
      for (const p of [
        'Matrix Product / Distance Product',
        'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP',
        'All-Pairs Shortest Paths (APSP) / Undirected, Weighted APSP',
        'Graph Triangle Problems / Negative Triangle Detection',
        'Shortest Path (Directed graphs) / Replacement Paths Problem (RPP)',
        'Shortest Path (Directed graphs) / Second Shortest Simple Path',
        'Metricity / Metricity',
        'Matrix Product / Distance Product Verification',
        'Maximum Subarray Problem / 2D Maximum Subarray',
        'Graph Metrics / Directed Radius',
        'Vertex Centrality / Betweenness Centrality (BC)',
      ]) {
        assert.ok(conflicts.includes(p), p);
      }
      assert.ok(near(ub(a, 'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP', 'n=p1|m=p2|M=P'), 2.9963432, 1e-9));
    });

    it('leaves SETH, 3SUM, OV, k-Clique and BMM consistent', () => {
      const a = analyze(model, scenario(group(SETH, H_3SUM, 'OV hypothesis', 'k-Clique hypothesis', 'Combinatorial BMM hypothesis', KNOWN, SY)));
      assert.deepEqual(conflictsOf(a), []);
    });
  });
});
