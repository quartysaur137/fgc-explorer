import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { analyze, Analysis, rowUsable } from '../src/engine/analysis';
import { explainLower, lbChain, LBFact } from '../src/engine/lower';
import { constantEnv } from '../src/engine/rowEval';
import { UBFact, ubParts } from '../src/engine/upper';
import { primaryFormula } from '../src/math/cells';
import { parseFormula, parseList } from '../src/math/parser';
import { initialScenario, KnobSpec, Scenario, validateConfig } from '../src/model/config';
import { buildModel, COL, Model } from '../src/model/model';
import { CsvTable } from '../src/util/csv';
import { near, scenario } from './helpers';

/*
 * Integration tests on the real sheet (data/FGC_Reductions_filled.csv) and the default config.
 *
 * Partitions: every formula cell parses; row-status counts do not regress; each hypothesis produces its textbook
 * consequences; upper bounds flow backward; conflicts are detected; known equivalences hold; the initial scenario is
 * consistent; the 2026 algorithms refute exactly the hypotheses they should; derivations take no detours; every
 * problem has its best bound, the same inside other derivations (no reduction gives a better one, whatever the length
 * of the derivation); a raised 3SUM hypothesis makes a cycle raise lower bounds without limit.
 */

const csv = readFileSync(new URL('../data/FGC_Reductions_filled.csv', import.meta.url), 'utf8');
const configJson = JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'));

describe('real sheet', function () {
  this.timeout(60000);
  const { table } = CsvTable.fromText(csv);
  const config = validateConfig(configJson);
  const model: Model = buildModel(table, config.value);
  /** The knobs of the config's initial groups with these labels (all of them switched on). */
  const group = (...labels: string[]): KnobSpec[] => {
    const groups = config.value.initialKnobs.filter((g) => labels.includes(g.label));
    assert.equal(groups.length, labels.length, `initial knob groups ${labels.join(', ')}`);
    return groups.flatMap((g) => g.knobs);
  };
  const SETH = 'SETH';
  const H_3SUM = '3SUM hypothesis';
  const H_APSP = 'APSP hypothesis';
  const KNOWN = 'Known algorithms';
  const AVW = 'Alman & Vassilevska Williams 2026';
  const lb = (a: Analysis, problem: string, key: string): number | undefined => a.lower.facts.get(problem)?.get(key)?.exponent;
  const ub = (a: Analysis, problem: string, key: string): number | undefined =>
    a.summaries.get(problem)?.regimes.find((r) => r.regime.key === key)?.ub?.exponent;

  it('has a valid default config', () => {
    assert.deepEqual(config.errors, []);
    assert.deepEqual(
      model.diagnostics.filter((d) => d.level !== 'info').map((d) => d.message),
      [],
    );
  });

  it('parses every formula cell', () => {
    for (let i = 0; i < table.rowCount; i++) {
      for (const col of [COL.fromTime, COL.rt]) {
        const f = primaryFormula(table.get(i, col));
        if (f !== null) assert.doesNotThrow(() => parseFormula(f), `${table.get(i, COL.id)} ${col}: ${f}`);
      }
      const t = primaryFormula(table.get(i, COL.toTime));
      if (t !== null) assert.doesNotThrow(() => parseList(t), `${table.get(i, COL.id)} To-time: ${t}`);
    }
  });

  it('uses all rows that have a static formula', () => {
    const counts: Record<string, number> = {};
    for (const r of model.rows) counts[r.status] = (counts[r.status] ?? 0) + 1;
    assert.ok((counts.ok ?? 0) >= 238, JSON.stringify(counts));
    assert.equal(counts['unknown-symbols'] ?? 0, 0);
    assert.equal(counts['parse-error'] ?? 0, 0);
    assert.equal(counts['non-monotone'] ?? 0, 0);
    assert.equal(counts.arity ?? 0, 0);
  });

  it('SETH: OV, k-OV, edit distance, diameter, subset sum', () => {
    const a = analyze(model, scenario(group(SETH)));
    assert.ok(near(lb(a, 'Orthogonal Vectors / OV', 'n=p1|d=L'), 2));
    assert.ok(near(lb(a, 'Orthogonal Vectors / k-OV', 'n=p1|d=L|k=c3'), 3));
    assert.ok(near(lb(a, 'String Similarity / Edit Distance', 'n=p1|sigma=c7'), 2));
    assert.ok(near(lb(a, 'Longest Common Subsequence / Longest Common Subsequence', 'n=p1|m=p1|sigma=c2'), 2));
    assert.ok(near(lb(a, 'Graph Metrics / Diameter 2 vs 3', 'n=p1|m=p1'), 2));
    // Subset Sum: t^{1-o(1)} 2^{o(N)} (as ε → 0)
    assert.ok(near(lb(a, 'The Subset-Sum Problem / Subset Sum', 'N=L|t=p1'), 1, 1e-3));
  });

  it('3SUM: geometry and convolution', () => {
    const a = analyze(model, scenario(group(H_3SUM)));
    for (const p of ['Geometric Base / GeomBase', '3SUM / Convolution 3SUM', '3SUM / 3SUM\'']) {
      assert.ok(near(lb(a, p, 'n=p1|M=P'), 2), p);
    }
    for (const p of ['Geometric Incidence Problems / 3 Points on Line', 'Geometric Covering Problems / Strips Cover Box']) {
      assert.ok(near(lb(a, p, 'n=p1'), 2), p);
    }
  });

  it('APSP: dense Negative Triangle and the subcubic-equivalence class', () => {
    const a = analyze(model, scenario(group(H_APSP)));
    const dense = 'n=p1|m=p2|M=P';
    assert.ok(near(lb(a, 'Matrix Product / Distance Product', 'n=p1|M=P'), 3));
    for (const p of [
      'Graph Triangle Problems / Negative Triangle Detection',
      'Graph Metrics / Directed Radius',
      'Vertex Centrality / Betweenness Centrality (BC)',
      'Shortest Path (Directed graphs) / Replacement Paths Problem (RPP)',
      'Graph Cycles / Shortest Cycle',
    ]) {
      assert.ok(near(lb(a, p, dense), 3), p);
    }
  });

  it('known algorithms make the hypotheses tight', () => {
    const a = analyze(model, scenario(group(SETH, H_3SUM, H_APSP, KNOWN)));
    assert.equal(a.summaries.get('Boolean Satisfiability / CNF-SAT')!.status, 'tight');
    assert.equal(a.summaries.get('Orthogonal Vectors / OV')!.status, 'tight');
    assert.equal(a.summaries.get('3SUM / 3SUM')!.status, 'tight');
    assert.equal(a.summaries.get('Graph Triangle Problems / Negative Triangle Detection')!.status, 'tight');
    assert.ok(near(ub(a, 'Orthogonal Vectors / OV', 'n=p1|d=L'), 2));
  });

  it('upper bounds flow backward along reductions', () => {
    const a = analyze(model, scenario([{ problem: '3SUM / 3SUM', kind: 'UB', regime: 'n=1, M=poly', exponent: 1.9 }]));
    assert.ok(near(ub(a, "3SUM / 3SUM'", 'n=p1|M=P'), 1.9));
    assert.ok(near(ub(a, '3SUM / Convolution 3SUM', 'n=p1|M=P'), 1.9));
  });

  it('detects conflicts between hypotheses and algorithms', () => {
    const a = analyze(
      model,
      scenario([...group(H_APSP), { problem: 'Graph Triangle Problems / Negative Triangle Detection', kind: 'UB', formula: 'n^{2.9}' }]),
    );
    assert.equal(a.summaries.get('Graph Triangle Problems / Negative Triangle Detection')!.status, 'conflict');
    // APSP reduces to Negative Triangle, so APSP inherits the n^{2.9} algorithm and conflicts with its own hypothesis
    assert.equal(a.summaries.get('All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP')!.status, 'conflict');
  });

  const conflictsOf = (a: Analysis): string[] => [...a.summaries.values()].filter((s) => s.status === 'conflict').map((s) => s.problem.id);

  it('starts from a consistent initial scenario whose switched-off knobs are valid too', () => {
    const initial = initialScenario(config.value);
    assert.ok(initial.knobs.some((k) => !k.enabled), 'some initial knobs start switched off');
    const a = analyze(model, initial);
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    const all = analyze(model, { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) });
    assert.deepEqual([...all.knobIssues.values()], [], 'every initial knob refers to a problem, regime and formula that work');
  });

  it('finds no conflict between the classic hypotheses and the known algorithms', () => {
    // The hypotheses were believed consistent with the textbook algorithms: a conflict here means a bug in the engine,
    // the config annotations or a sheet formula (this caught an unsound simplification of row 316).
    const t0 = Date.now();
    const hypotheses = config.value.initialKnobs.filter((g) => g.knobs.every((k) => k.kind === 'LB')).map((g) => g.label);
    assert.ok(hypotheses.length >= 7, hypotheses.join(', '));
    const a = analyze(model, scenario(group(...hypotheses, KNOWN)));
    assert.deepEqual([...a.knobIssues.values()], []);
    assert.deepEqual(conflictsOf(a), []);
    assert.deepEqual(a.lower.inconsistencies, []);
    assert.ok(Date.now() - t0 < 30000);
  });

  it('derives every bound without a detour (no problem at the same regime twice on a path)', () => {
    const initial = initialScenario(config.value);
    for (const s of [initial, { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) }]) {
      const a = analyze(model, s);
      const detours: string[] = [];
      const walk = (f: UBFact, path: readonly string[]): void => {
        const key = `${f.problem} @ ${f.regime.key}`;
        if (path.includes(key)) detours.push(`UB of ${path[0]}: ${[...path, key].join(' → ')}`);
        else if (f.origin.kind === 'row') f.origin.children.forEach((c) => walk(c, [...path, key]));
      };
      for (const summary of a.summaries.values()) {
        for (const r of summary.regimes) {
          if (r.ub) walk(r.ub, []);
          if (r.lb) {
            const keys = lbChain(r.lb).map((f) => `${f.problem} @ ${f.regime.key}`);
            if (new Set(keys).size < keys.length) detours.push(`LB: ${keys.join(' ← ')}`);
          }
        }
      }
      assert.deepEqual(detours, []);
    }
    // Diameter: straight from APSP, not through Reach Centrality and back.
    const d = analyze(model, initial).summaries.get('Graph Metrics / Diameter')!.primary!.ub!;
    assert.equal(d.steps, 1);
    assert.equal(d.origin.kind === 'row' && d.origin.children[0]!.problem, 'All-Pairs Shortest Paths (APSP) / Undirected, Weighted APSP');
  });

  /** The initial scenario with the knobs of these ids switched on. */
  const withKnobs = (...ids: string[]): Scenario => {
    const initial = initialScenario(config.value);
    return { ...initial, knobs: initial.knobs.map((k) => (ids.includes(k.id) ? { ...k, enabled: true } : k)) };
  };

  it('gives each problem its best bound, the same one inside other derivations', () => {
    const initial = initialScenario(config.value);
    const allOn = { ...initial, knobs: initial.knobs.map((k) => ({ ...k, enabled: true })) };
    for (const s of [initial, allOn, withKnobs('26')]) {
      const a = analyze(model, s);
      const opts = { settings: s.settings, constants: constantEnv(model, s.constants), usable: (r: (typeof model.rows)[number]) => rowUsable(r, s) };
      const issues: string[] = [];
      for (const summary of a.summaries.values()) {
        const r = summary.primary;
        if (!summary.problem.isStatic || r === null) continue;
        const at = `${summary.problem.id} @ ${r.regime.key}`;
        // No reduction gives a better bound than the one shown (whatever the length of its derivation).
        for (const { row, verdict } of a.upperOverlay.explain(summary.problem.id, r.regime)) {
          if (verdict.kind === 'weaker' && (r.ub === null || verdict.fact.exponent < r.ub.exponent - 1e-7)) issues.push(`UB of ${at} through #${row.id}: ${verdict.fact.exponent}`);
        }
        for (const { row, verdict } of explainLower(model, a.lower, summary.problem.id, r.regime, opts)) {
          if (verdict.kind === 'weaker' && (r.lb === null || verdict.fact.exponent > r.lb.exponent + 1e-7)) issues.push(`LB of ${at} through #${row.id}: ${verdict.fact.exponent}`);
        }
        // Inside a derivation, each problem has the bound it has on its own at that regime.
        const seen = new Set<UBFact>();
        const walk = (f: UBFact): void => {
          if (seen.has(f)) return;
          seen.add(f);
          for (const c of ubParts(f)) {
            const own = a.upperOverlay.known(c.problem, c.regime);
            if (own === undefined || own === null || Math.abs(own.exponent - c.exponent) > 1e-9) issues.push(`UB of ${at} uses ${c.problem} @ ${c.regime.key} ≤ ${c.exponent}, not ${own?.exponent}`);
            walk(c);
          }
        };
        if (r.ub) walk(r.ub);
        if (r.lb) {
          for (const f of lbChain(r.lb).slice(1)) {
            const own: LBFact | undefined = a.lower.facts.get(f.problem)?.get(f.regime.key);
            if (own === undefined || Math.abs(own.exponent - f.exponent) > 1e-9) issues.push(`LB of ${at} uses ${f.problem} @ ${f.regime.key} ≥ ${f.exponent}, not ${own?.exponent}`);
          }
        }
      }
      assert.deepEqual(issues, []);
    }
  });

  it('gives Unbounded Knapsack and Superadditivity Testing the bound of 0-1 Knapsack (with the 3SUM algorithm of 2026)', () => {
    // 0-1 Knapsack gets 3SUM's n^{1.9992} through four reductions; Unbounded Knapsack reduces to it (row 205) and
    // Superadditivity Testing to Unbounded Knapsack (row 204): five and six reductions from the 3SUM algorithm.
    const s = withKnobs('26');
    assert.equal(s.knobs.find((k) => k.id === '26')!.problem, '3SUM / 3SUM');
    const a = analyze(model, s);
    const own = (p: string): UBFact => a.summaries.get(p)!.primary!.ub!;
    const k01 = own('The Knapsack Problem / 0-1 Knapsack');
    const uk = own('The Knapsack Problem / Unbounded Knapsack');
    const sup = own('Convolution Problems / Superadditivity Testing');
    assert.ok(k01.exponent < 2 - 1e-4, String(k01.exponent));
    assert.ok(near(uk.exponent, k01.exponent, 1e-9) && near(sup.exponent, k01.exponent, 1e-9));
    assert.deepEqual([k01.steps, uk.steps, sup.steps], [4, 5, 6]);
    // Each derivation goes through the next problem's own derivation.
    assert.equal(uk.origin.kind === 'row' && uk.origin.children[0], k01);
    assert.equal(sup.origin.kind === 'row' && sup.origin.children[0], uk);
  });

  it('raises lower bounds without limit through a cycle when the 3SUM hypothesis is above 2', () => {
    // Rows 65 and 68 (3SUM → Exact Weight 3-Star → 3SUM) turn a lower bound L of 3SUM into 1.5L − 1: a fixed point at
    // 2, repelling above (the hypothesis cannot be raised a little without contradicting polynomial-time algorithms).
    const initial = initialScenario(config.value);
    const raised = { ...initial, knobs: initial.knobs.map((k) => (k.problem === '3SUM / 3SUM' && k.kind === 'LB' ? { ...k, exponent: 2.05 } : k)) };
    const a = analyze(model, raised);
    for (const p of ['3SUM / 3SUM', 'Graph Subgraph Problems / Exact Weight 3-Star Detection', 'Graph Subgraph Problems / Exact Weight 3-Matching Detection']) {
      assert.equal(a.summaries.get(p)!.primary!.lb?.exponent, Infinity, p);
    }
    assert.ok(a.lower.cycles.some((f) => f.problem === '3SUM / 3SUM' && f.exponent === Infinity));
    assert.deepEqual(a.lower.capped, []);
    // At the hypothesis itself (2) the cycle changes nothing.
    assert.deepEqual(analyze(model, initial).lower.cycles, []);
  });

  it('reads SETH as 2^{c·n^a}: kept by MAX-CNF-SAT, too strong for every other reduction, tight with such an algorithm', () => {
    const initial = initialScenario(config.value);
    const SAT = 'Boolean Satisfiability / CNF-SAT';
    const MAX = 'Boolean Satisfiability / MAX-CNF-SAT';
    // SETH (Bound ID 1) as "CNF-SAT needs 2^{0.5 n^{0.75}}"
    const eth = { ...initial, knobs: initial.knobs.map((k) => (k.id === '1' ? { ...k, exponent: 0.5, power: 0.75 } : k)) };
    const a = analyze(model, eth);
    for (const p of [SAT, MAX]) {
      const s = a.summaries.get(p)!.primary!;
      assert.ok(s.lb !== null && s.lb.power === 0.75 && near(s.lb.exponent, 0.5), p);
      assert.equal(s.status, 'gap', p);
    }
    // Every other lower bound from CNF-SAT would need a reduction faster than 2^{0.5 n^{0.75}}; none is (the one to
    // Subset Sum takes 2^{εn} for some ε > 0: row 256's ε = 0 is not a reduction).
    const fromSat: string[] = [];
    for (const [p, facts] of a.lower.facts) {
      if (p === SAT || p === MAX) continue;
      for (const f of facts.values()) if (lbChain(f).at(-1)!.problem === SAT) fromSat.push(`${p}#${f.regime.key}`);
    }
    assert.deepEqual(fromSat, []);
    // An algorithm in 2^{0.5 n^{0.75}} poly(n) makes it tight; MAX-CNF-SAT keeps its 2^n.
    const b = analyze(model, { ...eth, knobs: eth.knobs.map((k) => (k.id === '10' ? { ...k, formula: '2^{0.5 n^{0.75}} \\cdot m' } : k)) });
    assert.equal(b.summaries.get(SAT)!.status, 'tight');
    assert.equal(b.summaries.get(MAX)!.status, 'gap');
  });

  describe('the Oct 2026 algorithms of Alman and Vassilevska Williams (arXiv:2610.06783)', () => {
    it('conflict with the 3SUM and APSP hypotheses throughout their classes', () => {
      const a = analyze(model, scenario(group(H_3SUM, H_APSP, KNOWN, AVW)));
      const conflicts = conflictsOf(a);
      for (const p of [
        '3SUM / 3SUM',
        '3SUM / Convolution 3SUM',
        'Geometric Base / GeomBase',
        'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP',
        'All-Pairs Shortest Paths (APSP) / Undirected, Weighted APSP',
        'Graph Triangle Problems / Negative Triangle Detection',
        'Graph Triangle Problems / Exact Triangle',
        'Graph Metrics / Directed Radius',
      ]) {
        assert.ok(conflicts.includes(p), p);
      }
    });

    it('leave SETH, OV, k-Clique and BMM consistent', () => {
      const a = analyze(model, scenario(group(SETH, 'OV hypothesis', 'k-Clique hypothesis', 'Combinatorial BMM hypothesis', KNOWN, AVW)));
      assert.deepEqual(conflictsOf(a), []);
    });

    it('give 3SUM in n^{1.99915} through Exact Triangle in n^{2.9983} (rows 53 and 60)', () => {
      // Convolution 3SUM in O(√n · T_ExactTriangle(√n)): 1/2 + 2.9983/2 = 1.99915, below the paper's stated 1.9992.
      const a = analyze(model, scenario(group(AVW)));
      assert.ok(near(ub(a, '3SUM / 3SUM', 'n=p1|M=P'), 1.99915, 1e-9));
    });
  });
});
