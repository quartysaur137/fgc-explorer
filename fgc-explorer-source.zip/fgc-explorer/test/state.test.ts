import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { initialScenario, Knob, validateConfig } from '../src/model/config';
import { GROUPS_ADDED_IN, initialState, numberFormat2Ids } from '../src/ui/state';

/*
 * Testing strategy for saved data (src/ui/state.ts)
 *
 * numberFormat2Ids, partition on each knob's id: format-2 id of an initial knob (its ID free / taken by another
 * knob), other text (added in the app "k…", own), Bound ID (kept); on the knobs: all initial knobs, some deleted, all
 * with Bound IDs already (unchanged objects). Order is always kept.
 * initialState with saved data: format 2 (renumbered), format 3 (text ids kept), format 4 (numbers: the initial knobs'
 * place, the user's after the initial IDs as legacyBoundId says), format 7 (unchanged, no message); the groups added
 * since appended to the knobs with the Bound IDs of the initial settings (a saved knob with one of them moves to a new
 * one; not again when the saved knobs have them: data of this version saved again by an earlier one) and to a saved
 * custom config (recognized by Bound ID and problem, also next to a user's group of the same name; a knob whose ID the
 * config has for another knob without it; the knobs then get the config's IDs, and none when the config has the group
 * already), with a message: before format 5 those of formats 5 and 6, with the IDs' letters, and rounded exponents of
 * knob regimes and pins back to fractions; format 5 those of format 6, and the IDs moved; a custom config saved before
 * format 7 gets the built-in limits of parameters for the problems without its own (kept), format 7 none; a saved config
 * with problems used for its valid parts (a non-object ignored); settings.maxDepthUB of formats 2 and 3
 * (their default 4: the new default; other values, and format 4: kept); the focus mode (saved, invalid or the old
 * true/false: off) and the theme (saved, invalid: system); the selection is never restored.
 */

const configJson: unknown = JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'));
const config = validateConfig(configJson).value;
const initial = initialScenario(config).knobs;
/** The 33 initial knobs of formats 2–4 (L1–L9, U1–U24), in their order then. */
const initial33 = initial.filter((k) => /^(L[1-9]|U([1-9]|1\d|2[0-4]))$/.test(k.id));
/** The initial knob groups formats 5 and 6 added, and their knobs. */
const ADDED = [...GROUPS_ADDED_IN[5]!, ...GROUPS_ADDED_IN[6]!];
const addedSince4 = initial.filter((k) => !initial33.includes(k));
const addedIn6 = initial.filter((k) => k.note?.startsWith('Saha & Ye 2026'));

/** The Bound IDs of the previous version's data/initial-bounds.csv (format 2), in order. */
const FORMAT2_IDS = [
  'seth/cnf-sat',
  '3sum-hypothesis/3sum',
  'apsp-hypothesis/directed-weighted-apsp',
  'apsp-hypothesis/undirected-weighted-apsp',
  'ov-hypothesis/ov',
  'min-weight-k-clique-hypothesis/min-weight-k-clique',
  'min-weight-k-clique-hypothesis/max-weight-k-clique',
  'k-clique-hypothesis/k-clique',
  'combinatorial-bmm-hypothesis/combinatorial-bmm',
  'known-algorithms/cnf-sat',
  'known-algorithms/max-cnf-sat',
  'known-algorithms/ov',
  'known-algorithms/3sum',
  'known-algorithms/directed-weighted-apsp',
  'known-algorithms/undirected-weighted-apsp',
  'known-algorithms/negative-triangle-detection',
  'known-algorithms/exact-triangle',
  'known-algorithms/edge-triangle-detection',
  'known-algorithms/triangle-detection',
  'known-algorithms/combinatorial-bmm',
  'known-algorithms/min-weight-k-clique',
  'known-algorithms/max-weight-k-clique',
  'known-algorithms/k-clique',
  'known-algorithms/edit-distance',
  'known-algorithms/longest-common-subsequence',
  'alman-vassilevska-williams-2026/3sum',
  'alman-vassilevska-williams-2026/real-3sum',
  'alman-vassilevska-williams-2026/directed-weighted-apsp',
  'alman-vassilevska-williams-2026/apsp-on-directed-graphs-with-real-valued-weights',
  'alman-vassilevska-williams-2026/distance-product',
  'alman-vassilevska-williams-2026/exact-triangle',
  'alman-vassilevska-williams-2026/real-exact-triangle',
  'alman-vassilevska-williams-2026/mono-convolution',
];

/** The initial knobs as format 2 saved them, edited a little (exponent, switched on). */
const format2: Knob[] = initial33.map((k, i) => ({ ...k, id: FORMAT2_IDS[i]!, enabled: true, ...(k.exponent !== undefined ? { exponent: k.exponent - 0.1 } : {}) }));

describe('numberFormat2Ids', () => {
  it('gives the initial knobs their Bound IDs (L1–L9, U1–U24) and keeps everything else', () => {
    assert.equal(format2.length, 33);
    const knobs = numberFormat2Ids(format2, config);
    assert.deepEqual(
      knobs.map((k) => k.id),
      initial33.map((k) => k.id),
    );
    assert.deepEqual(
      initial33.map((k) => k.id),
      [...Array.from({ length: 9 }, (_, i) => `L${i + 1}`), ...Array.from({ length: 24 }, (_, i) => `U${i + 1}`)],
    );
    knobs.forEach((k, i) => assert.deepEqual({ ...k, id: 'same' }, { ...format2[i]!, id: 'same' }));
  });

  it('gives added and own ids new Bound IDs after all others, and an initial knob whose ID is taken likewise', () => {
    const pick = (id: string): Knob => ({ ...format2[0]!, id });
    const knobs = numberFormat2Ids(
      [
        pick('seth/cnf-sat'),
        pick('apsp-hypothesis/directed-weighted-apsp'),
        pick('kmg3x41'),
        pick('L7'),
        pick('my bound'),
        pick('min-weight-k-clique-hypothesis/max-weight-k-clique'),
      ],
      config,
    );
    // L2 was deleted (its ID stays free); "L7" was imported from a CSV (as "7") and keeps its ID, so the initial knob
    // with ID L7 gets a new one (all are lower bounds here).
    assert.deepEqual(
      knobs.map((k) => k.id),
      ['L1', 'L3', 'L10', 'L7', 'L11', 'L12'],
    );
  });

  it('leaves knobs with Bound IDs as they are', () => {
    const knobs = initial.slice(0, 3);
    const result = numberFormat2Ids(knobs, config);
    assert.ok(result.every((k, i) => k === knobs[i]));
  });
});

describe('initialState with saved data', () => {
  /** Run `body` with `data` saved under the app's localStorage key. */
  function withSaved(data: unknown, body: () => void): void {
    const items = new Map([['fgc-explorer.v1', JSON.stringify(data)]]);
    const fake = {
      getItem: (key: string) => items.get(key) ?? null,
      setItem: (key: string, value: string) => void items.set(key, value),
      removeItem: (key: string) => void items.delete(key),
    };
    const before = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
    Object.defineProperty(globalThis, 'localStorage', { value: fake, configurable: true, writable: true });
    try {
      body();
    } finally {
      if (before) Object.defineProperty(globalThis, 'localStorage', before);
      else delete (globalThis as { localStorage?: unknown }).localStorage;
    }
  }
  const saved = (format: number, knobs: readonly Knob[], settings: object = {}) => ({ format, scenario: { version: 1, constants: {}, knobs, settings } });

  it('renumbers the knobs saved in format 2, adds the knobs of formats 5 and 6 and says so', () => {
    withSaved(saved(2, format2.slice(0, 3)), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.slice(0, 3).map((k) => k.id),
        ['L1', 'L2', 'L3'],
      );
      assert.equal(state.scenario.knobs[1]!.exponent, format2[1]!.exponent);
      assert.deepEqual(state.scenario.knobs.slice(3), addedSince4);
      assert.equal(messages.length, 1);
      assert.equal(messages[0]!.error, false);
      assert.match(messages[0]!.text, /IDs have letters now/);
      assert.match(messages[0]!.text, new RegExp(`adds ${addedSince4.length} algorithms`));
    });
  });

  it('keeps text ids of format 3 and gives the numbers of format 4 their place, new ones after the initial IDs', () => {
    withSaved(saved(3, format2.slice(0, 2)), () => {
      const { state } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.slice(0, 2).map((k) => k.id),
        FORMAT2_IDS.slice(0, 2),
      );
    });
    const numbered = (id: string, k: Knob): Knob => ({ ...k, id });
    const [seth, cnf, avw] = [initial33[0]!, initial33[9]!, initial33[25]!];
    withSaved(saved(4, [numbered('1', seth), numbered('10', cnf), numbered('26', avw), numbered('34', cnf), numbered('35', seth)]), () => {
      const { state, messages } = initialState('', configJson);
      // (the user's 34 and 35 come after the initial knobs of format 5, as in a config or bounds CSV: U368 and L35; U368
      // is an initial knob of format 6, so the user's moves to the next free ID)
      assert.deepEqual(
        state.scenario.knobs.slice(0, 5).map((k) => k.id),
        ['L1', 'U1', 'U17', 'U370', 'L35'],
      );
      assert.equal(state.scenario.knobs.find((k) => k.id === 'U17')!.problem, '3SUM / 3SUM', 'the first 2026 algorithm');
      assert.equal(state.scenario.knobs.length, 5 + addedSince4.length);
      assert.deepEqual(state.scenario.knobs.slice(5), addedSince4, 'with the IDs of the initial settings');
      assert.equal(new Set(state.scenario.knobs.map((k) => k.id)).size, state.scenario.knobs.length, 'IDs are unique');
      assert.equal(messages.length, 1);
      assert.doesNotMatch(messages[0]!.text, /is now/, 'every ID changed anyway');
    });
  });

  it('adds the knobs of format 6 to data of format 5 (switched off), with their IDs, and says so', () => {
    // (an algorithm the user added in format 5 got the next free ID, U368)
    const mine = { ...initial.find((k) => k.kind === 'UB')!, id: 'U368', enabled: true };
    withSaved(saved(5, [...initial.slice(0, 2), mine]), () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(addedIn6.length, 2);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        [initial[0]!.id, initial[1]!.id, 'U370', 'U368', 'U369'],
      );
      assert.deepEqual(state.scenario.knobs[2], { ...mine, id: 'U370' });
      assert.deepEqual(state.scenario.knobs.slice(3), addedIn6);
      assert.ok(state.scenario.knobs.slice(3).every((k) => !k.enabled));
      assert.equal(messages.length, 1);
      assert.match(messages[0]!.text, /adds 2 algorithms to your knobs \(Saha & Ye 2026; switched off\)\. They take Bound IDs your knobs had: U368 is now U370\./);
      // Saved again by the previous version (as format 5), the data gets nothing more.
      withSaved(saved(5, state.scenario.knobs), () => {
        const again = initialState('', configJson);
        assert.deepEqual(again.state.scenario.knobs, state.scenario.knobs);
        assert.deepEqual(again.messages, []);
      });
    });
  });

  it('leaves data of the current format as it is', () => {
    const knobs = [...initial.slice(0, 2), { ...initial[2]!, id: 'mine', enabled: false }];
    withSaved(saved(7, knobs, { disabledRows: ['R12'] }), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.scenario.knobs, knobs);
      assert.deepEqual(state.scenario.settings.disabledRows, ['R12']);
      assert.deepEqual(messages, []);
    });
  });

  it('adds the groups of formats 5 and 6 to a custom config saved before (with the IDs of then), and the rows its letters', () => {
    const old = JSON.parse(JSON.stringify(configJson)) as { initialKnobs: { label: string; knobs: { id: string; kind: string }[] }[]; rows: Record<string, unknown> };
    old.initialKnobs = old.initialKnobs.filter((g) => !ADDED.includes(g.label));
    for (const g of old.initialKnobs) for (const k of g.knobs) k.id = String(k.kind === 'LB' ? Number(k.id.slice(1)) : Number(k.id.slice(1)) + 9);
    old.rows = Object.fromEntries(Object.entries(old.rows).map(([id, r]) => [id.slice(1), r]));
    withSaved({ format: 4, config: old, scenario: { version: 1, constants: {}, knobs: [{ ...initial33[9]!, id: '10' }], settings: { disabledRows: ['106'] } } }, () => {
      const { state } = initialState('', configJson);
      assert.equal(state.configCustom, true);
      assert.deepEqual(
        state.config.initialKnobs.map((g) => g.label),
        config.initialKnobs.filter((g) => !ADDED.includes(g.label)).map((g) => g.label).concat(ADDED),
      );
      assert.deepEqual(initialScenario(state.config).knobs.map((k) => k.id).sort(), initial.map((k) => k.id).sort());
      assert.deepEqual(Object.keys(state.config.rows).sort(), Object.keys(config.rows).sort());
      assert.deepEqual(state.scenario.settings.disabledRows, ['R106']);
      assert.equal(state.scenario.knobs[0]!.id, 'U1');
    });
  });

  it("recognizes the added groups by their knobs' IDs and problems, not by label (a user's group may have the same name)", () => {
    const old = JSON.parse(JSON.stringify(configJson)) as { initialKnobs: { label: string; knobs: object[] }[] };
    old.initialKnobs = old.initialKnobs.filter((g) => !ADDED.includes(g.label));
    const mine = { id: 34, problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^{1.5}' };
    old.initialKnobs.push({ label: 'Best known algorithms', knobs: [mine] });
    withSaved({ format: 4, config: old, scenario: { version: 1, constants: {}, knobs: [{ ...mine, enabled: true }] } }, () => {
      const { state } = initialState('', configJson);
      const ids = state.scenario.knobs.map((k) => k.id);
      assert.equal(ids.filter((id) => id === 'U368').length, 1, 'my knob once, with the ID it has in my config');
      assert.equal(ids.length, 1 + addedSince4.length);
      assert.equal(new Set(ids).size, ids.length);
      const initialIds = initialScenario(state.config).knobs.map((k) => k.id);
      assert.equal(initialIds.filter((id) => id === 'U368').length, 1);
      assert.equal(new Set(initialIds).size, initialIds.length, 'the Saha & Ye knob with my ID gets another one');
      assert.equal(state.config.initialKnobs.filter((g) => g.label === 'Best known algorithms').length, 2);
      assert.equal(state.config.initialKnobs.filter((g) => g.label === 'Saha & Ye 2026').length, 1);
      // The knobs added have the IDs the config gives them.
      const ofSahaYe = (knobs: readonly Knob[]) => knobs.filter((k) => k.note?.startsWith('Saha & Ye 2026')).map((k) => [k.id, k.problem]);
      assert.deepEqual(ofSahaYe(state.scenario.knobs), ofSahaYe(initialScenario(state.config).knobs));
      assert.notEqual(ofSahaYe(state.scenario.knobs)[0]![0], 'U368');
    });
    // A config whose own U368 is the Distance Product: the group is there already, so neither it nor its knobs are added.
    const own = JSON.parse(JSON.stringify(configJson)) as { initialKnobs: { label: string; knobs: object[] }[] };
    own.initialKnobs = own.initialKnobs.filter((g) => !GROUPS_ADDED_IN[6]!.includes(g.label));
    const product = { id: 'U368', problem: addedIn6[0]!.problem, kind: 'UB', formula: 'n^{2.99}' };
    own.initialKnobs.push({ label: 'Mine', knobs: [product] });
    withSaved({ format: 5, config: own, scenario: { version: 1, constants: {}, knobs: [{ ...product, enabled: true }] } }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.config.initialKnobs.filter((g) => g.label === 'Saha & Ye 2026').length, 0);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        ['U368'],
      );
      assert.deepEqual(messages, []);
    });
    // A config of format 5 has the groups of format 5: only the one of format 6 is added (once).
    const five = JSON.parse(JSON.stringify(configJson)) as { initialKnobs: { label: string }[] };
    five.initialKnobs = five.initialKnobs.filter((g) => !GROUPS_ADDED_IN[6]!.includes(g.label));
    withSaved({ format: 5, config: five }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(
        state.config.initialKnobs.map((g) => g.label),
        config.initialKnobs.map((g) => g.label),
      );
      assert.deepEqual(messages, []);
    });
    withSaved({ format: 6, config: five }, () => {
      assert.equal(initialState('', configJson).state.config.initialKnobs.length, five.initialKnobs.length, 'not added to a config of format 6');
    });
  });

  it('gives a custom config saved before format 7 the built-in limits of parameters, where it has none', () => {
    const TL = 'Graph Triangle Problems / Triangle Listing';
    const FLOW = 'Maximum Flow / ST-Maximum Flow';
    const old = JSON.parse(JSON.stringify(configJson)) as { problems: Record<string, { constraints?: string[] }> };
    for (const entry of Object.values(old.problems)) delete entry.constraints;
    delete old.problems[FLOW];
    old.problems[TL] = { ...old.problems[TL], constraints: ['t <= n^3'] };
    const builtIn = (configJson as { problems: Record<string, { constraints?: string[] }> }).problems;
    withSaved({ format: 6, config: old }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.config.problems[TL]!.constraints, ['t <= n^3'], 'its own limits are kept');
      assert.deepEqual(state.config.problems[FLOW]!.constraints, builtIn[FLOW]!.constraints, 'a problem it did not list');
      assert.deepEqual(state.config.problems['Graph Triangle Problems / Triangle Detection']!.regimes, ['n=1, m=2', 'n=1, m=1']);
      assert.deepEqual(state.config.problems['Graph Triangle Problems / Triangle Detection']!.constraints, builtIn['Graph Triangle Problems / Triangle Detection']!.constraints);
      assert.deepEqual(messages, []);
    });
    withSaved({ format: 7, config: old }, () => {
      assert.equal(initialState('', configJson).state.config.problems[FLOW], undefined, 'a config of format 7 is used as it is');
    });
  });

  it('uses the valid parts of a saved config with problems, and says so', () => {
    const json = { ...(configJson as object), rows: { '1': { note: 'a' }, R1: { note: 'b' } } };
    withSaved({ format: 5, config: json }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.configCustom, true);
      assert.deepEqual(state.config.rows, { R1: { note: 'a' } });
      assert.equal(messages.length, 1);
      assert.match(messages[0]!.text, /saved config: 1 problem\(s\), the rest is used/);
    });
    withSaved({ format: 5, config: 'garbage' }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.configCustom, false);
      assert.match(messages[0]!.text, /ignored/);
    });
  });

  it('writes the rounded exponents of regimes saved before format 5 (pins, knobs) as the fractions they were', () => {
    const knob = { ...initial33[13]!, id: '14', regime: 'n=1, m=1.333333, M=poly', formula: undefined, exponent: 2.5 };
    withSaved({ format: 4, scenario: { version: 1, constants: {}, knobs: [knob] }, pinned: { 'A / B': ['n=1, m=0.666667', 'n=1, m=2'] } }, () => {
      const { state } = initialState('', configJson);
      assert.equal(state.scenario.knobs[0]!.regime, 'n=1, m=4/3, M=poly');
      assert.deepEqual(state.pinned, { 'A / B': ['n=1, m=2/3', 'n=1, m=2'] });
    });
  });

  it('replaces the old default limit of upper-bound derivations by the new default (a limit on detours only)', () => {
    for (const [format, depth, expected] of [
      [3, 4, 3],
      [2, 4, 3],
      [3, 6, 6],
      [4, 4, 4],
    ] as const) {
      withSaved(saved(format, initial.slice(0, 1), { maxDepthUB: depth }), () => {
        assert.equal(initialState('', configJson).state.scenario.settings.maxDepthUB, expected, `format ${format}, ${depth}`);
      });
    }
  });

  it('restores a valid focus mode, and starts with nothing selected', () => {
    for (const [focus, expected] of [
      ['lineage', 'lineage'],
      ['derivations', 'derivations'],
      ['sideways', 'off'],
      [true, 'off'],
    ] as const) {
      withSaved({ format: 3, prefs: { focus } }, () => {
        const { state } = initialState('', configJson);
        assert.equal(state.prefs.focus, expected);
        assert.deepEqual(state.selection, []);
      });
    }
  });

  it('restores a valid theme, else follows the system', () => {
    for (const [theme, expected] of [
      ['dark', 'dark'],
      ['light', 'light'],
      ['system', 'system'],
      ['sepia', 'system'],
    ] as const) {
      withSaved({ format: 3, prefs: { theme } }, () => assert.equal(initialState('', configJson).state.prefs.theme, expected));
    }
    withSaved({ format: 3 }, () => assert.equal(initialState('', configJson).state.prefs.theme, 'system'));
  });
});
