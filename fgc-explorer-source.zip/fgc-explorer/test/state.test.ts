import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { initialScenario, Knob, validateConfig } from '../src/model/config';
import { CONSTANTS_CHANGED_IN, ENTRIES_ADDED_IN, ENTRIES_CHANGED_IN, GROUPS_ADDED_IN, GROUPS_RENAMED_IN, initialState, KNOBS_ADDED_IN, KNOBS_CHANGED_IN, numberFormat2Ids } from '../src/ui/state';

/*
 * Testing strategy for saved data (src/ui/state.ts)
 *
 * numberFormat2Ids, partition on each knob's id: format-2 id of an initial knob (its ID free / taken by another
 * knob), other text (added in the app "k…", own), Bound ID (kept); on the knobs: all initial knobs, some deleted, all
 * with Bound IDs already (unchanged objects). Order is always kept.
 * initialState with saved data: format 2 (renumbered), format 3 (text ids kept), format 4 (numbers: the initial knobs'
 * place, the user's after the initial IDs as legacyBoundId says), format 12 (unchanged, no message); the groups added
 * since, and the knobs added since to groups there were, appended to the knobs with the Bound IDs of the initial
 * settings (a saved knob with one of them moves to a new one; not again when the saved knobs have them: data of this
 * version saved again by an earlier one) and to a saved custom config (groups recognized by Bound ID and problem, also
 * next to a user's group of the same name; knobs added to the groups of the same label, where there are such groups; a
 * knob whose ID the config has for another knob without it; the knobs then get the config's IDs, and none when the
 * config has the group already), with a message: before format 5 those of formats 5, 6, 8, 9, 11 and 12, with the IDs'
 * letters, and rounded exponents of knob regimes and pins back to fractions; format 5 those of formats 6, 8, 9, 11 and
 * 12, and the IDs moved; format 7 those of formats 8, 9, 11 and 12 (hypotheses and algorithms); format 8 those of
 * formats 9, 11 and 12; format 10 those of formats 11 and 12; format 11 the one of format 12; a custom config saved
 * before format 9 gets the problems and rows added since where it has no entry of its own (kept), format 11 the rows of
 * format 12, format 12 none; the entries changed since (format 12: k-GeomBase) where its entry is the old built-in one
 * (an edited one kept), and the row entries of the first version of format 11 (numbered before two rows were removed)
 * replaced by the built-in ones of their IDs or dropped (an edited one kept); the group renamed in format 11 (SETH), in a custom config saved
 * before (recognized by its knob, not by label: a user's group of that name keeps it; the old description replaced, the
 * user's kept) and as the note of a saved knob (the old default note; the user's own note kept); a custom config saved before
 * format 7 gets the built-in limits of parameters for the problems without its own (kept), format 7 none; the bounds
 * changed in format 13 (KNOBS_CHANGED_IN), in saved knobs and in a custom config, where they are the old built-in ones
 * (switch kept; note kept unless it was the old default; an edited bound kept), and the constants changed (ω: the old
 * default replaced, another value kept); a saved config
 * with problems used for its valid parts (a non-object ignored); settings.maxDepthUB of formats 2 and 3
 * (their default 4: the new default; other values, and format 4: kept); the focus mode (saved, invalid or the old
 * true/false: off) and the theme (saved, invalid: system); the family boxes (before format 10 off whatever was saved,
 * since on was the default; format 10 as saved; not a boolean: off); the selection is never restored.
 */

const configJson: unknown = JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'));
const config = validateConfig(configJson).value;
const initial = initialScenario(config).knobs;
/** The 33 initial knobs of formats 2–4 (L1–L9, U1–U24), in their order then. */
const initial33 = initial.filter((k) => /^(L[1-9]|U([1-9]|1\d|2[0-4]))$/.test(k.id));
/** The initial knob groups formats 5 and 6 added, and their knobs. */
const ADDED = [...GROUPS_ADDED_IN[5]!, ...GROUPS_ADDED_IN[6]!];
const addedSince4 = initial.filter((k) => !initial33.includes(k));
const addedIn6 = initial.filter((k) => k.note?.startsWith('Saha & Ye 2026'));
/** The group label of each initial knob. */
const groupOf = config.initialKnobs.flatMap((g) => g.knobs.map(() => g.label));
/** The knobs format 8 added: its groups' and those it added to groups there were. */
const addedIn8 = initial.filter((k, i) => GROUPS_ADDED_IN[8]!.includes(groupOf[i]!) || KNOBS_ADDED_IN[8]!.includes(k.id));
/** The knobs format 9 added (to groups there were). */
const addedIn9 = initial.filter((k) => KNOBS_ADDED_IN[9]!.includes(k.id));
/** The knobs format 11 added: its groups' and those it added to groups there were. */
const addedIn11 = initial.filter((k, i) => GROUPS_ADDED_IN[11]!.includes(groupOf[i]!) || KNOBS_ADDED_IN[11]!.includes(k.id));
/** The knob format 12 added (to a group there was). */
const addedIn12 = initial.filter((k) => KNOBS_ADDED_IN[12]!.includes(k.id));
/** The knobs format 13 added: its groups' (k-SAT, (min,+)-convolution, low-dimension OV, the October 2026 k-SAT algorithm). */
const addedIn13 = initial.filter((k, i) => GROUPS_ADDED_IN[13]!.includes(groupOf[i]!) || (KNOBS_ADDED_IN[13] ?? []).includes(k.id));
/** The knobs formats 8, 9, 11, 12 and 13 added, in the order of the initial settings. */
const addedSince7 = initial.filter((k) => addedIn8.includes(k) || addedIn9.includes(k) || addedIn11.includes(k) || addedIn12.includes(k) || addedIn13.includes(k));
/** The knobs formats 9, 11, 12 and 13 added, in the order of the initial settings. */
const addedSince8 = initial.filter((k) => addedIn9.includes(k) || addedIn11.includes(k) || addedIn12.includes(k) || addedIn13.includes(k));
/** The labels of the groups of these initial knobs, in the order of the initial settings. */
const groupsOf = (knobs: readonly Knob[]): string[] => [...new Set(initial.flatMap((k, i) => (knobs.includes(k) ? [groupOf[i]!] : [])))];
/** The next free Bound ID of each kind after the initial knobs'. */
const nextFree = (kind: 'L' | 'U', after = 0): string => `${kind}${Math.max(...initial.filter((k) => k.id.startsWith(kind)).map((k) => Number(k.id.slice(1)))) + 1 + after}`;
type ConfigJson = {
  constants: Record<string, { value: number }>;
  initialKnobs: { label: string; description?: string; knobs: { id: string; kind: string; problem?: string; note?: string }[] }[];
  problems: Record<string, unknown>;
  rows: Record<string, unknown>;
};
/**
 * A copy of a config (JSON) as saved before `format`: without the groups, knobs, problems and rows that format and later
 * ones added, with the entries of problems and rows they changed (but for the repairs of format 12), the knobs they
 * changed and the defaults of constants as they were, and with the labels and descriptions the groups they renamed had
 * (their knobs' notes are left out).
 */
const savedBefore = (format: number, json: unknown): ConfigJson => {
  const c = JSON.parse(JSON.stringify(json)) as ConfigJson;
  for (const [f, e] of Object.entries(ENTRIES_CHANGED_IN).sort(([a], [b]) => Number(b) - Number(a))) {
    if (Number(f) < format) continue;
    for (const [name, old] of Object.entries(e.problems)) c.problems[name] = JSON.parse(JSON.stringify(old));
    // (format 12 lists rows of the first version of format 11, not old entries of the built-in rows of those IDs)
    if (Number(f) !== 12) for (const [id, old] of Object.entries(e.rows)) c.rows[id] = JSON.parse(JSON.stringify(old));
  }
  for (const [f, changed] of Object.entries(KNOBS_CHANGED_IN).sort(([a], [b]) => Number(b) - Number(a))) {
    if (Number(f) < format) continue;
    for (const g of c.initialKnobs) {
      g.knobs = g.knobs.map((k) => (changed[k.id] !== undefined && k.problem === changed[k.id]!.old.problem ? { id: k.id, ...JSON.parse(JSON.stringify(changed[k.id]!.old)) } : k));
    }
  }
  // (latest first, so that the value of the earliest format at or after `format` stays)
  for (const [f, constants] of Object.entries(CONSTANTS_CHANGED_IN).sort(([a], [b]) => Number(b) - Number(a))) {
    if (Number(f) < format) continue;
    for (const [name, old] of Object.entries(constants)) c.constants[name]!.value = old;
  }
  const since = (table: Readonly<Record<number, readonly string[]>>): string[] => Object.entries(table).flatMap(([f, x]) => (Number(f) >= format ? x : []));
  const groups = since(GROUPS_ADDED_IN);
  const knobs = since(KNOBS_ADDED_IN);
  c.initialKnobs = c.initialKnobs.filter((g) => !groups.includes(g.label)).map((g) => ({ ...g, knobs: g.knobs.filter((k) => !knobs.includes(k.id)) }));
  for (const [f, e] of Object.entries(ENTRIES_ADDED_IN)) {
    if (Number(f) < format) continue;
    for (const p of e.problems) delete c.problems[p];
    for (const r of e.rows) delete c.rows[r];
  }
  for (const [f, renames] of Object.entries(GROUPS_RENAMED_IN).sort(([a], [b]) => Number(b) - Number(a))) {
    if (Number(f) < format) continue;
    for (const r of renames) {
      for (const g of c.initialKnobs.filter((x) => x.label === r.to)) {
        g.label = r.from;
        g.description = r.description;
        g.knobs = g.knobs.map(({ note: _note, ...k }) => k);
      }
    }
  }
  return c;
};
/** The renamed group (Satisfiability Hypothesis, SETH before format 11). */
const SAT = { old: 'SETH', label: 'Satisfiability Hypothesis' };
/** A copy of a config (JSON) as saved before format 8 (without what formats 8 and 9 added). */
const beforeFormat8 = (json: unknown): ConfigJson => savedBefore(8, json);
/** "4 hypotheses and 49 algorithms", as the message counts knobs. */
const counted = (knobs: readonly Knob[]): string => {
  const lbs = knobs.filter((k) => k.kind === 'LB').length;
  const ubs = knobs.length - lbs;
  return [lbs > 0 ? `${lbs} hypothes${lbs === 1 ? 'is' : 'es'}` : '', ubs > 0 ? `${ubs} algorithm${ubs === 1 ? '' : 's'}` : ''].filter((x) => x !== '').join(' and ');
};

/** The Bound IDs of the previous version's data/initial-bounds.csv (format 2), in order. */
const FORMAT2_IDS = [
  'seth/cnf-sat',
  '3sum-hypothesis/3sum',
  'apsp-hypothesis/directed-weighted-apsp',
  'apsp-hypothesis/undirected-weighted-apsp',
  'ov-hypothesis/ov',
  'min-weight-k-clique-hypothesis/min-weight-k-clique',
  'min-weight-k-clique-hypothesis/max-weight-k-clique',
  'k-clique-hypothesis/k-clique',
  'combinatorial-bmm-hypothesis/combinatorial-bmm',
  'known-algorithms/cnf-sat',
  'known-algorithms/max-cnf-sat',
  'known-algorithms/ov',
  'known-algorithms/3sum',
  'known-algorithms/directed-weighted-apsp',
  'known-algorithms/undirected-weighted-apsp',
  'known-algorithms/negative-triangle-detection',
  'known-algorithms/exact-triangle',
  'known-algorithms/edge-triangle-detection',
  'known-algorithms/triangle-detection',
  'known-algorithms/combinatorial-bmm',
  'known-algorithms/min-weight-k-clique',
  'known-algorithms/max-weight-k-clique',
  'known-algorithms/k-clique',
  'known-algorithms/edit-distance',
  'known-algorithms/longest-common-subsequence',
  'alman-vassilevska-williams-2026/3sum',
  'alman-vassilevska-williams-2026/real-3sum',
  'alman-vassilevska-williams-2026/directed-weighted-apsp',
  'alman-vassilevska-williams-2026/apsp-on-directed-graphs-with-real-valued-weights',
  'alman-vassilevska-williams-2026/distance-product',
  'alman-vassilevska-williams-2026/exact-triangle',
  'alman-vassilevska-williams-2026/real-exact-triangle',
  'alman-vassilevska-williams-2026/mono-convolution',
];

/** The initial knobs as format 2 saved them, edited a little (exponent, switched on). */
const format2: Knob[] = initial33.map((k, i) => ({ ...k, id: FORMAT2_IDS[i]!, enabled: true, ...(k.exponent !== undefined ? { exponent: k.exponent - 0.1 } : {}) }));

describe('numberFormat2Ids', () => {
  it('gives the initial knobs their Bound IDs (L1–L9, U1–U24) and keeps everything else', () => {
    assert.equal(format2.length, 33);
    const knobs = numberFormat2Ids(format2, config);
    assert.deepEqual(
      knobs.map((k) => k.id),
      initial33.map((k) => k.id),
    );
    assert.deepEqual(
      initial33.map((k) => k.id),
      [...Array.from({ length: 9 }, (_, i) => `L${i + 1}`), ...Array.from({ length: 24 }, (_, i) => `U${i + 1}`)],
    );
    knobs.forEach((k, i) => assert.deepEqual({ ...k, id: 'same' }, { ...format2[i]!, id: 'same' }));
  });

  it('gives added and own ids new Bound IDs after all others, and an initial knob whose ID is taken likewise', () => {
    const pick = (id: string): Knob => ({ ...format2[0]!, id });
    const knobs = numberFormat2Ids(
      [
        pick('seth/cnf-sat'),
        pick('apsp-hypothesis/directed-weighted-apsp'),
        pick('kmg3x41'),
        pick('L7'),
        pick('my bound'),
        pick('min-weight-k-clique-hypothesis/max-weight-k-clique'),
      ],
      config,
    );
    // L2 was deleted (its ID stays free); "L7" was imported from a CSV (as "7") and keeps its ID, so the initial knob
    // with ID L7 gets a new one (all are lower bounds here), after those of the initial knobs (L1–L18). (The first knob
    // is SETH's, named after the group's label of then.)
    assert.equal(nextFree('L'), 'L19');
    assert.deepEqual(
      knobs.map((k) => k.id),
      ['L1', 'L3', 'L19', 'L7', 'L20', 'L21'],
    );
  });

  it('leaves knobs with Bound IDs as they are', () => {
    const knobs = initial.slice(0, 3);
    const result = numberFormat2Ids(knobs, config);
    assert.ok(result.every((k, i) => k === knobs[i]));
  });
});

describe('initialState with saved data', () => {
  /** Run `body` with `data` saved under the app's localStorage key. */
  function withSaved(data: unknown, body: () => void): void {
    const items = new Map([['fgc-explorer.v1', JSON.stringify(data)]]);
    const fake = {
      getItem: (key: string) => items.get(key) ?? null,
      setItem: (key: string, value: string) => void items.set(key, value),
      removeItem: (key: string) => void items.delete(key),
    };
    const before = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
    Object.defineProperty(globalThis, 'localStorage', { value: fake, configurable: true, writable: true });
    try {
      body();
    } finally {
      if (before) Object.defineProperty(globalThis, 'localStorage', before);
      else delete (globalThis as { localStorage?: unknown }).localStorage;
    }
  }
  const saved = (format: number, knobs: readonly Knob[], settings: object = {}) => ({ format, scenario: { version: 1, constants: {}, knobs, settings } });

  it('renumbers the knobs saved in format 2, adds the knobs of formats 5, 6, 8, 9, 11, 12 and 13 and says so', () => {
    withSaved(saved(2, format2.slice(0, 3)), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.slice(0, 3).map((k) => k.id),
        ['L1', 'L2', 'L3'],
      );
      assert.equal(state.scenario.knobs[1]!.exponent, format2[1]!.exponent);
      assert.deepEqual(state.scenario.knobs.slice(3), addedSince4);
      assert.equal(messages.length, 1);
      assert.equal(messages[0]!.error, false);
      assert.match(messages[0]!.text, /IDs have letters now/);
      assert.match(messages[0]!.text, new RegExp(`adds ${counted(addedSince4)} to your knobs`));
      assert.match(messages[0]!.text, /adds 9 hypotheses and \d+ algorithms/);
    });
  });

  it('keeps text ids of format 3 and gives the numbers of format 4 their place, new ones after the initial IDs', () => {
    withSaved(saved(3, format2.slice(0, 2)), () => {
      const { state } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.slice(0, 2).map((k) => k.id),
        FORMAT2_IDS.slice(0, 2),
      );
    });
    const numbered = (id: string, k: Knob): Knob => ({ ...k, id });
    const [seth, cnf, avw] = [initial33[0]!, initial33[9]!, initial33[25]!];
    withSaved(saved(4, [numbered('1', seth), numbered('10', cnf), numbered('26', avw), numbered('34', cnf), numbered('35', seth)]), () => {
      const { state, messages } = initialState('', configJson);
      // (the user's 34 and 35 come after the initial knobs of format 5, as in a config or bounds CSV: U368 and L35; U368
      // is an initial knob of format 6, so the user's moves to the next free ID, after those of format 8)
      assert.deepEqual(
        state.scenario.knobs.slice(0, 5).map((k) => k.id),
        ['L1', 'U1', 'U17', nextFree('U'), 'L35'],
      );
      assert.equal(state.scenario.knobs.find((k) => k.id === 'U17')!.problem, '3SUM / 3SUM', 'the first 2026 algorithm');
      assert.equal(state.scenario.knobs.length, 5 + addedSince4.length);
      assert.deepEqual(state.scenario.knobs.slice(5), addedSince4, 'with the IDs of the initial settings');
      assert.equal(new Set(state.scenario.knobs.map((k) => k.id)).size, state.scenario.knobs.length, 'IDs are unique');
      assert.equal(messages.length, 1);
      assert.doesNotMatch(messages[0]!.text, /is now/, 'every ID changed anyway');
    });
  });

  it('adds the knobs of formats 6, 8, 9, 11, 12 and 13 to data of format 5, with their IDs, and says so', () => {
    // (an algorithm the user added in format 5 got the next free ID, U368)
    const mine = { ...initial.find((k) => k.kind === 'UB')!, id: 'U368', enabled: true };
    const added = initial.filter((k) => addedIn6.includes(k) || addedSince7.includes(k));
    // (two knobs that format 5 had: the first two of the initial settings that were not added since)
    const had = initial.filter((k) => !added.includes(k)).slice(0, 2);
    withSaved(saved(5, [...had, mine]), () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(addedIn6.length, 2);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        [had[0]!.id, had[1]!.id, nextFree('U'), ...added.map((k) => k.id)],
      );
      assert.deepEqual(state.scenario.knobs[2], { ...mine, id: nextFree('U') });
      assert.deepEqual(state.scenario.knobs.slice(3), added);
      assert.ok(state.scenario.knobs.filter((k) => addedIn6.includes(k)).every((k) => !k.enabled), 'Saha & Ye switched off');
      assert.equal(messages.length, 1);
      const on = added.filter((k) => k.enabled).length;
      assert.ok(on > 0 && on < added.length);
      assert.equal(
        messages[0]!.text,
        `This version adds ${counted(added)} to your knobs (${groupsOf(added).join(', ')}; ${on} switched on). They take Bound IDs your knobs had: U368 is now ${nextFree('U')}.`,
      );
      assert.match(messages[0]!.text, /Saha & Ye 2026/);
      // Saved again by the previous version (as format 5), the data gets nothing more.
      withSaved(saved(5, state.scenario.knobs), () => {
        const again = initialState('', configJson);
        assert.deepEqual(again.state.scenario.knobs, state.scenario.knobs);
        assert.deepEqual(again.messages, []);
      });
    });
  });

  it('adds the hypotheses and algorithms of formats 8, 9, 11, 12 and 13 to data of format 7, with their IDs, and says so', () => {
    // (an algorithm the user added in format 7 got the next free ID then, U370, which format 8 gives an initial knob)
    const mine = { ...initial.find((k) => k.kind === 'UB')!, id: 'U370', enabled: true };
    const before = initial.filter((k) => !addedSince7.includes(k));
    withSaved(saved(7, [...before, mine]), () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(addedIn8.length, 4 + KNOBS_ADDED_IN[8]!.length);
      assert.equal(addedIn9.length, KNOBS_ADDED_IN[9]!.length);
      assert.equal(addedIn11.length, 2 + KNOBS_ADDED_IN[11]!.length);
      assert.equal(addedIn12.length, KNOBS_ADDED_IN[12]!.length);
      assert.equal(addedIn13.length, 4);
      assert.deepEqual(state.scenario.knobs, [...before, { ...mine, id: nextFree('U') }, ...addedSince7]);
      assert.ok([...addedIn8, ...addedIn11, ...addedIn13].filter((k) => k.kind === 'LB').every((k) => !k.enabled), 'the new hypotheses start switched off');
      assert.equal(messages.length, 1);
      const algorithms = KNOBS_ADDED_IN[8]!.length + KNOBS_ADDED_IN[9]!.length + KNOBS_ADDED_IN[11]!.length + KNOBS_ADDED_IN[12]!.length + 1;
      assert.deepEqual(groupsOf(addedSince7), [
        'Satisfiability Hypothesis (k-SAT)',
        '(min,+)-convolution hypothesis',
        'Low-dimension OV hypothesis',
        'OMv conjecture',
        'Hitting Set hypothesis',
        '∀∀∃-OV hypothesis',
        '3-uniform hyperclique hypothesis',
        'k-AP hypothesis',
        'Zero-Weight k-Clique hypothesis',
        'Trivial algorithms',
        'Best known algorithms',
        'Non-combinatorial algorithms',
        'Alman & Vassilevska Williams 2026',
        'Subexponential k-SAT (Oct 2026)',
      ]);
      const escape = (x: string): string => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      assert.match(
        messages[0]!.text,
        new RegExp(`^This version adds 9 hypotheses and ${algorithms} algorithms to your knobs \\(${escape(groupsOf(addedSince7).join(', '))}; \\d+ switched on\\)\\. They take Bound IDs your knobs had: U370 is now ${nextFree('U')}\\.$`),
      );
    });
  });

  it("adds a knob of format 8 once, to the built-in group of its label, also when the user has a group of that label", () => {
    const old = beforeFormat8(configJson) as unknown as { initialKnobs: { label: string; knobs: object[] }[] };
    const mine = { id: 'U370', problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^{1.9}' };
    old.initialKnobs.push({ label: 'Best known algorithms', knobs: [mine] });
    withSaved({ format: 7, config: old, scenario: { version: 1, constants: {}, knobs: [{ ...mine, enabled: true }] } }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(messages.length, 1, messages.map((m) => m.text).join(' | '));
      assert.equal(messages[0]!.error, false);
      const best = state.config.initialKnobs.filter((g) => g.label === 'Best known algorithms');
      assert.equal(best.length, 2);
      assert.deepEqual(best[1]!.knobs.map((k) => k.problem), ['3SUM / 3SUM'], "the user's group gets nothing");
      const ids = initialScenario(state.config).knobs.map((k) => k.id);
      assert.equal(new Set(ids).size, ids.length, 'every knob once');
      assert.equal(state.scenario.knobs.length, 1 + addedSince7.length);
      assert.equal(state.scenario.knobs.filter((k) => k.problem === '3SUM / 3SUM' && k.formula === 'n^{1.9}').length, 1);
    });
  });

  it('does not add a knob of format 8 again that came without its Bound ID (taken in the config), when data is saved again by an earlier version', () => {
    const old = beforeFormat8(configJson) as unknown as { initialKnobs: { label: string; knobs: object[] }[] };
    // (the config's own U370 and L10 are other knobs: the new U370 and L10 come without IDs)
    old.initialKnobs.push({ label: 'Mine', knobs: [{ id: 'U370', problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^{1.9}' }, { id: 'L10', problem: '3SUM / 3SUM', kind: 'LB', regime: 'n=1, M=poly', exponent: 1.5 }] });
    withSaved({ format: 7, config: old }, () => {
      const first = initialState('', configJson).state;
      const omv = (c: typeof first.config) => initialScenario(c).knobs.filter((k) => k.problem === 'Matrix-Vector Multiplication / OMv');
      assert.equal(omv(first.config).length, 3, 'the conjecture, a trivial and a best known algorithm');
      assert.ok(omv(first.config).every((k) => k.id !== 'U370' && k.id !== 'L10'));
      withSaved({ format: 7, config: first.config, scenario: first.scenario }, () => {
        const again = initialState('', configJson);
        assert.deepEqual(again.messages, []);
        assert.equal(omv(again.state.config).length, 3, 'not added twice');
        assert.equal(again.state.config.initialKnobs.filter((g) => g.label === 'OMv conjecture').length, 1);
        assert.deepEqual(again.state.scenario.knobs, first.scenario.knobs);
      });
    });
  });

  it('leaves data of the current format as it is', () => {
    const knobs = [...initial.slice(0, 2), { ...initial[2]!, id: 'mine', enabled: false }];
    withSaved(saved(14, knobs, { disabledRows: ['R12'] }), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.scenario.knobs, knobs);
      assert.deepEqual(state.scenario.settings.disabledRows, ['R12']);
      assert.deepEqual(messages, []);
    });
  });

  it('adds the algorithm of format 12 to data of format 11, its rows to a custom config, and the new k-GeomBase entry where the old one is unedited', () => {
    const since11 = initial.filter((k) => addedIn12.includes(k) || addedIn13.includes(k));
    const before = initial.filter((k) => !since11.includes(k));
    assert.deepEqual(addedIn12.map((k) => [k.id, k.problem]), [['U441', 'Geometric Covering Problems / Weighted Depth']]);
    withSaved(saved(11, before), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.scenario.knobs, [...before, ...since11]);
      assert.deepEqual(messages.map((m) => m.text), [
        `This version adds ${counted(since11)} to your knobs (${groupsOf(since11).join(', ')}; 1 switched on).`,
      ]);
      assert.equal(counted(since11), '3 hypotheses and 2 algorithms');
    });
    const KGB = 'Geometric Base / k-GeomBase';
    const old = savedBefore(12, configJson);
    assert.deepEqual(old.problems[KGB], ENTRIES_CHANGED_IN[12]!.problems[KGB]);
    for (const id of ENTRIES_ADDED_IN[12]!.rows) assert.equal(old.rows[id], undefined, id);
    withSaved({ format: 11, config: old }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(messages, []);
      assert.deepEqual(state.config.problems, config.problems, 'k-GeomBase for k >= 4');
      assert.deepEqual(state.config.rows, config.rows, 'R118, R434, R463–R465 (and those of format 13)');
      // (U441 in its place; the groups of format 13 appended)
      const appended = initial.filter((k) => addedIn13.includes(k));
      assert.deepEqual(
        initialScenario(state.config).knobs.map((k) => k.id),
        [...initial.filter((k) => !appended.includes(k)), ...appended].map((k) => k.id),
      );
    });
    // An entry the user edited is kept, also with its keys in another order.
    const edited = savedBefore(12, configJson);
    edited.problems[KGB] = { ...(edited.problems[KGB] as object), note: 'mine' };
    const reordered = savedBefore(12, configJson);
    reordered.problems[KGB] = Object.fromEntries(Object.entries(reordered.problems[KGB] as object).reverse());
    withSaved({ format: 11, config: edited }, () => {
      assert.equal((initialState('', configJson).state.config.problems[KGB] as { note?: string }).note, 'mine');
    });
    withSaved({ format: 11, config: reordered }, () => {
      assert.deepEqual(initialState('', configJson).state.config.problems[KGB], config.problems[KGB], 'the same entry');
    });
  });

  it('updates the bounds format 13 changed where saved data has the old built-in ones, and the old default of ω in a custom config', () => {
    const changed = KNOBS_CHANGED_IN[13]!;
    const now = (id: string): Knob => initial.find((k) => k.id === id)!;
    const oldKnob = (id: string): Knob => {
      const { note: _n, formula: _f, exponent: _e, power: _p, regime: _r, ...rest } = now(id);
      return { ...rest, ...changed[id]!.old, note: changed[id]!.old.note ?? changed[id]!.group } as Knob;
    };
    assert.equal(oldKnob('U14').regime, undefined);
    assert.equal(now('U14').regime, 'k=const:[3,6]');
    const knobs = [oldKnob('U14'), { ...oldKnob('U273'), enabled: false }, { ...oldKnob('U304'), formula: 'n^{2.6}' }, { ...oldKnob('U417'), note: 'my note' }];
    const before = initial.filter((k) => !addedIn13.includes(k) && !knobs.some((x) => x.id === k.id));
    withSaved(saved(12, [...knobs, ...before]), () => {
      const { state, messages } = initialState('', configJson);
      const at = (id: string): Knob => state.scenario.knobs.find((k) => k.id === id)!;
      assert.deepEqual(at('U14'), now('U14'), 'the regime k = 3, 6 and the new note');
      assert.deepEqual(at('U273'), { ...now('U273'), enabled: false }, 'its switch kept');
      assert.deepEqual(at('U304'), knobs[2], 'an edited bound kept');
      assert.deepEqual(at('U417'), { ...now('U417'), note: 'my note' }, 'its own note kept');
      assert.deepEqual(state.scenario.knobs.slice(knobs.length + before.length), addedIn13);
      assert.deepEqual(
        messages.map((m) => m.text),
        [
          `This version adds ${counted(addedIn13)} to your knobs (${groupsOf(addedIn13).join(', ')}; switched off).`,
          'This version updates 3 built-in bounds you had as they were: U14, U273, U417 (see their notes).',
        ].reverse(),
      );
    });
    // A custom config saved before: its old knobs, entries and ω replaced (the groups of format 13 appended), ...
    const old = savedBefore(13, configJson);
    assert.equal(old.constants['omega']!.value, 2.371552);
    assert.deepEqual((old.rows['R350'] as { requires?: string }).requires, 'd=log');
    withSaved({ format: 12, config: old }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(messages, []);
      assert.deepEqual(state.config.constants, config.constants);
      assert.deepEqual(state.config.problems, config.problems);
      assert.deepEqual(state.config.rows, config.rows);
      const sorted = (ks: readonly Knob[]): Knob[] => [...ks].sort((a, b) => a.id.localeCompare(b.id));
      assert.deepEqual(sorted(initialScenario(state.config).knobs), sorted(initial));
    });
    // ... but an edited knob, and another value of ω, kept.
    const edited = savedBefore(13, configJson);
    for (const g of edited.initialKnobs) g.knobs = g.knobs.map((k) => (k.id === 'U14' ? { ...k, formula: 'n^{2.5 k/3}' } : k));
    edited.constants['omega']!.value = 2.5;
    withSaved({ format: 12, config: edited }, () => {
      const { state } = initialState('', configJson);
      const u14 = initialScenario(state.config).knobs.find((k) => k.id === 'U14')!;
      assert.deepEqual([u14.formula, u14.regime], ['n^{2.5 k/3}', undefined]);
      assert.equal(state.config.constants['omega']!.value, 2.5);
    });
  });

  it('renames the k-SAT group (format 14), gives L1, L16 and U442 their new notes where saved data has the old ones, and ω its new default', () => {
    const changed = KNOBS_CHANGED_IN[14]!;
    const now = (id: string): Knob => initial.find((k) => k.id === id)!;
    const oldKnob = (id: string): Knob => ({ ...now(id), ...changed[id]!.old, note: changed[id]!.old.note ?? changed[id]!.group }) as Knob;
    const [oldL1, oldL16, oldU442] = [oldKnob('L1'), oldKnob('L16'), oldKnob('U442')];
    assert.notEqual(oldL1.note, now('L1').note);
    assert.deepEqual({ ...oldL1, note: now('L1').note }, now('L1'), 'only the note changed');
    assert.deepEqual({ ...oldU442, note: now('U442').note }, now('U442'), 'only the note changed');
    // Saved knobs with the old notes get the new ones (L1 stays switched off); a note of the user's own stays.
    const knobs = initial.map((k) => (k.id === 'L1' ? { ...oldL1, enabled: false } : k.id === 'L16' ? oldL16 : k.id === 'U442' ? oldU442 : k));
    withSaved(saved(13, knobs), () => {
      const { state, messages } = initialState('', configJson);
      const at = (id: string): Knob => state.scenario.knobs.find((k) => k.id === id)!;
      assert.deepEqual(at('L1'), { ...now('L1'), enabled: false });
      assert.deepEqual(at('L16'), now('L16'));
      assert.deepEqual(at('U442'), now('U442'));
      assert.deepEqual(messages, [{ text: 'This version updates 3 built-in bounds you had as they were: L1, L16, U442 (see their notes).', error: false }]);
    });
    withSaved(saved(13, knobs.map((k) => (k.id === 'L16' ? { ...k, note: 'mine' } : k))), () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.scenario.knobs.find((k) => k.id === 'L16')!.note, 'mine');
      assert.deepEqual(messages.map((m) => m.text), ['This version updates 2 built-in bounds you had as they were: L1, U442 (see their notes).']);
    });
    // A custom config saved in format 13: the group "SETH (k-SAT form)" renamed (with the new description, as it had the
    // old one), the old notes of L1, L16 and U442 replaced, and the old default of ω.
    const rename = GROUPS_RENAMED_IN[14]![0]!;
    assert.deepEqual([rename.from, rename.to], ['SETH (k-SAT form)', 'Satisfiability Hypothesis (k-SAT)']);
    const old = savedBefore(14, configJson);
    // (savedBefore leaves out the notes of a renamed group's knobs; L16's own note was the old one)
    for (const g of old.initialKnobs) g.knobs = g.knobs.map((k) => (k.id === 'L16' ? { ...k, note: changed['L16']!.old.note } : k));
    assert.equal(old.constants['omega']!.value, 2.371339);
    assert.ok(old.initialKnobs.some((g) => g.label === 'SETH (k-SAT form)' && g.description === rename.description));
    withSaved({ format: 13, config: old }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(messages, []);
      assert.deepEqual(state.config.initialKnobs, config.initialKnobs);
      assert.equal(state.config.constants['omega']!.value, 2.25);
      assert.deepEqual(state.config.constants, config.constants);
    });
  });

  it('repairs the row entries of the first version of format 11, numbered before rows R435 and R453 were removed', () => {
    const first = savedBefore(12, configJson);
    const changed = ENTRIES_CHANGED_IN[12]!.rows;
    first.rows = { ...first.rows, R435: changed['R435'], R453: changed['R453'], R455: changed['R455'] };
    // (its R453 was the row from 4-AP Detection to 3-uniform 4-hyperclique, now R434; its R455 the lopsided row, now R453)
    assert.deepEqual((changed['R453'] as { match: object }).match, (config.rows['R434'] as { match: object }).match);
    assert.deepEqual(changed['R455'], (configJson as ConfigJson).rows['R453']);
    withSaved({ format: 11, config: first }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(messages, []);
      assert.deepEqual(state.config.rows, config.rows);
    });
    // a user's own entry for one of those IDs is kept
    const mine = { ...first, rows: { ...first.rows, R435: { note: 'mine' } } };
    withSaved({ format: 11, config: mine }, () => {
      assert.deepEqual(initialState('', configJson).state.config.rows['R435'], { note: 'mine' });
    });
    // data of format 12 is used as it is
    withSaved({ format: 12, config: first }, () => {
      assert.deepEqual(initialState('', configJson).state.config.rows['R455'], changed['R455']);
    });
  });

  it('adds the knobs of formats 9, 11, 12 and 13 to data of format 8, and their knobs and entries to a custom config of format 8', () => {
    const before = initial.filter((k) => !addedSince8.includes(k));
    withSaved(saved(8, before), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.scenario.knobs, [...before, ...addedSince8]);
      const on = addedSince8.filter((k) => k.enabled).length;
      assert.deepEqual(messages.map((m) => m.text), [
        `This version adds 5 hypotheses and ${KNOBS_ADDED_IN[9]!.length + KNOBS_ADDED_IN[11]!.length + KNOBS_ADDED_IN[12]!.length + 1} algorithms to your knobs (Satisfiability Hypothesis (k-SAT), (min,+)-convolution hypothesis, Low-dimension OV hypothesis, k-AP hypothesis, Zero-Weight k-Clique hypothesis, Trivial algorithms, Best known algorithms, Alman & Vassilevska Williams 2026, Subexponential k-SAT (Oct 2026); ${on} switched on).`,
      ]);
    });
    const old = savedBefore(9, configJson);
    assert.equal(old.problems['Graph Triangle Problems / All-Edges Exact Triangle'], undefined);
    assert.equal(old.problems['Clique / Zero-Weight k-Clique'], undefined);
    withSaved({ format: 8, config: old, scenario: { version: 1, constants: {}, knobs: before } }, () => {
      const { state } = initialState('', configJson);
      assert.equal(state.configCustom, true);
      // (the groups of formats 11 and 13 are appended, the knobs added to groups there were are in their place)
      const appended = [...GROUPS_ADDED_IN[11]!, ...GROUPS_ADDED_IN[13]!];
      const inAddedGroups = (k: Knob): boolean => initial.some((a, i) => a.id === k.id && appended.includes(groupOf[i]!));
      assert.deepEqual(
        initialScenario(state.config).knobs.filter((k) => !inAddedGroups(k)).map((k) => k.id),
        initial.filter((k) => !inAddedGroups(k)).map((k) => k.id),
        'in the order of the built-in config',
      );
      // (in the order of the built-in config)
      assert.deepEqual(state.config.initialKnobs.slice(-appended.length).map((g) => g.label), config.initialKnobs.map((g) => g.label).filter((l) => appended.includes(l)));
      assert.deepEqual(state.config.problems, config.problems);
      assert.deepEqual(state.config.rows, config.rows);
      // (the knobs added, in the order of the upgraded config)
      assert.deepEqual(state.scenario.knobs, [...before, ...initialScenario(state.config).knobs.filter((k) => addedSince8.some((a) => a.id === k.id))]);
      assert.equal(state.scenario.knobs.length, before.length + addedSince8.length);
      const sat = state.config.initialKnobs.find((g) => g.knobs.some((k) => k.id === 'L1'))!;
      assert.deepEqual([sat.label, sat.description], [SAT.label, config.initialKnobs.find((g) => g.label === SAT.label)!.description]);
    });
  });

  it('renames the group SETH in a custom config saved before format 11 (recognized by its knob), and the default note of its saved knob', () => {
    const old = savedBefore(11, configJson);
    const seth = old.initialKnobs.find((g) => g.label === SAT.old)!;
    assert.ok(seth.knobs.some((k) => k.id === 'L1'));
    // the user's own group named SETH, and a copy of the built-in one with the user's description
    const mine = { id: 'L99', problem: 'Orthogonal Vectors / OV', kind: 'LB', regime: 'n=1, d=log', exponent: 2 };
    old.initialKnobs.push({ label: SAT.old, knobs: [mine] });
    const before = initial.filter((k) => !addedIn11.includes(k));
    const knobs = [...before.map((k) => (k.id === 'L1' ? { ...k, note: SAT.old } : k)), { ...mine, enabled: true, note: SAT.old } as Knob];
    withSaved({ format: 10, config: old, scenario: { version: 1, constants: {}, knobs } }, () => {
      const { state } = initialState('', configJson);
      const labels = state.config.initialKnobs.map((g) => g.label);
      assert.equal(labels.filter((l) => l === SAT.label).length, 1);
      assert.equal(labels.filter((l) => l === SAT.old).length, 1, "the user's group keeps its name");
      const sat = state.config.initialKnobs.find((g) => g.label === SAT.label)!;
      assert.deepEqual(sat.knobs.map((k) => k.id), ['L1']);
      assert.equal(sat.description, config.initialKnobs.find((g) => g.label === SAT.label)!.description, 'the new description');
      // (the custom config's knob has no note of its own: its default note is the new label)
      assert.equal(state.scenario.knobs.find((k) => k.id === 'L1')!.note, SAT.label);
      assert.equal(state.scenario.knobs.find((k) => k.id === 'L99')!.note, SAT.old, "the user's knob keeps its note");
    });
    // the built-in config: the knob's note is the built-in one; a note of the user's own is kept; a description of the
    // user's own is kept
    withSaved({ format: 10, scenario: { version: 1, constants: {}, knobs } }, () => {
      const { state } = initialState('', configJson);
      assert.equal(state.scenario.knobs.find((k) => k.id === 'L1')!.note, initial.find((k) => k.id === 'L1')!.note);
      assert.notEqual(initial.find((k) => k.id === 'L1')!.note, SAT.old);
    });
    const own = knobs.map((k) => (k.id === 'L1' ? { ...k, note: 'my SETH' } : k));
    withSaved({ format: 10, scenario: { version: 1, constants: {}, knobs: own } }, () => {
      assert.equal(initialState('', configJson).state.scenario.knobs.find((k) => k.id === 'L1')!.note, 'my SETH');
    });
    seth.description = 'my description';
    withSaved({ format: 10, config: old }, () => {
      const sat = initialState('', configJson).state.config.initialKnobs.find((g) => g.label === SAT.label)!;
      assert.equal(sat.description, 'my description');
    });
    withSaved({ format: 11, config: old }, () => {
      assert.ok(initialState('', configJson).state.config.initialKnobs.every((g) => g.label !== SAT.label), 'a config of format 11 is used as it is');
    });
  });

  it('adds the groups of formats 5, 6, 8, 11 and 13, and the knobs and entries of formats 8, 9, 11, 12 and 13, to a custom config saved before (with the IDs of then and the label SETH), and the rows its letters', () => {
    const old = beforeFormat8(configJson);
    old.initialKnobs = old.initialKnobs.filter((g) => !ADDED.includes(g.label));
    for (const g of old.initialKnobs) for (const k of g.knobs) k.id = String(k.kind === 'LB' ? Number(k.id.slice(1)) : Number(k.id.slice(1)) + 9);
    old.rows = Object.fromEntries(Object.entries(old.rows).map(([id, r]) => [id.slice(1), r]));
    withSaved({ format: 4, config: old, scenario: { version: 1, constants: {}, knobs: [{ ...initial33[9]!, id: '10' }], settings: { disabledRows: ['106'] } } }, () => {
      const { state } = initialState('', configJson);
      assert.equal(state.configCustom, true);
      const since4 = [...ADDED, ...GROUPS_ADDED_IN[8]!, ...GROUPS_ADDED_IN[11]!, ...GROUPS_ADDED_IN[13]!];
      assert.deepEqual(
        state.config.initialKnobs.map((g) => g.label),
        // (appended in the order of the built-in config)
        config.initialKnobs.filter((g) => !since4.includes(g.label)).map((g) => g.label).concat(config.initialKnobs.filter((g) => since4.includes(g.label)).map((g) => g.label)),
      );
      assert.deepEqual(initialScenario(state.config).knobs.map((k) => k.id).sort(), initial.map((k) => k.id).sort());
      assert.deepEqual(Object.keys(state.config.rows).sort(), Object.keys(config.rows).sort());
      assert.deepEqual(Object.keys(state.config.problems).sort(), Object.keys(config.problems).sort());
      assert.deepEqual(state.config.rows['R340'], config.rows['R340'], 'the free parameters of a new row');
      assert.deepEqual(state.scenario.settings.disabledRows, ['R106']);
      assert.equal(state.scenario.knobs[0]!.id, 'U1');
    });
  });

  it("recognizes the added groups by their knobs' IDs and problems, not by label (a user's group may have the same name)", () => {
    const old = JSON.parse(JSON.stringify(configJson)) as { initialKnobs: { label: string; knobs: object[] }[] };
    old.initialKnobs = old.initialKnobs.filter((g) => !ADDED.includes(g.label));
    const mine = { id: 34, problem: '3SUM / 3SUM', kind: 'UB', formula: 'n^{1.5}' };
    old.initialKnobs.push({ label: 'Best known algorithms', knobs: [mine] });
    withSaved({ format: 4, config: old, scenario: { version: 1, constants: {}, knobs: [{ ...mine, enabled: true }] } }, () => {
      const { state } = initialState('', configJson);
      const ids = state.scenario.knobs.map((k) => k.id);
      assert.equal(ids.filter((id) => id === 'U368').length, 1, 'my knob once, with the ID it has in my config');
      assert.equal(ids.length, 1 + addedSince4.length);
      assert.equal(new Set(ids).size, ids.length);
      const initialIds = initialScenario(state.config).knobs.map((k) => k.id);
      assert.equal(initialIds.filter((id) => id === 'U368').length, 1);
      assert.equal(new Set(initialIds).size, initialIds.length, 'the Saha & Ye knob with my ID gets another one');
      assert.equal(state.config.initialKnobs.filter((g) => g.label === 'Best known algorithms').length, 2);
      assert.equal(state.config.initialKnobs.filter((g) => g.label === 'Saha & Ye 2026').length, 1);
      // The knobs added have the IDs the config gives them.
      const ofSahaYe = (knobs: readonly Knob[]) => knobs.filter((k) => k.note?.startsWith('Saha & Ye 2026')).map((k) => [k.id, k.problem]);
      assert.deepEqual(ofSahaYe(state.scenario.knobs), ofSahaYe(initialScenario(state.config).knobs));
      assert.notEqual(ofSahaYe(state.scenario.knobs)[0]![0], 'U368');
    });
    // A config whose own U368 is the Distance Product: the group is there already, so neither it nor its knobs are added
    // (only those of format 8).
    const own = beforeFormat8(configJson) as { initialKnobs: { label: string; knobs: object[] }[] };
    own.initialKnobs = own.initialKnobs.filter((g) => !GROUPS_ADDED_IN[6]!.includes(g.label));
    const product = { id: 'U368', problem: addedIn6[0]!.problem, kind: 'UB', formula: 'n^{2.99}' };
    own.initialKnobs.push({ label: 'Mine', knobs: [product] });
    withSaved({ format: 5, config: own, scenario: { version: 1, constants: {}, knobs: [{ ...product, enabled: true }] } }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.config.initialKnobs.filter((g) => g.label === 'Saha & Ye 2026').length, 0);
      // (in the order of the upgraded config: the knobs added to its groups, then the groups appended to it)
      const added8 = initialScenario(state.config).knobs.filter((k) => addedSince7.some((a) => a.id === k.id));
      assert.equal(added8.length, addedSince7.length);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        ['U368', ...added8.map((k) => k.id)],
      );
      assert.equal(messages.length, 1);
      assert.doesNotMatch(messages[0]!.text, /Saha/);
    });
    // A config of format 5 has the groups of format 5: only the one of format 6 is added (once).
    const five = JSON.parse(JSON.stringify(configJson)) as { initialKnobs: { label: string }[] };
    five.initialKnobs = five.initialKnobs.filter((g) => !GROUPS_ADDED_IN[6]!.includes(g.label));
    withSaved({ format: 5, config: five }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.config.initialKnobs.map((g) => g.label), [...five.initialKnobs.map((g) => g.label), ...GROUPS_ADDED_IN[6]!]);
      assert.deepEqual(messages, []);
    });
    withSaved({ format: 6, config: five }, () => {
      assert.equal(initialState('', configJson).state.config.initialKnobs.length, five.initialKnobs.length, 'not added to a config of format 6');
    });
  });

  it('gives a custom config saved before format 7 the built-in limits of parameters, where it has none', () => {
    const TL = 'Graph Triangle Problems / Triangle Listing';
    const FLOW = 'Maximum Flow / ST-Maximum Flow';
    const old = JSON.parse(JSON.stringify(configJson)) as { problems: Record<string, { constraints?: string[] }> };
    for (const entry of Object.values(old.problems)) delete entry.constraints;
    delete old.problems[FLOW];
    old.problems[TL] = { ...old.problems[TL], constraints: ['t <= n^3'] };
    const builtIn = (configJson as { problems: Record<string, { constraints?: string[] }> }).problems;
    withSaved({ format: 6, config: old }, () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(state.config.problems[TL]!.constraints, ['t <= n^3'], 'its own limits are kept');
      assert.deepEqual(state.config.problems[FLOW]!.constraints, builtIn[FLOW]!.constraints, 'a problem it did not list');
      assert.deepEqual(state.config.problems['Graph Triangle Problems / Triangle Detection']!.regimes, ['n=1, m=2', 'n=1, m=1']);
      assert.deepEqual(state.config.problems['Graph Triangle Problems / Triangle Detection']!.constraints, builtIn['Graph Triangle Problems / Triangle Detection']!.constraints);
      assert.deepEqual(messages, []);
    });
    withSaved({ format: 7, config: old }, () => {
      assert.equal(initialState('', configJson).state.config.problems[FLOW], undefined, 'a config of format 7 is used as it is');
    });
  });

  it('uses the valid parts of a saved config with problems, and says so', () => {
    const json = { ...(configJson as object), rows: { '1': { note: 'a' }, R1: { note: 'b' } } };
    withSaved({ format: 13, config: json }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.configCustom, true);
      assert.deepEqual(state.config.rows, { R1: { note: 'a' } });
      assert.equal(messages.length, 1);
      assert.match(messages[0]!.text, /saved config: 1 problem\(s\), the rest is used/);
    });
    withSaved({ format: 8, config: 'garbage' }, () => {
      const { state, messages } = initialState('', configJson);
      assert.equal(state.configCustom, false);
      assert.match(messages[0]!.text, /ignored/);
    });
  });

  it('writes the rounded exponents of regimes saved before format 5 (pins, knobs) as the fractions they were', () => {
    const knob = { ...initial33[13]!, id: '14', regime: 'n=1, m=1.333333, M=poly', formula: undefined, exponent: 2.5 };
    withSaved({ format: 4, scenario: { version: 1, constants: {}, knobs: [knob] }, pinned: { 'A / B': ['n=1, m=0.666667', 'n=1, m=2'] } }, () => {
      const { state } = initialState('', configJson);
      assert.equal(state.scenario.knobs[0]!.regime, 'n=1, m=4/3, M=poly');
      assert.deepEqual(state.pinned, { 'A / B': ['n=1, m=2/3', 'n=1, m=2'] });
    });
  });

  it('replaces the old default limit of upper-bound derivations by the new default (a limit on detours only)', () => {
    for (const [format, depth, expected] of [
      [3, 4, 3],
      [2, 4, 3],
      [3, 5, 5],
      [4, 4, 4],
      [4, 8, 5], // at most MAX_DEPTH_UB: past it the search reaches its node limit and gets worse (SPEC §6)
    ] as const) {
      withSaved(saved(format, initial.slice(0, 1), { maxDepthUB: depth }), () => {
        assert.equal(initialState('', configJson).state.scenario.settings.maxDepthUB, expected, `format ${format}, ${depth}`);
      });
    }
  });

  it('restores a valid focus mode, and starts with nothing selected', () => {
    for (const [focus, expected] of [
      ['lineage', 'lineage'],
      ['derivations', 'derivations'],
      ['sideways', 'off'],
      [true, 'off'],
    ] as const) {
      withSaved({ format: 3, prefs: { focus } }, () => {
        const { state } = initialState('', configJson);
        assert.equal(state.prefs.focus, expected);
        assert.deepEqual(state.selection, []);
      });
    }
  });

  it('turns the family boxes off in data saved before format 10 (on was the default), and keeps those of format 10', () => {
    for (const [format, groupFamilies, expected] of [
      [9, true, false],
      [9, false, false],
      [3, true, false],
      [10, true, true],
      [10, false, false],
      [10, 'yes', false],
      [11, true, true],
    ] as const) {
      withSaved({ format, prefs: { groupFamilies } }, () => {
        assert.equal(initialState('', configJson).state.prefs.groupFamilies, expected, `format ${format}, ${groupFamilies}`);
      });
    }
    withSaved({ prefs: { groupFamilies: true } }, () => assert.equal(initialState('', configJson).state.prefs.groupFamilies, false, 'first version'));
    withSaved({ format: 10 }, () => assert.equal(initialState('', configJson).state.prefs.groupFamilies, false, 'nothing saved'));
  });

  it('restores a valid theme, else follows the system', () => {
    for (const [theme, expected] of [
      ['dark', 'dark'],
      ['light', 'light'],
      ['system', 'system'],
      ['sepia', 'system'],
    ] as const) {
      withSaved({ format: 3, prefs: { theme } }, () => assert.equal(initialState('', configJson).state.prefs.theme, expected));
    }
    withSaved({ format: 3 }, () => assert.equal(initialState('', configJson).state.prefs.theme, 'system'));
  });
});
