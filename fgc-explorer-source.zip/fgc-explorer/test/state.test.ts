import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { initialScenario, Knob, validateConfig } from '../src/model/config';
import { initialState, numberFormat2Ids } from '../src/ui/state';

/*
 * Testing strategy for saved data (src/ui/state.ts)
 *
 * numberFormat2Ids, partition on each knob's id: format-2 id of an initial knob (its number free / taken by another
 * knob), other text (added in the app "k…", own), number (kept); on the knobs: all initial knobs, some deleted, all
 * numeric already (unchanged objects). Order is always kept.
 * initialState with saved data: format 2 (renumbered, message), format 2 already numeric (no message), format 3 (ids
 * kept even if not numbers, no message); the focus mode (saved, invalid or the old true/false: off); the selection is
 * never restored.
 */

const configJson: unknown = JSON.parse(readFileSync(new URL('../data/default-config.json', import.meta.url), 'utf8'));
const config = validateConfig(configJson).value;
const initial = initialScenario(config).knobs;

/** The Bound IDs of the previous version's data/initial-bounds.csv (format 2), in order. */
const FORMAT2_IDS = [
  'seth/cnf-sat',
  '3sum-hypothesis/3sum',
  'apsp-hypothesis/directed-weighted-apsp',
  'apsp-hypothesis/undirected-weighted-apsp',
  'ov-hypothesis/ov',
  'min-weight-k-clique-hypothesis/min-weight-k-clique',
  'min-weight-k-clique-hypothesis/max-weight-k-clique',
  'k-clique-hypothesis/k-clique',
  'combinatorial-bmm-hypothesis/combinatorial-bmm',
  'known-algorithms/cnf-sat',
  'known-algorithms/max-cnf-sat',
  'known-algorithms/ov',
  'known-algorithms/3sum',
  'known-algorithms/directed-weighted-apsp',
  'known-algorithms/undirected-weighted-apsp',
  'known-algorithms/negative-triangle-detection',
  'known-algorithms/exact-triangle',
  'known-algorithms/edge-triangle-detection',
  'known-algorithms/triangle-detection',
  'known-algorithms/combinatorial-bmm',
  'known-algorithms/min-weight-k-clique',
  'known-algorithms/max-weight-k-clique',
  'known-algorithms/k-clique',
  'known-algorithms/edit-distance',
  'known-algorithms/longest-common-subsequence',
  'alman-vassilevska-williams-2026/3sum',
  'alman-vassilevska-williams-2026/real-3sum',
  'alman-vassilevska-williams-2026/directed-weighted-apsp',
  'alman-vassilevska-williams-2026/apsp-on-directed-graphs-with-real-valued-weights',
  'alman-vassilevska-williams-2026/distance-product',
  'alman-vassilevska-williams-2026/exact-triangle',
  'alman-vassilevska-williams-2026/real-exact-triangle',
  'alman-vassilevska-williams-2026/mono-convolution',
];

/** The initial knobs as format 2 saved them, edited a little (exponent, switched on). */
const format2: Knob[] = initial.map((k, i) => ({ ...k, id: FORMAT2_IDS[i]!, enabled: true, ...(k.exponent !== undefined ? { exponent: k.exponent - 0.1 } : {}) }));

describe('numberFormat2Ids', () => {
  it('gives the initial knobs their numbers 1–33 and keeps everything else', () => {
    assert.equal(format2.length, 33);
    const knobs = numberFormat2Ids(format2, config);
    assert.deepEqual(
      knobs.map((k) => k.id),
      initial.map((k) => k.id),
    );
    assert.deepEqual(
      initial.map((k) => k.id),
      Array.from({ length: 33 }, (_, i) => String(i + 1)),
    );
    knobs.forEach((k, i) => assert.deepEqual({ ...k, id: 'same' }, { ...format2[i]!, id: 'same' }));
  });

  it('numbers added and own ids after all numbers, and an initial knob whose number is taken likewise', () => {
    const pick = (id: string): Knob => ({ ...format2[0]!, id });
    const knobs = numberFormat2Ids(
      [
        pick('seth/cnf-sat'),
        pick('apsp-hypothesis/directed-weighted-apsp'),
        pick('kmg3x41'),
        pick('7'),
        pick('my bound'),
        pick('min-weight-k-clique-hypothesis/max-weight-k-clique'),
      ],
      config,
    );
    // Knob 2 was deleted (its number stays free); "7" was imported from a CSV and keeps its number, so the initial
    // knob numbered 7 gets a new one.
    assert.deepEqual(
      knobs.map((k) => k.id),
      ['1', '3', '34', '7', '35', '36'],
    );
  });

  it('leaves numbered knobs as they are', () => {
    const knobs = initial.slice(0, 3);
    const result = numberFormat2Ids(knobs, config);
    assert.ok(result.every((k, i) => k === knobs[i]));
  });
});

describe('initialState with saved data', () => {
  /** Run `body` with `data` saved under the app's localStorage key. */
  function withSaved(data: unknown, body: () => void): void {
    const items = new Map([['fgc-explorer.v1', JSON.stringify(data)]]);
    const fake = {
      getItem: (key: string) => items.get(key) ?? null,
      setItem: (key: string, value: string) => void items.set(key, value),
      removeItem: (key: string) => void items.delete(key),
    };
    const before = Object.getOwnPropertyDescriptor(globalThis, 'localStorage');
    Object.defineProperty(globalThis, 'localStorage', { value: fake, configurable: true, writable: true });
    try {
      body();
    } finally {
      if (before) Object.defineProperty(globalThis, 'localStorage', before);
      else delete (globalThis as { localStorage?: unknown }).localStorage;
    }
  }
  const saved = (format: number, knobs: readonly Knob[]) => ({ format, scenario: { version: 1, constants: {}, knobs, settings: {} } });

  it('renumbers the knobs saved in format 2 and says so', () => {
    withSaved(saved(2, format2.slice(0, 3)), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        ['1', '2', '3'],
      );
      assert.equal(state.scenario.knobs[1]!.exponent, format2[1]!.exponent);
      assert.equal(messages.length, 1);
      assert.equal(messages[0]!.error, false);
      assert.match(messages[0]!.text, /Bound IDs are numbers now/);
    });
  });

  it('says nothing when the format-2 knobs have numbers already', () => {
    withSaved(saved(2, initial.slice(0, 3)), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        ['1', '2', '3'],
      );
      assert.deepEqual(messages, []);
    });
  });

  it('keeps the ids of the current format, numbers or not', () => {
    withSaved(saved(3, format2.slice(0, 2)), () => {
      const { state, messages } = initialState('', configJson);
      assert.deepEqual(
        state.scenario.knobs.map((k) => k.id),
        FORMAT2_IDS.slice(0, 2),
      );
      assert.deepEqual(messages, []);
    });
  });

  it('restores a valid focus mode, and starts with nothing selected', () => {
    for (const [focus, expected] of [
      ['lineage', 'lineage'],
      ['derivations', 'derivations'],
      ['sideways', 'off'],
      [true, 'off'],
    ] as const) {
      withSaved({ format: 3, prefs: { focus } }, () => {
        const { state } = initialState('', configJson);
        assert.equal(state.prefs.focus, expected);
        assert.deepEqual(state.selection, []);
      });
    }
  });
});
