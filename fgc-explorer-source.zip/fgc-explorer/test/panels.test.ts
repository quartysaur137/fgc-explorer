import assert from 'node:assert/strict';
import { clampPanelSize, DEFAULT_PANELS, defaultPanels, validatePanelPrefs } from '../src/ui/panels';

/*
 * Testing strategy for panel sizes
 *
 * clampPanelSize: below the minimum, within range, above what leaves the graph its minimum, no room at all; side and
 *   bottom panels
 * validatePanelPrefs: nothing saved, a complete valid record, partial records, wrong types and non-positive sizes;
 *   window-dependent defaults
 * defaultPanels: laptop, desktop, very small and very large windows
 */

describe('defaultPanels', () => {
  it('matches DEFAULT_PANELS for a 1600 × 1000 window', () => {
    assert.deepEqual(defaultPanels(1600, 1000), DEFAULT_PANELS);
  });

  it('gives smaller windows narrower panels, within limits', () => {
    const laptop = defaultPanels(1280, 760);
    assert.ok(laptop.left.size < DEFAULT_PANELS.left.size && laptop.right.size < DEFAULT_PANELS.right.size);
    assert.ok(laptop.bottom.size < DEFAULT_PANELS.bottom.size);
    assert.deepEqual(defaultPanels(400, 300), { left: { open: true, size: 260 }, right: { open: true, size: 300 }, bottom: { open: true, size: 160 } });
    assert.deepEqual(defaultPanels(4000, 3000), { left: { open: true, size: 340 }, right: { open: true, size: 420 }, bottom: { open: true, size: 300 } });
  });
});

describe('clampPanelSize', () => {
  it('keeps panels between their minimum and what leaves the graph its minimum', () => {
    assert.equal(clampPanelSize('left', 100, 1200), 220);
    assert.equal(clampPanelSize('left', 400, 1200), 400);
    assert.equal(clampPanelSize('left', 1100, 1200), 1200 - 320);
    assert.equal(clampPanelSize('right', 10, 1200), 260);
    assert.equal(clampPanelSize('bottom', 700, 800), 800 - 160);
    assert.equal(clampPanelSize('bottom', 50, 800), 100);
  });

  it('prefers the panel minimum when there is no room', () => {
    assert.equal(clampPanelSize('left', 500, 300), 220);
    assert.equal(clampPanelSize('bottom', 500, 0), 100);
  });

  it('rounds to whole pixels', () => {
    assert.equal(clampPanelSize('left', 333.7, 1200), 334);
  });
});

describe('validatePanelPrefs', () => {
  it('uses the defaults for nothing or garbage', () => {
    assert.deepEqual(validatePanelPrefs(undefined), DEFAULT_PANELS);
    assert.deepEqual(validatePanelPrefs('wide'), DEFAULT_PANELS);
    assert.deepEqual(validatePanelPrefs(null), DEFAULT_PANELS);
  });

  it('fills gaps from the given defaults', () => {
    const d = defaultPanels(1280, 760);
    assert.deepEqual(validatePanelPrefs({ left: { open: false, size: 300 } }, d), { ...d, left: { open: false, size: 300 } });
  });

  it('keeps valid entries and repairs invalid ones', () => {
    const v = validatePanelPrefs({
      left: { open: false, size: 250.4 },
      right: { open: 'yes', size: -5 },
      bottom: { size: 180 },
    });
    assert.deepEqual(v, {
      left: { open: false, size: 250 },
      right: { open: DEFAULT_PANELS.right.open, size: DEFAULT_PANELS.right.size },
      bottom: { open: DEFAULT_PANELS.bottom.open, size: 180 },
    });
  });
});
