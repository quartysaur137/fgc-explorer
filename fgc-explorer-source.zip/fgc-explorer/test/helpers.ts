/** Test helpers: synthetic sheets and scenarios. */

import { Knob, KnobSpec, Scenario, Settings, validateConfig, validateScenario } from '../src/model/config';
import { buildModel, COL, Model } from '../src/model/model';
import { CsvTable } from '../src/util/csv';

export interface RowSpec {
  id: string;
  /** "Family / Variation" */
  from: string;
  to: string;
  toTime: string;
  fromTime: string;
  rt?: string;
  randomized?: string;
}

const HEADER = [COL.fromFamily, COL.fromVariation, COL.toFamily, COL.toVariation, COL.id, COL.randomized, COL.toTime, COL.fromTime, COL.rt];

/** A sheet with the given rows (cells are taken verbatim). */
export function sheet(rows: readonly RowSpec[]): CsvTable {
  const split = (p: string): [string, string] => {
    const i = p.indexOf(' / ');
    return i < 0 ? [p, p] : [p.slice(0, i), p.slice(i + 3)];
  };
  return new CsvTable(
    HEADER,
    rows.map((r) => [...split(r.from), ...split(r.to), r.id, r.randomized ?? '', r.toTime, r.fromTime, r.rt ?? '$O(n)$']),
  );
}

/** Build a model from rows and a (JSON) config; fails the test if the config does not validate. */
export function model(rows: readonly RowSpec[], config: object = {}): Model {
  const v = validateConfig({ version: 1, ...config });
  if (v.errors.length > 0) throw new Error(`config errors: ${v.errors.join('; ')}`);
  return buildModel(sheet(rows), v.value);
}

/** A scenario with the given knobs (ids k1, k2, ...) and settings. */
export function scenario(knobs: readonly KnobSpec[], settings: Partial<Settings> = {}, constants: Record<string, number> = {}): Scenario {
  const v = validateScenario({
    version: 1,
    constants,
    knobs: knobs.map((k, i): Knob => ({ ...k, id: `k${i + 1}`, enabled: true })),
    settings,
  });
  if (v.errors.length > 0) throw new Error(`scenario errors: ${v.errors.join('; ')}`);
  return v.value;
}

/** Approximate equality for exponents. */
export function near(actual: number | undefined, expected: number, tol = 1e-6): boolean {
  return actual !== undefined && Math.abs(actual - expected) <= tol;
}
