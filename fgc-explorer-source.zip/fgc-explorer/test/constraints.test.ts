import assert from 'node:assert/strict';
import { analyze, clippedRegimes, regimesFromSpec } from '../src/engine/analysis';
import * as G from '../src/growth/growth';
import { validateConfig } from '../src/model/config';
import { clipToLimits, ConstraintError, constraintTex, parseConstraint } from '../src/model/constraints';
import { parseRegimeSpec, Regime } from '../src/model/regime';
import { model, near, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for the limits of parameters (src/model/constraints.ts, and their use in regimes and the engine)
 *
 * parseConstraint, partition on: operator (<=, ≤); right side (one parameter, a power: ^2, ^{1/2}, ^(3/2), ^1.5; a
 *   product with * or spaces; a sum; a constant factor; a constant alone); a reason after ":" (none, given); errors (no
 *   operator, unknown parameter on either side, a parameter bounded by itself, a bad power, an empty limit)
 * clipToLimits, partition on: no limits (copy); a limit that holds (unchanged: smaller polynomial, constant, polylog);
 *   one that clips a polynomial (to a polynomial, to a polylogarithm when the limit is one); several in a chain (m ≤ n·α
 *   then t ≤ m·α; α ≤ √m), a sum (the largest term)
 * constraintTex: powers, products, sums, factors
 * Regime.normalize / regimesFromSpec with limits: clipped key, normalizer kept, all clipped to nothing (degenerate);
 *   clippedRegimes (a spec that the limits clip, one they do not, an invalid one)
 * model: limits of the config on the problem (also of non-log-dependent parameters only), bad ones ignored with a
 *   diagnostic; config validation (not a string array)
 * engine: a reduction claiming instances beyond a limit gives its bound at the clipped regime; two such regimes that
 *   clip to one regime give one fact (the better bound)
 */

const P = ['n', 'm', 'alpha', 't'];
const lim = (text: string) => parseConstraint(text, P);
const exps = (gs: readonly G.Growth[]) => gs.map((g) => (g.kind === 'poly' ? g.exp : g.kind));

describe('parseConstraint', () => {
  it('reads a parameter bounded by a sum of products of powers', () => {
    const c = lim('t <= m*alpha: a graph has O(m·α) triangles');
    assert.deepEqual([c.param, c.text, c.reason], ['t', 't <= m*alpha', 'a graph has O(m·α) triangles']);
    assert.deepEqual(c.terms, [{ factor: 1, powers: [['m', 1], ['alpha', 1]] }]);
    assert.deepEqual(lim('alpha ≤ m^{1/2}').terms[0]!.powers, [['m', 0.5]]);
    assert.deepEqual(lim('alpha <= m^(1/2)').terms[0]!.powers, [['m', 0.5]]);
    assert.deepEqual(lim('t <= m^1.5').terms[0]!.powers, [['m', 1.5]]);
    assert.deepEqual(lim('m <= n alpha').terms[0]!.powers, [['n', 1], ['alpha', 1]]);
    assert.deepEqual(lim('t <= n^2 + m').terms, [
      { factor: 1, powers: [['n', 2]] },
      { factor: 1, powers: [['m', 1]] },
    ]);
    assert.deepEqual(lim('m <= 2*n^2').terms, [{ factor: 2, powers: [['n', 2]] }]);
    assert.deepEqual(lim('alpha <= 10').terms, [{ factor: 10, powers: [] }]);
    assert.equal(lim('m <= n^2').reason, null);
  });

  it('rejects malformed limits', () => {
    for (const bad of ['m = n^2', 'x <= n', 'm <= x', 'm <= m^{1/2}', 'm <= n^{-1}', 'm <= n^a', 'm <=', 'm <= n +']) {
      assert.throws(() => lim(bad), ConstraintError, bad);
    }
  });
});

describe('clipToLimits', () => {
  const tl = ['m <= n^2', 'alpha <= m^{1/2}', 'm <= n*alpha', 't <= m*alpha'].map(lim);
  const clip = (growths: G.Growth[], limits = tl) => clipToLimits(P, growths, limits);

  it('changes nothing without limits, or where they hold', () => {
    const gs = [G.poly(1), G.poly(1.5), G.poly(0.5), G.poly(1.5)];
    assert.deepEqual(clip(gs, []), gs);
    assert.deepEqual(clip(gs), gs);
    assert.deepEqual(clip([G.poly(1), G.poly(1), G.constant(3), G.POLYLOG]), [G.poly(1), G.poly(1), G.constant(3), G.POLYLOG]);
  });

  it('lowers a parameter to its limit, and those whose limits that lowers', () => {
    // Triangle Listing with m = n^{1.5}: an arboricity above √m = n^{0.75}, and more than m·α triangles, cannot be.
    assert.deepEqual(exps(clip([G.poly(1), G.poly(1.5), G.poly(1), G.poly(3.5)])), [1, 1.5, 0.75, 2.25]);
    // m ≤ n·α lowers m, which lowers the limit of t.
    assert.deepEqual(exps(clip([G.poly(1), G.poly(2), G.poly(0.25), G.poly(3)])), [1, 1.25, 0.25, 1.5]);
    // A graph on polylogarithmically many vertices has polylogarithmically many edges.
    assert.deepEqual(exps(clip([G.POLYLOG, G.poly(1), G.poly(0.5), G.poly(1)])).slice(0, 2), ['log', 'log']);
  });

  it('takes the largest term of a sum', () => {
    const s = parseConstraint('sigma <= n + m', ['n', 'm', 'sigma']);
    assert.deepEqual(exps(clipToLimits(['n', 'm', 'sigma'], [G.poly(1), G.poly(2), G.poly(3)], [s])), [1, 2, 2]);
  });

  it('reaches the fixed point of cyclic limits without a fixed cap', () => {
    // m ≤ n·α and α ≤ √m alone: m = 4, α = 2 approaches m = 2, α = 1 geometrically.
    const cyclic = ['m <= n*alpha', 'alpha <= m^{1/2}'].map(lim);
    const [, m, a] = exps(clip([G.poly(1), G.poly(4), G.poly(2), G.poly(1)], cyclic)) as number[];
    assert.ok(near(m, 2, 1e-12) && near(a, 1, 1e-12), `${m} ${a}`);
  });
});

describe('constraintTex', () => {
  it('writes powers, products, sums and factors', () => {
    assert.equal(constraintTex(lim('alpha <= m^{1/2}')), '\\alpha \\le m^{1/2}');
    assert.equal(constraintTex(lim('t <= m*alpha')), 't \\le m \\cdot \\alpha');
    assert.equal(constraintTex(lim('t <= 2*n^3 + m^1.5')), 't \\le 2 \\cdot n^{3} + m^{3/2}');
  });
});

describe('limits in regimes and the model', () => {
  const TL = 'G / TL';
  const S = 'G / S';
  const rows: RowSpec[] = [
    // S's instances of size n become graphs on n vertices with n^{1.5} edges, arboricity n and n^{2.5+r} triangles (r
    // free): the arboricity and the triangles exceed what such graphs can have.
    { id: 'st', from: S, to: TL, toTime: '$T(n, m, \\alpha, t)$', fromTime: '$O(T(n, n^{1.5}, n, n^{2.5+r}))$', rt: '$O(n)$' },
  ];
  const limits = ['m <= n^2: a simple graph', 'alpha <= m^{1/2}', 'm <= n*alpha', 't <= m*alpha'];
  const cfg = {
    problems: { [TL]: { regimes: ['n=1, m=1.5, alpha=0.5, t=1.5'], constraints: [...limits, 'M <= n', 'q <= n'] }, [S]: { params: ['n'] } },
    rows: { st: { free: [{ name: 'r', type: 'real', min: 0, max: 1 }] } },
  };
  const m = model(rows, cfg);
  const tl = m.problems.get(TL)!;

  it('keeps the valid limits of a problem and reports the others', () => {
    assert.deepEqual(
      tl.constraints.map((c) => c.text),
      ['m <= n^2', 'alpha <= m^{1/2}', 'm <= n*alpha', 't <= m*alpha'],
    );
    assert.equal(tl.constraints[0]!.reason, 'a simple graph');
    const issues = m.diagnostics.filter((d) => d.problemId === TL && /limit/.test(d.message));
    assert.equal(issues.length, 2, JSON.stringify(issues));
    assert.equal(validateConfig({ version: 1, problems: { [TL]: { constraints: 'm <= n^2' } } }).errors.length, 1);
  });

  it('clips regimes made from specs, keeping their normalizer', () => {
    const [r] = regimesFromSpec(tl, 'n=1, m=1.5, alpha=1, t=4');
    assert.equal(r!.key, 'n=p1|m=p1.5|alpha=p0.75|t=p2.25');
    assert.equal(regimesFromSpec(tl, 'n=1, m=1.5, alpha=1, t=4', false)[0]!.key, 'n=p1|m=p1.5|alpha=p1|t=p4');
    assert.deepEqual(
      clippedRegimes(tl, 'n=1, m=1.5, alpha=1, t=4').map((x) => x.key),
      ['n=p1|m=p1.5|alpha=p0.75|t=p2.25'],
    );
    assert.deepEqual(clippedRegimes(tl, 'n=1, m=1.5, alpha=0.5, t=1.5'), []);
    assert.deepEqual(clippedRegimes(tl, 'n=1, x=2'), [], 'invalid');
    // (all clipped to polylogarithms: no growing parameter)
    const n = Regime.normalize(tl.params, [G.POLYLOG, G.poly(1), G.poly(1), G.poly(1)], tl.logParams, tl.constraints);
    assert.equal(n.kind, 'degenerate');
  });

  it('rejects a spec whose measuring parameter the limits clip (its exponents would be read against another scale)', () => {
    // m grows while n is polylogarithmic: m ≤ n² clips m too, leaving no growing parameter.
    assert.throws(() => regimesFromSpec(tl, 'n=polylog, m=1, alpha=0.5, t=1'), /m cannot grow so fast/);
    assert.doesNotThrow(() => regimesFromSpec(tl, 'n=polylog, m=1, alpha=0.5, t=1', false));
    assert.deepEqual(clippedRegimes(tl, 'n=polylog, m=1, alpha=0.5, t=1'), []);
  });

  it('matches the regime filter of a formula knob also where the limits clip the sizes it names', () => {
    const filter = (spec: string) => new Map([...parseRegimeSpec(spec)]);
    const [r] = regimesFromSpec(tl, 'n=1, m=1.5, alpha=1, t=1'); // α clipped to n^{0.75}
    assert.ok(!r!.satisfies(filter('alpha=1')));
    assert.ok(r!.satisfiesClipped(filter('alpha=1'), tl.constraints));
    assert.ok(r!.satisfiesClipped(filter('alpha=0.75'), tl.constraints));
    assert.ok(!r!.satisfiesClipped(filter('alpha=0.5'), tl.constraints), 'a smaller arboricity is other instances');
    assert.ok(!r!.satisfiesClipped(filter('alpha=1, m=2'), tl.constraints), 'm = n^2 is not this regime');
    // A formula knob for α = n applies there.
    const a = analyze(m, scenario([{ problem: TL, kind: 'UB', regime: 'alpha=1', formula: 'n^{1.1}' }]), new Map([[TL, ['n=1, m=1.5, alpha=1, t=1']]]));
    const s = a.summaries.get(TL)!.regimes.find((x) => x.regime.key === r!.key)!;
    assert.ok(near(s.ub!.exponent, 1.1), String(s.ub?.exponent));
  });

  it('derives bounds at the clipped regime of the instances a reduction claims', () => {
    const a = analyze(m, scenario([{ problem: S, kind: 'LB', regime: 'n=1', exponent: 3 }], { gridPoints: 5 }));
    const facts = a.lower.facts.get(TL)!;
    // Every r gives the same clipped regime (α = n^{0.75}, t = m·α = n^{2.25}), so one fact.
    assert.deepEqual([...facts.keys()], ['n=p1|m=p1.5|alpha=p0.75|t=p2.25']);
    assert.ok(near(facts.get('n=p1|m=p1.5|alpha=p0.75|t=p2.25')!.exponent, 3));
    const summary = a.summaries.get(TL)!;
    for (const s of summary.regimes) {
      const e = Object.fromEntries(s.regime.params.map((p, i) => [p, G.exponentOf(s.regime.growths[i]!)]));
      assert.ok(e['alpha']! <= e['m']! / 2 + 2e-6 && e['t']! <= e['m']! + e['alpha']! + 2e-6, s.regime.key);
    }
  });
});
