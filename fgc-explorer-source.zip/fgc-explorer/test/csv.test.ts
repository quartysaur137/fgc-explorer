import assert from 'node:assert/strict';
import { CsvTable, parseCsv, serializeCsv } from '../src/util/csv';

/*
 * Testing strategy for parseCsv / serializeCsv / CsvTable
 *
 * parseCsv(text):
 *   partition on line endings: LF, CRLF, CR, mixed
 *   partition on quoting: no quotes, quoted field with comma / quote ("") / newline, quote inside unquoted field,
 *     unterminated quote
 *   partition on ends: empty input, trailing newline, no trailing newline, leading BOM
 *   partition on fields: empty fields, empty last field, ragged rows
 * serializeCsv(records): round trip for fields needing quotes and not; eol choice
 * CsvTable: get by column name (present / missing column), short rows, header trimming, blank rows dropped, toText
 */

describe('parseCsv', () => {
  it('parses LF and CRLF records', () => {
    assert.deepEqual(parseCsv('a,b\n1,2\n').records, [
      ['a', 'b'],
      ['1', '2'],
    ]);
    assert.deepEqual(parseCsv('a,b\r\n1,2').records, [
      ['a', 'b'],
      ['1', '2'],
    ]);
    assert.deepEqual(parseCsv('a\rb').records, [['a'], ['b']]);
    assert.deepEqual(parseCsv('a\r\nb\nc').records, [['a'], ['b'], ['c']]);
  });

  it('handles quoted commas, escaped quotes and embedded newlines', () => {
    const { records, warnings } = parseCsv('"x, y","say ""hi""","line1\nline2"\r\nz,,""');
    assert.deepEqual(records, [
      ['x, y', 'say "hi"', 'line1\nline2'],
      ['z', '', ''],
    ]);
    assert.deepEqual(warnings, []);
  });

  it('keeps quotes inside unquoted fields and warns about unterminated quotes', () => {
    assert.deepEqual(parseCsv('a"b,c').records, [['a"b', 'c']]);
    const r = parseCsv('"abc,d\n');
    assert.equal(r.records.length, 1);
    assert.match(r.warnings[0]!, /unterminated/);
  });

  it('handles empty input, BOM, empty last field and ragged rows', () => {
    assert.deepEqual(parseCsv('').records, []);
    assert.deepEqual(parseCsv('﻿a,b').records, [['a', 'b']]);
    assert.deepEqual(parseCsv('a,\n').records, [['a', '']]);
    assert.deepEqual(parseCsv('a,b,c\n1\n').records, [['a', 'b', 'c'], ['1']]);
  });
});

describe('serializeCsv', () => {
  it('round-trips fields that need quoting', () => {
    const recs = [
      ['plain', 'with,comma', 'with "quote"', 'multi\nline', ''],
      ['$T(n, m)$', ' spaced ', 'x'],
    ];
    assert.deepEqual(parseCsv(serializeCsv(recs)).records, recs);
    assert.deepEqual(parseCsv(serializeCsv(recs, '\n')).records, recs);
    assert.equal(serializeCsv([['a', 'b']]), 'a,b');
  });
});

describe('CsvTable', () => {
  const text = ' Name ,Value\r\nx,1\r\n,\r\ny\r\n';
  const { table } = CsvTable.fromText(text);

  it('trims headers and drops blank rows', () => {
    assert.deepEqual(table.columns, ['Name', 'Value']);
    assert.equal(table.rowCount, 2);
  });

  it('gets cells by column name, with "" for short rows and missing columns', () => {
    assert.equal(table.get(0, 'Value'), '1');
    assert.equal(table.get(1, 'Value'), '');
    assert.equal(table.get(0, 'Missing'), '');
    assert.equal(table.hasColumn('Missing'), false);
    assert.throws(() => table.get(5, 'Name'), RangeError);
  });

  it('serializes back to text', () => {
    assert.equal(table.toText('\n'), 'Name,Value\nx,1\ny');
  });

  it('edits cells and appends rows without mutating the original', () => {
    const t2 = table.withCell(1, 'Value', '7').withCell(0, 'Extra', 'e');
    assert.equal(t2.get(1, 'Value'), '7');
    assert.equal(t2.get(0, 'Extra'), 'e');
    assert.equal(t2.get(1, 'Extra'), '');
    assert.equal(table.get(1, 'Value'), '');
    assert.equal(table.hasColumn('Extra'), false);
    const t3 = table.withRow({ Name: 'z', New: 'n' });
    assert.equal(t3.rowCount, 3);
    assert.deepEqual(t3.columns, ['Name', 'Value', 'New']);
    assert.equal(t3.get(2, 'New'), 'n');
    assert.throws(() => table.withCell(9, 'Name', 'x'), RangeError);
  });
});
