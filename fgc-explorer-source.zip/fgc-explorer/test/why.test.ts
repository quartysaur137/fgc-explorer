import assert from 'node:assert/strict';
import { analyze, rowUsable } from '../src/engine/analysis';
import { explainLower, LBRowVerdict } from '../src/engine/lower';
import { constantEnv } from '../src/engine/rowEval';
import { UBRowVerdict } from '../src/engine/upper';
import { model, near, RowSpec, scenario } from './helpers';

/*
 * Testing strategy for the explanations of what each reduction does for a bound (UpperBounds.explain, explainLower)
 *
 * upper bound of P at a regime, per reduction from P: gives the bound (used), gives a worse one (weaker), cannot beat
 *   it even with free calls (skipped), a call without bound (searched: no-call-bound; beyond the detour limit: not
 *   searched), restriction not met (not applicable), switched off (unusable)
 * lower bound of T at a regime, per reduction into T: gives the bound (used), a smaller one (weaker), source without
 *   lower bound, bounds only at other regimes of T (elsewhere), nothing (fails, with the reason: too slow), switched off
 */

const [P, Q, R, S, U, V, X, Y] = ['G / P', 'G / Q', 'G / R', 'G / S', 'G / U', 'G / V', 'G / X', 'G / Y'];
const [T, S1, S2, S3, S4] = ['H / T', 'H / S1', 'H / S2', 'H / S3', 'H / S4'];

const rows: RowSpec[] = [
  { id: 'u1', from: P, to: Q, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: 'u2', from: P, to: R, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  // (calls S at a regime that is not listed, so that its bound is not known)
  { id: 'u3', from: P, to: S, toTime: '$T(n, m)$', fromTime: '$O(n^3 \\cdot T(n, n^2))$' },
  { id: 'u4', from: P, to: U, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: 'u5', from: P, to: V, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
  { id: 'u6', from: P, to: X, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: 'u7', from: P, to: Y, toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: 'l1', from: S1, to: T, toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$' },
  { id: 'l2', from: S2, to: T, toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$' },
  { id: 'l3', from: S3, to: T, toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$' },
  { id: 'l4', from: S1, to: T, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
  { id: 'l5', from: S4, to: T, toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$', rt: '$O(n^3)$' },
  { id: 'l6', from: S1, to: T, toTime: '$T(n, m)$', fromTime: '$O(T(n, n))$' },
];
const n = { params: ['n'] };
const cfg = { problems: { [P]: { params: ['n', 'm'] }, [S1]: n, [S2]: n, [S3]: n, [S4]: n }, rows: { u6: { requires: 'm=2' } } };
const m = model(rows, cfg);
const sc = scenario(
  [
    { problem: Q, kind: 'UB', regime: 'n=1', exponent: 2 },
    { problem: R, kind: 'UB', regime: 'n=1', exponent: 3 },
    { problem: S, kind: 'UB', formula: 'n' },
    { problem: S1, kind: 'LB', regime: 'n=1', exponent: 2 },
    { problem: S2, kind: 'LB', regime: 'n=1', exponent: 1.5 },
    { problem: S4, kind: 'LB', regime: 'n=1', exponent: 2 },
  ],
  { maxDepthUB: 0, disabledRows: ['u7', 'l6'] },
);
const a = analyze(m, sc);

describe('UpperBounds.explain', () => {
  const p = a.summaries.get(P)!.primary!;
  const verdicts = new Map(a.upperOverlay.explain(P, p.regime).map((x) => [x.row.id, x.verdict]));
  const kind = (id: string): UBRowVerdict['kind'] | undefined => verdicts.get(id)?.kind;

  it('lists every reduction from the problem, in sheet order', () => {
    assert.deepEqual([...verdicts.keys()], ['u1', 'u2', 'u3', 'u4', 'u5', 'u6', 'u7']);
  });

  it('names the reduction that gives the bound and the bounds the others give', () => {
    assert.ok(near(p.ub!.exponent, 2));
    assert.equal(kind('u1'), 'used');
    const u2 = verdicts.get('u2')!;
    assert.ok(u2.kind === 'weaker' && near(u2.fact.exponent, 3));
  });

  it('says when a reduction cannot help even with free calls', () => {
    const u3 = verdicts.get('u3')!;
    assert.ok(u3.kind === 'skipped' && near(u3.optimistic.exponent, 3) && u3.optimistic.power === 1);
  });

  it('names a call without upper bound, and whether the search went there', () => {
    const u4 = verdicts.get('u4')!;
    assert.ok(u4.kind === 'no-call-bound' && u4.target === U && u4.searched);
    const u5 = verdicts.get('u5')!;
    assert.ok(u5.kind === 'no-call-bound' && u5.target === V && !u5.searched && u5.regime.key === 'n=p1|m=p2');
  });

  it('says when the search stopped too early to find a bound for a call', () => {
    // P → X(n, n^2) → Y(n, n^3) → V(n, n^4) → U(n, n^5) → Z (knob): with the default 3 detours, the search stops at U.
    const [P2, X2, Y2, V2, U2, Z2] = ['K / P', 'K / X', 'K / Y', 'K / V', 'K / U', 'K / Z'];
    const chain: RowSpec[] = [
      { id: 'px', from: P2, to: X2, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$' },
      { id: 'xy', from: X2, to: Y2, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' },
      { id: 'yv', from: Y2, to: V2, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' },
      { id: 'vu', from: V2, to: U2, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' },
      { id: 'uz', from: U2, to: Z2, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$' },
    ];
    const mc = model(chain, { problems: { [P2]: { params: ['n'] } } });
    const ac = analyze(mc, scenario([{ problem: Z2, kind: 'UB', formula: 'n m' }]));
    const pp = ac.summaries.get(P2)!.primary!;
    assert.equal(pp.ub, null);
    const v = ac.upperOverlay.explain(P2, pp.regime)[0]!.verdict;
    assert.ok(v.kind === 'no-call-bound' && v.target === X2 && !v.searched, JSON.stringify(v));
    // Asked for at its own regime, X has a bound (the search starts there).
    assert.ok(near(ac.upperOverlay.query(X2, v.regime)?.exponent, 7));
  });

  it('says the search stopped too early also when the call is read during its own search (a cycle)', () => {
    // maxDepthUB = 1. A (listed) → B(n, n^2) → A, and A → C(n, n^3) → D(n, n^4) (budget 0) → E (knob).
    const [A6, B6, C6, D6, E6] = ['M / A', 'M / B', 'M / C', 'M / D', 'M / E'];
    const r: RowSpec[] = [
      { id: 'ab', from: A6, to: B6, toTime: '$T(n, m)$', fromTime: '$O(T(n, n^2))$', rt: '$O(1)$' },
      { id: 'ac', from: A6, to: C6, toTime: '$T(n, m)$', fromTime: '$O(n^{0.5} T(n, n^3))$', rt: '$O(1)$' },
      { id: 'ba', from: B6, to: A6, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$O(1)$' },
      { id: 'cd', from: C6, to: D6, toTime: '$T(n, m)$', fromTime: '$O(T(n, n m))$', rt: '$O(1)$' },
      { id: 'de', from: D6, to: E6, toTime: '$T(n, m)$', fromTime: '$O(T(n, m))$', rt: '$O(1)$' },
    ];
    const m6 = model(r, { problems: { [A6]: { params: ['n'] } } });
    const a6 = analyze(m6, scenario([{ problem: E6, kind: 'UB', formula: 'n m' }], { maxDepthUB: 1 }));
    const pa = a6.summaries.get(A6)!.primary!;
    for (const { verdict: v } of a6.upperOverlay.explain(A6, pa.regime)) assert.ok(v.kind === 'no-call-bound' && !v.searched, JSON.stringify(v));
  });

  it('gives the reason for reductions that do not apply or are not used', () => {
    const u6 = verdicts.get('u6')!;
    assert.ok(u6.kind === 'not-applicable' && /m=2/.test(u6.reason), JSON.stringify(u6));
    assert.equal(kind('u7'), 'unusable');
  });
});

describe('explainLower', () => {
  const t = a.summaries.get(T)!.regimes.find((r) => r.regime.key === 'n=p1|m=p1')!;
  const opts = { settings: sc.settings, constants: constantEnv(m, sc.constants), usable: (r: (typeof m.rows)[number]) => rowUsable(r, sc) };
  const verdicts = new Map(explainLower(m, a.lower, T, t.regime, opts).map((x) => [x.row.id, x.verdict]));
  const kind = (id: string): LBRowVerdict['kind'] | undefined => verdicts.get(id)?.kind;

  it('lists every reduction into the problem, in sheet order', () => {
    assert.deepEqual([...verdicts.keys()], ['l1', 'l2', 'l3', 'l4', 'l5', 'l6']);
  });

  it('names the reduction that gives the bound and the bounds the others give', () => {
    assert.ok(near(t.lb!.exponent, 2));
    assert.equal(kind('l1'), 'used');
    const l2 = verdicts.get('l2')!;
    assert.ok(l2.kind === 'weaker' && near(l2.fact.exponent, 1.5));
  });

  it('says when the source has no lower bound, or when its bounds lead to other regimes', () => {
    assert.equal(kind('l3'), 'no-source-bound');
    const l4 = verdicts.get('l4')!;
    assert.ok(l4.kind === 'elsewhere' && l4.regimes.map((r) => r.key).join() === 'n=p1|m=p2');
  });

  it('names the source bound for which the reason holds', () => {
    // S → T applies only where m = n^2 (S ≥ 2 there; S ≥ 3 at m = n, where it does not apply): too slow at m = n^2.
    const [S5, T5] = ['J / S', 'J / T'];
    const r: RowSpec[] = [{ id: 'st', from: S5, to: T5, toTime: '$T(n)$', fromTime: '$O(T(n))$', rt: '$O(m^{1.5})$' }];
    const mm = model(r, { problems: { [S5]: { params: ['n', 'm'] } }, rows: { st: { requires: 'm=2' } } });
    const ss = scenario([
      { problem: S5, kind: 'LB', regime: 'n=1, m=1', exponent: 3 },
      { problem: S5, kind: 'LB', regime: 'n=1, m=2', exponent: 2 },
      { problem: T5, kind: 'LB', regime: 'n=1', exponent: 1 },
    ]);
    const aa = analyze(mm, ss);
    const o = { settings: ss.settings, constants: constantEnv(mm, {}), usable: (x: (typeof mm.rows)[number]) => rowUsable(x, ss) };
    const v = explainLower(mm, aa.lower, T5, aa.summaries.get(T5)!.primary!.regime, o)[0]!.verdict;
    assert.ok(v.kind === 'fails' && /takes time n\^3, not less than the lower bound n\^2 /.test(v.reason) && v.from.regime.key === 'n=p1|m=p2', JSON.stringify(v));
  });

  it('gives the reason a reduction derives nothing, and reductions not used', () => {
    const l5 = verdicts.get('l5')!;
    assert.ok(l5.kind === 'fails' && /reduction itself takes time n\^3/.test(l5.reason) && l5.from.problem === S4, JSON.stringify(l5));
    assert.equal(kind('l6'), 'unusable');
  });
});
