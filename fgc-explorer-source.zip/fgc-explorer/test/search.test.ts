import assert from 'node:assert/strict';
import { Knob } from '../src/model/config';
import { bestProblem, knobMatches, matchRanges, NO_SEARCH, problemMatches, reductionOf, search, searchQuery } from '../src/ui/search';
import { model as makeModel } from './helpers';

/*
 * Testing strategy for the search (the left panel's filter and marks are covered by the e2e test)
 *
 * searchQuery: spaces around, upper case, blank
 * problemMatches, partition on where the text is: the sheet's name (family or variation), the name as shown (TeX as
 *   plain text), nowhere; case; empty query
 * knobMatches, partition on: Bound ID (equal in any case, a prefix of it, longer), note (contains, does not), running
 *   time formula (contains), knob without note or formula; empty query
 * search, partition on: query (empty or blank, a problem name, a Bound ID, a word of notes); problems found by name,
 *   through a bound (a knob naming its problem differently), both, problems not in the sheet (named by a box or by a
 *   knob); exact (none, one)
 * bestProblem, partition on how the best problem is found: its name shown equal to the query (before a family equal),
 *   having it as a whole word (before a part of a word, also a first box), its family equal or having it as a word, a
 *   name containing it (the first box, else the first in the sheet), through a bound only (after any name); nothing
 *   found; no search
 * reductionOf: R<n> of the model (case, leading zeros, spaces), R<n> not in the model, a bare number, other text, empty
 * matchRanges: no occurrence, one, several, overlapping occurrences, case, empty query
 */

const m = makeModel([
  { id: 'R1', from: '3SUM / 3SUM', to: 'Geometry / GeomBase', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  { id: 'R2', from: '$k$-Clique / Triangle Detection', to: 'APSP / Negative Triangle', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
]);

const knob = (id: string, problem: string, extra: Partial<Knob> = {}): Knob => ({ id, problem, kind: 'UB', regime: 'n=1', exponent: 2, enabled: true, ...extra });

describe('searchQuery', () => {
  it('trims and lower-cases', () => {
    assert.equal(searchQuery('  U12 '), 'u12');
    assert.equal(searchQuery('APSP'), 'apsp');
    assert.equal(searchQuery(' \t '), '');
  });
});

describe('problemMatches', () => {
  const p = (id: string) => m.problems.get(id)!;

  it("finds a problem by its family or variation, as in the sheet or as shown, in any case", () => {
    assert.ok(problemMatches(p('Geometry / GeomBase'), 'geombase'));
    assert.ok(problemMatches(p('Geometry / GeomBase'), 'geometry'));
    assert.ok(problemMatches(p('Geometry / GeomBase'), 'try / geom'), 'across the separator of the sheet name');
    assert.ok(problemMatches(p('$k$-Clique / Triangle Detection'), 'k-clique'), 'TeX as plain text');
    assert.ok(problemMatches(p('$k$-Clique / Triangle Detection'), '$k$'), 'TeX as in the sheet');
  });

  it('does not find a problem by other text, or by the empty query', () => {
    assert.ok(!problemMatches(p('3SUM / 3SUM'), 'apsp'));
    assert.ok(!problemMatches(p('3SUM / 3SUM'), ''));
  });
});

describe('knobMatches', () => {
  it('finds a bound by its whole Bound ID in any case, not by a part of it', () => {
    const k = knob('U12', 'A');
    assert.ok(knobMatches(k, 'u12'));
    assert.ok(knobMatches(knob('L3', 'A'), 'l3'));
    assert.ok(!knobMatches(k, 'u1'), 'a prefix');
    assert.ok(!knobMatches(k, 'u123'));
  });

  it('finds a bound by a part of its note or running time', () => {
    const k = knob('U5', 'A', { exponent: undefined, formula: 'n^{\\omega}', note: 'Williams 2014; see also Chan' });
    assert.ok(knobMatches(k, 'williams'));
    assert.ok(knobMatches(k, 'chan'));
    assert.ok(knobMatches(k, '\\omega'));
    assert.ok(!knobMatches(k, 'dijkstra'));
    assert.ok(!knobMatches(knob('U6', 'A'), 'williams'), 'no note or formula');
    assert.ok(!knobMatches(k, ''));
  });
});

describe('search', () => {
  const knobs = [
    knob('L1', '3sum  /  3SUM', { kind: 'LB', note: '3SUM hypothesis' }),
    knob('U2', 'Geometry / GeomBase', { note: 'trivial: all triples' }),
    knob('U12', 'APSP / Negative Triangle', { note: 'Williams 2014' }),
    knob('U13', 'Elsewhere / Unknown', { note: 'not in the sheet' }),
  ];

  it('finds nothing without a query', () => {
    assert.equal(search('', m, knobs), NO_SEARCH);
    assert.equal(search('   ', m, knobs).query, '');
    assert.equal(NO_SEARCH.problems.size + NO_SEARCH.knobs.size, 0);
  });

  it('finds problems by name and through their bounds (under their box keys)', () => {
    const r = search('3sum', m, knobs);
    assert.deepEqual([...r.problems].sort(), ['3SUM / 3SUM']);
    assert.deepEqual([...r.knobs], ['L1'], 'the note mentions 3SUM');
    assert.equal(r.exact, null);
    const w = search('Williams', m, knobs);
    assert.deepEqual([...w.problems], ['APSP / Negative Triangle']);
    assert.deepEqual([...w.knobs], ['U12']);
    const t = search('tri', m, knobs);
    assert.deepEqual(
      [...t.problems].sort(),
      ['$k$-Clique / Triangle Detection', 'APSP / Negative Triangle', 'Geometry / GeomBase'],
      'by name (both triangle problems) and by a note (GeomBase: "all triples")',
    );
  });

  it('goes to the bound with the Bound ID searched for', () => {
    const r = search(' u12 ', m, knobs);
    assert.deepEqual(r.exact, { id: 'U12', problem: 'APSP / Negative Triangle' });
    assert.deepEqual([...r.knobs], ['U12']);
    assert.deepEqual([...r.problems], ['APSP / Negative Triangle']);
    assert.deepEqual(search('l1', m, knobs).exact, { id: 'L1', problem: '3SUM / 3SUM' }, 'a knob naming its problem differently');
    assert.equal(search('u1', m, knobs).exact, null);
  });

  it('finds problems that are not in the sheet by the name given', () => {
    assert.deepEqual([...search('unknown', m, knobs).problems], ['Elsewhere / Unknown']);
    assert.deepEqual([...search('U13', m, knobs).problems], ['Elsewhere / Unknown']);
    assert.deepEqual([...search('nowhere', m, knobs, ['Nowhere  /  Empty']).problems], ['Nowhere / Empty'], 'a box without bounds');
    assert.deepEqual([...search('nowhere', m, knobs).problems], []);
  });
});

describe('reductionOf', () => {
  it('names a reduction of the model written as R<n> (any case, leading zeros, spaces around)', () => {
    assert.equal(reductionOf('R2', m), 'R2');
    assert.equal(reductionOf(' r02 ', m), 'R2');
    assert.equal(reductionOf('R9', m), null, 'not in the model');
    assert.equal(reductionOf('2', m), null, 'a bare number');
    assert.equal(reductionOf('R2 x', m), null);
    assert.equal(reductionOf('', m), null);
  });
});

describe('matchRanges', () => {
  it('lists the occurrences of the query, in any case, without overlaps', () => {
    assert.deepEqual(matchRanges('Negative Triangle', 'tri'), [[9, 12]]);
    assert.deepEqual(matchRanges('APSP and apsp', 'apsp'), [
      [0, 4],
      [9, 13],
    ]);
    assert.deepEqual(matchRanges('aaaa', 'aa'), [
      [0, 2],
      [2, 4],
    ]);
    assert.deepEqual(matchRanges('aaa', 'aa'), [[0, 2]]);
    assert.deepEqual(matchRanges('3SUM', 'apsp'), []);
    assert.deepEqual(matchRanges('3SUM', ''), []);
  });
});

describe('bestProblem', () => {
  // Problems named alike in families named alike: Enter picks the name the query matches best.
  const names = makeModel([
    { id: 'R1', from: 'Cliques / Triangles Listing', to: 'APSP / APSP', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: 'R2', from: 'APSP / Negative Triangle', to: 'APSP / APSP', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: 'R3', from: 'Cliques / Triangle Detection', to: 'Cycles / Shortest Cycle', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
    { id: 'R4', from: '3SUM / 3SUM', to: 'APSP / APSP', toTime: '$T(n)$', fromTime: '$O(T(n))$' },
  ]);
  const pick = (query: string, knobs: Knob[] = [], order: string[] = []) => bestProblem(search(query, names, knobs), names, order);
  const sheet = [...names.problems.keys()];

  it('prefers the name shown equal to the query, then having it as a whole word, then the family', () => {
    assert.equal(pick('apsp'), 'APSP / APSP', 'equal (before the family equal)');
    assert.ok(sheet.indexOf('Cliques / Triangles Listing') < sheet.indexOf('APSP / Negative Triangle'));
    assert.equal(pick('triangle'), 'APSP / Negative Triangle', 'a whole word before a part of one (Triangles), the first in the sheet');
    assert.equal(pick('triangle', [], ['Cliques / Triangles Listing', 'Cliques / Triangle Detection']), 'Cliques / Triangle Detection', 'the first box');
    assert.equal(pick('cycles'), 'Cycles / Shortest Cycle', 'the family equal');
    assert.equal(pick('cliques'), 'Cliques / Triangles Listing', 'the family, the first in the sheet');
  });

  it('then a name containing it, the first box first, then the first in the sheet; then problems found through a bound', () => {
    assert.equal(pick('angle'), 'Cliques / Triangles Listing', 'the first in the sheet');
    assert.equal(pick('angle', [], ['3SUM / 3SUM', 'Cliques / Triangle Detection']), 'Cliques / Triangle Detection', 'the first box');
    assert.equal(pick('neg'), 'APSP / Negative Triangle');
    assert.equal(pick('zwick', [knob('U1', '3SUM / 3SUM', { note: 'Zwick' })]), '3SUM / 3SUM', 'through a bound');
    assert.equal(pick('3sum', [knob('U1', 'APSP / APSP', { note: 'via 3SUM' })], ['APSP / APSP']), '3SUM / 3SUM', 'a name before a bound');
    assert.equal(pick('nothing'), null);
    assert.equal(bestProblem(NO_SEARCH, names, []), null);
  });
});
