import assert from 'node:assert/strict';
import { formatNumber } from '../src/growth/growth';
import { boundDecimals } from '../src/ui/format';

/*
 * Testing strategy for boundDecimals (display precision of bounds)
 *
 * partition on the bounds given: lower only, upper only, both
 * partition on the value: integer, short decimal, needs 5–6 decimals (1.99915, ω), repeating decimal (4/3), search
 *   noise just below an integer (1.99999976)
 * partition on the pair: tight (equal, or within the tolerance), gap, conflict that 4 decimals would hide
 */

const shown = (x: number, d: number): number => Number(formatNumber(x, d));

describe('boundDecimals', () => {
  it('keeps integers and short decimals short', () => {
    assert.equal(boundDecimals(2, 2), 4);
    assert.equal(formatNumber(2, boundDecimals(2, 2)), '2');
    assert.equal(formatNumber(1.9992, boundDecimals(undefined, 1.9992)), '1.9992');
    assert.equal(formatNumber(2.9995, boundDecimals(3, 2.9995)), '2.9995');
  });

  it('never shows an upper bound smaller or a lower bound larger than computed', () => {
    // 3SUM through Exact Triangle: 1/2 + 2.9983/2 = 1.99915 must not be shown as 1.9991
    const ub = 0.5 + 2.9983 / 2;
    assert.ok(shown(ub, boundDecimals(undefined, ub)) >= ub - 1e-6);
    assert.equal(formatNumber(ub, boundDecimals(undefined, ub)), '1.99915');
    const omega = 2.371552;
    assert.ok(shown(omega, boundDecimals(omega, undefined)) <= omega + 1e-6);
    for (const x of [4 / 3, 5 / 3, (2 * omega) / (omega + 1), omega]) {
      const d = boundDecimals(x, x);
      assert.ok(shown(x, d) <= x + 1e-6 && shown(x, d) >= x - 1e-6, `${x} with ${d} decimals`);
    }
  });

  it('shows search noise below an integer as the integer', () => {
    assert.equal(formatNumber(1.999999759, boundDecimals(1.999999759, 2)), '2');
  });

  it('separates a conflict or a gap that 4 decimals would hide', () => {
    const d = boundDecimals(2, 1.99995);
    assert.notEqual(formatNumber(2, d), formatNumber(1.99995, d));
    const g = boundDecimals(2, 2.00015);
    assert.notEqual(formatNumber(2, g), formatNumber(2.00015, g));
  });

  it('ignores missing and infinite bounds', () => {
    assert.equal(boundDecimals(undefined, undefined), 4);
    assert.equal(boundDecimals(Infinity, 2), 4);
  });
});
