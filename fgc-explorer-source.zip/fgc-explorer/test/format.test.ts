import assert from 'node:assert/strict';
import * as G from '../src/growth/growth';
import { formatNumber } from '../src/growth/growth';
import { Regime } from '../src/model/regime';
import { boundDecimals, timePlain } from '../src/ui/format';

/*
 * Testing strategy for boundDecimals (display precision of bounds)
 *
 * partition on the bounds given: lower only, upper only, both
 * partition on the value: integer, short decimal, needs 5–6 decimals (1.99915, ω), repeating decimal (4/3), search
 *   noise just below an integer (1.99999976)
 * partition on the pair: tight (equal, or within the tolerance), gap, conflict that 4 decimals would hide
 *
 * partition on the powers of the pair: equal, different (no separation needed)
 *
 * timePlain: polynomial, exponential (factor 1 omitted, other factors), infinite; powers other than 1 at exponential
 *   and polynomial scales, exponent 0 (o(·)), rate zero
 */

const shown = (x: number, d: number): number => Number(formatNumber(x, d));
/** boundDecimals of exponents at power 1 (or `power`). */
const decimals = (lb: number | undefined, ub: number | undefined, power = 1): number =>
  boundDecimals(lb === undefined ? undefined : { power, exponent: lb }, ub === undefined ? undefined : { power, exponent: ub });

describe('boundDecimals', () => {
  it('keeps integers and short decimals short', () => {
    assert.equal(decimals(2, 2), 4);
    assert.equal(formatNumber(2, decimals(2, 2)), '2');
    assert.equal(formatNumber(1.9992, decimals(undefined, 1.9992)), '1.9992');
    assert.equal(formatNumber(2.9995, decimals(3, 2.9995)), '2.9995');
  });

  it('never shows an upper bound smaller or a lower bound larger than computed', () => {
    // 3SUM through Exact Triangle: 1/2 + 2.9983/2 = 1.99915 must not be shown as 1.9991
    const ub = 0.5 + 2.9983 / 2;
    assert.ok(shown(ub, decimals(undefined, ub)) >= ub - 1e-6);
    assert.equal(formatNumber(ub, decimals(undefined, ub)), '1.99915');
    const omega = 2.371552;
    assert.ok(shown(omega, decimals(omega, undefined)) <= omega + 1e-6);
    for (const x of [4 / 3, 5 / 3, (2 * omega) / (omega + 1), omega]) {
      const d = decimals(x, x);
      assert.ok(shown(x, d) <= x + 1e-6 && shown(x, d) >= x - 1e-6, `${x} with ${d} decimals`);
    }
  });

  it('shows search noise below an integer as the integer', () => {
    assert.equal(formatNumber(1.999999759, decimals(1.999999759, 2)), '2');
  });

  it('separates a conflict or a gap that 4 decimals would hide', () => {
    const d = decimals(2, 1.99995);
    assert.notEqual(formatNumber(2, d), formatNumber(1.99995, d));
    const g = decimals(2, 2.00015);
    assert.notEqual(formatNumber(2, g), formatNumber(2.00015, g));
  });

  it('compares only bounds of the same power', () => {
    // 2^{2 n^{0.5}} and 2^{1.99996 n}: different powers, so there is nothing to separate
    assert.equal(boundDecimals({ power: 0.5, exponent: 2 }, { power: 1, exponent: 1.99996 }), 4);
    assert.equal(decimals(2, 1.99996, 0.5), 5, 'same power: separated');
  });

  it('ignores missing and infinite bounds', () => {
    assert.equal(decimals(undefined, undefined), 4);
    assert.equal(decimals(Infinity, 2), 4);
  });
});

describe('timePlain', () => {
  it('writes polynomial and exponential times, 2^n without a factor 1', () => {
    const poly = Regime.normalize(['n'], [G.poly(1)], new Set());
    const exp = Regime.normalize(['n', 'm'], [G.logClass(1, 1), G.logClass(Infinity)], new Set());
    assert.ok(poly.kind === 'ok' && exp.kind === 'ok');
    const at = (exponent: number, power = 1): G.Rate => ({ power, exponent });
    assert.equal(timePlain(poly.regime, at(2.5)), 'n^2.5');
    assert.equal(timePlain(exp.regime, at(1)), '2^n');
    assert.equal(timePlain(exp.regime, at(0.5)), '2^(0.5n)');
    assert.equal(timePlain(exp.regime, at(Infinity)), '∞');
  });

  it('writes running times 2^{c·n^a} and quasi-polynomial ones', () => {
    const poly = Regime.normalize(['n'], [G.poly(1)], new Set());
    const exp = Regime.normalize(['n', 'm'], [G.logClass(1, 1), G.logClass(Infinity)], new Set());
    assert.ok(poly.kind === 'ok' && exp.kind === 'ok');
    const at = (exponent: number, power: number): G.Rate => ({ power, exponent });
    assert.equal(timePlain(exp.regime, at(0.5, 0.75)), '2^(0.5n^0.75)');
    assert.equal(timePlain(exp.regime, at(1, 0.99)), '2^(n^0.99)');
    assert.equal(timePlain(exp.regime, at(0, 1)), '2^o(n)');
    assert.equal(timePlain(exp.regime, G.RATE_ZERO), 'poly(n)');
    assert.equal(timePlain(poly.regime, at(1, 2)), '2^(log^2 n)');
    assert.equal(timePlain(poly.regime, at(0.5, 0.5)), '2^(0.5 log^0.5 n)');
    assert.equal(timePlain(poly.regime, G.RATE_ZERO), 'polylog(n)');
  });
});
