/**
 * Free parameters of reductions: value classes, grids and local refinement (SPEC §3.3, §6.3).
 */

import { evaluate } from '../growth/evaluate';
import * as G from '../growth/growth';
import { EvalError, Growth } from '../growth/growth';
import { FreeParam } from '../model/model';

/**
 * An assignment of free parameters: int/real/fixed → the value (NaN for an unknown fixed constant); size → τ, the
 * exponent in base^τ.
 */
export type Theta = ReadonlyMap<string, number>;

/** Maximum number of grid points of a row (product over its parameters). */
export const GRID_CAP = 400;

const isContinuous = (p: FreeParam): boolean => p.def.type === 'real' || p.def.type === 'size';

/**
 * The class of a free parameter's value.
 * @param env classes of the source parameters and earlier free parameters (for the size base)
 * @throws EvalError if the base does not evaluate
 */
export function freeParamGrowth(p: FreeParam, value: number, env: ReadonlyMap<string, Growth>): Growth {
  switch (p.def.type) {
    case 'int':
    case 'real':
    case 'fixed':
      return G.constant(Number.isNaN(value) ? null : value);
    case 'size': {
      const base = p.base === null ? G.poly(1) : evaluate(p.base, { env });
      return G.power(base, G.constant(value));
    }
  }
}

/**
 * The range [lo, hi] of a continuous parameter given the classes of earlier parameters.
 * @throws EvalError if a bound is not a known constant or lo > hi
 */
export function paramRange(p: FreeParam, env: ReadonlyMap<string, Growth>): [number, number] {
  const bound = (e: typeof p.min, which: string): number => {
    if (e === null) throw new EvalError(`free parameter ${p.def.name} has no ${which}`);
    const v = G.constValue(evaluate(e, { env }));
    if (v === null) throw new EvalError(`the ${which} of free parameter ${p.def.name} is not a known constant`);
    return v;
  };
  const lo = bound(p.min, 'min');
  const hi = bound(p.max, 'max');
  if (lo > hi + 1e-12) throw new EvalError(`empty range [${lo}, ${hi}] for free parameter ${p.def.name}`);
  return [lo, Math.max(lo, hi)];
}

function linspace(lo: number, hi: number, k: number): number[] {
  if (k <= 1 || hi - lo < 1e-12) return [lo];
  return Array.from({ length: k }, (_, i) => lo + ((hi - lo) * i) / (k - 1));
}

/** Environment extended with the classes of the free parameters assigned in `theta` (in declaration order). */
export function extendEnv(params: readonly FreeParam[], theta: Theta, env: ReadonlyMap<string, Growth>): Map<string, Growth> {
  const out = new Map(env);
  for (const p of params) {
    const value = theta.get(p.def.name);
    if (value === undefined) continue;
    out.set(p.def.name, freeParamGrowth(p, value, out));
  }
  return out;
}

/**
 * The number of grid values of each continuous parameter: `points`, fewer when the product with the values of the
 * discrete ones would exceed GRID_CAP (at least 2).
 */
export function continuousGridPoints(params: readonly FreeParam[], points: number): number {
  const discrete = params.filter((p) => !isContinuous(p)).reduce((acc, p) => acc * (p.def.type === 'int' ? p.def.values!.length : 1), 1);
  const nCont = params.filter(isContinuous).length;
  return nCont === 0 ? 1 : Math.max(2, Math.min(points, Math.floor((GRID_CAP / Math.max(1, discrete)) ** (1 / nCont))));
}

/**
 * Grid points for `params` (Cartesian product; ranges of later parameters may depend on earlier ones).
 * Continuous parameters get `points` values each, reduced so that the product stays within GRID_CAP.
 * Points whose ranges fail to evaluate are dropped.
 * @param env classes of the source parameters
 */
export function gridPoints(params: readonly FreeParam[], env: ReadonlyMap<string, Growth>, points: number): Theta[] {
  if (params.length === 0) return [new Map()];
  const perCont = continuousGridPoints(params, points);
  const out: Theta[] = [];
  const rec = (i: number, theta: Map<string, number>, scope: Map<string, Growth>): void => {
    if (out.length >= GRID_CAP) return;
    if (i === params.length) {
      out.push(new Map(theta));
      return;
    }
    const p = params[i]!;
    let values: number[];
    try {
      switch (p.def.type) {
        case 'int':
          values = [...p.def.values!];
          break;
        case 'fixed':
          values = [p.def.value === null || p.def.value === undefined ? NaN : p.def.value];
          break;
        default: {
          const [lo, hi] = paramRange(p, scope);
          values = linspace(lo, hi, perCont);
        }
      }
    } catch (e) {
      if (e instanceof EvalError) return;
      throw e;
    }
    for (const v of values) {
      theta.set(p.def.name, v);
      let next: Map<string, Growth>;
      try {
        next = new Map(scope);
        next.set(p.def.name, freeParamGrowth(p, v, scope));
      } catch (e) {
        if (e instanceof EvalError) continue;
        throw e;
      }
      rec(i + 1, theta, next);
    }
    theta.delete(p.def.name);
  };
  rec(0, new Map(), new Map(env));
  return out;
}

/**
 * Clamp every continuous parameter into its range given the (possibly changed) earlier parameters.
 * @returns the clamped assignment, or null if some range does not evaluate or is empty
 */
export function clampTheta(params: readonly FreeParam[], theta: Theta, env: ReadonlyMap<string, Growth>): Theta | null {
  const out = new Map(theta);
  const scope = new Map(env);
  for (const p of params) {
    const v = out.get(p.def.name);
    if (v === undefined) continue;
    try {
      if (isContinuous(p)) {
        const [lo, hi] = paramRange(p, scope);
        out.set(p.def.name, Math.min(hi, Math.max(lo, v)));
      }
      scope.set(p.def.name, freeParamGrowth(p, out.get(p.def.name)!, scope));
    } catch (e) {
      if (e instanceof EvalError) return null;
      throw e;
    }
  }
  return out;
}

/**
 * Coordinate-wise local refinement of continuous parameters around `start` (SPEC §6.3).
 * @param objective value to maximize at an assignment, or null if the assignment is not admissible
 * @param startValue objective(start)
 * @param rounds number of halving rounds
 * @param points the grid points asked for: the first step is the spacing of the grid that gridPoints made, range /
 *        (values − 1), with values reduced as there (a smaller step could not reach the best point between two values)
 * @returns the best admissible assignment found (start if none is better)
 */
export function refine(
  params: readonly FreeParam[],
  env: ReadonlyMap<string, Growth>,
  start: Theta,
  startValue: number,
  objective: (theta: Theta) => number | null,
  rounds: number,
  points: number,
): { theta: Theta; value: number } {
  const cont = params.filter(isContinuous);
  if (cont.length === 0 || rounds <= 0) return { theta: start, value: startValue };
  let best = new Map(start);
  let bestValue = startValue;
  const steps = new Map<string, number>();
  const perCont = continuousGridPoints(params, points);
  for (const p of cont) {
    try {
      const scope = extendEnv(params.slice(0, params.indexOf(p)), best, env);
      const [lo, hi] = paramRange(p, scope);
      steps.set(p.def.name, (hi - lo) / Math.max(1, perCont - 1));
    } catch {
      steps.set(p.def.name, 0);
    }
  }
  for (let round = 0; round < rounds; round++) {
    for (const p of cont) {
      const step = steps.get(p.def.name)!;
      if (step <= 0) continue;
      let range: [number, number];
      try {
        range = paramRange(p, extendEnv(params.slice(0, params.indexOf(p)), best, env));
      } catch {
        continue;
      }
      const cur = best.get(p.def.name)!;
      for (const d of [-step / 2, step / 2]) {
        const cand = Math.min(range[1], Math.max(range[0], cur + d));
        if (Math.abs(cand - cur) < 1e-15) continue;
        const moved = new Map(best);
        moved.set(p.def.name, cand);
        // Later parameters may have ranges that depend on this one (e.g. b ∈ [0, 1 − a]).
        const theta = clampTheta(params, moved, env);
        if (theta === null) continue;
        let value: number | null;
        try {
          value = objective(theta);
        } catch (e) {
          if (e instanceof EvalError) continue;
          throw e;
        }
        if (value !== null && value > bestValue + 1e-12) {
          best = new Map(theta);
          bestValue = value;
        }
      }
    }
    for (const p of cont) steps.set(p.def.name, steps.get(p.def.name)! / 2);
  }
  return { theta: best, value: bestValue };
}

/** Text such as "k = 3, τ(t) = 0.5". */
export function describeTheta(params: readonly FreeParam[], theta: Theta): string {
  return params
    .map((p) => {
      const v = theta.get(p.def.name);
      if (v === undefined) return null;
      // (4 decimals, but a tiny nonzero value, such as epsilon = 1e-12, keeps its size: 0 would be another value)
      const num = Number.isNaN(v) ? 'O(1)' : v !== 0 && Math.abs(v) < 5e-5 ? v.toExponential(0) : G.formatNumber(v, 4);
      return p.def.type === 'size' ? `${p.def.name} = ${p.base ? 'base' : 'N'}^${num}` : `${p.def.name} = ${num}`;
    })
    .filter((s): s is string => s !== null)
    .join(', ');
}
