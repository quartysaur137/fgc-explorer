/**
 * The order of a problem's regimes for display (SPEC §6.7). The graph shows each problem's first regime and the
 * inspector lists them in this order: a conflict first, then the pinned and configured regimes (the others are special
 * cases of the problem), and among those regimes that read nicely (whole-number exponents such as m = n² and m = n, or
 * simple fractions such as n^{3/2}) and say the most (both bounds, then a lower bound, then an upper bound). Regimes
 * with unusual exponents (n^{10/11}), which free parameters of reductions produce by the dozen, come last.
 */

import { Rate } from '../growth/growth';
import { Regime } from '../model/regime';
import type { RegimeOrigin, Status } from './analysis';

/**
 * The smallest denominator q ≤ maxDen of a fraction equal to x up to `tol` (x·q within q·tol of an integer), or
 * Infinity. Regime exponents are stored rounded up to 6 decimals, which the tolerance absorbs (2/3 is 0.666667).
 */
export function simpleDenominator(x: number, maxDen = 12, tol = 2e-6): number {
  if (!Number.isFinite(x)) return Infinity;
  for (let q = 1; q <= maxDen; q++) if (Math.abs(x * q - Math.round(x * q)) <= q * tol) return q;
  return Infinity;
}

/** How nicely a regime's parameters read: 0 the nicest. */
export type NiceTier = 0 | 1 | 2 | 3;

/**
 * How a number reads as the exponent of a parameter (or as a constant's value): 0 whole; 1 halves, thirds or quarters
 * up to 3 (n^{3/2}, n^{4/3}); 2 fifths or sixths up to 4; 3 anything else (n^{10/11}, n^{11.5}).
 */
export function numberTier(x: number): NiceTier {
  const q = simpleDenominator(x);
  if (q === 1) return 0;
  if (q <= 4 && x <= 3) return 1;
  if (q <= 6 && x <= 4) return 2;
  return 3;
}

export interface Niceness {
  /** The worst tier of the parameters (see numberTier). */
  readonly tier: NiceTier;
  /** The sum over the parameters of (denominator − 1), large for unusual ones: fewer and simpler fractions first. */
  readonly weight: number;
}

/**
 * How nicely a regime reads. The main parameter, growth classes (polylog, subpoly, an unspecified constant) and
 * log-dependent parameters read as whole numbers; polynomial parameters by their exponents, constants by their values.
 */
export function regimeNiceness(r: Regime): Niceness {
  let tier: NiceTier = 0;
  let weight = 0;
  r.growths.forEach((g, i) => {
    if (i === r.normalizer || r.logDep.has(r.params[i]!)) return;
    const x = g.kind === 'poly' ? g.exp : g.kind === 'const' && g.value !== null ? g.value : null;
    if (x === null) return;
    const t = numberTier(x);
    if (t > tier) tier = t;
    const q = simpleDenominator(x);
    weight += Number.isFinite(q) ? q - 1 : 100;
  });
  return { tier, weight };
}

/** What a regime of a problem holds, as far as its order is concerned (see RegimeSummary). */
export interface RankedRegime {
  readonly regime: Regime;
  readonly lb: (Rate & { readonly hops: number }) | null;
  readonly status: Status;
  readonly origins: readonly RegimeOrigin[];
  /**
   * The status of its own bounds, without those carried over from the problem's other regimes (RegimeSummary); the
   * same as `status` if omitted.
   */
  readonly ownStatus?: Status;
  /**
   * Whether it is neither configured nor pinned while the problem has such a regime: a special case (e.g. constant weights
   * inside polynomial ones, or the regime a reduction happens to produce), which does not stand for the problem (it comes
   * after those regimes, unless it has a conflict), even when its bounds say more.
   */
  readonly special?: boolean;
}

/** How much a regime's bounds say: both (tight, then a gap; a conflict is ranked apart), a lower bound, an upper bound. */
const INFORMATION: Readonly<Record<Status, number>> = { conflict: 0, tight: 0, gap: 1, lb: 2, ub: 3, none: 4 };

/** The denominator of a lower bound's exponent, up to 100 (1 without one): its simplicity breaks ties. */
function lbDenominator(lb: Rate | null): number {
  if (lb === null || !Number.isFinite(lb.exponent)) return 1;
  return Math.min(simpleDenominator(lb.exponent, 100), 101);
}

/**
 * The sort key of a regime (compared lexicographically, smaller first): a conflict (so that it shows, also when
 * another regime is pinned); pinned; configured or pinned (any other regime is a special case while the problem has
 * such a regime, so that, say, Negative Triangle Detection with constant weights, tight, does not stand for the problem
 * when the configured polynomial weights leave a gap); niceness, with whole numbers and the simple fractions of tier 1
 * counted as one (so that, say, a configured m = n^{3/2} with a lower bound comes before a configured m = n² with an
 * upper bound only); how much its own bounds say, then how much they say with those carried over from the problem's
 * other regimes (so that a gap at m = n^{3/2} comes before the gap m = n² inherits from it, and the order is the one of
 * the regimes' own bounds, apart from conflicts); then the exact tier and weight, a simple lower-bound exponent,
 * configured before knob regimes before those of reductions, fewer reductions, and the larger lower bound.
 */
export function regimeRankKey(s: RankedRegime): number[] {
  const n = regimeNiceness(s.regime);
  return [
    s.status === 'conflict' ? 0 : 1,
    s.origins.includes('pinned') ? 0 : 1,
    s.special === true ? 1 : 0,
    Math.max(n.tier - 1, 0),
    INFORMATION[s.ownStatus ?? s.status],
    INFORMATION[s.status],
    n.tier,
    n.weight,
    lbDenominator(s.lb),
    s.origins.includes('config') ? 0 : s.origins.includes('knob') ? 1 : 2,
    s.lb ? s.lb.hops : 99,
    s.lb ? -s.lb.power : 0,
    s.lb ? -s.lb.exponent : 0,
  ];
}

/**
 * The order of a problem's lower-bound regimes before upper bounds are known (the order in which their upper bounds
 * are computed): niceness, a simple exponent, fewer reductions, the larger bound.
 */
export function lbRegimeKey(f: Rate & { readonly regime: Regime; readonly hops: number }): number[] {
  const n = regimeNiceness(f.regime);
  return [Math.max(n.tier - 1, 0), n.tier, n.weight, lbDenominator(f), f.hops, -f.power, -f.exponent];
}

/** Lexicographic order of sort keys. */
export function compareKeys(a: readonly number[], b: readonly number[]): number {
  for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i]! < b[i]! ? -1 : 1;
  return a.length - b.length;
}

/** Whether the inspector lists a regime without being asked to (see analysis: also those derivations go through). */
export function listedByItself(s: RankedRegime): boolean {
  return s.origins.some((o) => o !== 'lb') || regimeNiceness(s.regime).tier <= 1;
}
