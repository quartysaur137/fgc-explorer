/**
 * Limits of bounds that improve each time a cycle of reductions is repeated (SPEC §6.9).
 *
 * Going once around a cycle maps the bound of its first problem to a new bound of the same problem: a nondecreasing
 * map H of the exponent (a larger lower bound, or a larger running time of an algorithm, can only give a larger
 * result). When H improves the bound (H(y) > y for lower bounds, H(y) < y for upper bounds), repeating the cycle gives
 * y, H(y), H(H(y)), …, which converges to the nearest fixed point of H in the direction of improvement, or, for lower
 * bounds, grows without limit. Every element of the sequence is a valid bound, hence so is the limit (a supremum of
 * lower bounds, an infimum of upper bounds).
 */

import { Expr, oracleCalls } from '../math/ast';
import { CompiledRow } from '../model/model';

/** Lower bounds whose iteration still improves, without slowing down, beyond this exponent grow without limit. */
export const DIVERGENCE_EXPONENT = 1e6;
/** The search for a fixed point gives up beyond this exponent (keeping a finite bound). */
const SEARCH_CEILING = 1e15;

/**
 * The limit of y0, H(y0), H(H(y0)), … for a nondecreasing H that improves y0, when H is convex (upper bounds) or
 * concave (lower bounds); see shapeKnown.
 *
 * The fixed point is located by steps that double from H(y0) − y0, then by bisection between the last improving point
 * and the first point where H no longer improves; H is evaluated at those points, never iterated to convergence, so
 * slow (even linear) convergence costs no more than fast convergence. The points where a convex (concave) H improves
 * form an interval that ends at the nearest fixed point, so no probe can jump over it. A point where H does not
 * evaluate counts as not improving, which can only make the limit less extreme (it stays a valid bound). A lower bound
 * still improving at DIVERGENCE_EXPONENT by at least as much at twice that is taken to grow without limit (the
 * breakpoints of exponent maps are far below: from there on the improvement is affine).
 *
 * @param H the map, NaN where it does not evaluate
 * @param direction 1 for lower bounds (increasing), −1 for upper bounds (decreasing, never below 0)
 * @returns the limit, on its safe side (at most the fixed point for lower bounds, at least it for upper bounds), or
 *          Infinity for lower bounds that grow without limit
 */
export function iterationLimit(H: (y: number) => number, y0: number, direction: 1 | -1): number {
  const gain = (y: number): number => direction * (H(y) - y);
  const improves = (y: number): boolean => gain(y) > 0;
  if (!improves(y0)) return y0;
  // `good`: the furthest point known to improve; `bad`: a point where H stops improving.
  let good = y0;
  let bad = NaN;
  for (let step = gain(y0); Number.isNaN(bad); step *= 2) {
    let y = good + direction * step;
    if (direction === -1 && y <= 0) y = 0;
    if (!improves(y)) {
      bad = y;
      break;
    }
    if (y === 0) return 0; // (cannot happen for a map to nonnegative exponents)
    good = y;
    if (direction === 1 && y >= DIVERGENCE_EXPONENT) {
      if (gain(2 * y) >= gain(y) - 1e-9) return Infinity;
      if (y >= SEARCH_CEILING) return lap(H, good);
    }
  }
  for (let i = 0; i < 200 && Math.abs(bad - good) > 1e-13 * Math.max(1, Math.abs(good)); i++) {
    const mid: number = (good + bad) / 2;
    if (mid === good || mid === bad) break;
    if (improves(mid)) good = mid;
    else bad = mid;
  }
  return lap(H, good);
}

/** One more lap from an improving point: still a valid bound, and on the safe side of the fixed point. */
function lap(H: (y: number) => number, y: number): number {
  const h = H(y);
  return Number.isNaN(h) ? y : h;
}

/**
 * The limit of y0, H(y0), … by plain iteration, for maps of unknown shape: at most `laps` laps, stopping when a lap
 * improves by at most 1e-9. Every iterate is a valid bound (it may stop short of the limit).
 */
export function iteratedLimit(H: (y: number) => number, y0: number, direction: 1 | -1, laps = 200): number {
  let y = y0;
  for (let i = 0; i < laps; i++) {
    const h = H(y);
    if (!(direction * (h - y) > 1e-9)) break;
    y = h;
  }
  return y;
}

/**
 * Whether going around a cycle through these rows is a convex map of the exponent for upper bounds and a concave one
 * for lower bounds, as iterationLimit needs. The exponent of a From-time is a maximum of affine functions of the calls'
 * exponents when calls only occur under sums, products, quotients by call-free terms, powers with call-free exponents,
 * maxima, ceilings, roots, absolute values, polylogarithms, O-style bounds and sums over ranges: such an exponent is
 * convex, and the lower-bound threshold inverts a convex function, hence is concave; composing keeps both. Anything
 * else around a call (\min, floors, named functions, …) may break this.
 */
export function shapeKnown(rows: readonly CompiledRow[]): boolean {
  return rows.every((r) => r.from !== null && r.from.alternatives.every((e) => shapeOk(e)));
}

const SHAPE_FUNCS: ReadonlySet<string> = new Set(['max', 'ceil', 'sqrt', 'root', 'abs', 'polylog']);

/** Whether every call in `e` occurs only under the constructs listed in shapeKnown. */
function shapeOk(e: Expr): boolean {
  if (oracleCalls(e).length === 0) return true;
  switch (e.type) {
    case 'call':
      return true;
    case 'add':
      return e.terms.every((t) => shapeOk(t.expr));
    case 'mul':
      return e.factors.every(shapeOk);
    case 'div':
      return oracleCalls(e.den).length === 0 && shapeOk(e.num);
    case 'pow':
      return oracleCalls(e.exp).length === 0 && shapeOk(e.base);
    case 'func':
      return SHAPE_FUNCS.has(e.fn) && e.args.every(shapeOk);
    case 'bound':
      return shapeOk(e.arg);
    case 'sum':
      return shapeOk(e.body) && (e.lo === null || oracleCalls(e.lo).length === 0) && (e.hi === null || oracleCalls(e.hi).length === 0);
    default:
      return false;
  }
}
