/**
 * Upper-bound evaluation (SPEC §2.5, §6.6): algorithms flow backward along reductions.
 *
 * Every (problem, regime) met is a node with a single best bound: the best over derivations of any length that use
 * the knobs and the reductions, so a problem's bound is the same wherever it is used (in its own box, or inside the
 * derivation of another problem). The bounds are the fixpoint of "a node's bound is the best of its knobs and of each
 * reduction from it, its calls valued at the bounds of their targets", computed on demand: solving a node solves the
 * nodes its candidates call (recursively), and a node whose bound improves has the nodes that read it solved again
 * (Seidl's top-down solver; cycles of reductions are handled the same way). Candidates that cannot beat a node's bound
 * are dropped for good (bounds only improve), which keeps the search to the part of the graph that matters.
 */

import { evaluate } from '../growth/evaluate';
import * as G from '../growth/growth';
import { compareRates, EvalError, finiteRate, Growth, maxRate, Rate, RATE_NONE, RATE_ZERO, samePower } from '../growth/growth';
import { Expr } from '../math/ast';
import { CompiledRow, Model } from '../model/model';
import { ParamSpec, Regime } from '../model/regime';
import { iteratedLimit, iterationLimit, shapeKnown } from './cycles';
import { gridPoints, refine, Theta } from './freeparams';
import { PropagationOptions, TOL } from './lower';
import { evaluateF, prepareRow, PreparedRow } from './rowEval';

export type UBOrigin =
  | { readonly kind: 'knob'; readonly knobId: string }
  | {
      readonly kind: 'row';
      readonly rowId: string;
      readonly theta: Theta;
      /** The upper bounds used for the row's calls (one per target regime). */
      readonly children: readonly UBFact[];
      /** The rate of the reduction runtime (null: unknown). */
      readonly rt: Rate | null;
    }
  | {
      /**
       * The limit of repeating a cycle of reductions that improves the bound each time (SPEC §6.9): `lap` goes once
       * around it, from this problem (lap[0], a bound through a reduction) down to `base`, an earlier bound of this
       * problem that the lap improves; the cycle can start from it again and again.
       */
      readonly kind: 'cycle';
      readonly lap: readonly UBFact[];
      readonly base: UBFact;
    };

/**
 * "`problem` has an algorithm on instances of `regime` running in time 2^{(exponent+o(1))·L^power}" (L = log2 N; power
 * 1: N^{exponent+o(1)}; power 0: of rate zero, e.g. polylogarithmic; SPEC §2.4).
 */
export interface UBFact extends Rate {
  readonly problem: string;
  readonly regime: Regime;
  /**
   * Number of reductions in the derivation: 0 for a knob; for a row, 1 + those of the bounds its calls use; for the
   * limit of a cycle, that of its lap.
   */
  readonly steps: number;
  readonly origin: UBOrigin;
}

/**
 * Whether `f` is a better upper bound than `g` (or than none): a smaller rate (a smaller power, or the same power and a
 * smaller exponent), or one equal within TOL with fewer reductions. The tie-break keeps derivations short and free of
 * detours, e.g. through a problem and back.
 */
export function betterUB(f: UBFact, g: UBFact | null): boolean {
  if (g === null) return true;
  const c = compareRates(f, g, TOL);
  return c < 0 || (c === 0 && f.steps < g.steps);
}

/** The bounds a bound's derivation uses directly (the calls of a row; the lap of a cycle). */
export function ubParts(f: UBFact): readonly UBFact[] {
  switch (f.origin.kind) {
    case 'knob':
      return [];
    case 'row':
      return f.origin.children;
    case 'cycle':
      return [f.origin.lap[0]!];
  }
}

/** What a reduction from a problem does for its upper bound at one regime (see UpperBounds.explain). */
export type UBRowVerdict =
  /** It derives the problem's upper bound there. */
  | { readonly kind: 'used'; readonly fact: UBFact }
  /** With the bounds of its calls, it gives this bound at best: not better (or as good through more reductions). */
  | { readonly kind: 'weaker'; readonly fact: UBFact }
  /** Even with every call free, it would take time of rate `optimistic` at least: not better than the problem's bound. */
  | { readonly kind: 'skipped'; readonly optimistic: Rate }
  /**
   * A call has no upper bound: `target` at `regime` (`searched` false when the search stopped there or below, too many
   * regimes away from the regimes of interest, see the setting maxDepthUB: a wider search might find one).
   */
  | { readonly kind: 'no-call-bound'; readonly target: string; readonly regime: Regime; readonly searched: boolean }
  /** The search did not follow reductions from this regime (too far from the regimes of interest). */
  | { readonly kind: 'not-searched' }
  /** It does not evaluate at this regime (`reason`), e.g. its restriction does not hold. */
  | { readonly kind: 'not-applicable'; readonly reason: string }
  /** The engine does not use it (unsupported formulas or the settings): see the row. */
  | { readonly kind: 'unusable' };

/** An upper-bound knob prepared for evaluation. */
export interface UBKnob {
  readonly id: string;
  readonly problem: string;
  /** Exponent knobs: the regime keys where the rate (exponent, power) applies. */
  readonly exactKeys: ReadonlySet<string> | null;
  readonly exponent: number | null;
  readonly power: number;
  /** Formula knobs: the runtime formula and an optional regime filter. */
  readonly formula: Expr | null;
  readonly filter: ReadonlyMap<string, ParamSpec> | null;
}

/** Thrown (as one shared instance, to avoid building stack traces in the search) when a call has no upper bound. */
const NO_BOUND = new EvalError('no upper bound for a call');

/** Nodes beyond this many are not searched (only their knobs count); a message says so. */
export const MAX_UB_NODES = 60000;
/** An overlay shared by analyses holds at most about this many nodes (see UpperBounds.overlay). */
const OVERLAY_NODES = 20000;
/** Nested solving deeper than this is postponed (to a list solved afterwards), to stay within the call stack. */
const MAX_NESTING = 120;
/** A node's bound is not changed more often than this (cycles that keep improving are handled by their limits). */
const MAX_IMPROVEMENTS = 400;
/** Limits of improving cycles computed per node at most (each later one starts closer to the fixed point). */
const MAX_CYCLE_LIMITS = 8;

/** A reduction from a node's problem at one point θ of its free parameters, prepared once. */
interface Candidate {
  readonly row: CompiledRow;
  readonly theta: Theta;
  readonly prep: PreparedRow;
  /** max(reduction runtime, From-time with every call of rate zero): no bound through it can be smaller. */
  readonly optimistic: Rate;
}

/**
 * A (problem, regime) pair, and at a regime that is not of interest also the budget: how many such regimes in a row a
 * derivation may still pass through from here, this one included (maxDepthUB below a regime of interest, one less at
 * each further one; at 0 only the knobs count). The budget is part of the node's identity, so that a node's bound is a
 * pure function of it (whatever the order of the search), at the price of up to maxDepthUB + 1 nodes per regime.
 */
interface Node {
  readonly key: string;
  readonly problem: string;
  readonly regime: Regime;
  /** The solver that owns the node (the nodes of an overlay's base are read only). */
  readonly owner: UpperBounds;
  /** Whether the node is at a regime of interest (or was asked for): its reductions are always searched. */
  readonly interest: boolean;
  /** At a regime that is not of interest: the budget (see above). */
  readonly budget: number;
  best: UBFact | null;
  /** Whether `best` takes the current bounds of the nodes it read into account. */
  stable: boolean;
  /** Whether the node is not searched although reductions start from its problem (budget 0, or the node cap). */
  truncated: boolean;
  /** The nodes its evaluations read. */
  readonly reads: Set<Node>;
  /** Nodes whose evaluation read this node's bound since it last changed. */
  readonly readers: Set<Node>;
  /** Whether its knobs were evaluated. */
  knobsDone: boolean;
  /** The candidates that may still beat `best`, per row; null until searched (never for a node not searched). */
  rows: ReadonlyArray<readonly Candidate[]> | null;
  /** Over the node cap: knobs only. */
  readonly frontier: boolean;
  improvements: number;
  cycleLimits: number;
}

/** Whether a bound through a candidate whose bounds are at least `lower` cannot beat `incumbent` (see betterUB). */
function cannotBeat(lower: Rate, incumbent: UBFact | null): boolean {
  if (incumbent === null) return false;
  // A row adds a reduction, so a tie needs an incumbent with at least two.
  const c = compareRates(lower, incumbent, TOL);
  return c > 0 || (incumbent.steps <= 1 && c >= 0);
}

/** The rate of a bound through a row: max(From-time, reduction runtime, rate zero). */
function rowRate(F: Growth, rt: Rate): Rate {
  return maxRate(maxRate(G.rateOf(F), rt), RATE_ZERO);
}

/** The target regimes of a row bound's calls, as a string. */
const signature = (f: UBFact): string => (f.origin.kind === 'row' ? f.origin.children.map((c) => c.regime.key).sort().join(';') : '');

/** Key of a (problem, regime) pair, as in the set of regimes of interest. */
export function nodeKey(problem: string, regime: Regime): string {
  return `${problem}#${regime.key}`;
}

/** Whether reductions from the node are searched (else only its knobs count). */
function searched(v: Node): boolean {
  return (v.interest || v.budget > 0) && !v.frontier;
}

/**
 * Upper bounds of one analysis (knobs, settings and regimes of interest are fixed), solved on demand and remembered.
 *
 * Derivations are searched from the regimes of interest (the configured regimes, those of UB knobs, pinned ones)
 * without any limit on their length, except that they pass through at most maxDepthUB regimes in a row that are not
 * of interest: the search follows the reductions from those regimes, and uses only the knobs of the next one, unless
 * it is of interest again. (Free parameters make the number of regimes grow quickly: 200 000 within seven reductions
 * of the initial ones.) Every node's bound is a pure function of the node (see Node), the knobs, the settings and the
 * regimes of interest, whatever the order of the queries. Bounds at other regimes are asked for in an overlay (see
 * `overlay`), which reads these nodes without changing them.
 */
export class UpperBounds {
  private readonly nodes = new Map<string, Node>();
  private readonly knobsByProblem = new Map<string, UBKnob[]>();
  private evaluations = 0;
  private nesting = 0;
  /** Nodes whose solving was postponed (see MAX_NESTING). */
  private readonly postponed: Node[] = [];
  private readonly cappedMessages = new Set<string>();
  /** Limits of cycles, with the node they were found for. */
  private readonly cycleFacts: Array<{ readonly key: string; readonly fact: UBFact }> = [];

  /**
   * @param interest keys (see nodeKey) of the regimes of interest
   * @param base for an overlay: the solver whose nodes it reads without changing them
   */
  constructor(
    private readonly model: Model,
    private readonly knobs: readonly UBKnob[],
    private readonly opts: PropagationOptions,
    private readonly interest: ReadonlySet<string> = new Set(),
    private readonly base: UpperBounds | null = null,
  ) {
    for (const k of knobs) {
      const list = this.knobsByProblem.get(k.problem) ?? [];
      list.push(k);
      this.knobsByProblem.set(k.problem, list);
    }
  }

  /** Number of (problem, regime) nodes met so far. */
  get nodeCount(): number {
    return this.nodes.size;
  }

  /** Number of node evaluations so far (a node is evaluated again when a bound it uses improves). */
  get evaluationCount(): number {
    return this.evaluations;
  }

  /** Messages about limits that were hit (results may be incomplete). */
  get capped(): readonly string[] {
    return [...this.cappedMessages];
  }

  /**
   * The limits of cycles that lower a bound each time around (SPEC §6.9) that are still the best bounds of their nodes
   * (found here, not in the base).
   */
  get cycles(): readonly UBFact[] {
    return this.cycleFacts.filter((c) => this.nodes.get(c.key)?.best === c.fact).map((c) => c.fact);
  }

  /**
   * The best bound found so far for `problem` at `regime` (here or in the base), over the nodes of that regime (asked
   * for or of interest, and with every budget), without solving anything; undefined if no such node was met.
   */
  known(problem: string, regime: Regime): UBFact | null | undefined {
    const key = nodeKey(problem, regime);
    let met = false;
    let best: UBFact | null = null;
    for (const k of [key, ...Array.from({ length: this.opts.settings.maxDepthUB + 1 }, (_, b) => `${key}#${b}`)]) {
      const v = this.lookup(k);
      if (v === undefined) continue;
      met = true;
      if (v.best !== null && betterUB(v.best, best)) best = v.best;
    }
    return met ? best : undefined;
  }

  /**
   * A solver for bounds at further regimes, searched as regimes of interest, that reads the bounds of this one without
   * changing them (so asking for them does not change what this solver found, or will find, anywhere else). Its bounds
   * are pure functions of the nodes, like these, so one overlay serves every analysis that reuses this solver (until it
   * holds more than OVERLAY_NODES nodes: then a new one starts, so that the node cap is never reached by accumulation).
   */
  overlay(): UpperBounds {
    if (this.shared === null || this.shared.nodeCount > OVERLAY_NODES) this.shared = new UpperBounds(this.model, this.knobs, this.opts, this.interest, this);
    return this.shared;
  }

  private shared: UpperBounds | null = null;

  /**
   * The best upper bound for `problem` at `regime` (searched as a regime of interest: see the class comment).
   * @returns null if no bound is derivable
   */
  query(problem: string, regime: Regime): UBFact | null {
    const v = this.node(problem, regime, null);
    this.solve(v);
    while (this.postponed.length > 0) this.solve(this.postponed.pop()!);
    return v.best;
  }

  /**
   * The node of `problem` at `regime` (created on first use): of interest if the regime is one, or if `budget` is null
   * (a regime asked for); else with that budget.
   */
  private node(problem: string, regime: Regime, budget: number | null): Node {
    const pair = nodeKey(problem, regime);
    const interest = budget === null || this.interest.has(pair);
    const key = interest ? pair : `${pair}#${budget}`;
    let v = this.lookup(key);
    if (v === undefined) {
      const frontier = this.nodes.size >= MAX_UB_NODES;
      if (frontier) this.cappedMessages.add(`upper bounds: more than ${MAX_UB_NODES} problem regimes met; reductions from further ones were not searched`);
      v = {
        key,
        problem,
        regime,
        owner: this,
        interest,
        budget: interest ? this.opts.settings.maxDepthUB : budget!,
        best: null,
        stable: false,
        truncated: false,
        reads: new Set(),
        readers: new Set(),
        knobsDone: false,
        rows: null,
        frontier,
        improvements: 0,
        cycleLimits: 0,
      };
      this.nodes.set(key, v);
    }
    return v;
  }

  /** The budget of the nodes that `v`'s candidates call, at regimes that are not of interest. */
  private childBudget(v: Node): number {
    return v.interest ? this.opts.settings.maxDepthUB : v.budget - 1;
  }

  /** The node with this key, here or in the base. */
  private lookup(key: string): Node | undefined {
    return this.nodes.get(key) ?? this.base?.lookup(key);
  }

  /** Bring `v` up to date: evaluate it, and if its bound improves, solve the nodes that read it again. */
  private solve(v: Node): void {
    if (v.stable || v.owner !== this) return;
    if (this.nesting >= MAX_NESTING) {
      this.postponed.push(v);
      return;
    }
    v.stable = true;
    this.nesting += 1;
    try {
      const before = v.best;
      const f = this.evaluate(v);
      if (f !== null && f !== v.best && betterUB(f, v.best)) this.improve(v, f);
      // (A knob set during the evaluation is news to nodes that read this one before, e.g. while it was postponed.)
      else if (v.best !== before) this.notify(v);
    } finally {
      this.nesting -= 1;
    }
  }

  /** The bound of `w` for the evaluation of `reader`, which is solved again if that bound improves. */
  private read(reader: Node, w: Node): UBFact | null {
    this.solve(w);
    if (w.owner === this) w.readers.add(reader);
    reader.reads.add(w);
    return w.best;
  }

  /** Whether the search stopped (detour budget or node cap) at `v` or below it, where it could have gone on. */
  private static cutShort(v: Node): boolean {
    const seen = new Set<Node>();
    const stack = [v];
    while (stack.length > 0) {
      const x = stack.pop()!;
      if (x.truncated) return true;
      for (const y of x.reads) {
        if (!seen.has(y)) {
          seen.add(y);
          stack.push(y);
        }
      }
    }
    return false;
  }

  private improve(v: Node, f: UBFact): void {
    if (v.improvements >= MAX_IMPROVEMENTS) {
      this.cappedMessages.add(`upper bounds: the bound of ${v.problem} at ${v.regime.key} improved more than ${MAX_IMPROVEMENTS} times; later improvements were dropped`);
      return;
    }
    let g = f;
    if (v.cycleLimits < MAX_CYCLE_LIMITS) {
      const lap = cycleThrough(f);
      if (lap !== null) {
        v.cycleLimits += 1;
        const limit = this.cycleLimit(lap, f);
        if (limit !== null && betterUB(limit, f)) {
          g = limit;
          this.cycleFacts.push({ key: v.key, fact: limit });
        }
      }
    }
    v.best = g;
    v.improvements += 1;
    this.notify(v);
  }

  /** Solve again the nodes that read `v` (its bound changed). */
  private notify(v: Node): void {
    const readers = [...v.readers];
    v.readers.clear();
    for (const w of readers) w.stable = false;
    for (const w of readers) this.solve(w);
  }

  /** The best bound from the node's knobs and candidates (`v.best` if none beats it). */
  private evaluate(v: Node): UBFact | null {
    this.evaluations += 1;
    if (!v.knobsDone) {
      v.knobsDone = true;
      let knob: UBFact | null = null;
      for (const k of this.knobsByProblem.get(v.problem) ?? []) {
        const f = this.knobValue(k, v.regime);
        if (f !== null && finiteRate(f) && betterUB(f, knob)) knob = f;
      }
      // The knob is the bound from now on, before any reduction is tried: nothing has read the node yet, and the nodes
      // its search reaches (through cycles) see it.
      if (knob !== null && betterUB(knob, v.best)) {
        v.best = knob;
        v.improvements += 1;
      }
      if (!searched(v)) v.truncated = (this.model.rowsBySource.get(v.problem) ?? []).some((r) => r.status === 'ok' && this.opts.usable(r));
    }
    let best = v.best;
    if (!searched(v)) return best;
    // Candidates that cannot beat the bound now never will (it only improves): drop them.
    const rows: Array<readonly Candidate[]> = [];
    for (const cands of v.rows ?? this.candidates(v)) {
      const live = cands.filter((c) => !cannotBeat(c.optimistic, best));
      if (live.length > 0) rows.push(live.length === cands.length ? cands : live);
    }
    v.rows = rows;
    for (const cands of rows) {
      const f = this.throughRow(v, cands, best);
      if (f !== null && betterUB(f, best)) best = f;
    }
    return best;
  }

  /**
   * The candidates of a node, per row: every usable row from its problem whose requirements the regime meets, at each
   * grid point of its free parameters; rows in order of their most promising candidate (good bounds found early prune
   * more), candidates of a row in grid order.
   */
  private candidates(v: Node): Array<readonly Candidate[]> {
    const env = this.regimeEnv(v.regime);
    const out: Array<{ cands: Candidate[]; min: Rate }> = [];
    for (const row of this.model.rowsBySource.get(v.problem) ?? []) {
      if (row.status !== 'ok' || !this.opts.usable(row)) continue;
      if (row.requires !== null && !v.regime.satisfies(row.requires)) continue;
      const cands: Candidate[] = [];
      let min: Rate = RATE_NONE;
      for (const theta of gridPoints(row.free, env, this.opts.settings.gridPoints)) {
        const prep = this.prepare(row, v.regime, theta);
        if (prep === null) continue;
        const rt = this.runtime(prep);
        if (rt === null) continue;
        let optimistic: Rate;
        try {
          optimistic = rowRate(evaluateF(prep, () => G.POLYLOG), rt);
        } catch (e) {
          if (e instanceof EvalError) continue;
          throw e;
        }
        if (!finiteRate(optimistic)) continue; // without bound (or unknown) whatever the calls cost
        cands.push({ row, theta, prep, optimistic });
        if (compareRates(optimistic, min, 0) < 0) min = optimistic;
      }
      if (cands.length > 0) out.push({ cands, min });
    }
    // (Array.prototype.sort is stable: equal rows keep the sheet order.)
    return out.sort((a, b) => compareRates(a.min, b.min, 0)).map((x) => x.cands);
  }

  /**
   * Best bound through one row: its grid candidates (skipping those that cannot beat the better of `incumbent` and
   * the row's best so far), then local refinement of the free parameters when the calls of at least two grid points
   * land in the same target regimes (cf. lower.ts); refinement only moves within those regimes, whose bounds are known.
   */
  private throughRow(v: Node, cands: readonly Candidate[], incumbent: UBFact | null): UBFact | null {
    const row = cands[0]!.row;
    let best: UBFact | null = null;
    const hits = new Map<string, number>();
    for (const c of cands) {
      if (cannotBeat(c.optimistic, best !== null && betterUB(best, incumbent) ? best : incumbent)) continue;
      const f = this.valueOf(v, c.prep, null);
      if (f === null) continue;
      hits.set(signature(f), (hits.get(signature(f)) ?? 0) + 1);
      if (betterUB(f, best)) best = f;
    }
    if (best !== null && best.origin.kind === 'row' && row.free.length > 0 && (hits.get(signature(best)) ?? 0) >= 2) {
      const keys = new Set(best.origin.children.map((c) => c.regime.key));
      const at = (theta: Theta): UBFact | null => {
        const prep = this.prepare(row, v.regime, theta);
        return prep === null ? null : this.valueOf(v, prep, keys);
      };
      // (Only points with the same power are compared: their exponents are on one scale.)
      const power = best.power;
      const objective = (theta: Theta): number | null => {
        const f = at(theta);
        return f === null || !samePower(f.power, power) ? null : -f.exponent;
      };
      const s = this.opts.settings;
      const r = refine(row.free, this.regimeEnv(v.regime), best.origin.theta, -best.exponent, objective, s.refineRounds, s.gridPoints);
      if (-r.value < best.exponent - TOL) {
        const g = at(r.theta);
        if (g !== null && betterUB(g, best)) best = g;
      }
    }
    return best;
  }

  /**
   * The bound through a prepared candidate of `v`, its calls valued at the bounds of their targets (read from `v`).
   * @param keys if given, the only target regimes allowed (other calls make it fail)
   * @returns null if a call has no bound or the result has none
   */
  private valueOf(v: Node, prep: PreparedRow, keys: ReadonlySet<string> | null): UBFact | null {
    const rt = this.runtime(prep);
    if (rt === null) return null;
    const row = prep.row;
    const children = new Map<string, UBFact>();
    try {
      const F = evaluateF(prep, (target, scale) => {
        if (keys !== null && !keys.has(target.key)) throw NO_BOUND;
        const c = this.read(v, this.node(row.target, target, this.childBudget(v)));
        if (c === null) throw NO_BOUND;
        children.set(target.key, c);
        return G.rateGrowth(c, scale);
      });
      const value = rowRate(F, rt);
      if (!finiteRate(value)) return null;
      const used = [...children.values()];
      return {
        problem: v.problem,
        regime: v.regime,
        exponent: value.exponent,
        power: value.power,
        steps: 1 + used.reduce((n, c) => n + c.steps, 0),
        origin: { kind: 'row', rowId: row.id, theta: prep.theta, children: used, rt: prep.rt },
      };
    } catch (e) {
      if (e instanceof EvalError) return null;
      throw e;
    }
  }

  /**
   * The limit of repeating the cycle of `lap` (SPEC §6.9): lap[0] = `f`, the new bound of a node, and each next
   * element a bound used by the previous one, down to the last, an earlier bound of the same node. Going around with
   * the same free parameters maps an exponent y of the earlier bound (at its power) to H(y); the limit is H's fixed
   * point below.
   * @returns null if the lap cannot be evaluated again, or changed the power of the bound
   */
  private cycleLimit(lap: readonly UBFact[], f: UBFact): UBFact | null {
    const base = lap[lap.length - 1]!;
    const power = base.power;
    if (!samePower(f.power, power)) return null;
    const steps: Array<{ prep: PreparedRow; rt: Rate; via: string; others: ReadonlyMap<string, Rate> }> = [];
    const rows: CompiledRow[] = [];
    for (let i = lap.length - 2; i >= 0; i--) {
      const g = lap[i]!;
      if (g.origin.kind !== 'row') return null;
      const row = this.model.rowsById.get(g.origin.rowId);
      const prep = row === undefined ? null : this.prepare(row, g.regime, g.origin.theta);
      const rt = prep === null ? null : this.runtime(prep);
      if (prep === null || rt === null) return null;
      rows.push(prep.row);
      steps.push({ prep, rt, via: lap[i + 1]!.regime.key, others: new Map(g.origin.children.map((c) => [c.regime.key, c])) });
    }
    const H = (y: number): number => {
      let x: Rate = { power, exponent: y };
      for (const s of steps) {
        try {
          const F = evaluateF(s.prep, (target, scale) => {
            const r = target.key === s.via ? x : s.others.get(target.key);
            if (r === undefined) throw NO_BOUND;
            return G.rateGrowth(r, scale);
          });
          x = rowRate(F, s.rt);
        } catch (e) {
          if (e instanceof EvalError) return NaN;
          throw e;
        }
      }
      // (A lap that ends at another power is not this map: a larger power improves nothing, a smaller one is not
      // repeated here.)
      return samePower(x.power, power) ? x.exponent : x.power > power ? Infinity : NaN;
    };
    // (A call under \min can make H neither convex nor concave: then the cycle is only repeated, a lap at a time.)
    const limit = shapeKnown(rows) ? iterationLimit(H, base.exponent, -1) : iteratedLimit(H, base.exponent, -1);
    if (!(limit < f.exponent)) return null;
    return { problem: f.problem, regime: f.regime, exponent: limit, power, steps: f.steps, origin: { kind: 'cycle', lap: lap.slice(0, -1), base } };
  }

  /**
   * For each reduction from `problem` (in sheet order), what it does for the upper bound at `regime`, with the bounds
   * found so far (ask `query` first).
   */
  explain(problem: string, regime: Regime): Array<{ readonly row: CompiledRow; readonly verdict: UBRowVerdict }> {
    const v = this.lookup(nodeKey(problem, regime));
    const best = v?.best ?? null;
    return (this.model.rowsBySource.get(problem) ?? []).map((row) => ({ row, verdict: this.verdict(v, row, regime, best) }));
  }

  private verdict(v: Node | undefined, row: CompiledRow, regime: Regime, best: UBFact | null): UBRowVerdict {
    if (row.status !== 'ok' || !this.opts.usable(row)) return { kind: 'unusable' };
    if (row.requires !== null && !regime.satisfies(row.requires)) return { kind: 'not-applicable', reason: `it applies only where ${row.requiresText ?? 'its restriction holds'}` };
    if (best !== null && best.origin.kind === 'row' && best.origin.rowId === row.id) return { kind: 'used', fact: best };
    let error = 'it does not evaluate at this regime';
    let weakest: UBFact | null = null;
    let optimistic: Rate = RATE_NONE;
    let missing: { target: Regime; searched: boolean } | null = null;
    for (const theta of gridPoints(row.free, this.regimeEnv(regime), this.opts.settings.gridPoints)) {
      let prep: PreparedRow;
      try {
        prep = prepareRow(this.model, row, regime, theta, this.opts.constants, this.opts.settings.gridPoints);
      } catch (e) {
        if (!(e instanceof EvalError)) throw e;
        error = `it does not evaluate at this regime (${e.message})`;
        continue;
      }
      const rt = this.runtime(prep);
      if (rt === null) {
        error = 'its reduction runtime is unknown (such rows are blocked in the settings)';
        continue;
      }
      const children = new Map<string, UBFact>();
      let pointOptimistic: Rate;
      try {
        pointOptimistic = rowRate(evaluateF(prep, () => G.POLYLOG), rt);
      } catch (e) {
        if (!(e instanceof EvalError)) throw e;
        error = `it does not evaluate at this regime (${e.message})`;
        continue;
      }
      if (!finiteRate(pointOptimistic)) continue;
      if (compareRates(pointOptimistic, optimistic, 0) < 0) optimistic = pointOptimistic;
      // (Only points that could beat the bound are searched: a missing call bound elsewhere explains nothing.)
      const searchable = !cannotBeat(pointOptimistic, best);
      try {
        const F = evaluateF(prep, (target, scale) => {
          const pair = nodeKey(row.target, target);
          const w = this.lookup(this.interest.has(pair) ? pair : `${pair}#${v === undefined ? this.opts.settings.maxDepthUB : this.childBudget(v)}`);
          if (w === undefined || w.best === null) {
            if (searchable) missing ??= { target, searched: w !== undefined && searched(w) && !UpperBounds.cutShort(w) };
            throw NO_BOUND;
          }
          children.set(target.key, w.best);
          return G.rateGrowth(w.best, scale);
        });
        const value = rowRate(F, rt);
        if (!finiteRate(value)) continue;
        const used = [...children.values()];
        const f: UBFact = {
          problem: row.source,
          regime,
          exponent: value.exponent,
          power: value.power,
          steps: 1 + used.reduce((n, c) => n + c.steps, 0),
          origin: { kind: 'row', rowId: row.id, theta, children: used, rt: prep.rt },
        };
        if (betterUB(f, weakest)) weakest = f;
      } catch (e) {
        if (!(e instanceof EvalError)) throw e;
        if (e !== NO_BOUND) error = `it does not evaluate at this regime (${e.message})`;
      }
    }
    if (weakest !== null) return { kind: 'weaker', fact: weakest };
    if (!finiteRate(optimistic)) return { kind: 'not-applicable', reason: error };
    if (cannotBeat(optimistic, best)) return { kind: 'skipped', optimistic };
    if (v !== undefined && !searched(v)) return { kind: 'not-searched' };
    // (assigned in a callback, which control-flow analysis does not see)
    const call = missing as { target: Regime; searched: boolean } | null;
    if (call !== null) return { kind: 'no-call-bound', target: row.target, regime: call.target, searched: call.searched };
    return { kind: 'not-applicable', reason: error };
  }

  /** Value of a knob at a regime, or null if it does not apply. */
  private knobValue(k: UBKnob, regime: Regime): UBFact | null {
    if (k.exponent !== null) {
      if (k.exactKeys === null || !k.exactKeys.has(regime.key)) return null;
      return { problem: k.problem, regime, exponent: k.exponent, power: k.power, steps: 0, origin: { kind: 'knob', knobId: k.id } };
    }
    if (k.formula === null) return null;
    if (k.filter !== null && !regime.satisfies(k.filter)) return null;
    try {
      const r = G.rateOf(evaluate(k.formula, { env: this.regimeEnv(regime) }));
      if (!finiteRate(r)) return null;
      return { problem: k.problem, regime, exponent: r.exponent, power: r.power, steps: 0, origin: { kind: 'knob', knobId: k.id } };
    } catch (err) {
      if (err instanceof EvalError) return null;
      throw err;
    }
  }

  /** The constants and the classes of the regime's parameters. */
  private regimeEnv(regime: Regime): Map<string, Growth> {
    const env = new Map<string, Growth>(this.opts.constants);
    for (const [p, g] of regime.env()) env.set(p, g);
    return env;
  }

  /** The row prepared at a regime and point, or null if it does not evaluate there. */
  private prepare(row: CompiledRow, regime: Regime, theta: Theta): PreparedRow | null {
    try {
      return prepareRow(this.model, row, regime, theta, this.opts.constants, this.opts.settings.gridPoints);
    } catch (e) {
      if (e instanceof EvalError) return null;
      throw e;
    }
  }

  /** The reduction runtime's rate (rate zero when unknown and assumed negligible), or null if the row is blocked. */
  private runtime(prep: PreparedRow): Rate | null {
    if (prep.rt !== null) return prep.rt;
    return this.opts.settings.unknownRT === 'block' ? null : RATE_ZERO;
  }
}

/** The problems in each bound's derivation (memoized: derivations share their parts). */
const problemsMemo = new WeakMap<UBFact, ReadonlySet<string>>();

/** The problems of the bounds in `f`'s derivation, `f`'s own included. */
function problemsIn(f: UBFact): ReadonlySet<string> {
  let s = problemsMemo.get(f);
  if (s === undefined) {
    const out = new Set<string>([f.problem]);
    for (const c of ubParts(f)) for (const p of problemsIn(c)) out.add(p);
    s = out;
    problemsMemo.set(f, s);
  }
  return s;
}

/**
 * If `f`'s derivation uses an earlier, worse bound of its own problem and regime (it improved that bound by going
 * around a cycle), the bounds from `f` down to that one (both included); else null.
 */
export function cycleThrough(f: UBFact): UBFact[] | null {
  if (f.origin.kind !== 'row' || !f.origin.children.some((c) => problemsIn(c).has(f.problem))) return null;
  const seen = new Set<UBFact>();
  const path: UBFact[] = [f];
  const search = (g: UBFact): boolean => {
    for (const c of ubParts(g)) {
      if (seen.has(c) || !problemsIn(c).has(f.problem)) continue;
      seen.add(c);
      path.push(c);
      if (c.problem === f.problem && c.regime.key === f.regime.key) {
        if (compareRates(c, f, TOL) > 0) return true;
      } else if (search(c)) return true;
      path.pop();
    }
    return false;
  };
  return search(f) ? path : null;
}
