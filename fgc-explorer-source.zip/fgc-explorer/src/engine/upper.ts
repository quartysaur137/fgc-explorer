/**
 * Upper-bound evaluation (SPEC §2.5, §6.6): algorithms flow backward along reductions.
 */

import { evaluate } from '../growth/evaluate';
import * as G from '../growth/growth';
import { EvalError, Growth } from '../growth/growth';
import { Expr } from '../math/ast';
import { CompiledRow, Model } from '../model/model';
import { ParamSpec, Regime } from '../model/regime';
import { gridPoints, refine, Theta } from './freeparams';
import { PropagationOptions, TOL } from './lower';
import { evaluateF, prepareRow, PreparedRow } from './rowEval';

export type UBOrigin =
  | { readonly kind: 'knob'; readonly knobId: string }
  | {
      readonly kind: 'row';
      readonly rowId: string;
      readonly theta: Theta;
      /** The upper bounds used for the row's calls. */
      readonly children: readonly UBFact[];
      readonly rtExponent: number | null;
    };

/** "`problem` has an N^{exponent+o(1)} algorithm on instances of `regime`" (SPEC §2.4). */
export interface UBFact {
  readonly problem: string;
  readonly regime: Regime;
  readonly exponent: number;
  readonly origin: UBOrigin;
}

/** An upper-bound knob prepared for evaluation. */
export interface UBKnob {
  readonly id: string;
  readonly problem: string;
  /** Exponent knobs: the regime keys where the exponent applies. */
  readonly exactKeys: ReadonlySet<string> | null;
  readonly exponent: number | null;
  /** Formula knobs: the runtime formula and an optional regime filter. */
  readonly formula: Expr | null;
  readonly filter: ReadonlyMap<string, ParamSpec> | null;
}

/** Thrown (as one shared instance, to avoid building stack traces in the search) when a call has no upper bound. */
const NO_BOUND = new EvalError('no upper bound for a call');

/**
 * Memoized, depth-limited upper-bound queries. One instance per analysis (knobs and settings are fixed).
 */
export class UpperBounds {
  private readonly memo = new Map<string, UBFact | null>();
  private readonly knobsByProblem = new Map<string, UBKnob[]>();
  private queries = 0;

  constructor(
    private readonly model: Model,
    knobs: readonly UBKnob[],
    private readonly opts: PropagationOptions,
  ) {
    for (const k of knobs) {
      const list = this.knobsByProblem.get(k.problem) ?? [];
      list.push(k);
      this.knobsByProblem.set(k.problem, list);
    }
  }

  /** Number of distinct (problem, regime, depth) queries evaluated so far. */
  get queryCount(): number {
    return this.queries;
  }

  /**
   * Best upper bound for `problem` at `regime` using at most `depth` reductions.
   * @returns null if no bound is known
   */
  query(problem: string, regime: Regime, depth: number = this.opts.settings.maxDepthUB): UBFact | null {
    const key = `${problem}#${regime.key}#${depth}`;
    if (this.memo.has(key)) return this.memo.get(key)!;
    this.memo.set(key, null); // (depth strictly decreases, so this is never read during the computation)
    this.queries += 1;
    let best: UBFact | null = null;
    const consider = (f: UBFact | null): void => {
      if (f !== null && Number.isFinite(f.exponent) && (best === null || f.exponent < best.exponent - TOL)) best = f;
    };
    for (const k of this.knobsByProblem.get(problem) ?? []) consider(this.knobValue(k, regime));
    if (depth > 0) {
      for (const row of this.model.rowsBySource.get(problem) ?? []) {
        if (row.status !== 'ok' || !this.opts.usable(row)) continue;
        consider(this.throughRow(row, regime, depth, best === null ? Infinity : (best as UBFact).exponent));
      }
    }
    this.memo.set(key, best);
    return best;
  }

  /** Value of a knob at a regime, or null if it does not apply. */
  private knobValue(k: UBKnob, regime: Regime): UBFact | null {
    if (k.exponent !== null) {
      if (k.exactKeys === null || !k.exactKeys.has(regime.key)) return null;
      return { problem: k.problem, regime, exponent: k.exponent, origin: { kind: 'knob', knobId: k.id } };
    }
    if (k.formula === null) return null;
    if (k.filter !== null && !regime.satisfies(k.filter)) return null;
    try {
      const env = new Map<string, Growth>(this.opts.constants);
      for (const [p, g] of regime.env()) env.set(p, g);
      const e = G.exponentOf(evaluate(k.formula, { env }));
      if (!Number.isFinite(e)) return null;
      return { problem: k.problem, regime, exponent: Math.max(0, e), origin: { kind: 'knob', knobId: k.id } };
    } catch (err) {
      if (err instanceof EvalError) return null;
      throw err;
    }
  }

  /**
   * Best bound through one row (grid search + refinement over its free parameters), or null if none is below `bound`
   * (branch and bound: candidates that cannot beat the best bound so far are not explored).
   */
  private throughRow(row: CompiledRow, regime: Regime, depth: number, bound: number): UBFact | null {
    if (row.requires !== null && !regime.satisfies(row.requires)) return null;
    const env = new Map(this.opts.constants);
    for (const [p, g] of regime.env()) env.set(p, g);
    let best: UBFact | null = null;
    const hits = new Map<string, number>();
    const signature = (f: UBFact): string => (f.origin.kind === 'row' ? f.origin.children.map((c) => c.regime.key).sort().join(';') : '');
    for (const theta of gridPoints(row.free, env, this.opts.settings.gridPoints)) {
      const f = this.attempt(row, regime, theta, depth, best === null ? bound : Math.min(bound, best.exponent));
      if (f === null) continue;
      hits.set(signature(f), (hits.get(signature(f)) ?? 0) + 1);
      if (best === null || f.exponent < best.exponent - TOL) best = f;
    }
    // Refine only when the calls of several grid points land in the same target regimes (cf. lower.ts).
    if (best !== null && row.free.length > 0 && best.origin.kind === 'row' && (hits.get(signature(best)) ?? 0) >= 2) {
      const objective = (theta: Theta): number | null => {
        const f = this.attempt(row, regime, theta, depth, Infinity);
        return f === null ? null : -f.exponent;
      };
      const r = refine(row.free, env, best.origin.theta, -best.exponent, objective, this.opts.settings.refineRounds, this.opts.settings.gridPoints);
      if (-r.value < best.exponent - TOL) {
        const f = this.attempt(row, regime, r.theta, depth, Infinity);
        if (f !== null) best = f;
      }
    }
    return best;
  }

  /** The bound through `row` at `theta`, or null if it does not evaluate or cannot be below `bound`. */
  private attempt(row: CompiledRow, regime: Regime, theta: Theta, depth: number, bound: number): UBFact | null {
    let prep: PreparedRow;
    try {
      prep = prepareRow(this.model, row, regime, theta, this.opts.constants, this.opts.settings.gridPoints);
    } catch (e) {
      if (e instanceof EvalError) return null;
      throw e;
    }
    let rt = prep.rtExponent;
    if (rt === null) {
      if (this.opts.settings.unknownRT === 'block') return null;
      rt = -Infinity;
    }
    const children = new Map<string, UBFact>();
    try {
      // Optimistic value (every call worth N^0): if even that cannot beat `bound`, skip the queries.
      if (rt >= bound - TOL || Math.max(G.exponentOf(evaluateF(prep, () => G.SUBPOLY)), rt) >= bound - TOL) return null;
      const F = evaluateF(prep, (target, scale) => {
        const c = this.query(row.target, target, depth - 1);
        if (c === null) throw NO_BOUND;
        children.set(c.regime.key, c);
        return G.poly(scale * c.exponent);
      });
      const value = Math.max(G.exponentOf(F), rt, 0);
      if (!Number.isFinite(value)) return null;
      return {
        problem: row.source,
        regime,
        exponent: value,
        origin: { kind: 'row', rowId: row.id, theta, children: [...children.values()], rtExponent: prep.rtExponent },
      };
    } catch (e) {
      if (e instanceof EvalError) return null;
      throw e;
    }
  }
}
