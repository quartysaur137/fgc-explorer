/**
 * Lower-bound propagation (SPEC §2.5, §6.5): hardness flows forward along reductions.
 */

import * as G from '../growth/growth';
import { compareRates, EvalError, Growth, Rate } from '../growth/growth';
import { Settings } from '../model/config';
import { CompiledRow, Model } from '../model/model';
import { Regime } from '../model/regime';
import { DIVERGENCE_EXPONENT, iteratedLimit, iterationLimit, shapeKnown } from './cycles';
import { gridPoints, refine, Theta } from './freeparams';
import { evaluateF, prepareRow, PreparedRow } from './rowEval';

export type LBOrigin =
  | { readonly kind: 'knob'; readonly knobId: string }
  | {
      readonly kind: 'row';
      readonly rowId: string;
      readonly theta: Theta;
      readonly parent: LBFact;
      /** The rate of the reduction runtime (null: unknown). */
      readonly rt: Rate | null;
    }
  | {
      /**
       * The limit of repeating a cycle of reductions that raises the bound each time (SPEC §6.9): `closing` came back
       * to this problem and regime around the cycle from `base`, an earlier and smaller bound in its chain.
       */
      readonly kind: 'cycle';
      readonly closing: LBFact;
      readonly base: LBFact;
    };

/**
 * "For every ε > 0, `problem` has no algorithm on instances of `regime` running in time 2^{(exponent−ε)·L^power}"
 * (L = log2 N; power 1: N^{exponent−ε}; SPEC §2.4); an infinite exponent at power 1: no polynomial-time algorithm. The
 * power is that of the knob the bound derives from (a reduction keeps it).
 */
export interface LBFact extends Rate {
  readonly problem: string;
  readonly regime: Regime;
  /** Number of reductions between the fact and its knob (for the limit of a cycle: those of its closing fact). */
  readonly hops: number;
  readonly origin: LBOrigin;
}

/** A row that, given an LB fact for its source, would solve the source below its lower bound regardless of the target. */
export interface Inconsistency {
  readonly rowId: string;
  readonly parent: LBFact;
  readonly theta: Theta;
  readonly message: string;
}

export interface LBResult {
  /** Best fact per problem and regime key. */
  readonly facts: ReadonlyMap<string, ReadonlyMap<string, LBFact>>;
  readonly inconsistencies: readonly Inconsistency[];
  /** Messages about caps that were hit (results may be incomplete). */
  readonly capped: readonly string[];
  readonly pops: number;
  /** The limits of cycles that raise a bound each time around (SPEC §6.9) that are still the best bounds. */
  readonly cycles: readonly LBFact[];
}

export interface PropagationOptions {
  readonly settings: Settings;
  readonly constants: ReadonlyMap<string, Growth>;
  /** Whether a row (status ok) may be used under the current settings. */
  readonly usable: (row: CompiledRow) => boolean;
}

/** Improvement threshold for exponents. */
export const TOL = 1e-9;
/** Largest exponent considered by the threshold search. */
export const X_MAX = 64;
export const MAX_POPS = 20000;
export const MAX_KEYS_PER_PROBLEM = 400;
/** Limits of raising cycles computed per (problem, regime) at most (each later one starts closer to the fixed point). */
const MAX_CYCLE_LIMITS = 8;

/**
 * Exponent of the From-time at power `power` (see exponentAtPower) when every non-degenerate call takes time of rate
 * (power, x) at its target: N'^x for power 1, 2^{x·log^a N'} for power a.
 */
export function fromExponentAt(prep: PreparedRow, x: number, power = 1): number {
  const rate: Rate = { power, exponent: x };
  return G.exponentAtPower(
    evaluateF(prep, (_r, s) => G.rateGrowth(rate, s)),
    power,
  );
}

/**
 * Smallest x in [0, xMax] with g(x) ≥ L, for g nondecreasing (and, in practice, piecewise linear).
 * Uses the Illinois variant of regula falsi on a bracket [lo, hi] with g(lo) < L ≤ g(hi), which converges in a few
 * steps on piecewise-linear functions, interleaved with bisection steps, to within 1e-9.
 * @returns 0 if g(0) ≥ L; 'unbounded' if g(xMax) < L.
 */
export function threshold(g: (x: number) => number, L: number, xMax: number = X_MAX): number | 'unbounded' {
  const target = L - TOL;
  const g0 = g(0);
  if (g0 >= target) return 0;
  let lo = 0;
  let hi = xMax;
  let hLo = g0 - target;
  let hHi = g(xMax) - target;
  if (hHi < 0) return 'unbounded';
  if (!Number.isFinite(hHi)) {
    // g is superpolynomial at xMax: shrink the bracket by doubling from 1 until finite (or bisection fallback).
    for (let x = 1; x < xMax; x *= 2) {
      const h = g(x) - target;
      if (h >= 0) {
        hi = x;
        hHi = h;
        break;
      }
      lo = x;
      hLo = h;
    }
  }
  let side = 0;
  for (let i = 0; i < 100 && hi - lo > 1e-9; i++) {
    let x = Number.isFinite(hHi) ? (lo * hHi - hi * hLo) / (hHi - hLo) : (lo + hi) / 2;
    if (!(x > lo && x < hi)) x = (lo + hi) / 2;
    const h = g(x) - target;
    if (h >= 0) {
      hi = x;
      hHi = h;
      if (side === 1) hLo /= 2;
      side = 1;
    } else {
      lo = x;
      hLo = h;
      if (side === -1) hHi /= 2;
      side = -1;
    }
    // Regula falsi can stall on one side; switch to bisection steps when the bracket stops shrinking fast.
    if (i % 4 === 3) {
      const mid = (lo + hi) / 2;
      const hm = g(mid) - target;
      if (hm >= 0) {
        hi = mid;
        hHi = hm;
      } else {
        lo = mid;
        hLo = hm;
      }
    }
  }
  return hi;
}

interface Candidate {
  readonly regime: Regime;
  readonly x: number;
  readonly theta: Theta;
  readonly rt: Rate | null;
}

type Attempt = { kind: 'ok'; cand: Candidate } | { kind: 'none'; reason: string } | { kind: 'inconsistent'; message: string };

/** One LB derivation attempt through `row` from fact `f` with free parameters `theta`. */
function attempt(model: Model, row: CompiledRow, f: LBFact, theta: Theta, opts: PropagationOptions): Attempt {
  let prep: PreparedRow;
  try {
    prep = prepareRow(model, row, f.regime, theta, opts.constants, opts.settings.gridPoints);
  } catch (e) {
    if (e instanceof EvalError) return { kind: 'none', reason: `it does not evaluate there (${e.message})` };
    throw e;
  }
  const L = f.exponent;
  const P = f.power;
  const rt = prep.rt;
  if (rt === null && opts.settings.unknownRT === 'block') return { kind: 'none', reason: 'its reduction runtime is unknown (such rows are blocked in the settings)' };
  if (rt !== null && compareRates(rt, f, TOL) >= 0) {
    return { kind: 'none', reason: `the reduction itself takes time ${f.regime.timeText(rt)}, not less than the lower bound ${f.regime.timeText(f)} it would transfer` };
  }
  try {
    const keys = new Map<string, Regime>();
    let minScale = Infinity;
    evaluateF(prep, (_r, s) => G.poly(s), (site) => {
      if (site.regime !== null && !keys.has(site.regime.key)) keys.set(site.regime.key, site.regime);
      if (site.regime !== null) minScale = Math.min(minScale, site.scale);
    });
    const g = (x: number): number => fromExponentAt(prep, x, P);
    if (keys.size === 0) {
      if (g(0) < L - TOL) {
        const message =
          L === Infinity
            ? 'the From-time is polynomial without any non-trivial call, against a superpolynomial lower bound'
            : `the From-time is below the lower bound ${f.regime.timeText(f)} without any non-trivial call`;
        return { kind: 'inconsistent', message };
      }
      return { kind: 'none', reason: 'its calls are all on instances of constant or polylogarithmic size' };
    }
    if (keys.size > 1) return { kind: 'none', reason: 'its calls land in several regimes of the target (no single-regime bound)' };
    const regime = [...keys.values()][0]!;
    if (L === Infinity) {
      // No polynomial-time algorithm for the source: none for the target either, if its cost can grow without limit.
      // (g is affine far beyond its breakpoints: it grows without limit if it still grows there.)
      if (g(2 * DIVERGENCE_EXPONENT) > g(DIVERGENCE_EXPONENT) + TOL) return { kind: 'ok', cand: { regime, x: Infinity, theta, rt } };
      return { kind: 'inconsistent', message: 'the From-time stays polynomial for every running time of the target, below the superpolynomial lower bound' };
    }
    // A call whose normalizer is N^s needs x up to about L/s^a to reach L (e.g. a target normalized by a tiny parameter).
    const x = threshold(g, L, Math.max(X_MAX, (2 * (L + 1)) / minScale ** P));
    if (x === 'unbounded') {
      return { kind: 'inconsistent', message: `the From-time stays below the lower bound ${f.regime.timeText(f)} for every running time of the target` };
    }
    if (x <= TOL) return { kind: 'none', reason: 'its overhead alone already reaches the lower bound, so it says nothing about the target' };
    return { kind: 'ok', cand: { regime, x, theta, rt } };
  } catch (e) {
    if (e instanceof EvalError) return { kind: 'none', reason: `it does not evaluate there (${e.message})` };
    throw e;
  }
}

/**
 * All LB facts derivable through `row` from fact `f` (best per target regime key, after grid search and refinement).
 * @param inconsistencies receives the inconsistencies found
 * @param reasons if given, counts why grid points gave nothing
 */
export function deriveThroughRow(
  model: Model,
  row: CompiledRow,
  f: LBFact,
  opts: PropagationOptions,
  inconsistencies: Inconsistency[] = [],
  reasons?: Map<string, number>,
): LBFact[] {
  if (row.requires !== null && !f.regime.satisfies(row.requires)) {
    // (Counted 0: where the row applies, the reason it gives nothing says more.)
    const reason = `it applies only where ${row.requiresText ?? 'its restriction holds'}`;
    reasons?.set(reason, reasons.get(reason) ?? 0);
    return [];
  }
  const env = new Map(opts.constants);
  for (const [p, g] of f.regime.env()) env.set(p, g);
  const best = new Map<string, Candidate>();
  const hits = new Map<string, number>();
  for (const theta of gridPoints(row.free, env, opts.settings.gridPoints)) {
    const a = attempt(model, row, f, theta, opts);
    if (a.kind === 'inconsistent') {
      if (!inconsistencies.some((i) => i.rowId === row.id && i.parent === f)) {
        inconsistencies.push({ rowId: row.id, parent: f, theta, message: a.message });
      }
      const reason = `it would solve the source below its lower bound (${a.message})`;
      reasons?.set(reason, (reasons.get(reason) ?? 0) + 1);
      continue;
    }
    if (a.kind !== 'ok') {
      reasons?.set(a.reason, (reasons.get(a.reason) ?? 0) + 1);
      continue;
    }
    const key = a.cand.regime.key;
    hits.set(key, (hits.get(key) ?? 0) + 1);
    const cur = best.get(key);
    if (cur === undefined || a.cand.x > cur.x + TOL) best.set(key, a.cand);
  }
  const out: LBFact[] = [];
  for (const [key, cand] of best) {
    let chosen = cand;
    // Refine only when several grid points reach this target regime: if the regime moves with the free parameters,
    // a perturbed point lands in another regime anyway (those points are separate facts of a trade-off).
    if (row.free.length > 0 && (hits.get(key) ?? 0) >= 2) {
      const objective = (theta: Theta): number | null => {
        const a = attempt(model, row, f, theta, opts);
        return a.kind === 'ok' && a.cand.regime.key === key ? a.cand.x : null;
      };
      const r = refine(row.free, env, cand.theta, cand.x, objective, opts.settings.refineRounds, opts.settings.gridPoints);
      if (r.value > cand.x + TOL) {
        const a = attempt(model, row, f, r.theta, opts);
        if (a.kind === 'ok') chosen = a.cand;
      }
    }
    out.push({
      problem: row.target,
      regime: chosen.regime,
      exponent: chosen.x,
      power: f.power,
      hops: f.hops + 1,
      origin: { kind: 'row', rowId: row.id, theta: chosen.theta, parent: f, rt: chosen.rt },
    });
  }
  return out;
}

/** What a reduction into a problem does for its lower bound at one regime (see explainLower). */
export type LBRowVerdict =
  /** It derives the problem's lower bound there. */
  | { readonly kind: 'used'; readonly fact: LBFact }
  /** It derives a lower bound there that is not better (or as good through more reductions). */
  | { readonly kind: 'weaker'; readonly fact: LBFact }
  /** The source has no lower bound. */
  | { readonly kind: 'no-source-bound' }
  /** From the source's lower bounds it derives bounds only at other regimes of the problem. */
  | { readonly kind: 'elsewhere'; readonly regimes: readonly Regime[] }
  /** It derives nothing from the source's lower bounds; `reason` is the most frequent cause, for `from`. */
  | { readonly kind: 'fails'; readonly reason: string; readonly from: LBFact }
  /** The engine does not use it (unsupported formulas or the settings): see the row. */
  | { readonly kind: 'unusable' };

/** Lower bounds of a source tried per reduction by explainLower at most (fewest reductions first). */
const EXPLAIN_SOURCE_FACTS = 24;

/**
 * For each reduction into `problem` (in sheet order), what it does for the lower bound at `regime`, from the lower
 * bounds its source has in `result`.
 */
export function explainLower(
  model: Model,
  result: LBResult,
  problem: string,
  regime: Regime,
  opts: PropagationOptions,
): Array<{ readonly row: CompiledRow; readonly verdict: LBRowVerdict }> {
  const current = result.facts.get(problem)?.get(regime.key);
  const out: Array<{ row: CompiledRow; verdict: LBRowVerdict }> = [];
  for (const row of model.rows) {
    if (row.target !== problem) continue;
    if (row.status !== 'ok' || !opts.usable(row)) {
      out.push({ row, verdict: { kind: 'unusable' } });
      continue;
    }
    if (current !== undefined && current.origin.kind === 'row' && current.origin.rowId === row.id) {
      out.push({ row, verdict: { kind: 'used', fact: current } });
      continue;
    }
    const sources = [...(result.facts.get(row.source)?.values() ?? [])].sort((a, b) => a.hops - b.hops || compareRates(b, a, 0));
    if (sources.length === 0) {
      out.push({ row, verdict: { kind: 'no-source-bound' } });
      continue;
    }
    let here: LBFact | undefined;
    const elsewhere = new Map<string, Regime>();
    // Why grid points gave nothing: how often, and the first source bound for which it happened.
    const reasons = new Map<string, { count: number; from: LBFact }>();
    for (const f of sources.slice(0, EXPLAIN_SOURCE_FACTS)) {
      const mine = new Map<string, number>();
      for (const g of deriveThroughRow(model, row, f, opts, [], mine)) {
        if (g.regime.key === regime.key) {
          if (betterLB(g, here)) here = g;
        } else elsewhere.set(g.regime.key, g.regime);
      }
      for (const [reason, count] of mine) {
        const r = reasons.get(reason);
        reasons.set(reason, { count: (r?.count ?? 0) + count, from: r?.from ?? f });
      }
    }
    if (here !== undefined) out.push({ row, verdict: { kind: 'weaker', fact: here } });
    else if (elsewhere.size > 0) out.push({ row, verdict: { kind: 'elsewhere', regimes: [...elsewhere.values()] } });
    else {
      const top = [...reasons.entries()].sort((a, b) => b[1].count - a[1].count)[0];
      out.push({ row, verdict: { kind: 'fails', reason: top?.[0] ?? 'it derives nothing', from: top?.[1].from ?? sources[0]! } });
    }
  }
  return out;
}

/**
 * Whether `f` is a better lower bound than `g` (or than none): a larger rate (a larger power, or the same power and a
 * larger exponent), or one equal within TOL reached through fewer reductions (short derivations, without detours).
 */
export function betterLB(f: LBFact, g: LBFact | undefined): boolean {
  if (g === undefined) return true;
  const c = compareRates(f, g, TOL);
  return c > 0 || (c === 0 && f.hops < g.hops);
}

/**
 * Forward propagation from `seeds` (SPEC §6.5): a FIFO worklist that keeps the best fact per (problem, regime key)
 * (see betterLB); a fact that replaces another is propagated again, until nothing improves (there is no limit on the
 * length of derivations). A fact that came back around a cycle to its own problem and regime, raising the bound it
 * started from, is replaced by the limit of repeating that cycle (SPEC §6.9).
 */
export function propagateLB(model: Model, seeds: readonly LBFact[], opts: PropagationOptions): LBResult {
  const facts = new Map<string, Map<string, LBFact>>();
  const queue: LBFact[] = [];
  const capped = new Set<string>();
  const inconsistencies: Inconsistency[] = [];
  const limits = new Map<string, number>();
  const cycles: LBFact[] = [];
  const offer = (f: LBFact): void => {
    let m = facts.get(f.problem);
    if (m === undefined) {
      m = new Map();
      facts.set(f.problem, m);
    }
    const cur = m.get(f.regime.key);
    if (!betterLB(f, cur)) return;
    if (cur === undefined && m.size >= MAX_KEYS_PER_PROBLEM) {
      capped.add(`more than ${MAX_KEYS_PER_PROBLEM} regimes with lower bounds for ${f.problem}; further ones were dropped`);
      return;
    }
    const key = `${f.problem}#${f.regime.key}`;
    const base = (limits.get(key) ?? 0) < MAX_CYCLE_LIMITS ? cycleBase(f) : null;
    if (base !== null) {
      limits.set(key, (limits.get(key) ?? 0) + 1);
      const limit = cycleLimit(model, f, base, opts);
      if (limit !== null) {
        f = limit;
        cycles.push(limit);
      }
    }
    m.set(f.regime.key, f);
    queue.push(f);
  };
  seeds.forEach(offer);
  let head = 0;
  let pops = 0;
  while (head < queue.length) {
    if (pops >= MAX_POPS) {
      capped.add(`stopped after ${MAX_POPS} propagation steps`);
      break;
    }
    const f = queue[head++]!;
    pops += 1;
    if (facts.get(f.problem)?.get(f.regime.key) !== f) continue; // superseded by a better fact
    for (const row of model.rowsBySource.get(f.problem) ?? []) {
      if (row.status !== 'ok' || !opts.usable(row)) continue;
      for (const g of deriveThroughRow(model, row, f, opts, inconsistencies)) offer(g);
    }
  }
  // (A limit that a better bound replaced later no longer matters.)
  const current = cycles.filter((f) => facts.get(f.problem)?.get(f.regime.key) === f);
  return { facts, inconsistencies, capped: [...capped], pops, cycles: current };
}

/** The fact in `f`'s chain (f excluded) at f's problem and regime with a smaller exponent, if any (nearest first). */
function cycleBase(f: LBFact): LBFact | null {
  if (f.origin.kind !== 'row') return null;
  for (let g: LBFact | null = f.origin.parent; g !== null; g = g.origin.kind === 'row' ? g.origin.parent : g.origin.kind === 'cycle' ? g.origin.closing : null) {
    if (g.problem === f.problem && g.regime.key === f.regime.key) return G.samePower(g.power, f.power) && g.exponent < f.exponent - TOL ? g : null;
  }
  return null;
}

/**
 * The limit of repeating the cycle from `base` to `closing` (SPEC §6.9): going around it with the same free parameters
 * maps an exponent x of `base` to H(x) at the same problem and regime; the limit is H's nearest fixed point above
 * (Infinity if there is none).
 * @returns null if it is no larger than closing's exponent
 */
function cycleLimit(model: Model, closing: LBFact, base: LBFact, opts: PropagationOptions): LBFact | null {
  // The lap: the facts after `base` up to `closing`, all derived through a row (else it cannot be repeated as is).
  const lap: LBFact[] = [];
  for (let g = closing; g !== base; g = g.origin.parent) {
    if (g.origin.kind !== 'row') return null;
    lap.unshift(g);
  }
  const H = (x: number): number => {
    let cur: LBFact = { ...base, exponent: x };
    for (const g of lap) {
      const row = model.rowsById.get((g.origin as { rowId: string }).rowId);
      if (row === undefined) return NaN;
      const a = attempt(model, row, cur, (g.origin as { theta: Theta }).theta, opts);
      if (a.kind !== 'ok' || a.cand.regime.key !== g.regime.key) return NaN;
      cur = { ...g, exponent: a.cand.x };
    }
    return cur.exponent;
  };
  // (A call under \min can make H neither convex nor concave: then the cycle is only repeated, a lap at a time.)
  const rows = lap.map((g) => model.rowsById.get((g.origin as { rowId: string }).rowId)!);
  const limit = shapeKnown(rows) ? iterationLimit(H, base.exponent, 1) : iteratedLimit(H, base.exponent, 1);
  if (!(limit > closing.exponent + TOL)) return null;
  return { problem: closing.problem, regime: closing.regime, exponent: limit, power: closing.power, hops: closing.hops, origin: { kind: 'cycle', closing, base } };
}

/** The chain of facts from `f` back to its knob (f first; for the limit of a cycle, its closing fact next). */
export function lbChain(f: LBFact): LBFact[] {
  const out: LBFact[] = [f];
  let cur = f;
  while (cur.origin.kind !== 'knob') {
    cur = cur.origin.kind === 'row' ? cur.origin.parent : cur.origin.closing;
    out.push(cur);
  }
  return out;
}
