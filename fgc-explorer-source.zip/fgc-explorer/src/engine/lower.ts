/**
 * Lower-bound propagation (SPEC §2.5, §6.5): hardness flows forward along reductions.
 */

import * as G from '../growth/growth';
import { EvalError, Growth } from '../growth/growth';
import { Settings } from '../model/config';
import { CompiledRow, Model } from '../model/model';
import { Regime } from '../model/regime';
import { gridPoints, refine, Theta } from './freeparams';
import { evaluateF, prepareRow, PreparedRow } from './rowEval';

export type LBOrigin =
  | { readonly kind: 'knob'; readonly knobId: string }
  | {
      readonly kind: 'row';
      readonly rowId: string;
      readonly theta: Theta;
      readonly parent: LBFact;
      readonly rtExponent: number | null;
    };

/** "For every ε > 0, `problem` has no N^{exponent−ε} algorithm on instances of `regime`" (SPEC §2.4). */
export interface LBFact {
  readonly problem: string;
  readonly regime: Regime;
  readonly exponent: number;
  /** Number of reductions between the fact and its knob. */
  readonly hops: number;
  readonly origin: LBOrigin;
}

/** A row that, given an LB fact for its source, would solve the source below its lower bound regardless of the target. */
export interface Inconsistency {
  readonly rowId: string;
  readonly parent: LBFact;
  readonly theta: Theta;
  readonly message: string;
}

export interface LBResult {
  /** Best fact per problem and regime key. */
  readonly facts: ReadonlyMap<string, ReadonlyMap<string, LBFact>>;
  readonly inconsistencies: readonly Inconsistency[];
  /** Messages about caps that were hit (results may be incomplete). */
  readonly capped: readonly string[];
  readonly pops: number;
}

export interface PropagationOptions {
  readonly settings: Settings;
  readonly constants: ReadonlyMap<string, Growth>;
  /** Whether a row (status ok) may be used under the current settings. */
  readonly usable: (row: CompiledRow) => boolean;
}

/** Improvement threshold for exponents. */
export const TOL = 1e-9;
/** Largest exponent considered by the threshold search. */
export const X_MAX = 64;
export const MAX_POPS = 20000;
export const MAX_KEYS_PER_PROBLEM = 400;

/** Exponent of the From-time when every non-degenerate call is worth (normalizer)^x. */
export function fromExponentAt(prep: PreparedRow, x: number): number {
  return G.exponentOf(evaluateF(prep, (_r, s) => G.poly(s * x)));
}

/**
 * Smallest x in [0, xMax] with g(x) ≥ L, for g nondecreasing (and, in practice, piecewise linear).
 * Uses the Illinois variant of regula falsi on a bracket [lo, hi] with g(lo) < L ≤ g(hi), which converges in a few
 * steps on piecewise-linear functions, interleaved with bisection steps, to within 1e-9.
 * @returns 0 if g(0) ≥ L; 'unbounded' if g(xMax) < L.
 */
export function threshold(g: (x: number) => number, L: number, xMax: number = X_MAX): number | 'unbounded' {
  const target = L - TOL;
  const g0 = g(0);
  if (g0 >= target) return 0;
  let lo = 0;
  let hi = xMax;
  let hLo = g0 - target;
  let hHi = g(xMax) - target;
  if (hHi < 0) return 'unbounded';
  if (!Number.isFinite(hHi)) {
    // g is superpolynomial at xMax: shrink the bracket by doubling from 1 until finite (or bisection fallback).
    for (let x = 1; x < xMax; x *= 2) {
      const h = g(x) - target;
      if (h >= 0) {
        hi = x;
        hHi = h;
        break;
      }
      lo = x;
      hLo = h;
    }
  }
  let side = 0;
  for (let i = 0; i < 100 && hi - lo > 1e-9; i++) {
    let x = Number.isFinite(hHi) ? (lo * hHi - hi * hLo) / (hHi - hLo) : (lo + hi) / 2;
    if (!(x > lo && x < hi)) x = (lo + hi) / 2;
    const h = g(x) - target;
    if (h >= 0) {
      hi = x;
      hHi = h;
      if (side === 1) hLo /= 2;
      side = 1;
    } else {
      lo = x;
      hLo = h;
      if (side === -1) hHi /= 2;
      side = -1;
    }
    // Regula falsi can stall on one side; switch to bisection steps when the bracket stops shrinking fast.
    if (i % 4 === 3) {
      const mid = (lo + hi) / 2;
      const hm = g(mid) - target;
      if (hm >= 0) {
        hi = mid;
        hHi = hm;
      } else {
        lo = mid;
        hLo = hm;
      }
    }
  }
  return hi;
}

interface Candidate {
  readonly regime: Regime;
  readonly x: number;
  readonly theta: Theta;
  readonly rtExponent: number | null;
}

type Attempt = { kind: 'ok'; cand: Candidate } | { kind: 'none' } | { kind: 'inconsistent'; message: string };

/** One LB derivation attempt through `row` from fact `f` with free parameters `theta`. */
function attempt(model: Model, row: CompiledRow, f: LBFact, theta: Theta, opts: PropagationOptions): Attempt {
  let prep: PreparedRow;
  try {
    prep = prepareRow(model, row, f.regime, theta, opts.constants, opts.settings.gridPoints);
  } catch (e) {
    if (e instanceof EvalError) return { kind: 'none' };
    throw e;
  }
  const L = f.exponent;
  const rt = prep.rtExponent;
  if (rt === null && opts.settings.unknownRT === 'block') return { kind: 'none' };
  if (rt !== null && rt >= L - TOL) return { kind: 'none' }; // the reduction alone is too slow
  try {
    const keys = new Map<string, Regime>();
    let minScale = Infinity;
    evaluateF(prep, (_r, s) => G.poly(s), (site) => {
      if (site.regime !== null && !keys.has(site.regime.key)) keys.set(site.regime.key, site.regime);
      if (site.regime !== null) minScale = Math.min(minScale, site.scale);
    });
    const g = (x: number): number => fromExponentAt(prep, x);
    if (keys.size === 0) {
      if (g(0) < L - TOL) {
        return { kind: 'inconsistent', message: `the From-time is below the lower bound ${G.formatNumber(L, 3)} without any non-trivial call` };
      }
      return { kind: 'none' };
    }
    if (keys.size > 1) return { kind: 'none' }; // calls in several target regimes: no single-regime bound
    const regime = [...keys.values()][0]!;
    // A call whose normalizer is N^s needs x up to about L/s to reach L (e.g. a target normalized by a tiny parameter).
    const x = threshold(g, L, Math.max(X_MAX, (2 * (L + 1)) / minScale));
    if (x === 'unbounded') {
      return { kind: 'inconsistent', message: `the From-time stays below the lower bound ${G.formatNumber(L, 3)} for every running time of the target` };
    }
    if (x <= TOL) return { kind: 'none' };
    return { kind: 'ok', cand: { regime, x, theta, rtExponent: rt } };
  } catch (e) {
    if (e instanceof EvalError) return { kind: 'none' };
    throw e;
  }
}

/**
 * All LB facts derivable through `row` from fact `f` (best per target regime key, after grid search and refinement).
 */
export function deriveThroughRow(
  model: Model,
  row: CompiledRow,
  f: LBFact,
  opts: PropagationOptions,
  inconsistencies: Inconsistency[] = [],
): LBFact[] {
  if (row.requires !== null && !f.regime.satisfies(row.requires)) return [];
  const env = new Map(opts.constants);
  for (const [p, g] of f.regime.env()) env.set(p, g);
  const best = new Map<string, Candidate>();
  const hits = new Map<string, number>();
  for (const theta of gridPoints(row.free, env, opts.settings.gridPoints)) {
    const a = attempt(model, row, f, theta, opts);
    if (a.kind === 'inconsistent') {
      if (!inconsistencies.some((i) => i.rowId === row.id && i.parent === f)) {
        inconsistencies.push({ rowId: row.id, parent: f, theta, message: a.message });
      }
      continue;
    }
    if (a.kind !== 'ok') continue;
    const key = a.cand.regime.key;
    hits.set(key, (hits.get(key) ?? 0) + 1);
    const cur = best.get(key);
    if (cur === undefined || a.cand.x > cur.x + TOL) best.set(key, a.cand);
  }
  const out: LBFact[] = [];
  for (const [key, cand] of best) {
    let chosen = cand;
    // Refine only when several grid points reach this target regime: if the regime moves with the free parameters,
    // a perturbed point lands in another regime anyway (those points are separate facts of a trade-off).
    if (row.free.length > 0 && (hits.get(key) ?? 0) >= 2) {
      const objective = (theta: Theta): number | null => {
        const a = attempt(model, row, f, theta, opts);
        return a.kind === 'ok' && a.cand.regime.key === key ? a.cand.x : null;
      };
      const r = refine(row.free, env, cand.theta, cand.x, objective, opts.settings.refineRounds, opts.settings.gridPoints);
      if (r.value > cand.x + TOL) {
        const a = attempt(model, row, f, r.theta, opts);
        if (a.kind === 'ok') chosen = a.cand;
      }
    }
    out.push({
      problem: row.target,
      regime: chosen.regime,
      exponent: chosen.x,
      hops: f.hops + 1,
      origin: { kind: 'row', rowId: row.id, theta: chosen.theta, parent: f, rtExponent: chosen.rtExponent },
    });
  }
  return out;
}

/**
 * Forward propagation from `seeds` (SPEC §6.5): a FIFO worklist that keeps the best fact per (problem, regime key).
 */
export function propagateLB(model: Model, seeds: readonly LBFact[], opts: PropagationOptions): LBResult {
  const facts = new Map<string, Map<string, LBFact>>();
  const queue: LBFact[] = [];
  const capped = new Set<string>();
  const inconsistencies: Inconsistency[] = [];
  const offer = (f: LBFact): void => {
    let m = facts.get(f.problem);
    if (m === undefined) {
      m = new Map();
      facts.set(f.problem, m);
    }
    const cur = m.get(f.regime.key);
    if (cur !== undefined && cur.exponent >= f.exponent - TOL) return;
    if (cur === undefined && m.size >= MAX_KEYS_PER_PROBLEM) {
      capped.add(`more than ${MAX_KEYS_PER_PROBLEM} regimes with lower bounds for ${f.problem}; further ones were dropped`);
      return;
    }
    m.set(f.regime.key, f);
    queue.push(f);
  };
  seeds.forEach(offer);
  let head = 0;
  let pops = 0;
  while (head < queue.length) {
    if (pops >= MAX_POPS) {
      capped.add(`stopped after ${MAX_POPS} propagation steps`);
      break;
    }
    const f = queue[head++]!;
    pops += 1;
    if (facts.get(f.problem)?.get(f.regime.key) !== f) continue; // superseded by a better fact
    if (f.hops >= opts.settings.maxHopsLB) continue;
    for (const row of model.rowsBySource.get(f.problem) ?? []) {
      if (row.status !== 'ok' || !opts.usable(row)) continue;
      for (const g of deriveThroughRow(model, row, f, opts, inconsistencies)) offer(g);
    }
  }
  return { facts, inconsistencies, capped: [...capped], pops };
}

/** The chain of facts from `f` back to its knob (f first). */
export function lbChain(f: LBFact): LBFact[] {
  const out: LBFact[] = [f];
  let cur = f;
  while (cur.origin.kind === 'row') {
    cur = cur.origin.parent;
    out.push(cur);
  }
  return out;
}
