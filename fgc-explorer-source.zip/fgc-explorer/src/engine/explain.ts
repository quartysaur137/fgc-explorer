/**
 * Explanations for the inspector: what the engine computes for one row at one source regime.
 */

import * as G from '../growth/growth';
import { EvalError, Growth, Rate } from '../growth/growth';
import { Settings } from '../model/config';
import { CompiledRow, Model } from '../model/model';
import { Regime } from '../model/regime';
import { gridPoints, Theta } from './freeparams';
import { evaluateF, prepareRow } from './rowEval';

export interface CallProbe {
  /** Target regime of the call, or null for a call on a constant-size instance. */
  readonly regime: Regime | null;
  readonly scale: number;
}

export interface RowProbe {
  readonly theta: Theta;
  /** Present when the row does not evaluate at this point. */
  readonly error?: string;
  readonly alternative: number;
  readonly calls: readonly CallProbe[];
  /** Rate of the reduction runtime, or null if unknown. */
  readonly rt: Rate | null;
  /** Exponent of the From-time when every call costs N'^1 (shows the overhead outside the calls). */
  readonly overheadAtOne: number | null;
}

/**
 * Evaluate `row` at `regime` for (up to `limit`) grid points of its free parameters.
 * Never throws for evaluation problems: they are reported per point.
 */
export function probeRow(model: Model, row: CompiledRow, regime: Regime, constants: ReadonlyMap<string, Growth>, settings: Settings, limit = 12): RowProbe[] {
  if (row.status !== 'ok') return [];
  const env = new Map(constants);
  for (const [p, g] of regime.env()) env.set(p, g);
  const thetas = gridPoints(row.free, env, Math.min(settings.gridPoints, 5));
  const step = Math.max(1, Math.ceil(thetas.length / limit));
  const out: RowProbe[] = [];
  for (let i = 0; i < thetas.length && out.length < limit; i += step) {
    const theta = thetas[i]!;
    try {
      const prep = prepareRow(model, row, regime, theta, constants, settings.gridPoints);
      const calls = new Map<string, CallProbe>();
      const F = evaluateF(prep, (_r, s) => G.poly(s), (site) => {
        const key = `${site.regime?.key ?? 'degenerate'}@${site.scale.toFixed(6)}`;
        if (!calls.has(key)) calls.set(key, { regime: site.regime, scale: site.scale });
      });
      out.push({
        theta,
        alternative: prep.alternative,
        calls: [...calls.values()].slice(0, 8),
        rt: prep.rt,
        overheadAtOne: G.exponentOf(F),
      });
    } catch (e) {
      if (!(e instanceof EvalError)) throw e;
      out.push({ theta, error: e.message, alternative: -1, calls: [], rt: null, overheadAtOne: null });
    }
  }
  return out;
}
