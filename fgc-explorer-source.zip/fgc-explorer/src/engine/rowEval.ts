/**
 * Evaluating one reduction at a source regime and a choice of free parameters (SPEC §6.2).
 */

import { evaluate, evaluateFormula } from '../growth/evaluate';
import * as G from '../growth/growth';
import { EvalError, Growth, Rate } from '../growth/growth';
import { CompiledRow, Model, Problem } from '../model/model';
import { Normalization, Regime } from '../model/regime';
import { assert } from '../util/assert';
import { extendEnv, Theta } from './freeparams';

/**
 * Normalizations of call arguments per prepared row (the arguments of a call do not depend on the values of other
 * calls, so threshold searches re-evaluate the same arguments many times). Weak keys: entries die with the row.
 */
const normalizationCache = new WeakMap<PreparedRow, Map<string, Normalization>>();

/** A string that identifies a growth exactly (used as a cache key). */
function growthSignature(g: Growth): string {
  switch (g.kind) {
    case 'const':
      return `c${g.value}`;
    case 'log':
      return `l${g.pow}:${g.coef}`;
    case 'qpoly':
      return `q${g.pow}:${g.coef}`;
    case 'poly':
      return `p${g.exp}`;
    case 'polyUnknown':
      return 'u';
    case 'super':
      return 's';
  }
}

/** Where an oracle call lands: the target regime and scale (normalizer of the target = N^scale), or degenerate. */
export interface CallSite {
  readonly regime: Regime | null;
  readonly scale: number;
}

/** Value of a non-degenerate call, given its target regime and scale. */
export type CallValue = (regime: Regime, scale: number) => Growth;

export interface PreparedRow {
  readonly row: CompiledRow;
  readonly target: Problem;
  readonly sourceRegime: Regime;
  readonly theta: Theta;
  readonly env: ReadonlyMap<string, Growth>;
  /** Index of the From-time alternative used. */
  readonly alternative: number;
  /** Rate of the reduction runtime, or null if unknown. */
  readonly rt: Rate | null;
  readonly sumGridPoints: number;
}

/** Constant values in scope: the config's constants with the scenario's overrides. */
export function constantEnv(model: Model, overrides: Readonly<Record<string, number>>): Map<string, Growth> {
  const env = new Map<string, Growth>();
  for (const [name, def] of model.constants) env.set(name, G.constant(overrides[name] ?? def.value));
  return env;
}

/**
 * Evaluate definitions in dependency order: repeatedly evaluate those whose symbols are available (first evaluable
 * alternative), until no progress. Definitions that never evaluate are left out (uses of them then fail).
 */
function addDefinitions(row: CompiledRow, env: Map<string, Growth>): void {
  let pending = [...row.defs];
  for (let progress = true; progress && pending.length > 0; ) {
    progress = false;
    const next: typeof pending = [];
    for (const d of pending) {
      try {
        env.set(d.name, evaluateFormula({ alternatives: d.alternatives }, { env }).value);
        progress = true;
      } catch (e) {
        if (!(e instanceof EvalError)) throw e;
        next.push(d);
      }
    }
    pending = next;
  }
}

/**
 * Prepare `row` (status 'ok') at `sourceRegime` (a regime of row.source) and free-parameter assignment `theta`.
 * Chooses the first From-time alternative that evaluates (probing with every call worth N^1).
 * @throws EvalError if no alternative evaluates
 */
export function prepareRow(
  model: Model,
  row: CompiledRow,
  sourceRegime: Regime,
  theta: Theta,
  constants: ReadonlyMap<string, Growth>,
  sumGridPoints: number,
): PreparedRow {
  assert(row.status === 'ok' && row.from !== null, `row ${row.id} is not usable`);
  const target = model.problems.get(row.target)!;
  const env = new Map<string, Growth>(constants);
  for (const [p, g] of sourceRegime.env()) env.set(p, g);
  const withFree = extendEnv(row.free, theta, env);
  addDefinitions(row, withFree);
  let rt: Rate | null = null;
  if (row.rt !== null) {
    try {
      rt = G.rateOf(evaluateFormula(row.rt, { env: withFree, sumGridPoints }).value);
    } catch (e) {
      if (!(e instanceof EvalError)) throw e;
      rt = null;
    }
  }
  const base = { row, target, sourceRegime, theta, env: withFree, rt, sumGridPoints };
  const errors: string[] = [];
  for (let i = 0; i < row.from.alternatives.length; i++) {
    const prep: PreparedRow = { ...base, alternative: i };
    try {
      evaluateF(prep, (_r, s) => G.poly(s));
      return prep;
    } catch (e) {
      if (!(e instanceof EvalError)) throw e;
      errors.push(e.message);
    }
  }
  throw new EvalError(errors.length === 1 ? errors[0]! : `no alternative evaluates: ${errors.join('; ')}`);
}

/**
 * The class of the From-time of a prepared row, with non-degenerate calls valued by `value`.
 * Degenerate calls (no growing argument) to polynomial-time targets are worth a polylogarithm, or N^{o(1)} when an
 * argument is sub-polynomial but not polylogarithmic (SPEC §6.2).
 * @param onSite called for every call evaluated (including those inside sums)
 * @throws EvalError if evaluation fails (e.g. a degenerate call to an exponential-time target)
 */
export function evaluateF(prep: PreparedRow, value: CallValue, onSite?: (site: CallSite) => void): Growth {
  const target = prep.target;
  const cache = normalizationCache.get(prep) ?? new Map<string, Normalization>();
  normalizationCache.set(prep, cache);
  const onCall = (fn: string, args: readonly Growth[]): Growth => {
    if (fn !== 'T' || args.length !== target.params.length) throw new EvalError(`bad call ${fn}`);
    const sig = args.map(growthSignature).join(',');
    let n = cache.get(sig);
    if (n === undefined) {
      n = Regime.normalize(target.params, args, target.logParams);
      cache.set(sig, n);
    }
    if (n.kind === 'degenerate') {
      onSite?.({ regime: null, scale: 0 });
      if (target.timeType === 'poly') return args.some((g) => g.kind === 'qpoly') ? G.SUBPOLY : G.POLYLOG;
      throw new EvalError(`a call to ${target.id} on an instance of sub-polynomial size (its time may be superpolynomial)`);
    }
    onSite?.({ regime: n.regime, scale: n.scale });
    return value(n.regime, n.scale);
  };
  const expr = prep.row.from!.alternatives[prep.alternative]!;
  return evaluate(expr, { env: prep.env, onCall, sumGridPoints: prep.sumGridPoints });
}
