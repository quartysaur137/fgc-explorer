/**
 * Analysis of a scenario on a model (SPEC §6.5–§6.7): knobs → lower-bound facts → upper bounds at the regimes of
 * interest → per-problem summaries and statuses.
 */

import { evaluate } from '../growth/evaluate';
import * as G from '../growth/growth';
import { EvalError, Growth } from '../growth/growth';
import { Expr } from '../math/ast';
import { ParseError, parseExpr } from '../math/parser';
import { Knob, Scenario } from '../model/config';
import { CompiledRow, findProblem, Model, Problem } from '../model/model';
import { ParamSpec, parseRegimeSpec, Regime, SpecError, specGrowths } from '../model/regime';
import { lbChain, LBFact, LBResult, propagateLB, PropagationOptions } from './lower';
import { constantEnv } from './rowEval';
import { UBFact, UBKnob, UpperBounds } from './upper';

export type Status = 'conflict' | 'tight' | 'gap' | 'lb' | 'ub' | 'none';

/** Most severe first (SPEC §6.7). */
export const STATUS_ORDER: readonly Status[] = ['conflict', 'tight', 'gap', 'lb', 'ub', 'none'];

export const STATUS_TEXT: Readonly<Record<Status, string>> = {
  conflict: 'conflict (upper bound below lower bound)',
  tight: 'tight (upper bound = lower bound)',
  gap: 'lower and upper bound',
  lb: 'lower bound only',
  ub: 'upper bound only',
  none: 'no bound',
};

/*
 * Tolerances for comparing an upper bound U with a lower bound L (SPEC §6.7). The numerical searches are one-sided:
 * optimizing a free parameter on a grid can only make a derived lower bound smaller and a derived upper bound larger
 * than the exact value, so they can hide a conflict but never create one. Hence:
 *  - a conflict needs U < L − CONFLICT_TOL, which only has to absorb floating-point noise (about 1e-8, including the
 *    2^-30-precise search for the largest term of a sum), so that small improvements are detected: 3SUM in n^{1.9992},
 *    and even n^{2-Ω(1)}, whose Ω(1) is evaluated as 1e-6 (growth.ts);
 *  - U ≤ L + TIGHT_TOL counts as tight, absorbing the inaccuracy of the free-parameter search (about 10^-6 with the
 *    default settings: 9 grid points, 20 refinement rounds).
 */
export const CONFLICT_TOL = 1e-7;
export const TIGHT_TOL = 1e-4;

/** Upper bounds are computed at most at this many lower-bound regimes per problem (fewest hops first). */
export const MAX_UB_REGIMES_FROM_LB = 12;

export type RegimeOrigin = 'config' | 'lb' | 'knob' | 'pinned';

export interface RegimeSummary {
  readonly regime: Regime;
  readonly lb: LBFact | null;
  readonly ub: UBFact | null;
  /** False if the upper bound was not computed (beyond MAX_UB_REGIMES_FROM_LB); query `analysis.upper` on demand. */
  readonly ubComputed: boolean;
  readonly status: Status;
  readonly origins: readonly RegimeOrigin[];
}

export interface ProblemSummary {
  readonly problem: Problem;
  readonly regimes: readonly RegimeSummary[];
  readonly status: Status;
  readonly primary: RegimeSummary | null;
}

export interface Analysis {
  readonly model: Model;
  readonly scenario: Scenario;
  readonly lower: LBResult;
  /** For on-demand upper-bound queries (e.g. a regime opened in the inspector). */
  readonly upper: UpperBounds;
  readonly summaries: ReadonlyMap<string, ProblemSummary>;
  /** Knob id → problem with the knob (it is ignored). */
  readonly knobIssues: ReadonlyMap<string, string>;
  /** Knob id → regimes it was instantiated at. */
  readonly knobRegimes: ReadonlyMap<string, readonly Regime[]>;
  /** Row id → number of displayed facts whose derivation uses it. */
  readonly rowUse: ReadonlyMap<string, { readonly lb: number; readonly ub: number }>;
  readonly elapsedMs: number;
  /** Fingerprints of the inputs of `lower` and `upper` (used to reuse them in the next analysis). */
  readonly lowerInputs: string;
  readonly upperInputs: string;
}

export function statusOf(lb: LBFact | null, ub: UBFact | null): Status {
  if (lb !== null && ub !== null) {
    if (ub.exponent < lb.exponent - CONFLICT_TOL) return 'conflict';
    if (ub.exponent <= lb.exponent + TIGHT_TOL) return 'tight';
    return 'gap';
  }
  if (lb !== null) return 'lb';
  if (ub !== null) return 'ub';
  return 'none';
}

/** The specs to use for each parameter of `problem`: `spec` overrides the problem's first regime, then defaults. */
export function completeRegimeSpec(problem: Problem, spec: ReadonlyMap<string, ParamSpec>): Map<string, ParamSpec> {
  let base = new Map<string, ParamSpec>();
  const first = problem.regimeSpecs[0];
  if (first !== undefined) {
    try {
      base = parseRegimeSpec(first);
    } catch {
      base = new Map();
    }
  }
  for (const p of spec.keys()) {
    if (!problem.params.includes(p)) throw new SpecError(`${p} is not a parameter of ${problem.id} (parameters: ${problem.params.join(', ')})`);
  }
  const out = new Map<string, ParamSpec>();
  for (const p of problem.params) {
    const s = spec.get(p) ?? base.get(p);
    out.set(p, s ?? (problem.logParams.has(p) ? { kind: 'logdep' } : { kind: 'poly', exp: 1 }));
  }
  return out;
}

/**
 * The regimes a spec stands for (const lists expand into one regime per combination).
 * @throws SpecError for malformed specs, unknown parameters, or a regime without a growing parameter
 */
export function regimesFromSpec(problem: Problem, specText: string): Regime[] {
  if (!problem.isStatic) throw new SpecError(`${problem.id} is not a static problem`);
  const spec = completeRegimeSpec(problem, parseRegimeSpec(specText));
  let combos: Array<Map<string, Growth>> = [new Map()];
  for (const p of problem.params) {
    const gs = specGrowths(spec.get(p)!);
    combos = combos.flatMap((m) => gs.map((g) => new Map([...m, [p, g]])));
    if (combos.length > 64) throw new SpecError('the regime expands into more than 64 regimes');
  }
  try {
    return combos.map((m) => Regime.fromGrowthMap(problem.params, m, problem.logParams));
  } catch (e) {
    if (e instanceof EvalError) throw new SpecError(e.message);
    throw e;
  }
}

function parseFormulaExpr(tex: string): Expr {
  try {
    return parseExpr(tex);
  } catch (e) {
    throw new SpecError(e instanceof ParseError ? `formula: ${e.message}` : String(e));
  }
}

/** Exponent of a knob formula at a regime. @throws EvalError */
function formulaExponent(formula: Expr, regime: Regime, constants: ReadonlyMap<string, Growth>): number {
  const env = new Map(constants);
  for (const [p, g] of regime.env()) env.set(p, g);
  return G.exponentOf(evaluate(formula, { env }));
}

/** Whether a row (status ok) may be used under the scenario's settings. */
export function rowUsable(row: CompiledRow, scenario: Scenario): boolean {
  if (!scenario.settings.useRandomized && row.randomized) return false;
  return !scenario.settings.disabledRows.includes(row.id);
}

/** Fingerprint of everything lower-bound propagation depends on (besides the model). */
function lowerInputsOf(scenario: Scenario): string {
  const s = scenario.settings;
  const knobs = scenario.knobs.filter((k) => k.enabled && k.kind === 'LB').map((k) => [k.id, k.problem, k.regime, k.exponent, k.formula]);
  return JSON.stringify([knobs, scenario.constants, s.maxHopsLB, s.gridPoints, s.refineRounds, s.unknownRT, s.useRandomized, s.disabledRows]);
}

/** Fingerprint of everything upper-bound evaluation depends on (besides the model). */
function upperInputsOf(scenario: Scenario): string {
  const s = scenario.settings;
  const knobs = scenario.knobs.filter((k) => k.enabled && k.kind === 'UB').map((k) => [k.id, k.problem, k.regime, k.exponent, k.formula]);
  return JSON.stringify([knobs, scenario.constants, s.maxDepthUB, s.gridPoints, s.refineRounds, s.unknownRT, s.useRandomized, s.disabledRows]);
}

/**
 * Analyze `scenario` on `model`.
 * @param pinned problem id → extra regime specs whose bounds should be shown
 * @param previous an earlier analysis of the same model: its lower-bound facts and upper-bound cache are reused when
 *        their inputs did not change (e.g. moving an LB slider keeps all upper bounds)
 */
export function analyze(
  model: Model,
  scenario: Scenario,
  pinned: ReadonlyMap<string, readonly string[]> = new Map(),
  previous: Analysis | null = null,
): Analysis {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const lowerInputs = lowerInputsOf(scenario);
  const upperInputs = upperInputsOf(scenario);
  const constants = constantEnv(model, scenario.constants);
  const opts: PropagationOptions = { settings: scenario.settings, constants, usable: (r) => rowUsable(r, scenario) };
  const knobIssues = new Map<string, string>();
  const knobRegimes = new Map<string, Regime[]>();
  const seeds: LBFact[] = [];
  const ubKnobs: UBKnob[] = [];

  for (const k of scenario.knobs) {
    if (!k.enabled) continue;
    try {
      instantiateKnob(model, k, constants, seeds, ubKnobs, knobRegimes);
    } catch (e) {
      if (e instanceof SpecError || e instanceof EvalError) knobIssues.set(k.id, e.message);
      else throw e;
    }
  }

  const sameModel = previous !== null && previous.model === model;
  const lower = sameModel && previous.lowerInputs === lowerInputs ? previous.lower : propagateLB(model, seeds, opts);
  const upper = sameModel && previous.upperInputs === upperInputs ? previous.upper : new UpperBounds(model, ubKnobs, opts);

  // Regimes of interest per problem.
  const summaries = new Map<string, ProblemSummary>();
  const rowUse = new Map<string, { lb: number; ub: number }>();
  const use = (rowId: string, kind: 'lb' | 'ub'): void => {
    const u = rowUse.get(rowId) ?? { lb: 0, ub: 0 };
    rowUse.set(rowId, { ...u, [kind]: u[kind] + 1 });
  };
  for (const problem of model.problems.values()) {
    const entries = new Map<string, { regime: Regime; origins: Set<RegimeOrigin> }>();
    const addRegime = (r: Regime, o: RegimeOrigin): void => {
      const e = entries.get(r.key) ?? { regime: r, origins: new Set<RegimeOrigin>() };
      e.origins.add(o);
      entries.set(r.key, e);
    };
    if (problem.isStatic) {
      for (const spec of problem.regimeSpecs) {
        try {
          regimesFromSpec(problem, spec).forEach((r) => addRegime(r, 'config'));
        } catch {
          // reported as a model diagnostic
        }
      }
      for (const spec of pinned.get(problem.id) ?? []) {
        try {
          regimesFromSpec(problem, spec).forEach((r) => addRegime(r, 'pinned'));
        } catch {
          // invalid pinned spec: ignored (the UI validates before pinning)
        }
      }
    }
    for (const k of scenario.knobs) {
      if (k.enabled && findProblem(model, k.problem) === problem) (knobRegimes.get(k.id) ?? []).forEach((r) => addRegime(r, 'knob'));
    }
    const lbFacts = lower.facts.get(problem.id);
    const lbSorted = [...(lbFacts?.values() ?? [])].sort((a, b) => a.hops - b.hops || b.exponent - a.exponent);
    for (const f of lbSorted) addRegime(f.regime, 'lb');
    const ubAt = new Set(lbSorted.slice(0, MAX_UB_REGIMES_FROM_LB).map((f) => f.regime.key));

    const regimes: RegimeSummary[] = [];
    for (const { regime, origins } of entries.values()) {
      const lb = lbFacts?.get(regime.key) ?? null;
      const ubComputed = problem.isStatic && (origins.size > 1 || !origins.has('lb') || ubAt.has(regime.key));
      const ub = ubComputed ? upper.query(problem.id, regime) : null;
      regimes.push({ regime, lb, ub, ubComputed, status: statusOf(lb, ub), origins: [...origins] });
    }
    const rank = (s: RegimeSummary): number[] => [
      s.origins.includes('pinned') ? 0 : 1,
      STATUS_ORDER.indexOf(s.status),
      s.lb ? s.lb.hops : 99,
      s.lb ? -s.lb.exponent : 0,
      s.origins.includes('config') ? 0 : 1,
    ];
    const cmp = (a: RegimeSummary, b: RegimeSummary): number => {
      const ra = rank(a);
      const rb = rank(b);
      for (let i = 0; i < ra.length; i++) if (ra[i] !== rb[i]) return ra[i]! - rb[i]!;
      return 0;
    };
    regimes.sort(cmp);
    const status = regimes.reduce<Status>((acc, s) => (STATUS_ORDER.indexOf(s.status) < STATUS_ORDER.indexOf(acc) ? s.status : acc), 'none');
    summaries.set(problem.id, { problem, regimes, status, primary: regimes[0] ?? null });
    for (const s of regimes) {
      if (s.lb && s.lb.origin.kind === 'row') use(s.lb.origin.rowId, 'lb');
      if (s.ub) walkUB(s.ub, (f) => use(f, 'ub'));
    }
  }
  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  return { model, scenario, lower, upper, summaries, knobIssues, knobRegimes, rowUse, elapsedMs: t1 - t0, lowerInputs, upperInputs };
}

/** The problems and reductions a bound's derivation goes through (its own problem included). */
export interface DerivationPath {
  readonly problems: ReadonlySet<string>;
  readonly rows: ReadonlySet<string>;
}

/** A lower bound's derivation: back along its chain to the knob (a knob on the problem itself: the problem alone). */
export function lbPath(f: LBFact): DerivationPath {
  const chain = lbChain(f);
  return { problems: new Set(chain.map((x) => x.problem)), rows: new Set(chain.flatMap((x) => (x.origin.kind === 'row' ? [x.origin.rowId] : []))) };
}

/** An upper bound's derivation: its whole tree down to the knobs (a knob on the problem itself: the problem alone). */
export function ubPath(f: UBFact): DerivationPath {
  const problems = new Set<string>();
  const rows = new Set<string>();
  const walk = (g: UBFact): void => {
    problems.add(g.problem);
    if (g.origin.kind !== 'row') return;
    rows.add(g.origin.rowId);
    g.origin.children.forEach(walk);
  };
  walk(f);
  return { problems, rows };
}

/**
 * The best bounds of a problem at one of its regimes and their derivations.
 * @param regimeKey the regime (default, or when the problem no longer has it: the primary one, which the graph shows)
 * @returns nulls for a bound the problem does not have (and for an unknown problem)
 */
export function boundDerivations(
  analysis: Analysis,
  problemId: string,
  regimeKey?: string,
): { readonly regime: RegimeSummary | null; readonly lb: DerivationPath | null; readonly ub: DerivationPath | null } {
  const summary = analysis.summaries.get(problemId);
  const s = summary?.regimes.find((r) => r.regime.key === regimeKey) ?? summary?.primary ?? null;
  if (s === null) return { regime: null, lb: null, ub: null };
  const ub = s.ubComputed ? s.ub : analysis.upper.query(problemId, s.regime);
  return { regime: s, lb: s.lb ? lbPath(s.lb) : null, ub: ub ? ubPath(ub) : null };
}

function walkUB(f: UBFact, visitRow: (rowId: string) => void): void {
  if (f.origin.kind !== 'row') return;
  visitRow(f.origin.rowId);
  for (const c of f.origin.children) walkUB(c, visitRow);
}

function instantiateKnob(
  model: Model,
  k: Knob,
  constants: ReadonlyMap<string, Growth>,
  seeds: LBFact[],
  ubKnobs: UBKnob[],
  knobRegimes: Map<string, Regime[]>,
): void {
  const problem = findProblem(model, k.problem);
  if (problem === undefined) throw new SpecError(`unknown problem "${k.problem}"`);
  if (!problem.isStatic) throw new SpecError(`${problem.id} is a dynamic / multi-function problem (not supported)`);
  const formula = k.formula !== undefined ? parseFormulaExpr(k.formula) : null;
  if (k.kind === 'LB') {
    if (k.regime === undefined) throw new SpecError('an LB knob needs a regime');
    const regimes = regimesFromSpec(problem, k.regime);
    knobRegimes.set(k.id, regimes);
    for (const r of regimes) {
      const x = formula !== null ? formulaExponent(formula, r, constants) : k.exponent!;
      if (!Number.isFinite(x) || x <= 0) throw new SpecError(`the lower bound must be a positive finite exponent (got ${x})`);
      seeds.push({ problem: problem.id, regime: r, exponent: x, hops: 0, origin: { kind: 'knob', knobId: k.id } });
    }
    return;
  }
  // UB knob
  if (formula === null) {
    if (k.regime === undefined) throw new SpecError('an UB knob with an exponent needs a regime (or use a formula)');
    const regimes = regimesFromSpec(problem, k.regime);
    knobRegimes.set(k.id, regimes);
    if (!(k.exponent! >= 0)) throw new SpecError('the exponent must be nonnegative');
    ubKnobs.push({ id: k.id, problem: problem.id, exactKeys: new Set(regimes.map((r) => r.key)), exponent: k.exponent!, formula: null, filter: null });
    return;
  }
  let filter: Map<string, ParamSpec> | null = null;
  if (k.regime !== undefined && k.regime.trim() !== '') {
    filter = parseRegimeSpec(k.regime);
    for (const p of filter.keys()) if (!problem.params.includes(p)) throw new SpecError(`${p} is not a parameter of ${problem.id}`);
    knobRegimes.set(k.id, regimesFromSpec(problem, k.regime));
  }
  // Validate the formula's symbols once at the problem's first regime.
  const probe = regimesFromSpec(problem, problem.regimeSpecs[0] ?? '')[0];
  if (probe !== undefined) {
    try {
      formulaExponent(formula, probe, constants);
    } catch (e) {
      if (e instanceof EvalError && /unknown symbol|unknown function/.test(e.message)) throw new SpecError(`formula: ${e.message}`);
    }
  }
  ubKnobs.push({ id: k.id, problem: problem.id, exactKeys: null, exponent: null, formula, filter });
}
