/**
 * Analysis of a scenario on a model (SPEC §6.5–§6.7): knobs → lower-bound facts → upper bounds at the regimes of
 * interest → per-problem summaries and statuses.
 */

import { evaluate } from '../growth/evaluate';
import * as G from '../growth/growth';
import { EvalError, Growth, Rate, samePower } from '../growth/growth';
import { Expr } from '../math/ast';
import { ParseError, parseExpr } from '../math/parser';
import { Knob, Scenario } from '../model/config';
import { CompiledRow, findProblem, Model, Problem } from '../model/model';
import { ParamSpec, parseRegimeSpec, Regime, SpecError, specGrowths } from '../model/regime';
import { lbChain, LBFact, LBResult, propagateLB, PropagationOptions } from './lower';
import { compareKeys, lbRegimeKey, listedByItself, regimeNiceness, regimeRankKey } from './regimeRank';
import { constantEnv } from './rowEval';
import { nodeKey, UBFact, UBKnob, ubParts, UpperBounds } from './upper';

export type Status = 'conflict' | 'tight' | 'gap' | 'lb' | 'ub' | 'none';

/** Most severe first (SPEC §6.7). */
export const STATUS_ORDER: readonly Status[] = ['conflict', 'tight', 'gap', 'lb', 'ub', 'none'];

export const STATUS_TEXT: Readonly<Record<Status, string>> = {
  conflict: 'conflict (upper bound below lower bound)',
  tight: 'tight (upper bound = lower bound)',
  gap: 'lower and upper bound',
  lb: 'lower bound only',
  ub: 'upper bound only',
  none: 'no bound',
};

/*
 * Tolerances for comparing an upper bound U with a lower bound L (SPEC §6.7). The numerical searches are one-sided:
 * optimizing a free parameter on a grid can only make a derived lower bound smaller and a derived upper bound larger
 * than the exact value, so they can hide a conflict but never create one. Hence:
 *  - a conflict needs U < L − CONFLICT_TOL, which only has to absorb floating-point noise (about 1e-8, including the
 *    2^-30-precise search for the largest term of a sum), so that small improvements are detected: 3SUM in n^{1.9992},
 *    and even n^{2-Ω(1)}, whose Ω(1) is evaluated as 1e-6 (growth.ts);
 *  - U ≤ L + TIGHT_TOL counts as tight, absorbing the inaccuracy of the free-parameter search (about 10^-6 with the
 *    default settings: 9 grid points, 20 refinement rounds).
 */
export const CONFLICT_TOL = 1e-7;
export const TIGHT_TOL = 1e-4;

export type RegimeOrigin = 'config' | 'lb' | 'knob' | 'pinned';

export interface RegimeSummary {
  readonly regime: Regime;
  /**
   * The best lower bound: of this regime, or of a regime it contains (its `regime` then differs: SPEC §2.3, the
   * instances of that regime are among these).
   */
  readonly lb: LBFact | null;
  /** The best upper bound: of this regime, or of a regime that contains it (its `regime` then differs). */
  readonly ub: UBFact | null;
  /**
   * Whether the upper bound was computed: always for static problems (so that a conflict shows wherever there is one),
   * never for dynamic ones.
   */
  readonly ubComputed: boolean;
  readonly status: Status;
  readonly origins: readonly RegimeOrigin[];
  /**
   * Whether the inspector lists it without being asked to (SPEC §6.7): the first regime, pinned, configured and knob
   * regimes, nice ones (listedByItself), and those that the derivation of another listed bound goes through.
   */
  readonly listed: boolean;
}

export interface ProblemSummary {
  readonly problem: Problem;
  /** Its regimes, in the order of display (regimeRankKey): the first is the primary one. */
  readonly regimes: readonly RegimeSummary[];
  /** The status at the primary regime (a conflict at any regime makes that regime the primary one). */
  readonly status: Status;
  /** The regime the graph shows. */
  readonly primary: RegimeSummary | null;
}

export interface Analysis {
  readonly model: Model;
  readonly scenario: Scenario;
  readonly lower: LBResult;
  /** The upper bounds at the regimes of interest (configured, of knobs, pinned), and wherever their search went. */
  readonly upper: UpperBounds;
  /** Upper bounds elsewhere (at regimes of lower bounds, or opened in the inspector), on top of `upper` (see overlay). */
  readonly upperOverlay: UpperBounds;
  readonly summaries: ReadonlyMap<string, ProblemSummary>;
  /** Knob id → problem with the knob (it is ignored). */
  readonly knobIssues: ReadonlyMap<string, string>;
  /** Knob id → regimes it was instantiated at. */
  readonly knobRegimes: ReadonlyMap<string, readonly Regime[]>;
  /** Row id → number of displayed facts whose derivation uses it. */
  readonly rowUse: ReadonlyMap<string, { readonly lb: number; readonly ub: number }>;
  readonly elapsedMs: number;
  /** Fingerprints of the inputs of `lower` and `upper` (used to reuse them in the next analysis). */
  readonly lowerInputs: string;
  readonly upperInputs: string;
  /**
   * Whether every regime's upper bound is computed. An analysis made with `complete: false` computes them first at the
   * nicest MAX_UB_REGIMES_FIRST regimes of lower bounds per problem; completeAnalysis computes the others.
   */
  readonly complete: boolean;
  /** (internal: what completeAnalysis needs) */
  readonly completion: Completion;
}

/** The state of an analysis's completion (see completeAnalysis). */
interface Completion {
  readonly plans: readonly Plan[];
  readonly interest: ReadonlySet<string>;
  /** The regimes whose upper bounds remain to be computed, and how many of them are done. */
  readonly queue: ReadonlyArray<{ readonly problem: string; readonly regime: Regime }>;
  next: number;
}

/** A problem's regimes of interest to the summaries. */
interface Plan {
  readonly problem: Problem;
  readonly entries: ReadonlyArray<{ readonly regime: Regime; readonly origins: ReadonlySet<RegimeOrigin>; readonly ubComputed: boolean }>;
}

/**
 * Upper bounds are computed first at this many regimes of lower bounds per problem (the nicest first, see
 * lbRegimeKey), when an analysis is made incomplete (`complete: false`, for the UI); the others follow in
 * completeAnalysis, so that the views show results sooner.
 */
export const MAX_UB_REGIMES_FIRST = 12;

export function statusOf(lb: LBFact | null, ub: UBFact | null): Status {
  if (lb !== null && ub !== null) {
    // (Rates of different powers are far apart: e.g. 2^{0.9 n^{0.99}} is below 2^{0.001 n}.)
    if (!samePower(ub.power, lb.power)) return ub.power < lb.power ? 'conflict' : 'gap';
    if (ub.exponent < lb.exponent - CONFLICT_TOL) return 'conflict';
    if (ub.exponent <= lb.exponent + TIGHT_TOL) return 'tight';
    return 'gap';
  }
  if (lb !== null) return 'lb';
  if (ub !== null) return 'ub';
  return 'none';
}

/** The specs to use for each parameter of `problem`: `spec` overrides the problem's first regime, then defaults. */
export function completeRegimeSpec(problem: Problem, spec: ReadonlyMap<string, ParamSpec>): Map<string, ParamSpec> {
  let base = new Map<string, ParamSpec>();
  const first = problem.regimeSpecs[0];
  if (first !== undefined) {
    try {
      base = parseRegimeSpec(first);
    } catch {
      base = new Map();
    }
  }
  for (const p of spec.keys()) {
    if (!problem.params.includes(p)) throw new SpecError(`${p} is not a parameter of ${problem.id} (parameters: ${problem.params.join(', ')})`);
  }
  const out = new Map<string, ParamSpec>();
  for (const p of problem.params) {
    const s = spec.get(p) ?? base.get(p);
    out.set(p, s ?? (problem.logParams.has(p) ? { kind: 'logdep' } : { kind: 'poly', exp: 1 }));
  }
  return out;
}

/**
 * The regimes a spec stands for (const lists expand into one regime per combination), clipped to the problem's limits
 * (SPEC §2.3) unless `clip` is false.
 * @throws SpecError for malformed specs, unknown parameters, or a regime without a growing parameter
 */
export function regimesFromSpec(problem: Problem, specText: string, clip = true): Regime[] {
  if (!problem.isStatic) throw new SpecError(`${problem.id} is not a static problem`);
  const spec = completeRegimeSpec(problem, parseRegimeSpec(specText));
  let combos: Array<Map<string, Growth>> = [new Map()];
  for (const p of problem.params) {
    const gs = specGrowths(spec.get(p)!);
    combos = combos.flatMap((m) => gs.map((g) => new Map([...m, [p, g]])));
    if (combos.length > 64) throw new SpecError('the regime expands into more than 64 regimes');
  }
  try {
    return combos.map((m) => Regime.fromGrowthMap(problem.params, m, problem.logParams, clip ? problem.constraints : []));
  } catch (e) {
    if (e instanceof EvalError) throw new SpecError(e.message);
    throw e;
  }
}

/**
 * The regimes of a spec that the problem's limits clip (SPEC §2.3: e.g. m = n^3 for a graph, which stands for the
 * same instances as m = n^2), as clipped; none if the limits change nothing or the spec is invalid.
 */
export function clippedRegimes(problem: Problem, specText: string): Regime[] {
  if (problem.constraints.length === 0) return [];
  try {
    const clipped = regimesFromSpec(problem, specText);
    const raw = regimesFromSpec(problem, specText, false);
    return clipped.filter((r, i) => r.key !== raw[i]?.key);
  } catch (e) {
    if (e instanceof SpecError) return [];
    throw e;
  }
}

function parseFormulaExpr(tex: string): Expr {
  try {
    return parseExpr(tex);
  } catch (e) {
    throw new SpecError(e instanceof ParseError ? `formula: ${e.message}` : String(e));
  }
}

/** Rate of a knob formula at a regime. @throws EvalError */
export function formulaRate(formula: Expr, regime: Regime, constants: ReadonlyMap<string, Growth>): Rate {
  return G.rateOf(formulaGrowth(formula, regime, constants));
}

/** The class of a formula in the problem's parameters at a regime. */
export function formulaGrowth(formula: Expr, regime: Regime, constants: ReadonlyMap<string, Growth>): Growth {
  const env = new Map(constants);
  for (const [p, g] of regime.env()) env.set(p, g);
  return evaluate(formula, { env });
}

/**
 * The power of an exponent knob (1 when not given; values within 1e-9 of 1 are 1).
 * @throws SpecError if it is not a positive finite number
 */
export function knobPower(k: Pick<Knob, 'power'>): number {
  const a = k.power ?? 1;
  if (!(a > 0 && Number.isFinite(a))) throw new SpecError(`the power must be a positive number (got ${a})`);
  return samePower(a, 1) ? 1 : a;
}

/** Whether a row (status ok) may be used under the scenario's settings. */
export function rowUsable(row: CompiledRow, scenario: Scenario): boolean {
  if (!scenario.settings.useRandomized && row.randomized) return false;
  return !scenario.settings.disabledRows.includes(row.id);
}

/** Fingerprint of everything lower-bound propagation depends on (besides the model). */
function lowerInputsOf(scenario: Scenario): string {
  const s = scenario.settings;
  const knobs = scenario.knobs.filter((k) => k.enabled && k.kind === 'LB').map((k) => [k.id, k.problem, k.regime, k.exponent, k.power, k.formula]);
  return JSON.stringify([knobs, scenario.constants, s.gridPoints, s.refineRounds, s.unknownRT, s.useRandomized, s.disabledRows]);
}

/** Fingerprint of everything upper-bound evaluation depends on (besides the model). */
function upperInputsOf(scenario: Scenario): string {
  const s = scenario.settings;
  const knobs = scenario.knobs.filter((k) => k.enabled && k.kind === 'UB').map((k) => [k.id, k.problem, k.regime, k.exponent, k.power, k.formula]);
  return JSON.stringify([knobs, scenario.constants, s.maxDepthUB, s.gridPoints, s.refineRounds, s.unknownRT, s.useRandomized, s.disabledRows]);
}

/**
 * Analyze `scenario` on `model`.
 * @param pinned problem id → extra regime specs whose bounds should be shown
 * @param previous an earlier analysis of the same model: its lower-bound facts and upper-bound cache are reused when
 *        their inputs did not change (e.g. moving an LB slider keeps all upper bounds)
 */
export function analyze(
  model: Model,
  scenario: Scenario,
  pinned: ReadonlyMap<string, readonly string[]> = new Map(),
  previous: Analysis | null = null,
  { complete = true }: { readonly complete?: boolean } = {},
): Analysis {
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  const lowerInputs = lowerInputsOf(scenario);
  const constants = constantEnv(model, scenario.constants);
  const opts: PropagationOptions = { settings: scenario.settings, constants, usable: (r) => rowUsable(r, scenario) };
  const knobIssues = new Map<string, string>();
  const knobRegimes = new Map<string, Regime[]>();
  const seeds: LBFact[] = [];
  const ubKnobs: UBKnob[] = [];

  for (const k of scenario.knobs) {
    if (!k.enabled) continue;
    try {
      instantiateKnob(model, k, constants, seeds, ubKnobs, knobRegimes);
    } catch (e) {
      if (e instanceof SpecError || e instanceof EvalError) knobIssues.set(k.id, e.message);
      else throw e;
    }
  }

  const sameModel = previous !== null && previous.model === model;
  const lower = sameModel && previous.lowerInputs === lowerInputs ? previous.lower : propagateLB(model, seeds, opts);

  // Regimes of interest per problem; upper bounds are computed at most of them (and searched from them: see upper.ts).
  const knobsOf = new Map<string, Knob[]>();
  for (const k of scenario.knobs) {
    const p = k.enabled ? findProblem(model, k.problem) : undefined;
    if (p !== undefined) knobsOf.set(p.id, [...(knobsOf.get(p.id) ?? []), k]);
  }
  const plans: Plan[] = [];
  const queue: Array<{ problem: string; regime: Regime }> = [];
  const interest = new Set<string>();
  for (const problem of model.problems.values()) {
    const entries = new Map<string, { regime: Regime; origins: Set<RegimeOrigin>; ubComputed: boolean }>();
    const addRegime = (r: Regime, o: RegimeOrigin): void => {
      const e = entries.get(r.key) ?? { regime: r, origins: new Set<RegimeOrigin>(), ubComputed: false };
      e.origins.add(o);
      entries.set(r.key, e);
    };
    if (problem.isStatic) {
      for (const spec of problem.regimeSpecs) {
        try {
          regimesFromSpec(problem, spec).forEach((r) => addRegime(r, 'config'));
        } catch {
          // reported as a model diagnostic
        }
      }
      for (const spec of pinned.get(problem.id) ?? []) {
        try {
          regimesFromSpec(problem, spec).forEach((r) => addRegime(r, 'pinned'));
        } catch {
          // invalid pinned spec: ignored (the UI validates before pinning)
        }
      }
    }
    const ubKnobAt = new Set<string>();
    for (const k of knobsOf.get(problem.id) ?? []) {
      for (const r of knobRegimes.get(k.id) ?? []) {
        addRegime(r, 'knob');
        if (k.kind === 'UB') ubKnobAt.add(r.key);
      }
    }
    // (upper bounds at every regime of a lower bound, so that no conflict stays hidden: the nicest first)
    const lbSorted = [...(lower.facts.get(problem.id)?.values() ?? [])]
      .map((f) => ({ f, key: lbRegimeKey(f) }))
      .sort((a, b) => compareKeys(a.key, b.key))
      .map((x) => x.f);
    for (const f of lbSorted) addRegime(f.regime, 'lb');
    const first = new Set(lbSorted.slice(0, MAX_UB_REGIMES_FIRST).map((f) => f.regime.key));
    for (const e of entries.values()) {
      e.ubComputed = problem.isStatic && (complete || e.origins.size > 1 || !e.origins.has('lb') || first.has(e.regime.key));
      if (problem.isStatic && !e.ubComputed) queue.push({ problem: problem.id, regime: e.regime });
      // The regimes of interest to the search: configured, pinned, of algorithms. Not those of lower bounds (or of their
      // knobs), so that the search does not depend on them and survives their changes: the upper bounds there come
      // from an overlay.
      const listed = e.origins.has('config') || e.origins.has('pinned') || ubKnobAt.has(e.regime.key);
      if (problem.isStatic && listed) interest.add(nodeKey(problem.id, e.regime));
    }
    plans.push({ problem, entries: [...entries.values()] });
  }
  const upperInputs = JSON.stringify([upperInputsOf(scenario), [...interest].sort()]);
  const sameUpper = sameModel && previous.upperInputs === upperInputs;
  const upper = sameUpper ? previous.upper : new UpperBounds(model, ubKnobs, opts, interest);
  // (the overlay too: its bounds depend on the same inputs, and it keeps those it computed for regimes of lower bounds)
  const upperOverlay = sameUpper ? previous.upperOverlay : upper.overlay();

  const { summaries, rowUse } = summarize(plans, lower, upper, upperOverlay, interest);
  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  return {
    model,
    scenario,
    lower,
    upper,
    upperOverlay,
    summaries,
    knobIssues,
    knobRegimes,
    rowUse,
    elapsedMs: t1 - t0,
    lowerInputs,
    upperInputs,
    complete: queue.length === 0,
    completion: { plans, interest, queue, next: 0 },
  };
}

/**
 * Compute the upper bounds an incomplete analysis left out (see Analysis.complete), until `timeUp()` says to stop.
 * @returns the complete analysis (a new object; the same bounds elsewhere), or null if time ran out first (call again
 *          to continue where it stopped)
 */
export function completeAnalysis(a: Analysis, timeUp: () => boolean = () => false): Analysis | null {
  if (a.complete) return a;
  const c = a.completion;
  const t0 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  while (c.next < c.queue.length) {
    if (timeUp()) return null;
    const { problem, regime } = c.queue[c.next]!;
    a.upperOverlay.query(problem, regime);
    c.next += 1;
  }
  const plans = c.plans.map(({ problem, entries }) => ({ problem, entries: entries.map((e) => ({ ...e, ubComputed: problem.isStatic })) }));
  const { summaries, rowUse } = summarize(plans, a.lower, a.upper, a.upperOverlay, c.interest);
  const t1 = typeof performance !== 'undefined' ? performance.now() : Date.now();
  return { ...a, summaries, rowUse, elapsedMs: a.elapsedMs + (t1 - t0), complete: true, completion: { plans, interest: c.interest, queue: [], next: 0 } };
}

/** Each problem's summary (its regimes with their bounds, in the order of display), and how often each row is used. */
function summarize(
  plans: readonly Plan[],
  lower: LBResult,
  upper: UpperBounds,
  upperOverlay: UpperBounds,
  interest: ReadonlySet<string>,
): { summaries: Map<string, ProblemSummary>; rowUse: Map<string, { lb: number; ub: number }> } {
  // Each problem's regimes with their bounds, in the order of display (regimeRank.ts).
  type Draft = Omit<RegimeSummary, 'listed'>;
  const drafts = new Map<string, { problem: Problem; regimes: Draft[] }>();
  for (const { problem, entries } of plans) {
    const lbFacts = lower.facts.get(problem.id);
    const own = entries.map(({ regime, origins, ubComputed }) => {
      const lb = lbFacts?.get(regime.key) ?? null;
      const ub = !ubComputed ? null : interest.has(nodeKey(problem.id, regime)) ? upper.query(problem.id, regime) : upperOverlay.query(problem.id, regime);
      return { regime, origins, ubComputed, lb, ub };
    });
    const regimes: Array<{ s: Draft; key: number[] }> = [];
    // (the regimes that stand for the problem, configured or pinned: another regime inside one of them is a special case)
    const general = own.filter((x) => x.origins.has('config') || x.origins.has('pinned'));
    for (const e of own) {
      const { lb, ub } = problem.isStatic ? throughContainment(e, own) : e;
      const s: Draft = { regime: e.regime, lb, ub, ubComputed: e.ubComputed, status: statusOf(lb, ub), origins: [...e.origins] };
      const special = !general.includes(e) && general.some((g) => g.regime.key !== e.regime.key && g.regime.contains(e.regime));
      regimes.push({ s, key: regimeRankKey({ ...s, ownStatus: statusOf(e.lb, e.ub), special }) });
    }
    regimes.sort((a, b) => compareKeys(a.key, b.key));
    drafts.set(problem.id, { problem, regimes: regimes.map((x) => x.s) });
  }
  // The regimes listed (RegimeSummary.listed): the first, and those listed by themselves, then those the derivations of
  // the bounds listed so far go through, at other problems (a weird regime that only leads to weird ones stays out), and
  // the regimes of the problem that a listed bound is carried from (so that "carried from" names a regime shown).
  const listed = new Set<string>();
  for (const { problem, regimes } of drafts.values()) {
    regimes.forEach((s, i) => {
      if (i === 0 || listedByItself(s)) listed.add(nodeKey(problem.id, s.regime));
    });
  }
  const through = new Set<string>();
  for (const { problem, regimes } of drafts.values()) {
    for (const s of regimes) {
      if (!listed.has(nodeKey(problem.id, s.regime))) continue;
      for (const n of derivationNodes(s)) if (n.problem !== problem.id) through.add(nodeKey(n.problem, n.regime));
      for (const f of [s.lb, s.ub]) if (f !== null && f.problem === problem.id && f.regime.key !== s.regime.key) through.add(nodeKey(problem.id, f.regime));
    }
  }
  const summaries = new Map<string, ProblemSummary>();
  const rowUse = new Map<string, { lb: number; ub: number }>();
  const use = (rowId: string, kind: 'lb' | 'ub'): void => {
    const u = rowUse.get(rowId) ?? { lb: 0, ub: 0 };
    rowUse.set(rowId, { ...u, [kind]: u[kind] + 1 });
  };
  for (const { problem, regimes: drafted } of drafts.values()) {
    const regimes: RegimeSummary[] = drafted.map((s) => {
      const key = nodeKey(problem.id, s.regime);
      return { ...s, listed: listed.has(key) || through.has(key) };
    });
    // (with a conflict anywhere, the first regime has one: regimeRankKey ranks conflicts first)
    summaries.set(problem.id, { problem, regimes, status: regimes[0]?.status ?? 'none', primary: regimes[0] ?? null });
    // The reductions the listed bounds use (the graph colors them).
    for (const s of regimes) {
      if (!s.listed) continue;
      if (s.lb) lbRows(s.lb).forEach((r) => use(r, 'lb'));
      if (s.ub) ubPath(s.ub).rows.forEach((r) => use(r, 'ub'));
    }
  }
  return { summaries, rowUse };
}

/**
 * A regime's best bounds among its own and those of the problem's other regimes that carry over (SPEC §2.3): the lower
 * bound of a regime it contains (its instances are among these), the upper bound of a regime that contains it.
 */
function throughContainment(e: ContainmentEntry, all: readonly ContainmentEntry[]): { lb: LBFact | null; ub: UBFact | null } {
  let lb = e.lb;
  let ub = e.ub;
  // (the preference of the regimes the bounds are carried from, null for the regime's own bound, which ties keep)
  let lbFrom: number[] | null = null;
  let ubFrom: number[] | null = null;
  for (const o of all) {
    if (o.regime.key === e.regime.key) continue;
    if (o.lb !== null && e.regime.contains(o.regime)) {
      const c = lb === null ? 1 : G.compareRates(o.lb, lb, 1e-9);
      if (c > 0 || (c === 0 && lbFrom !== null && compareKeys(sourcePreference(o), lbFrom) < 0)) {
        lb = o.lb;
        lbFrom = sourcePreference(o);
      }
    }
    if (o.ub !== null && o.regime.contains(e.regime)) {
      const c = ub === null ? -1 : G.compareRates(o.ub, ub, 1e-9);
      if (c < 0 || (c === 0 && ubFrom !== null && compareKeys(sourcePreference(o), ubFrom) < 0)) {
        ub = o.ub;
        ubFrom = sourcePreference(o);
      }
    }
  }
  return { lb, ub };
}

/** A regime of a problem with its own bounds, as throughContainment compares them. */
interface ContainmentEntry {
  readonly regime: Regime;
  readonly origins: ReadonlySet<RegimeOrigin>;
  readonly lb: LBFact | null;
  readonly ub: UBFact | null;
}

/**
 * Which of two regimes with equal bounds a bound is said to be carried from (smaller first): one the inspector lists by
 * itself (so that "carried from" names a regime shown), configured or pinned before a knob's before a reduction's, then
 * the nicer one. Without it the first in the order of the rows won.
 */
function sourcePreference(o: ContainmentEntry): number[] {
  const n = regimeNiceness(o.regime);
  const origins = [...o.origins];
  const listed = listedByItself({ regime: o.regime, lb: null, status: 'none', origins });
  return [listed ? 0 : 1, o.origins.has('config') || o.origins.has('pinned') ? 0 : o.origins.has('knob') ? 1 : 2, n.tier, n.weight];
}

/** The problems and reductions a bound's derivation goes through (its own problem included). */
export interface DerivationPath {
  readonly problems: ReadonlySet<string>;
  readonly rows: ReadonlySet<string>;
}

/** A lower bound's derivation: back along its chain to the knob (a knob on the problem itself: the problem alone). */
export function lbPath(f: LBFact): DerivationPath {
  const chain = lbChain(f);
  return { problems: new Set(chain.map((x) => x.problem)), rows: new Set(chain.flatMap((x) => (x.origin.kind === 'row' ? [x.origin.rowId] : []))) };
}

/** The reductions of a lower bound's derivation (see lbPath). */
function lbRows(f: LBFact): ReadonlySet<string> {
  return lbPath(f).rows;
}

/** The problems and regimes a regime's bounds are derived through: its lower bound's chain and its upper bound's tree. */
function derivationNodes(s: { readonly lb: LBFact | null; readonly ub: UBFact | null }): Array<{ readonly problem: string; readonly regime: Regime }> {
  const out: Array<{ problem: string; regime: Regime }> = [];
  if (s.lb) for (const f of lbChain(s.lb).slice(1)) out.push({ problem: f.problem, regime: f.regime });
  if (s.ub) {
    const seen = new Set<UBFact>([s.ub]);
    const walk = (g: UBFact): void => {
      for (const c of ubParts(g)) {
        if (seen.has(c)) continue;
        seen.add(c);
        out.push({ problem: c.problem, regime: c.regime });
        walk(c);
      }
    };
    walk(s.ub);
  }
  return out;
}

/** An upper bound's derivation: its whole tree down to the knobs (a knob on the problem itself: the problem alone). */
export function ubPath(f: UBFact): DerivationPath {
  const problems = new Set<string>();
  const rows = new Set<string>();
  const seen = new Set<UBFact>();
  const walk = (g: UBFact): void => {
    if (seen.has(g)) return;
    seen.add(g);
    problems.add(g.problem);
    if (g.origin.kind === 'row') rows.add(g.origin.rowId);
    ubParts(g).forEach(walk);
  };
  walk(f);
  return { problems, rows };
}

/**
 * The best upper bound of a problem at a regime the analysis did not list (e.g. one being pinned, or of a parameter
 * family's member), computed in an overlay that leaves the analysis as it is.
 */
export function upperOnDemand(analysis: Analysis, problemId: string, regime: Regime): UBFact | null {
  return analysis.upperOverlay.query(problemId, regime);
}

/**
 * The best bounds of a problem at one of its regimes and their derivations.
 * @param regimeKey the regime (default, or when the problem no longer has it: the primary one, which the graph shows)
 * @returns nulls for a bound the problem does not have (and for an unknown problem)
 */
export function boundDerivations(
  analysis: Analysis,
  problemId: string,
  regimeKey?: string,
): { readonly regime: RegimeSummary | null; readonly lb: DerivationPath | null; readonly ub: DerivationPath | null } {
  const summary = analysis.summaries.get(problemId);
  const s = summary?.regimes.find((r) => r.regime.key === regimeKey) ?? summary?.primary ?? null;
  if (s === null) return { regime: null, lb: null, ub: null };
  const ub = s.ubComputed ? s.ub : upperOnDemand(analysis, problemId, s.regime);
  return { regime: s, lb: s.lb ? lbPath(s.lb) : null, ub: ub ? ubPath(ub) : null };
}

function instantiateKnob(
  model: Model,
  k: Knob,
  constants: ReadonlyMap<string, Growth>,
  seeds: LBFact[],
  ubKnobs: UBKnob[],
  knobRegimes: Map<string, Regime[]>,
): void {
  const problem = findProblem(model, k.problem);
  if (problem === undefined) throw new SpecError(`unknown problem "${k.problem}"`);
  if (!problem.isStatic) throw new SpecError(`${problem.id} is a dynamic / multi-function problem (not supported)`);
  const formula = k.formula !== undefined ? parseFormulaExpr(k.formula) : null;
  if (k.kind === 'LB') {
    if (k.regime === undefined) throw new SpecError('an LB knob needs a regime');
    const regimes = regimesFromSpec(problem, k.regime);
    knobRegimes.set(k.id, regimes);
    const power = formula === null ? knobPower(k) : 1;
    for (const r of regimes) {
      const x = formula !== null ? formulaRate(formula, r, constants) : { power, exponent: k.exponent! };
      if (!(Number.isFinite(x.exponent) && x.exponent > 0 && Number.isFinite(x.power) && x.power > 0)) {
        const got = x.power === 0 || x.power === 1 ? G.formatNumber(x.exponent) : G.describeRate(x);
        throw new SpecError(`the lower bound must be a positive finite exponent (got ${got})`);
      }
      seeds.push({ problem: problem.id, regime: r, exponent: x.exponent, power: x.power, hops: 0, origin: { kind: 'knob', knobId: k.id } });
    }
    return;
  }
  // UB knob
  if (formula === null) {
    if (k.regime === undefined) throw new SpecError('an UB knob with an exponent needs a regime (or use a formula)');
    const regimes = regimesFromSpec(problem, k.regime);
    knobRegimes.set(k.id, regimes);
    if (!(k.exponent! >= 0)) throw new SpecError('the exponent must be nonnegative');
    const power = knobPower(k);
    ubKnobs.push({ id: k.id, problem: problem.id, exactKeys: new Set(regimes.map((r) => r.key)), exponent: k.exponent!, power, formula: null, filter: null });
    return;
  }
  let filter: Map<string, ParamSpec> | null = null;
  let probes: Regime[] = [];
  if (k.regime !== undefined && k.regime.trim() !== '') {
    filter = parseRegimeSpec(k.regime);
    for (const p of filter.keys()) if (!problem.params.includes(p)) throw new SpecError(`${p} is not a parameter of ${problem.id}`);
    probes = regimesFromSpec(problem, k.regime);
    knobRegimes.set(k.id, probes);
  } else {
    // (every configured regime: a formula such as n^2 \sigma^\sigma is a running time at σ = O(1) only)
    probes = problem.regimeSpecs.flatMap((spec) => {
      try {
        return regimesFromSpec(problem, spec);
      } catch {
        return [];
      }
    });
  }
  // The formula must give a finite running time of at least a constant somewhere: at its own regimes, or at one of the
  // problem's. Otherwise (e.g. \Omega(n^2), n^{O(1)}, \text{poly}(n), T(n), 2^n for a polynomial problem, or n^{-1} and
  // 0, which would count as polylogarithmic) the bound would just vanish, or be wrong; it is reported instead (SPEC §6.6).
  if (probes.length > 0) {
    let error: string | null = null;
    const ok = probes.some((r) => {
      try {
        const g = formulaGrowth(formula, r, constants);
        if (G.belowConstant(g)) {
          error = `a running time is at least a constant, and this is ${G.describe(g)}`;
          return false;
        }
        const x = G.rateOf(g);
        if (G.finiteRate(x)) return true;
        error = `it gives no finite running time (${G.describeRate(x)})`;
        return false;
      } catch (e) {
        if (!(e instanceof EvalError)) throw e;
        error = e.message;
        return false;
      }
    });
    if (!ok) {
      const where = probes.length === 1 || filter !== null ? `at the regime ${probes[0]!.key}` : `at the problem's regimes, e.g. ${probes[0]!.key}`;
      throw new SpecError(`formula: ${error ?? 'it does not evaluate'} (${where})`);
    }
  }
  ubKnobs.push({ id: k.id, problem: problem.id, exactKeys: null, exponent: null, power: 1, formula, filter });
}
