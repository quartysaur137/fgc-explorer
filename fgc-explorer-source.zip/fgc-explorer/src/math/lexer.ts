/**
 * Lexer for the LaTeX math subset of SPEC §4.
 *
 * Produces a flat token list. Whitespace and spacing commands are dropped. `\text{...}`-like commands become a single
 * `text` token holding their (trimmed) content, so multi-letter names such as \text{nnz} are atomic.
 */

export type TokenKind = 'num' | 'letter' | 'cmd' | 'sym' | 'text' | 'eof';

export interface Token {
  readonly kind: TokenKind;
  /** num: the digits ("1.5"); letter: one ASCII letter; cmd: name without backslash ("log", "{" for \{); sym: one
   *  character; text: content of \text{...}; eof: "". */
  readonly text: string;
  /** Offset of the token's first character in the input. */
  readonly pos: number;
}

/** A lexing or parsing failure at a position of the input. */
export class ParseError extends Error {
  constructor(
    message: string,
    readonly pos: number,
  ) {
    super(message);
    this.name = 'ParseError';
  }
}

/** Commands that only produce horizontal space. */
const SPACING = new Set([',', ';', ':', '!', ' ', 'quad', 'qquad', 'thinspace', 'medspace', 'thickspace', 'enspace']);
/** Commands whose braced argument is plain text (a name). */
const TEXT_CMDS = new Set(['text', 'textrm', 'textit', 'mathrm', 'operatorname', 'mathit', 'textnormal', 'mathsf']);
/** Commands that are ignored entirely (sizing / delimiter modifiers). */
const IGNORED = new Set([
  'left',
  'right',
  'big',
  'Big',
  'bigg',
  'Bigg',
  'bigl',
  'bigr',
  'Bigl',
  'Bigr',
  'displaystyle',
  'limits',
  'nolimits',
]);

/** Unicode characters accepted in place of their LaTeX commands (robustness for hand-edited cells). */
const UNICODE: Readonly<Record<string, { kind: TokenKind; text: string }>> = {
  '·': { kind: 'cmd', text: 'cdot' },
  '⋅': { kind: 'cmd', text: 'cdot' },
  '×': { kind: 'cmd', text: 'times' },
  '−': { kind: 'sym', text: '-' },
  '–': { kind: 'sym', text: '-' },
  '≤': { kind: 'cmd', text: 'le' },
  '≥': { kind: 'cmd', text: 'ge' },
  '⊆': { kind: 'cmd', text: 'subseteq' },
  '∈': { kind: 'cmd', text: 'in' },
  '√': { kind: 'cmd', text: 'sqrt' },
  'Σ': { kind: 'cmd', text: 'sum' },
  '∑': { kind: 'cmd', text: 'sum' },
  'Θ': { kind: 'cmd', text: 'Theta' },
  'Ω': { kind: 'cmd', text: 'Omega' },
  'Õ': { kind: 'cmd', text: 'softO' },
  'α': { kind: 'cmd', text: 'alpha' },
  'β': { kind: 'cmd', text: 'beta' },
  'γ': { kind: 'cmd', text: 'gamma' },
  'δ': { kind: 'cmd', text: 'delta' },
  'Δ': { kind: 'cmd', text: 'Delta' },
  'ε': { kind: 'cmd', text: 'epsilon' },
  'λ': { kind: 'cmd', text: 'lambda' },
  'ρ': { kind: 'cmd', text: 'rho' },
  'σ': { kind: 'cmd', text: 'sigma' },
  'ω': { kind: 'cmd', text: 'omega' },
};

/**
 * Tokenize `input`.
 * @throws ParseError on an unterminated \text{...} group or a lone backslash at the end.
 * @returns tokens ending with exactly one `eof` token.
 */
export function tokenize(input: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const n = input.length;
  while (i < n) {
    const ch = input[i]!;
    if (/\s/.test(ch) || ch === '~') {
      i += 1;
      continue;
    }
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(input[i + 1] ?? ''))) {
      const m = /^[0-9]*\.?[0-9]+|^[0-9]+/.exec(input.slice(i));
      const text = m![0];
      tokens.push({ kind: 'num', text, pos: i });
      i += text.length;
      continue;
    }
    if (/[A-Za-z]/.test(ch)) {
      tokens.push({ kind: 'letter', text: ch, pos: i });
      i += 1;
      continue;
    }
    if (ch === '\\') {
      const start = i;
      const next = input[i + 1];
      if (next === undefined) throw new ParseError('lone backslash at end of input', i);
      if (/[A-Za-z]/.test(next)) {
        let j = i + 1;
        while (j < n && /[A-Za-z]/.test(input[j]!)) j += 1;
        const name = input.slice(i + 1, j);
        i = j;
        if (SPACING.has(name) || IGNORED.has(name)) continue;
        if (TEXT_CMDS.has(name)) {
          while (i < n && /\s/.test(input[i]!)) i += 1;
          if (input[i] !== '{') throw new ParseError(`\\${name} must be followed by {...}`, i);
          const close = input.indexOf('}', i + 1);
          if (close < 0) throw new ParseError(`unterminated \\${name}{...}`, i);
          tokens.push({ kind: 'text', text: input.slice(i + 1, close).trim(), pos: start });
          i = close + 1;
          continue;
        }
        tokens.push({ kind: 'cmd', text: name, pos: start });
        continue;
      }
      // Single-character command: \, \; \! \{ \} \| \# \\ ...
      i += 2;
      if (SPACING.has(next)) continue;
      tokens.push({ kind: 'cmd', text: next, pos: start });
      continue;
    }
    const uni = UNICODE[ch];
    if (uni !== undefined) {
      tokens.push({ kind: uni.kind, text: uni.text, pos: i });
      i += 1;
      continue;
    }
    tokens.push({ kind: 'sym', text: ch, pos: i });
    i += 1;
  }
  tokens.push({ kind: 'eof', text: '', pos: n });
  return tokens;
}
