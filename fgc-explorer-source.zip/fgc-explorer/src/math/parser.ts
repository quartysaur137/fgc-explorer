/**
 * Recursive-descent parser for the formula language (SPEC §4.1).
 *
 * Entry points never return partial results: they either return a complete tree or throw ParseError with the position
 * of the first offending token.
 */

import { BoundKind, Expr, Formula, FuncName, SignedTerm } from './ast';
import { ParseError, Token, tokenize } from './lexer';

export { ParseError } from './lexer';

/** Greek letters accepted as identifiers, mapped to their canonical name. */
const GREEK: Readonly<Record<string, string>> = {
  alpha: 'alpha', beta: 'beta', gamma: 'gamma', delta: 'delta', epsilon: 'epsilon', varepsilon: 'epsilon',
  zeta: 'zeta', eta: 'eta', theta: 'theta', vartheta: 'theta', iota: 'iota', kappa: 'kappa', lambda: 'lambda',
  mu: 'mu', nu: 'nu', xi: 'xi', pi: 'pi', rho: 'rho', varrho: 'rho', sigma: 'sigma', tau: 'tau', upsilon: 'upsilon',
  phi: 'phi', varphi: 'phi', chi: 'chi', psi: 'psi', omega: 'omega', Gamma: 'Gamma', Delta: 'Delta', Theta: 'Theta',
  Lambda: 'Lambda', Xi: 'Xi', Pi: 'Pi', Sigma: 'Sigma', Upsilon: 'Upsilon', Phi: 'Phi', Psi: 'Psi', Omega: 'Omega',
};

/** Commands that start an atom (used to detect juxtaposition = multiplication). */
const ATOM_CMDS = new Set([
  ...Object.keys(GREEK),
  'log', 'ln', 'lg', 'sqrt', 'frac', 'dfrac', 'tfrac', 'binom', 'dbinom', 'tbinom', 'max', 'min', 'deg', 'exp',
  'poly', 'polylog', 'lceil', 'lfloor', 'tilde', 'widetilde', 'hat', 'widehat', 'sum', '{', 'softO',
]);

const ALT_CMDS = new Set(['subseteq', 'le', 'leq']);
const MUL_CMDS = new Set(['cdot', 'times', 'ast']);

class Parser {
  private i = 0;

  constructor(private readonly toks: readonly Token[]) {}

  // ---- token helpers ----

  private peek(k = 0): Token {
    return this.toks[Math.min(this.i + k, this.toks.length - 1)]!;
  }

  private next(): Token {
    const t = this.peek();
    if (this.i < this.toks.length - 1) this.i += 1;
    return t;
  }

  private isSym(t: Token, ch: string): boolean {
    return t.kind === 'sym' && t.text === ch;
  }

  private isCmd(t: Token, name: string): boolean {
    return t.kind === 'cmd' && t.text === name;
  }

  private fail(message: string, t: Token = this.peek()): never {
    const shown = t.kind === 'eof' ? 'end of input' : t.kind === 'cmd' ? `\\${t.text}` : `"${t.text}"`;
    throw new ParseError(`${message} (at ${shown})`, t.pos);
  }

  private expectSym(ch: string): void {
    if (!this.isSym(this.peek(), ch)) this.fail(`expected "${ch}"`);
    this.next();
  }

  private expectCmd(name: string): void {
    if (!this.isCmd(this.peek(), name)) this.fail(`expected \\${name}`);
    this.next();
  }

  expectEof(): void {
    if (this.peek().kind !== 'eof') this.fail('unexpected token');
  }

  // ---- grammar ----

  /** formula := expr (ALT expr)* */
  formula(): Formula {
    const alternatives = [this.expr()];
    while (this.atAlternativeSeparator()) {
      this.next();
      alternatives.push(this.expr());
    }
    return { alternatives };
  }

  /** list := expr (',' expr)* */
  list(): Expr[] {
    const out = [this.expr()];
    while (this.isSym(this.peek(), ',')) {
      this.next();
      out.push(this.expr());
    }
    return out;
  }

  atAlternativeSeparator(): boolean {
    const t = this.peek();
    return (t.kind === 'cmd' && ALT_CMDS.has(t.text)) || this.isSym(t, '=');
  }

  /** expr := ['+'|'-'] term (('+'|'-') term)* */
  expr(): Expr {
    const terms: SignedTerm[] = [];
    let sign: 1 | -1 = 1;
    if (this.isSym(this.peek(), '+')) this.next();
    else if (this.isSym(this.peek(), '-')) {
      this.next();
      sign = -1;
    }
    terms.push({ sign, expr: this.term() });
    for (;;) {
      const t = this.peek();
      if (this.isSym(t, '+') || this.isSym(t, '-')) {
        this.next();
        terms.push({ sign: t.text === '-' ? -1 : 1, expr: this.term() });
      } else break;
    }
    if (terms.length === 1) {
      const only = terms[0]!;
      return only.sign === 1 ? only.expr : { type: 'neg', arg: only.expr };
    }
    return { type: 'add', terms };
  }

  /** term := unary (('\cdot' | '/' | juxtaposition) unary)*, left-associative */
  term(): Expr {
    let acc = this.unary();
    for (;;) {
      const t = this.peek();
      if ((t.kind === 'cmd' && MUL_CMDS.has(t.text)) || this.isSym(t, '*')) {
        this.next();
        acc = this.times(acc, this.unary());
      } else if (this.isSym(t, '/')) {
        this.next();
        acc = { type: 'div', num: acc, den: this.unary() };
      } else if (this.startsAtom(t)) {
        acc = this.times(acc, this.power());
      } else break;
    }
    return acc;
  }

  private times(a: Expr, b: Expr): Expr {
    const fa = a.type === 'mul' ? a.factors : [a];
    return { type: 'mul', factors: [...fa, b] };
  }

  private startsAtom(t: Token): boolean {
    switch (t.kind) {
      case 'num':
      case 'letter':
      case 'text':
        return true;
      case 'sym':
        return t.text === '(' || t.text === '[' || t.text === '{';
      case 'cmd':
        return ATOM_CMDS.has(t.text);
      default:
        return false;
    }
  }

  /** unary := '-' unary | '+' unary | power */
  unary(): Expr {
    const t = this.peek();
    if (this.isSym(t, '-')) {
      this.next();
      return { type: 'neg', arg: this.unary() };
    }
    if (this.isSym(t, '+')) {
      this.next();
      return this.unary();
    }
    return this.power();
  }

  /** power := atom ['^' script] (also accepts a subscript after a group, which is ignored) */
  power(): Expr {
    const base = this.atom();
    if (this.isSym(this.peek(), '^')) {
      this.next();
      const exp = this.script();
      if (this.isSym(this.peek(), '^')) this.fail('double exponent');
      return { type: 'pow', base, exp };
    }
    return base;
  }

  /** script := '{' expr '}' | one token (a single digit, letter, Greek letter or \text{...}) */
  script(): Expr {
    const t = this.peek();
    if (this.isSym(t, '{')) {
      this.next();
      const e = this.expr();
      this.expectSym('}');
      return e;
    }
    if (t.kind === 'num') {
      this.next();
      if (t.text.length > 1) {
        // LaTeX takes a single character: n^23 means n^2 * 3. Split the token.
        const rest: Token = { kind: 'num', text: t.text.slice(1), pos: t.pos + 1 };
        (this.toks as Token[]).splice(this.i, 0, rest);
        return { type: 'num', value: Number(t.text[0]) };
      }
      return { type: 'num', value: Number(t.text) };
    }
    if (t.kind === 'letter' || t.kind === 'text' || (t.kind === 'cmd' && GREEK[t.text] !== undefined)) {
      this.next();
      return { type: 'var', name: this.baseName(t) };
    }
    return this.fail('expected an exponent or subscript');
  }

  /** Canonical name of an identifier token (letter, Greek command or \text{...}). */
  private baseName(t: Token): string {
    if (t.kind === 'letter') return t.text;
    if (t.kind === 'cmd') {
      const g = GREEK[t.text];
      if (g === undefined) this.fail('expected an identifier', t);
      return g;
    }
    if (t.kind === 'text') {
      const name = t.text.replace(/\s+/g, '');
      if (!/^[A-Za-z][A-Za-z0-9]*$/.test(name)) this.fail(`unsupported \\text{${t.text}}`, t);
      return name;
    }
    return this.fail('expected an identifier', t);
  }

  /** Subscript name: one token, or a braced sequence of identifier-like tokens, concatenated. */
  private subscriptName(): string {
    const t = this.peek();
    if (this.isSym(t, '{')) {
      this.next();
      let name = '';
      while (!this.isSym(this.peek(), '}')) {
        const u = this.next();
        if (u.kind === 'num') name += u.text;
        else if (u.kind === 'letter' || u.kind === 'text' || (u.kind === 'cmd' && GREEK[u.text] !== undefined)) {
          name += this.baseName(u);
        } else this.fail('unsupported subscript', u);
      }
      this.next();
      if (name === '') this.fail('empty subscript', t);
      return name;
    }
    const u = this.next();
    if (u.kind === 'num') return u.text;
    return this.baseName(u);
  }

  /** identifier := base ['_' subscript] ("'")*, given the already consumed base token. */
  private identifierAfter(baseToken: Token, baseOverride?: string): string {
    let name = baseOverride ?? this.baseName(baseToken);
    if (this.isSym(this.peek(), '_')) {
      this.next();
      name += `_${this.subscriptName()}`;
    }
    while (this.isSym(this.peek(), "'")) {
      this.next();
      name += "'";
    }
    return name;
  }

  private args(): Expr[] {
    this.expectSym('(');
    const out: Expr[] = [];
    if (this.isSym(this.peek(), ')')) {
      this.next();
      return out;
    }
    out.push(this.expr());
    while (this.isSym(this.peek(), ',')) {
      this.next();
      out.push(this.expr());
    }
    this.expectSym(')');
    return out;
  }

  /** Braced group {expr}. */
  private group(): Expr {
    this.expectSym('{');
    const e = this.expr();
    this.expectSym('}');
    return e;
  }

  private bound(kind: BoundKind): Expr {
    const a = this.args();
    if (a.length !== 1) this.fail(`${kind}(...) takes one argument`);
    return { type: 'bound', kind, arg: a[0]! };
  }

  atom(): Expr {
    const t = this.peek();
    switch (t.kind) {
      case 'num':
        this.next();
        return { type: 'num', value: Number(t.text) };
      case 'letter':
        return this.letterAtom();
      case 'text':
        return this.textAtom();
      case 'cmd':
        return this.commandAtom();
      case 'sym':
        return this.symbolAtom();
      default:
        return this.fail('unexpected end of input');
    }
  }

  private letterAtom(): Expr {
    const t = this.next();
    // Bounds O(...), O_k(...), o(...)
    if ((t.text === 'O' || t.text === 'o') && this.isSym(this.peek(), '(')) {
      return this.bound(t.text === 'O' ? 'O' : 'o');
    }
    if (t.text === 'O' && this.isSym(this.peek(), '_')) {
      const save = this.i;
      this.next();
      this.subscriptName();
      if (this.isSym(this.peek(), '(')) return this.bound('Osub');
      this.i = save;
    }
    const name = this.identifierAfter(t);
    if (this.isSym(this.peek(), '(')) {
      if (name === 'T' || name.startsWith('T_')) return { type: 'call', fn: name, args: this.args() };
      return { type: 'apply', name, args: this.args() };
    }
    return { type: 'var', name };
  }

  private textAtom(): Expr {
    const t = this.next();
    const word = t.text.replace(/\s+/g, '');
    if ((word === 'poly' || word === 'polylog') && this.isSym(this.peek(), '(')) {
      return { type: 'func', fn: word, args: this.args() };
    }
    const name = this.identifierAfter(t);
    if (this.isSym(this.peek(), '(')) return { type: 'apply', name, args: this.args() };
    return { type: 'var', name };
  }

  private symbolAtom(): Expr {
    const t = this.next();
    switch (t.text) {
      case '(': {
        const e = this.expr();
        this.expectSym(')');
        return e;
      }
      case '[': {
        const e = this.expr();
        this.expectSym(']');
        return e;
      }
      case '{': {
        const e = this.expr();
        this.expectSym('}');
        return e;
      }
      case '|': {
        const e = this.expr();
        this.expectSym('|');
        if (e.type === 'var') return { type: 'var', name: `|${e.name}|` };
        return { type: 'func', fn: 'abs', args: [e] };
      }
      default:
        return this.fail('unexpected symbol', t);
    }
  }

  private commandAtom(): Expr {
    const t = this.peek();
    const name = t.text;
    if (GREEK[name] !== undefined) {
      this.next();
      if ((name === 'Theta' || name === 'Omega') && this.isSym(this.peek(), '(')) {
        return this.bound(name === 'Theta' ? 'Theta' : 'Omega');
      }
      const id = this.identifierAfter(t);
      if (this.isSym(this.peek(), '(')) return { type: 'apply', name: id, args: this.args() };
      return { type: 'var', name: id };
    }
    this.next();
    switch (name) {
      case 'log':
      case 'ln':
      case 'lg':
        return this.logAtom(name);
      case 'sqrt': {
        if (this.isSym(this.peek(), '[')) {
          this.next();
          const k = this.expr();
          this.expectSym(']');
          return { type: 'func', fn: 'root', args: [this.group(), k] };
        }
        return { type: 'func', fn: 'sqrt', args: [this.group()] };
      }
      case 'frac':
      case 'dfrac':
      case 'tfrac': {
        const a = this.group();
        const b = this.group();
        return { type: 'div', num: a, den: b };
      }
      case 'binom':
      case 'dbinom':
      case 'tbinom': {
        const a = this.group();
        const b = this.group();
        return { type: 'func', fn: 'binom', args: [a, b] };
      }
      case 'max':
      case 'min': {
        if (this.isCmd(this.peek(), '{')) {
          this.next();
          const items = [this.expr()];
          while (this.isSym(this.peek(), ',')) {
            this.next();
            items.push(this.expr());
          }
          this.expectCmd('}');
          return { type: 'func', fn: name, args: items };
        }
        const a = this.args();
        if (a.length === 0) this.fail(`\\${name} needs arguments`);
        return { type: 'func', fn: name, args: a };
      }
      case 'deg':
      case 'exp':
      case 'poly':
      case 'polylog': {
        const fn: FuncName = name;
        const a = this.args();
        if (a.length !== 1) this.fail(`\\${name} takes one argument`);
        return { type: 'func', fn, args: a };
      }
      case 'lceil': {
        const e = this.expr();
        this.expectCmd('rceil');
        return { type: 'func', fn: 'ceil', args: [e] };
      }
      case 'lfloor': {
        const e = this.expr();
        this.expectCmd('rfloor');
        return { type: 'func', fn: 'floor', args: [e] };
      }
      case 'softO':
        return this.bound('softO');
      case 'tilde':
      case 'widetilde': {
        this.expectSym('{');
        const inner = this.next();
        this.expectSym('}');
        let kind: BoundKind | null = null;
        if (inner.kind === 'letter' && inner.text === 'O') kind = 'softO';
        else if (this.isCmd(inner, 'Theta')) kind = 'softTheta';
        else if (this.isCmd(inner, 'Omega')) kind = 'softOmega';
        if (kind === null || !this.isSym(this.peek(), '(')) this.fail('only \\tilde{O}(...), \\tilde{\\Theta}(...), \\tilde{\\Omega}(...) are supported', inner);
        return this.bound(kind);
      }
      case 'hat':
      case 'widehat': {
        this.expectSym('{');
        const inner = this.next();
        const base = `hat_${this.baseName(inner)}`;
        this.expectSym('}');
        const id = this.identifierAfter(inner, base);
        if (this.isSym(this.peek(), '(')) return { type: 'apply', name: id, args: this.args() };
        return { type: 'var', name: id };
      }
      case 'sum':
        return this.sumAtom();
      case '{': {
        const e = this.expr();
        this.expectCmd('}');
        return e;
      }
      default:
        return this.fail('unsupported command', t);
    }
  }

  /** LOG ['_' base] ['^' power] logarg */
  private logAtom(name: string): Expr {
    let base: Expr | null = name === 'ln' ? { type: 'num', value: Math.E } : null;
    let power: Expr | null = null;
    for (let k = 0; k < 2; k++) {
      if (this.isSym(this.peek(), '_') && base === null) {
        this.next();
        base = this.script();
      } else if (this.isSym(this.peek(), '^') && power === null) {
        this.next();
        power = this.script();
      }
    }
    let arg: Expr;
    if (this.isSym(this.peek(), '(')) {
      this.next();
      arg = this.expr();
      this.expectSym(')');
    } else {
      arg = this.logVariable() ?? this.power();
    }
    const log: Expr = { type: 'func', fn: 'log', args: base ? [arg, base] : [arg] };
    return power ? { type: 'pow', base: log, exp: power } : log;
  }

  /**
   * The argument of an unparenthesized \log when it is a letter (with its subscript and exponent) followed by "(":
   * the letter alone, so that `\log n (n + m)` reads as (log n)(n + m), as written, and not as log(n·(n + m)), which
   * is what `n (n + m)` means elsewhere. Null, consuming nothing, for anything else (and for O(…), o(…) and T(…)).
   */
  private logVariable(): Expr | null {
    const t = this.peek();
    if (t.kind !== 'letter' || /^[OoT]$/.test(t.text)) return null;
    const save = this.i;
    this.next();
    const name = this.identifierAfter(t);
    let arg: Expr = { type: 'var', name };
    if (this.isSym(this.peek(), '^')) {
      this.next();
      arg = { type: 'pow', base: arg, exp: this.script() };
    }
    if (this.isSym(this.peek(), '(')) return arg;
    this.i = save;
    return null;
  }

  /** '\sum' ['_' sub] ['^' script] term, where sub is "i", "{i=lo}" or "{v \in V}". */
  private sumAtom(): Expr {
    let index: string | null = null;
    let lo: Expr | null = null;
    let hi: Expr | null = null;
    for (let k = 0; k < 2; k++) {
      if (this.isSym(this.peek(), '_') && index === null) {
        this.next();
        if (this.isSym(this.peek(), '{')) {
          this.next();
          const id = this.next();
          index = this.identifierAfter(id);
          if (this.isSym(this.peek(), '=')) {
            this.next();
            lo = this.expr();
          } else if (this.isCmd(this.peek(), 'in')) {
            // \sum_{v \in V}: an index set, not a range.
            while (!this.isSym(this.peek(), '}') && this.peek().kind !== 'eof') this.next();
          }
          this.expectSym('}');
        } else {
          const id = this.next();
          index = this.baseName(id);
        }
      } else if (this.isSym(this.peek(), '^') && hi === null) {
        this.next();
        hi = this.script();
      }
    }
    const body = this.term();
    return { type: 'sum', index, lo, hi, body };
  }
}

function parser(src: string): Parser {
  return new Parser(tokenize(src));
}

/**
 * Parse a formula (one or more alternatives separated by \subseteq, \le, \leq or =).
 * @throws ParseError if `src` is not in the language of SPEC §4.1.
 */
export function parseFormula(src: string): Formula {
  const p = parser(src);
  const f = p.formula();
  p.expectEof();
  return f;
}

/**
 * Parse a single expression (no alternatives).
 * @throws ParseError if `src` is not a single expression.
 */
export function parseExpr(src: string): Expr {
  const p = parser(src);
  const e = p.expr();
  p.expectEof();
  return e;
}

/**
 * Parse a comma-separated list of expressions at top level, e.g. a To-time signature "T_p(n, m), T_q(n, m)".
 * @throws ParseError if some item is not an expression.
 */
export function parseList(src: string): Expr[] {
  const p = parser(src);
  const out = p.list();
  p.expectEof();
  return out;
}

/** A definition "X = e_1 = e_2 = ...": the defined identifier and the alternatives for its value. */
export interface Definition {
  readonly name: string;
  readonly alternatives: readonly Expr[];
}

/**
 * Parse a definition span such as "N = O(m + k \cdot 2^{n/(2k)})" or "\lambda = k - \lceil k/2 \rceil + 1 = ...".
 * @returns null if `src` is not of the form identifier '=' formula (no exception: legends contain arbitrary math).
 */
export function parseDefinition(src: string): Definition | null {
  let f: Formula;
  try {
    f = parseFormula(src);
  } catch {
    return null;
  }
  const [lhs, ...rest] = f.alternatives;
  if (lhs === undefined || lhs.type !== 'var' || rest.length === 0) return null;
  // Only "=" separators make a definition; \subseteq/\le chains are rejected by checking the source text.
  if (/\\subseteq|\\leq?(?![a-z])|\\geq?(?![a-z])/.test(src)) return null;
  return { name: lhs.name, alternatives: rest };
}
