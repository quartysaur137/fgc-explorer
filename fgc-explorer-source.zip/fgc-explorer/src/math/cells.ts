/**
 * Reading formulas out of sheet cells (SPEC §3.2): cells are prose with $...$ math spans.
 */

import { Definition, parseDefinition } from './parser';

export interface MathSpan {
  /** LaTeX between the dollars (trimmed). */
  readonly tex: string;
  /** Offset of the opening dollar. */
  readonly start: number;
  /** Offset just after the closing dollar. */
  readonly end: number;
}

/**
 * The $...$ spans of a cell, in order. "\$" is not a delimiter. An unmatched final "$" is ignored.
 */
export function mathSpans(cell: string): MathSpan[] {
  const spans: MathSpan[] = [];
  let open = -1;
  for (let i = 0; i < cell.length; i++) {
    if (cell[i] !== '$' || (i > 0 && cell[i - 1] === '\\')) continue;
    if (open < 0) {
      open = i;
    } else {
      const tex = cell.slice(open + 1, i).trim();
      if (tex !== '') spans.push({ tex, start: open, end: i + 1 });
      open = -1;
    }
  }
  return spans;
}

/** The primary formula of a cell: its first math span, or null if it has none. */
export function primaryFormula(cell: string): string | null {
  return mathSpans(cell)[0]?.tex ?? null;
}

/**
 * Abbreviations defined in the legend of a From-time cell: every math span after the first one that parses as
 * "X = e_1 (= e_2 ...)" where X is an identifier not in `exclude` (e.g. the source problem's parameters).
 * Later definitions of the same name are ignored (the first one wins).
 */
export function legendDefinitions(cell: string, exclude: ReadonlySet<string>): Definition[] {
  const out: Definition[] = [];
  const seen = new Set<string>();
  for (const span of mathSpans(cell).slice(1)) {
    const d = parseDefinition(span.tex);
    if (d === null || exclude.has(d.name) || seen.has(d.name)) continue;
    seen.add(d.name);
    out.push(d);
  }
  return out;
}
