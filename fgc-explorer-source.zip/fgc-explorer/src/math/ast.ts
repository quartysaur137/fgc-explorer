/**
 * Expression ADT for the formula language (SPEC §4).
 *
 * Immutable plain objects (discriminated union on `type`), built only through the parser or the constructors below.
 */

/** Asymptotic-notation wrappers. `softO` = \tilde{O}, `Osub` = O_k (a subscripted O). */
export type BoundKind = 'O' | 'Osub' | 'Theta' | 'Omega' | 'o' | 'softO' | 'softTheta' | 'softOmega';

/** Built-in functions. `log` has an optional base (args[1]); `root` is \sqrt[k]{x} with args [x, k]. */
export type FuncName =
  | 'log'
  | 'sqrt'
  | 'root'
  | 'ceil'
  | 'floor'
  | 'abs'
  | 'max'
  | 'min'
  | 'binom'
  | 'deg'
  | 'poly'
  | 'polylog'
  | 'exp';

export interface SignedTerm {
  readonly sign: 1 | -1;
  readonly expr: Expr;
}

export type Expr =
  | { readonly type: 'num'; readonly value: number }
  | { readonly type: 'var'; readonly name: string }
  /** Sum of signed terms; at least two terms or one negative term. */
  | { readonly type: 'add'; readonly terms: readonly SignedTerm[] }
  | { readonly type: 'neg'; readonly arg: Expr }
  /** Product of at least two factors. */
  | { readonly type: 'mul'; readonly factors: readonly Expr[] }
  | { readonly type: 'div'; readonly num: Expr; readonly den: Expr }
  | { readonly type: 'pow'; readonly base: Expr; readonly exp: Expr }
  /** Oracle call of a time function of the target problem (T, T_p, T_u, T_q, T_r). */
  | { readonly type: 'call'; readonly fn: string; readonly args: readonly Expr[] }
  | { readonly type: 'func'; readonly fn: FuncName; readonly args: readonly Expr[] }
  /** `name(args)` where `name` is neither an oracle nor a built-in: a product if `name` is a variable in scope,
   *  otherwise a named function (only `alpha` = inverse Ackermann is known). Resolved at evaluation time. */
  | { readonly type: 'apply'; readonly name: string; readonly args: readonly Expr[] }
  | { readonly type: 'bound'; readonly kind: BoundKind; readonly arg: Expr }
  /** \sum_{index=lo}^{hi} body; index/lo/hi may be absent (e.g. \sum_v). */
  | {
      readonly type: 'sum';
      readonly index: string | null;
      readonly lo: Expr | null;
      readonly hi: Expr | null;
      readonly body: Expr;
    };

/** A formula: one or more alternative expressions for the same quantity (separated by \subseteq, \le or =). */
export interface Formula {
  readonly alternatives: readonly Expr[];
}

// ---- constructors (used by the parser and by tests) ----

export const num = (value: number): Expr => ({ type: 'num', value });
export const v = (name: string): Expr => ({ type: 'var', name });
export const add = (...terms: Expr[]): Expr =>
  terms.length === 1 ? terms[0]! : { type: 'add', terms: terms.map((expr) => ({ sign: 1 as const, expr })) };
export const sub = (a: Expr, b: Expr): Expr => ({
  type: 'add',
  terms: [
    { sign: 1, expr: a },
    { sign: -1, expr: b },
  ],
});
export const mul = (...factors: Expr[]): Expr => (factors.length === 1 ? factors[0]! : { type: 'mul', factors });
export const div = (a: Expr, b: Expr): Expr => ({ type: 'div', num: a, den: b });
export const pow = (base: Expr, exp: Expr): Expr => ({ type: 'pow', base, exp });
export const call = (fn: string, ...args: Expr[]): Expr => ({ type: 'call', fn, args });
export const func = (fn: FuncName, ...args: Expr[]): Expr => ({ type: 'func', fn, args });
export const bound = (kind: BoundKind, arg: Expr): Expr => ({ type: 'bound', kind, arg });

// ---- queries ----

/** Children of a node, in a fixed order. */
export function children(e: Expr): readonly Expr[] {
  switch (e.type) {
    case 'num':
    case 'var':
      return [];
    case 'add':
      return e.terms.map((t) => t.expr);
    case 'neg':
      return [e.arg];
    case 'mul':
      return e.factors;
    case 'div':
      return [e.num, e.den];
    case 'pow':
      return [e.base, e.exp];
    case 'call':
    case 'func':
    case 'apply':
      return e.args;
    case 'bound':
      return [e.arg];
    case 'sum':
      return [e.lo, e.hi, e.body].filter((x): x is Expr => x !== null);
  }
}

/**
 * Free identifiers of `e`: variable names and the names of `apply` nodes (which may be variables), excluding sum
 * indices inside their sums. Oracle function names are not included.
 */
export function freeIdentifiers(e: Expr): Set<string> {
  const out = new Set<string>();
  const walk = (x: Expr, bound: ReadonlySet<string>): void => {
    switch (x.type) {
      case 'var':
        if (!bound.has(x.name)) out.add(x.name);
        return;
      case 'apply':
        if (!bound.has(x.name)) out.add(x.name);
        x.args.forEach((a) => walk(a, bound));
        return;
      case 'sum': {
        if (x.lo) walk(x.lo, bound);
        if (x.hi) walk(x.hi, bound);
        const inner = x.index === null ? bound : new Set([...bound, x.index]);
        walk(x.body, inner);
        return;
      }
      default:
        children(x).forEach((c) => walk(c, bound));
    }
  };
  walk(e, new Set());
  return out;
}

/** All oracle calls in `e` (in pre-order). */
export function oracleCalls(e: Expr): Array<Extract<Expr, { type: 'call' }>> {
  const out: Array<Extract<Expr, { type: 'call' }>> = [];
  const walk = (x: Expr): void => {
    if (x.type === 'call') out.push(x);
    children(x).forEach(walk);
  };
  walk(e);
  return out;
}

/** Functions that are nondecreasing in each argument (so oracle calls may occur inside them). */
const MONOTONE_FUNCS: ReadonlySet<FuncName> = new Set<FuncName>([
  'max',
  'min',
  'ceil',
  'floor',
  'sqrt',
  'abs',
  'poly',
  'polylog',
]);

/**
 * Checks that `e` is nondecreasing in the values of its oracle calls, syntactically: every call occurs only under
 * positive terms of sums, products, numerators, bases of powers with a call-free exponent that is not visibly negative,
 * nondecreasing functions (max, min, ceil, floor, roots), bounds other than o/Omega, and sum bodies. Anything else
 * (subtraction, denominators, negative powers, exponents, logarithms, binomials, nested calls) is rejected, because the
 * lower-bound threshold search of SPEC §2.5 relies on monotonicity.
 * @returns null if monotone, otherwise a description of the first offending position.
 */
export function monotoneInCalls(e: Expr): string | null {
  const hasCall = (x: Expr): boolean => oracleCalls(x).length > 0;
  const checkAll = (xs: readonly Expr[]): string | null => {
    for (const x of xs) {
      const r = check(x);
      if (r) return r;
    }
    return null;
  };
  const check = (x: Expr): string | null => {
    switch (x.type) {
      case 'num':
      case 'var':
        return null;
      case 'add':
        for (const t of x.terms) {
          if (t.sign === -1 && hasCall(t.expr)) return 'an oracle call is subtracted';
        }
        return checkAll(x.terms.map((t) => t.expr));
      case 'neg':
        return hasCall(x.arg) ? 'an oracle call is negated' : null;
      case 'mul':
        return checkAll(x.factors);
      case 'div':
        if (hasCall(x.den)) return 'an oracle call occurs in a denominator';
        return check(x.num);
      case 'pow':
        if (hasCall(x.exp)) return 'an oracle call occurs in an exponent';
        if (hasCall(x.base)) {
          if ((x.exp.type === 'num' && x.exp.value < 0) || x.exp.type === 'neg') {
            return 'an oracle call has a negative power';
          }
        }
        return check(x.base);
      case 'call':
        for (const a of x.args) if (hasCall(a)) return 'an oracle call occurs inside another call';
        return null;
      case 'func':
        if (x.fn === 'root') {
          if (x.args[1] && hasCall(x.args[1])) return 'an oracle call occurs in a root index';
          return x.args[0] ? check(x.args[0]) : null;
        }
        if (MONOTONE_FUNCS.has(x.fn)) return checkAll(x.args);
        for (const a of x.args) if (hasCall(a)) return `an oracle call occurs inside ${x.fn}(...)`;
        return null;
      case 'apply':
        for (const a of x.args) {
          const r = check(a);
          if (r) return r;
        }
        return null;
      case 'bound':
        if ((x.kind === 'o' || x.kind === 'Omega' || x.kind === 'softOmega') && hasCall(x.arg)) {
          return `an oracle call occurs inside ${x.kind}(...)`;
        }
        return check(x.arg);
      case 'sum':
        if ((x.lo && hasCall(x.lo)) || (x.hi && hasCall(x.hi))) return 'an oracle call occurs in a sum bound';
        return check(x.body);
    }
  };
  return check(e);
}

// ---- printing ----

const PREC = { add: 1, mul: 2, neg: 3, pow: 4, atom: 5 } as const;

const BOUND_TEX: Record<BoundKind, string> = {
  O: 'O',
  Osub: 'O_k',
  Theta: '\\Theta',
  Omega: '\\Omega',
  o: 'o',
  softO: '\\tilde{O}',
  softTheta: '\\tilde{\\Theta}',
  softOmega: '\\tilde{\\Omega}',
};

const GREEK = new Set([
  'alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'eta', 'theta', 'iota', 'kappa', 'lambda', 'mu', 'nu', 'xi',
  'pi', 'rho', 'sigma', 'tau', 'upsilon', 'phi', 'chi', 'psi', 'omega', 'Gamma', 'Delta', 'Theta', 'Lambda', 'Xi', 'Pi',
  'Sigma', 'Upsilon', 'Phi', 'Psi', 'Omega',
]);

/** LaTeX for a canonical identifier (inverse of the parser's canonicalization, up to spacing). */
export function identifierTex(name: string): string {
  if (/^\|.*\|$/.test(name)) return `|${identifierTex(name.slice(1, -1))}|`;
  const us = name.indexOf('_');
  const base = us < 0 ? name : name.slice(0, us);
  const subscript = us < 0 ? null : name.slice(us + 1);
  const texOf = (s: string): string => {
    if (GREEK.has(s)) return `\\${s}`;
    if (s.startsWith('hat_')) return `\\hat{${texOf(s.slice(4))}}`;
    return s.length > 1 ? `\\text{${s}}` : s;
  };
  if (base === 'hat' && subscript !== null) return `\\hat{${texOf(subscript)}}`;
  if (subscript === null) return texOf(base);
  return `${texOf(base)}_{${texOf(subscript)}}`;
}

/** LaTeX rendering of an expression (fully parenthesized where precedence requires). */
export function toTex(e: Expr): string {
  const go = (x: Expr, outer: number): string => {
    const wrap = (s: string, p: number): string => (p < outer ? `(${s})` : s);
    switch (x.type) {
      case 'num':
        return String(x.value);
      case 'var':
        return identifierTex(x.name);
      case 'add': {
        const parts = x.terms.map((t, i) => {
          const s = go(t.expr, t.sign === -1 ? PREC.mul : PREC.add);
          if (i === 0) return t.sign === -1 ? `-${s}` : s;
          return t.sign === -1 ? ` - ${s}` : ` + ${s}`;
        });
        return wrap(parts.join(''), PREC.add);
      }
      case 'neg':
        return wrap(`-${go(x.arg, PREC.neg)}`, PREC.neg);
      case 'mul':
        return wrap(x.factors.map((f) => go(f, PREC.mul)).join(' \\cdot '), PREC.mul);
      case 'div':
        return wrap(`${go(x.num, PREC.mul)}/${go(x.den, PREC.pow)}`, PREC.mul);
      case 'pow':
        return wrap(`${go(x.base, PREC.atom)}^{${go(x.exp, 0)}}`, PREC.pow);
      case 'call':
        return `${identifierTex(x.fn)}(${x.args.map((a) => go(a, 0)).join(', ')})`;
      case 'apply':
        return `${identifierTex(x.name)}(${x.args.map((a) => go(a, 0)).join(', ')})`;
      case 'func':
        switch (x.fn) {
          case 'sqrt':
            return `\\sqrt{${go(x.args[0]!, 0)}}`;
          case 'root':
            return `\\sqrt[${go(x.args[1]!, 0)}]{${go(x.args[0]!, 0)}}`;
          case 'ceil':
            return `\\lceil ${go(x.args[0]!, 0)} \\rceil`;
          case 'floor':
            return `\\lfloor ${go(x.args[0]!, 0)} \\rfloor`;
          case 'abs':
            return `|${go(x.args[0]!, 0)}|`;
          case 'binom':
            return `\\binom{${go(x.args[0]!, 0)}}{${go(x.args[1]!, 0)}}`;
          case 'log':
            return x.args.length > 1
              ? `\\log_{${go(x.args[1]!, 0)}}(${go(x.args[0]!, 0)})`
              : `\\log(${go(x.args[0]!, 0)})`;
          case 'poly':
          case 'polylog':
            return `\\text{${x.fn}}(${x.args.map((a) => go(a, 0)).join(', ')})`;
          default:
            return `\\${x.fn}(${x.args.map((a) => go(a, 0)).join(', ')})`;
        }
      case 'bound':
        return `${BOUND_TEX[x.kind]}(${go(x.arg, 0)})`;
      case 'sum': {
        const sub = x.index === null ? '' : `_{${identifierTex(x.index)}${x.lo ? `=${go(x.lo, 0)}` : ''}}`;
        const sup = x.hi ? `^{${go(x.hi, 0)}}` : '';
        return wrap(`\\sum${sub}${sup} ${go(x.body, PREC.mul)}`, PREC.mul);
      }
    }
  };
  return go(e, 0);
}
