/**
 * RFC 4180 CSV parsing and serialization (pure functions).
 *
 * Accepts LF or CRLF record separators, quoted fields with embedded commas, quotes ("") and newlines, an optional UTF-8
 * BOM, and an optional trailing newline. Every record keeps its own length (no padding): callers decide how to treat
 * ragged rows.
 */

/** Result of parsing: records as arrays of fields, plus problems found (never throws on malformed input). */
export interface CsvParseResult {
  readonly records: ReadonlyArray<ReadonlyArray<string>>;
  /** Human-readable problems, e.g. an unterminated quoted field. Empty for well-formed input. */
  readonly warnings: ReadonlyArray<string>;
}

/**
 * Parse CSV text.
 * @param text CSV content (any string)
 * @returns the records in order; an empty input gives zero records. A final newline does not create an empty record.
 */
export function parseCsv(text: string): CsvParseResult {
  const records: string[][] = [];
  const warnings: string[] = [];
  let i = text.charCodeAt(0) === 0xfeff ? 1 : 0;
  const n = text.length;
  let record: string[] = [];
  let field = '';
  let inQuotes = false;
  let fieldStartedQuoted = false;
  let quoteLine = 0;
  let line = 1;

  const endField = (): void => {
    record.push(field);
    field = '';
    fieldStartedQuoted = false;
  };
  const endRecord = (): void => {
    endField();
    records.push(record);
    record = [];
  };

  while (i < n) {
    const ch = text[i]!;
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i += 1;
        continue;
      }
      if (ch === '\n') line += 1;
      field += ch;
      i += 1;
      continue;
    }
    if (ch === '"') {
      if (field.length === 0 && !fieldStartedQuoted) {
        inQuotes = true;
        fieldStartedQuoted = true;
        quoteLine = line;
      } else {
        // A quote inside an unquoted field (or after a closing quote): keep it literally.
        field += ch;
        if (fieldStartedQuoted) warnings.push(`line ${line}: unexpected text after a closing quote`);
      }
      i += 1;
      continue;
    }
    if (ch === ',') {
      endField();
      i += 1;
      continue;
    }
    if (ch === '\r' && text[i + 1] === '\n') {
      endRecord();
      line += 1;
      i += 2;
      continue;
    }
    if (ch === '\n' || ch === '\r') {
      endRecord();
      line += 1;
      i += 1;
      continue;
    }
    if (fieldStartedQuoted) {
      warnings.push(`line ${line}: unexpected text after a closing quote`);
      fieldStartedQuoted = false;
    }
    field += ch;
    i += 1;
  }
  if (inQuotes) {
    warnings.push(`line ${quoteLine}: unterminated quoted field`);
  }
  // Last record (no trailing newline), unless the input ended exactly at a record boundary.
  if (field.length > 0 || record.length > 0 || fieldStartedQuoted) {
    endRecord();
  }
  return { records, warnings };
}

/** True iff the field must be quoted when serialized (minimal quoting, as Python's csv.QUOTE_MINIMAL). */
function needsQuotes(field: string): boolean {
  return /[",\r\n]/.test(field);
}

/**
 * Serialize records as CSV.
 * @param records rows of fields
 * @param eol record separator (default CRLF, as in RFC 4180)
 * @returns CSV text without a trailing separator; parseCsv(serializeCsv(r)).records deep-equals r for every r whose
 *          records are non-empty arrays.
 */
export function serializeCsv(records: ReadonlyArray<ReadonlyArray<string>>, eol: '\r\n' | '\n' = '\r\n'): string {
  return records
    .map((rec) => rec.map((f) => (needsQuotes(f) ? `"${f.replace(/"/g, '""')}"` : f)).join(','))
    .join(eol);
}

/** A parsed table with a header row, giving access to fields by column name. */
export class CsvTable {
  // AF: a table whose column names are header[0..] and whose data rows are rows[0..]; cell (r, c) = rows[r][c] ?? ''.
  // RI: header names are unique after trimming.
  // SRE: header and rows are copied on construction and exposed only as readonly views of fresh copies.
  private readonly header: readonly string[];
  private readonly rows: ReadonlyArray<readonly string[]>;
  private readonly index: ReadonlyMap<string, number>;

  constructor(header: readonly string[], rows: ReadonlyArray<readonly string[]>) {
    this.header = header.map((h) => h.trim());
    this.rows = rows.map((r) => [...r]);
    const index = new Map<string, number>();
    this.header.forEach((h, i) => {
      if (!index.has(h)) index.set(h, i);
    });
    this.index = index;
  }

  /** Build a table from CSV text: the first record is the header; records that are entirely empty are dropped. */
  static fromText(text: string): { table: CsvTable; warnings: readonly string[] } {
    const { records, warnings } = parseCsv(text);
    const [head, ...body] = records;
    const rows = body.filter((r) => r.some((f) => f.trim() !== ''));
    return { table: new CsvTable(head ?? [], rows), warnings };
  }

  get columns(): readonly string[] {
    return [...this.header];
  }

  get rowCount(): number {
    return this.rows.length;
  }

  hasColumn(name: string): boolean {
    return this.index.has(name);
  }

  /** @returns cell value, '' if the column is missing or the row is short. Requires 0 <= row < rowCount. */
  get(row: number, column: string): string {
    const r = this.rows[row];
    if (r === undefined) throw new RangeError(`row ${row} out of range`);
    const c = this.index.get(column);
    return c === undefined ? '' : (r[c] ?? '');
  }

  /** @returns a copy of the raw record of data row `row`. */
  record(row: number): string[] {
    const r = this.rows[row];
    if (r === undefined) throw new RangeError(`row ${row} out of range`);
    return [...r];
  }

  /** @returns the CSV text of the table (header + rows). */
  toText(eol: '\r\n' | '\n' = '\r\n'): string {
    return serializeCsv([this.header, ...this.rows], eol);
  }

  /** Header extended with `columns` that are missing (appended in order). */
  private headerWith(columns: Iterable<string>): string[] {
    const header = [...this.header];
    for (const c of columns) if (!header.includes(c)) header.push(c);
    return header;
  }

  /**
   * A copy of the table with cell (row, column) set to `value`. A missing column is appended to the header.
   * Requires 0 <= row < rowCount.
   */
  withCell(row: number, column: string, value: string): CsvTable {
    if (row < 0 || row >= this.rows.length) throw new RangeError(`row ${row} out of range`);
    const header = this.headerWith([column]);
    const c = header.indexOf(column);
    const rows = this.rows.map((r, i) => {
      if (i !== row) return r;
      const copy = [...r];
      while (copy.length <= c) copy.push('');
      copy[c] = value;
      return copy;
    });
    return new CsvTable(header, rows);
  }

  /** A copy of the table with one more data row; missing columns are empty, unknown ones are appended. */
  withRow(values: Readonly<Record<string, string>>): CsvTable {
    const header = this.headerWith(Object.keys(values));
    const row = header.map((c) => values[c] ?? '');
    return new CsvTable(header, [...this.rows, row]);
  }
}
