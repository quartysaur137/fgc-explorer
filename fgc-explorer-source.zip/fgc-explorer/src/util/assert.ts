/**
 * Assertions for preconditions and rep invariants (programming errors).
 * Invalid *user input* must never reach these: it is reported as a status or diagnostic instead.
 */

export class AssertionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AssertionError';
  }
}

/** Throws AssertionError(message) unless `condition` holds. */
export function assert(condition: unknown, message: string): asserts condition {
  if (!condition) {
    throw new AssertionError(message);
  }
}

/** For exhaustive switches: reaching this is a programming error. */
export function assertNever(value: never, what = 'value'): never {
  throw new AssertionError(`unexpected ${what}: ${JSON.stringify(value)}`);
}
