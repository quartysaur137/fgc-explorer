/**
 * Problem boxes (SPEC §3.4, §7): the left panel shows one box per problem, holding that problem's knobs (its lower
 * bounds and algorithms); the bounds CSV is written box by box. A box may be empty (a problem listed without bounds).
 */

import { KnobSpec } from './config';
import { findProblem, Model } from './model';

/** A problem and its knobs. */
export interface ProblemBox<K extends KnobSpec> {
  /** The problem's id (see canonicalProblem). */
  readonly problem: string;
  /** Its knobs, in scenario order. */
  readonly knobs: readonly K[];
}

/**
 * The function giving a problem name's box key: the model's id for a problem it knows (so "3sum / 3SUM" and
 * "3SUM / 3SUM" share a box), else the name with its spaces squashed.
 */
export function canonicalProblem(model: Model | null): (name: string) => string {
  return (name) => (model ? findProblem(model, name)?.id : undefined) ?? name.replace(/\s+/g, ' ').trim();
}

/**
 * The boxes of a scenario: first one per problem of `problems` (in that order), then one per problem of a knob not
 * listed there (in the order of its first knob). Each box has its problem's knobs in their order.
 * @param canonical the box key of a problem name (names with the same key share a box)
 */
export function problemBoxes<K extends KnobSpec>(
  problems: readonly string[],
  knobs: readonly K[],
  canonical: (name: string) => string = (name) => name,
): ProblemBox<K>[] {
  const boxes = new Map<string, K[]>();
  for (const name of problems) {
    const key = canonical(name);
    if (!boxes.has(key)) boxes.set(key, []);
  }
  for (const k of knobs) {
    const key = canonical(k.problem);
    const list = boxes.get(key);
    if (list) list.push(k);
    else boxes.set(key, [k]);
  }
  return [...boxes].map(([problem, ks]) => ({ problem, knobs: ks }));
}

/** The box order of a scenario as a complete list (every box listed, so that it survives any change of the knobs). */
export function boxOrder(problems: readonly string[], knobs: readonly KnobSpec[], canonical: (name: string) => string = (name) => name): string[] {
  return problemBoxes(problems, knobs, canonical).map((b) => b.problem);
}
