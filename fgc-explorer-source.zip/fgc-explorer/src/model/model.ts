/**
 * The model: problems and compiled reductions built from the sheet and the engine config (SPEC §3, §6.1).
 *
 * Building a model never throws on bad data: problems in the sheet become row statuses and diagnostics.
 */

import { Expr, Formula, freeIdentifiers, monotoneInCalls, oracleCalls, toTex } from '../math/ast';
import { legendDefinitions, primaryFormula } from '../math/cells';
import { ParseError, parseExpr, parseFormula, parseList } from '../math/parser';
import { isNamedFunction } from '../growth/evaluate';
import { CsvTable } from '../util/csv';
import { ConstantDef, EngineConfig, FreeParamDef, ProblemConfig, RowAnnotation } from './config';
import { ParamSpec, parseRegimeSpec, SpecError } from './regime';

// ---------------------------------------------------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------------------------------------------------

/** Column names of the sheet (SPEC §3.1). */
export const COL = {
  fromFamily: 'From (Problem)',
  fromVariation: 'From (Variation)',
  toFamily: 'To (Problem)',
  toVariation: 'To (Variation)',
  id: 'Reduction ID',
  type: 'Type',
  randomized: 'Randomized?',
  model: 'Model',
  hypothesis: 'Assumption/Hypothesis',
  toTime: 'To-time (generic)',
  fromTime: 'From-time (generic)',
  restrictions: 'Restrictions on to-time',
  rt: 'Reduction Runtime',
} as const;

export const REQUIRED_COLUMNS: readonly string[] = [
  COL.fromFamily,
  COL.fromVariation,
  COL.toFamily,
  COL.toVariation,
  COL.id,
  COL.toTime,
  COL.fromTime,
  COL.rt,
];

export interface TimeFunction {
  readonly name: string;
  readonly params: readonly string[];
}

export type SignatureSource = 'to-time' | 'config' | 'inferred' | 'none';

export interface Problem {
  /** "Family / Variation" (first spelling seen; variations are matched case-insensitively). */
  readonly id: string;
  readonly family: string;
  readonly variation: string;
  /** Time functions of the signature; empty if unknown. */
  readonly functions: readonly TimeFunction[];
  readonly signatureSource: SignatureSource;
  /** Static iff the signature is the single function T. */
  readonly isStatic: boolean;
  /** Parameters of T (static problems) or of the first function. */
  readonly params: readonly string[];
  readonly logParams: ReadonlySet<string>;
  readonly timeType: 'poly' | 'exp';
  /** Regime specs of interest (configured, or the default rule). */
  readonly regimeSpecs: readonly string[];
  readonly regimeSpecsConfigured: boolean;
  /** Reduction IDs where the problem is the source / the target. */
  readonly asSource: readonly string[];
  readonly asTarget: readonly string[];
}

export type RowStatus =
  | 'ok'
  | 'skipped'
  | 'no-formula'
  | 'parse-error'
  | 'dynamic'
  | 'no-signature'
  | 'arity'
  | 'non-monotone'
  | 'unknown-symbols';

export const ROW_STATUS_TEXT: Readonly<Record<RowStatus, string>> = {
  ok: 'used in propagation',
  skipped: 'skipped by the config',
  'no-formula': 'no From-time formula',
  'parse-error': 'formula does not parse',
  dynamic: 'dynamic / multi-function problem (not propagated)',
  'no-signature': 'a problem has no known signature',
  arity: 'T-call arity differs from the To-time signature',
  'non-monotone': 'From-time is not monotone in T',
  'unknown-symbols': 'undeclared symbols',
};

export interface Definition {
  readonly name: string;
  readonly alternatives: readonly Expr[];
  readonly origin: 'legend' | 'config';
  readonly tex: string;
}

/** A free parameter with its range expressions parsed. */
export interface FreeParam {
  readonly def: FreeParamDef;
  readonly min: Expr | null;
  readonly max: Expr | null;
  readonly base: Expr | null;
}

export interface CompiledRow {
  /** Index of the data row in the sheet (0-based, header excluded). */
  readonly index: number;
  readonly id: string;
  readonly source: string;
  readonly target: string;
  readonly status: RowStatus;
  readonly messages: readonly string[];
  readonly fromTex: string | null;
  readonly fromOverridden: boolean;
  readonly from: Formula | null;
  readonly rtTex: string | null;
  readonly rtOverridden: boolean;
  /** Null when the RT is unknown (no formula, parse error or undeclared symbols): the unknownRT policy applies. */
  readonly rt: Formula | null;
  readonly free: readonly FreeParam[];
  readonly defs: readonly Definition[];
  readonly requires: ReadonlyMap<string, ParamSpec> | null;
  readonly requiresText: string | null;
  readonly randomized: boolean;
  readonly annotation: RowAnnotation | null;
}

export type DiagnosticLevel = 'error' | 'warning' | 'info';

export interface Diagnostic {
  readonly level: DiagnosticLevel;
  readonly message: string;
  readonly rowId?: string;
  readonly problemId?: string;
}

export interface Model {
  readonly table: CsvTable;
  readonly config: EngineConfig;
  readonly problems: ReadonlyMap<string, Problem>;
  /** Lower-cased, whitespace-normalized id → id (for case-insensitive lookups of user-typed ids). */
  readonly problemIndex: ReadonlyMap<string, string>;
  readonly rows: readonly CompiledRow[];
  readonly rowsById: ReadonlyMap<string, CompiledRow>;
  readonly rowsBySource: ReadonlyMap<string, readonly CompiledRow[]>;
  readonly constants: ReadonlyMap<string, ConstantDef>;
  readonly diagnostics: readonly Diagnostic[];
}

// ---------------------------------------------------------------------------------------------------------------------
// Problems
// ---------------------------------------------------------------------------------------------------------------------

interface RawRow {
  readonly index: number;
  readonly id: string;
  readonly source: string;
  readonly target: string;
  readonly toTime: string;
  readonly fromTime: string;
  readonly rt: string;
  readonly randomized: string;
}

/** Whitespace runs (including line breaks inside sheet cells) become single spaces. */
function squash(s: string): string {
  return s.replace(/\s+/g, ' ').trim();
}

/** Resolves (family, variation) pairs to problem ids, merging variations case-insensitively. */
class ProblemNames {
  private readonly byLower = new Map<string, { id: string; family: string; variation: string }>();

  constructor(private readonly aliases: Readonly<Record<string, string>>) {}

  resolve(family: string, variation: string): { id: string; family: string; variation: string } | null {
    const f0 = squash(family);
    const fam = squash(this.aliases[f0] ?? f0);
    const vari = squash(variation);
    if (fam === '' && vari === '') return null;
    const lower = `${fam} / ${vari}`.toLowerCase();
    const known = this.byLower.get(lower);
    if (known) return known;
    const entry = { id: `${fam} / ${vari}`, family: fam, variation: vari };
    this.byLower.set(lower, entry);
    return entry;
  }

  /** The id of a problem given by id text (case-insensitive, whitespace-normalized), or null. */
  lookup(idText: string): string | null {
    return this.byLower.get(squash(idText).toLowerCase())?.id ?? null;
  }

  all(): Array<{ id: string; family: string; variation: string }> {
    return [...this.byLower.values()];
  }
}

/** Parse a To-time cell into time functions, or return an error message. */
function parseSignature(cell: string): TimeFunction[] | string {
  const tex = primaryFormula(cell);
  if (tex === null) return 'no formula';
  let items: Expr[];
  try {
    items = parseList(tex);
  } catch (e) {
    return e instanceof ParseError ? e.message : String(e);
  }
  const fns: TimeFunction[] = [];
  for (const it of items) {
    if (it.type !== 'call') return `"${tex}" is not a list of T(...) signatures`;
    const params: string[] = [];
    for (const a of it.args) {
      if (a.type !== 'var') return `signature argument is not a parameter name in "${tex}"`;
      params.push(a.name);
    }
    if (new Set(params).size !== params.length) return `repeated parameter in "${tex}"`;
    fns.push({ name: it.fn, params });
  }
  return fns;
}

const signatureText = (fns: readonly TimeFunction[]): string => fns.map((f) => `${f.name}(${f.params.join(', ')})`).join(', ');

/** Default regime spec of a problem without configured regimes: log-dependent params "poly", others exponent 1. */
export function defaultRegimeSpec(params: readonly string[], logParams: ReadonlySet<string>): string {
  return params.map((p) => `${p}=${logParams.has(p) ? 'poly' : '1'}`).join(', ');
}

// ---------------------------------------------------------------------------------------------------------------------
// Model construction
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Build the model.
 * @param table the sheet (must contain REQUIRED_COLUMNS; missing ones produce an error diagnostic and empty cells)
 * @param config validated engine config
 */
export function buildModel(table: CsvTable, config: EngineConfig): Model {
  const diagnostics: Diagnostic[] = [];
  for (const c of REQUIRED_COLUMNS) {
    if (!table.hasColumn(c)) diagnostics.push({ level: 'error', message: `the sheet has no column "${c}"` });
  }
  const names = new ProblemNames(config.aliases);
  const raw: RawRow[] = [];
  const seenIds = new Set<string>();
  for (let i = 0; i < table.rowCount; i++) {
    const get = (c: string): string => table.get(i, c);
    let id = get(COL.id).trim();
    if (id === '') id = `row${i + 2}`;
    if (seenIds.has(id)) {
      diagnostics.push({ level: 'warning', message: `duplicate Reduction ID ${id} (sheet row ${i + 2}); renamed`, rowId: id });
      let k = 2;
      while (seenIds.has(`${id}#${k}`)) k += 1;
      id = `${id}#${k}`;
    }
    seenIds.add(id);
    const s = names.resolve(get(COL.fromFamily), get(COL.fromVariation));
    const t = names.resolve(get(COL.toFamily), get(COL.toVariation));
    if (s === null || t === null) {
      diagnostics.push({ level: 'warning', message: `row ${id} has no ${s === null ? 'From' : 'To'} problem; ignored`, rowId: id });
      continue;
    }
    raw.push({
      index: i,
      id,
      source: s.id,
      target: t.id,
      toTime: get(COL.toTime),
      fromTime: get(COL.fromTime),
      rt: get(COL.rt),
      randomized: get(COL.randomized),
    });
  }

  // Problem configs keyed by resolved id (config keys are matched case-insensitively).
  const problemConfigs = new Map<string, ProblemConfig>();
  for (const [key, pc] of Object.entries(config.problems)) {
    const id = names.lookup(key);
    if (id === null) diagnostics.push({ level: 'info', message: `config.problems["${key}"] matches no problem in the sheet` });
    else problemConfigs.set(id, pc);
  }

  const constants = new Map(Object.entries(config.constants));
  const problems = buildProblems(names, raw, problemConfigs, config, constants, diagnostics);

  const rows = raw.map((r) => {
    let ann = config.rows[r.id] ?? null;
    const m = ann?.match;
    if (ann && m) {
      const same = (a: string | undefined, id: string): boolean => a === undefined || names.lookup(a) === id;
      if (!same(m.from, r.source) || !same(m.to, r.target)) {
        diagnostics.push({
          level: 'warning',
          rowId: r.id,
          message: `config.rows["${r.id}"] is for ${m.from ?? '?'} → ${m.to ?? '?'}, but row ${r.id} is ${r.source} → ${r.target}: annotation ignored`,
        });
        ann = null;
      }
    }
    return compileRow(r, problems, ann, constants);
  });
  for (const id of Object.keys(config.rows)) {
    if (!seenIds.has(id)) diagnostics.push({ level: 'info', message: `config.rows["${id}"] matches no Reduction ID`, rowId: id });
  }
  const rowsById = new Map(rows.map((r) => [r.id, r]));
  const rowsBySource = new Map<string, CompiledRow[]>();
  for (const r of rows) {
    const list = rowsBySource.get(r.source) ?? [];
    list.push(r);
    rowsBySource.set(r.source, list);
  }
  const problemIndex = new Map([...problems.keys()].map((id) => [squash(id).toLowerCase(), id]));
  return { table, config, problems, problemIndex, rows, rowsById, rowsBySource, constants, diagnostics };
}

/** The problem whose id matches `idText` case-insensitively (whitespace-normalized), or undefined. */
export function findProblem(model: Model, idText: string): Problem | undefined {
  const id = model.problemIndex.get(squash(idText).toLowerCase());
  return id === undefined ? undefined : model.problems.get(id);
}

function buildProblems(
  names: ProblemNames,
  raw: readonly RawRow[],
  problemConfigs: ReadonlyMap<string, ProblemConfig>,
  config: EngineConfig,
  constants: ReadonlyMap<string, ConstantDef>,
  diagnostics: Diagnostic[],
): Map<string, Problem> {
  const problems = new Map<string, Problem>();
  for (const { id, family, variation } of names.all()) {
    const asSource = raw.filter((r) => r.source === id).map((r) => r.id);
    const asTarget = raw.filter((r) => r.target === id).map((r) => r.id);
    // Signature from To-time cells: the most frequent one.
    const counts = new Map<string, { fns: TimeFunction[]; rows: string[] }>();
    for (const r of raw.filter((x) => x.target === id)) {
      const sig = parseSignature(r.toTime);
      if (typeof sig === 'string') {
        if (r.toTime.trim() !== '' && r.toTime.trim() !== '??') {
          diagnostics.push({ level: 'warning', message: `To-time of row ${r.id} is not a signature: ${sig}`, rowId: r.id, problemId: id });
        }
        continue;
      }
      const key = signatureText(sig);
      const entry = counts.get(key) ?? { fns: sig, rows: [] };
      entry.rows.push(r.id);
      counts.set(key, entry);
    }
    const ranked = [...counts.values()].sort((a, b) => b.rows.length - a.rows.length);
    const pc = problemConfigs.get(id);
    let functions: TimeFunction[] = [];
    let source: SignatureSource = 'none';
    if (ranked.length > 0) {
      functions = ranked[0]!.fns;
      source = 'to-time';
      if (ranked.length > 1) {
        diagnostics.push({
          level: 'warning',
          problemId: id,
          message: `${id}: To-time signatures disagree (${ranked.map((x) => `${signatureText(x.fns)} in rows ${x.rows.join(', ')}`).join('; ')}); using the first`,
        });
      }
      if (pc?.params && signatureText([{ name: 'T', params: pc.params }]) !== signatureText(functions)) {
        diagnostics.push({ level: 'info', problemId: id, message: `${id}: config params ignored, the sheet's To-time signature is used` });
      }
    } else if (pc?.params) {
      functions = [{ name: 'T', params: [...pc.params] }];
      source = 'config';
    } else {
      const inferred = inferParams(raw.filter((r) => r.source === id), config, constants);
      if (inferred.length > 0) {
        functions = [{ name: 'T', params: inferred }];
        source = 'inferred';
        diagnostics.push({
          level: 'info',
          problemId: id,
          message: `${id}: signature T(${inferred.join(', ')}) inferred from its From-time formulas (set config.problems["${id}"].params to fix it)`,
        });
      }
    }
    const isStatic = functions.length === 1 && functions[0]!.name === 'T';
    const params = functions[0]?.params ?? [];
    const logParams = new Set(pc?.logParams ?? params.filter((p) => p === 'M'));
    for (const lp of logParams) {
      if (!params.includes(lp)) diagnostics.push({ level: 'warning', problemId: id, message: `${id}: log-dependent parameter ${lp} is not in the signature` });
    }
    const regimeSpecs = pc?.regimes && pc.regimes.length > 0 ? [...pc.regimes] : params.length > 0 ? [defaultRegimeSpec(params, logParams)] : [];
    for (const spec of regimeSpecs) {
      try {
        const m = parseRegimeSpec(spec);
        for (const p of m.keys()) {
          if (!params.includes(p)) diagnostics.push({ level: 'warning', problemId: id, message: `${id}: regime "${spec}" mentions unknown parameter ${p}` });
        }
      } catch (e) {
        diagnostics.push({ level: 'warning', problemId: id, message: `${id}: bad regime "${spec}": ${(e as Error).message}` });
      }
    }
    problems.set(id, {
      id,
      family,
      variation,
      functions,
      signatureSource: source,
      isStatic,
      params,
      logParams,
      timeType: pc?.timeType ?? 'poly',
      regimeSpecs,
      regimeSpecsConfigured: !!(pc?.regimes && pc.regimes.length > 0),
      asSource,
      asTarget,
    });
  }
  return problems;
}

/** Parameters of a source-only problem, guessed from the identifiers of its From-time formulas. */
function inferParams(rows: readonly RawRow[], config: EngineConfig, constants: ReadonlyMap<string, ConstantDef>): string[] {
  const order: string[] = [];
  for (const r of rows) {
    const ann = config.rows[r.id];
    const tex = ann?.from ?? primaryFormula(r.fromTime);
    if (tex === null) continue;
    let f: Formula;
    try {
      f = parseFormula(tex);
    } catch {
      continue;
    }
    const excluded = new Set<string>([...(ann?.free ?? []).map((p) => p.name), ...Object.keys(ann?.defs ?? {}), ...constants.keys()]);
    for (const d of legendDefinitions(r.fromTime, new Set(['n', 'm']))) excluded.add(d.name);
    for (const alt of f.alternatives) {
      for (const name of freeIdentifiers(alt)) {
        if (!excluded.has(name) && !isNamedFunction(name) && !order.includes(name)) order.push(name);
      }
    }
  }
  const rank = (p: string): number => (p === 'n' ? 0 : p === 'm' ? 1 : 2);
  return order.sort((a, b) => rank(a) - rank(b));
}

// ---------------------------------------------------------------------------------------------------------------------
// Row compilation
// ---------------------------------------------------------------------------------------------------------------------

function tryParseFormula(tex: string): Formula | string {
  try {
    return parseFormula(tex);
  } catch (e) {
    return e instanceof ParseError ? `${e.message} in "${tex}"` : String(e);
  }
}

function tryParseExpr(tex: string | number | undefined): Expr | null | string {
  if (tex === undefined) return null;
  if (typeof tex === 'number') return { type: 'num', value: tex };
  try {
    return parseExpr(tex);
  } catch (e) {
    return e instanceof ParseError ? `${e.message} in "${tex}"` : String(e);
  }
}

function compileRow(r: RawRow, problems: ReadonlyMap<string, Problem>, ann: RowAnnotation | null, constants: ReadonlyMap<string, ConstantDef>): CompiledRow {
  const messages: string[] = [];
  const source = problems.get(r.source)!;
  const target = problems.get(r.target)!;
  let status: RowStatus = 'ok';
  const setStatus = (s: RowStatus): void => {
    if (status === 'ok') status = s;
  };
  if (ann?.skip !== undefined) {
    setStatus('skipped');
    messages.push(`skipped: ${ann.skip}`);
  }

  // From-time
  const fromOverridden = ann?.from !== undefined;
  const fromTex = ann?.from ?? primaryFormula(r.fromTime);
  let from: Formula | null = null;
  if (fromTex === null) {
    setStatus('no-formula');
    messages.push('the From-time cell has no $...$ formula');
  } else {
    const f = tryParseFormula(fromTex);
    if (typeof f === 'string') {
      setStatus('parse-error');
      messages.push(`From-time: ${f}`);
    } else from = f;
  }

  // Reduction runtime
  const rtOverridden = ann?.rt !== undefined;
  const rtTex = ann?.rt ?? primaryFormula(r.rt);
  let rt: Formula | null = null;
  if (rtTex === null) {
    messages.push('the Reduction Runtime has no formula (unknown RT policy applies)');
  } else {
    const f = tryParseFormula(rtTex);
    if (typeof f === 'string') messages.push(`Reduction Runtime: ${f} (treated as unknown)`);
    else rt = f;
  }

  // Problems
  if (!source.isStatic || !target.isStatic) {
    if (source.functions.length === 0 || target.functions.length === 0) {
      setStatus('no-signature');
      messages.push(`${source.functions.length === 0 ? source.id : target.id} has no known signature`);
    } else {
      setStatus('dynamic');
      const which = [!source.isStatic ? `source (${signatureText(source.functions)})` : null, !target.isStatic ? `target (${signatureText(target.functions)})` : null]
        .filter(Boolean)
        .join(' and ');
      messages.push(`the ${which} has several time functions`);
    }
  }

  // Calls: names and arities
  if (from !== null && target.isStatic) {
    for (const alt of from.alternatives) {
      for (const c of oracleCalls(alt)) {
        if (c.fn !== 'T') {
          setStatus('arity');
          messages.push(`call ${c.fn}(...) but the target's signature is ${signatureText(target.functions)}`);
        } else if (c.args.length !== target.params.length) {
          setStatus('arity');
          messages.push(`T-call with ${c.args.length} arguments; the target's signature T(${target.params.join(', ')}) has ${target.params.length}`);
        }
      }
      const mono = monotoneInCalls(alt);
      if (mono !== null) {
        setStatus('non-monotone');
        messages.push(`From-time: ${mono}`);
      }
    }
    if (from.alternatives.every((a) => oracleCalls(a).length === 0)) {
      messages.push('the From-time formula calls no T(...)');
    }
  }

  // Free parameters
  const free: FreeParam[] = [];
  for (const def of ann?.free ?? []) {
    const parts = { min: tryParseExpr(def.min), max: tryParseExpr(def.max), base: tryParseExpr(def.base) };
    const bad = Object.entries(parts).filter(([, x]) => typeof x === 'string');
    if (bad.length > 0) {
      setStatus('parse-error');
      bad.forEach(([k, x]) => messages.push(`free parameter ${def.name}.${k}: ${x}`));
      continue;
    }
    free.push({ def, min: parts.min as Expr | null, max: parts.max as Expr | null, base: parts.base as Expr | null });
  }
  const freeNames = new Set(free.map((f) => f.def.name));

  // Symbol resolution (SPEC §3.2, §6.1). A formula is usable if one of its alternatives only uses known symbols; a
  // definition becomes known once one of its alternatives does.
  const sourceParams = new Set(source.params);
  const missing = (e: Expr, have: ReadonlySet<string>): string[] =>
    [...freeIdentifiers(e)].filter((x) => !have.has(x) && !isNamedFunction(x));
  const have = new Set<string>([...sourceParams, ...constants.keys()]);
  for (const f of free) {
    for (const [k, e] of [['min', f.min], ['max', f.max], ['base', f.base]] as const) {
      const m = e === null ? [] : missing(e, have);
      if (m.length > 0) {
        setStatus('unknown-symbols');
        messages.push(`free parameter ${f.def.name}.${k} uses undeclared symbols ${m.join(', ')}`);
      }
    }
    have.add(f.def.name);
  }
  const configDefs: Definition[] = [];
  for (const [name, tex] of Object.entries(ann?.defs ?? {})) {
    if (freeNames.has(name)) {
      messages.push(`definition ${name} ignored: ${name} is declared as a free parameter`);
      continue;
    }
    const f = tryParseFormula(tex);
    if (typeof f === 'string') {
      setStatus('parse-error');
      messages.push(`definition ${name}: ${f}`);
    } else configDefs.push({ name, alternatives: f.alternatives, origin: 'config', tex });
  }
  const legendDefs: Definition[] = legendDefinitions(r.fromTime, new Set([...sourceParams, ...freeNames, ...configDefs.map((d) => d.name)]))
    .map((d) => ({ name: d.name, alternatives: d.alternatives.filter((a) => oracleCalls(a).length === 0), origin: 'legend' as const, tex: '' }))
    .filter((d) => d.alternatives.length > 0)
    .map((d) => ({ ...d, tex: d.alternatives.map(toTex).join(' = ') }));
  // Symbols mentioned by the formulas, closed under legend definitions (which are only used for these).
  const mentioned = new Set<string>();
  const mention = (e: Expr): void => freeIdentifiers(e).forEach((x) => mentioned.add(x));
  from?.alternatives.forEach(mention);
  rt?.alternatives.forEach(mention);
  configDefs.forEach((d) => d.alternatives.forEach(mention));
  for (let grew = true; grew; ) {
    const before = mentioned.size;
    legendDefs.filter((d) => mentioned.has(d.name)).forEach((d) => d.alternatives.forEach(mention));
    grew = mentioned.size > before;
  }
  const defs: Definition[] = [];
  let pendingConfig = configDefs;
  let pendingLegend = legendDefs;
  for (let changed = true; changed; ) {
    changed = false;
    const nextConfig: Definition[] = [];
    for (const d of pendingConfig) {
      if (d.alternatives.some((a) => missing(a, have).length === 0)) {
        defs.push(d);
        have.add(d.name);
        changed = true;
      } else nextConfig.push(d);
    }
    pendingConfig = nextConfig;
    const nextLegend: Definition[] = [];
    for (const d of pendingLegend) {
      if (mentioned.has(d.name) && !have.has(d.name) && d.alternatives.some((a) => missing(a, have).length === 0)) {
        defs.push(d);
        have.add(d.name);
        d.alternatives.forEach(mention);
        changed = true;
      } else nextLegend.push(d);
    }
    pendingLegend = nextLegend;
  }
  for (const d of pendingConfig) {
    messages.push(`definition ${d.name} uses undeclared symbols ${missing(d.alternatives[0]!, have).join(', ')}`);
  }
  if (from !== null && !from.alternatives.some((a) => missing(a, have).length === 0)) {
    setStatus('unknown-symbols');
    const m = [...new Set(from.alternatives.flatMap((a) => missing(a, have)))];
    messages.push(`undeclared symbols: ${m.join(', ')} (declare them as free parameters or abbreviations in the config)`);
  }
  if (rt !== null && !rt.alternatives.some((a) => missing(a, have).length === 0)) {
    const m = [...new Set(rt.alternatives.flatMap((a) => missing(a, have)))];
    messages.push(`Reduction Runtime uses undeclared symbols ${m.join(', ')} (treated as unknown)`);
    rt = null;
  }

  // Source-regime restriction
  let requires: Map<string, ParamSpec> | null = null;
  if (ann?.requires !== undefined) {
    try {
      requires = parseRegimeSpec(ann.requires);
      for (const p of requires.keys()) {
        if (!sourceParams.has(p)) messages.push(`requires: ${p} is not a parameter of ${source.id}`);
      }
    } catch (e) {
      setStatus('parse-error');
      messages.push(`requires: ${e instanceof SpecError ? e.message : String(e)}`);
    }
  }

  // "?" (unknown) counts as randomized, so that excluding randomized reductions is conservative.
  const randomized = /^\s*(yes|y|\?)\s*$/i.test(r.randomized);
  return {
    index: r.index,
    id: r.id,
    source: r.source,
    target: r.target,
    status,
    messages,
    fromTex,
    fromOverridden,
    from,
    rtTex,
    rtOverridden,
    rt,
    free,
    defs,
    requires,
    requiresText: ann?.requires ?? null,
    randomized,
    annotation: ann,
  };
}
