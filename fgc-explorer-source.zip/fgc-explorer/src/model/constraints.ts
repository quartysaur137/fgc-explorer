/**
 * Limits of a problem's parameters (SPEC §2.3, §3.7): inequalities that every instance satisfies, such as m ≤ n² for the
 * edges of a graph or t ≤ m·α for its triangles (α its arboricity). A regime is the class of instances whose parameters
 * grow at most as fast as it says (SPEC §2.3), so lowering a parameter to its limit names the same instances: every
 * regime is clipped to its problem's limits when it is formed (Regime.normalize), and no regime stands for instances
 * that cannot exist (say, a graph with more than n³ triangles). A derivation through a reduction that claims such
 * instances is read at the clipped regime, where the instances it produces are.
 */

import * as G from '../growth/growth';
import { EvalError, Growth } from '../growth/growth';
import { identifierTex } from '../math/ast';

/** One term of the right side: a constant factor times a product of parameters with exponents. */
export interface LimitTerm {
  readonly factor: number;
  readonly powers: ReadonlyArray<readonly [string, number]>;
}

/**
 * A limit of a parameter.
 *
 * AF: every instance of the problem has param ≤ O(Σ_terms factor · ∏_(p, a) p^a), for `reason` when given.
 * RI: param appears in no term; factors and exponents are positive and finite; at least one term.
 * SRE: all fields are readonly; arrays are frozen.
 */
export interface ParamConstraint {
  /** The inequality as written (without the reason), e.g. "t <= m*alpha". */
  readonly text: string;
  readonly param: string;
  readonly terms: readonly LimitTerm[];
  readonly reason: string | null;
}

export class ConstraintError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ConstraintError';
  }
}

function parseNumber(s: string): number | null {
  const t = s.trim().replace(/^[({]\s*/, '').replace(/\s*[)}]$/, '');
  const frac = /^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/.exec(t);
  if (frac) {
    const v = Number(frac[1]) / Number(frac[2]);
    return Number.isFinite(v) ? v : null;
  }
  return /^\d+(?:\.\d+)?$|^\.\d+$/.test(t) ? Number(t) : null;
}

/**
 * Parse a limit: "x <= rhs" (or "x ≤ rhs"), optionally followed by ": reason". The right side is a sum of terms, each
 * a product of factors separated by * or · (or spaces): a parameter with an optional power (n^2, m^{1/2}, m^(3/2),
 * m^1.5) or a positive constant (2*n).
 * @param params the parameters that may appear (the problem's parameters that are not log-dependent)
 * @throws ConstraintError if it is malformed, names another parameter, or bounds a parameter by itself
 */
export function parseConstraint(text: string, params: readonly string[]): ParamConstraint {
  const colon = text.indexOf(':');
  const body = (colon < 0 ? text : text.slice(0, colon)).trim();
  const reason = colon < 0 ? null : text.slice(colon + 1).trim() || null;
  const m = /^(.*?)\s*(?:<=|≤|=<)\s*(.*)$/.exec(body);
  if (m === null) throw new ConstraintError(`expected "parameter <= limit", got "${body}"`);
  const param = m[1]!.trim();
  if (!params.includes(param)) throw new ConstraintError(`${param === '' ? 'the left side' : param} is not a parameter here (${params.join(', ')})`);
  const rhs = m[2]!.trim();
  if (rhs === '') throw new ConstraintError('the limit is missing');
  const terms: LimitTerm[] = rhs.split('+').map((termText) => {
    const factors = termText
      .replace(/\\cdot|·/g, '*')
      .split(/\*|\s+/)
      .map((f) => f.trim())
      .filter((f) => f !== '');
    if (factors.length === 0) throw new ConstraintError(`empty term in "${rhs}"`);
    let factor = 1;
    const powers = new Map<string, number>();
    for (const f of factors) {
      const c = parseNumber(f);
      if (c !== null) {
        if (!(c > 0)) throw new ConstraintError(`a constant factor must be positive (${f})`);
        factor *= c;
        continue;
      }
      const caret = f.indexOf('^');
      const name = caret < 0 ? f : f.slice(0, caret);
      const exp = caret < 0 ? 1 : parseNumber(f.slice(caret + 1));
      if (exp === null || !(exp > 0) || !Number.isFinite(exp)) throw new ConstraintError(`bad power in "${f}"`);
      if (name === param) throw new ConstraintError(`${param} is bounded by itself`);
      if (!params.includes(name)) throw new ConstraintError(`${name} is not a parameter here (${params.join(', ')})`);
      powers.set(name, (powers.get(name) ?? 0) + exp);
    }
    return Object.freeze({ factor, powers: Object.freeze([...powers].map(([p, a]) => Object.freeze([p, a] as const))) });
  });
  return Object.freeze({ text: body.replace(/\s+/g, ' '), param, terms: Object.freeze(terms), reason });
}

/** Whether two growths are the same (also the same constant or coefficient). */
function sameGrowth(a: Growth, b: Growth): boolean {
  switch (a.kind) {
    case 'const':
      return b.kind === 'const' && a.value === b.value;
    case 'log':
      return b.kind === 'log' && a.pow === b.pow && a.coef === b.coef;
    case 'qpoly':
      return b.kind === 'qpoly' && a.pow === b.pow && a.coef === b.coef;
    case 'poly':
      return b.kind === 'poly' && a.exp === b.exp;
    default:
      return a.kind === b.kind;
  }
}

/** A limit with its parameters as indices into a parameter list. */
interface CompiledLimit {
  readonly target: number;
  readonly terms: ReadonlyArray<{ readonly factor: number; readonly powers: ReadonlyArray<readonly [number, number]> }>;
}

/** Compiled limits per parameter list (a problem's, which every regime of it uses) and limit. */
const compiledCache = new WeakMap<readonly string[], Map<ParamConstraint, CompiledLimit | null>>();

function compile(params: readonly string[], c: ParamConstraint): CompiledLimit | null {
  let cache = compiledCache.get(params);
  if (cache === undefined) compiledCache.set(params, (cache = new Map()));
  let k = cache.get(c);
  if (k === undefined) {
    const target = params.indexOf(c.param);
    const terms = c.terms.map((t) => ({ factor: t.factor, powers: t.powers.map(([p, a]) => [params.indexOf(p), a] as const) }));
    k = target < 0 || terms.some((t) => t.powers.some(([i]) => i < 0)) ? null : { target, terms };
    cache.set(c, k);
  }
  return k;
}

/** The class of a limit's right side at the growths `g`, or null if a term does not evaluate. */
function limitGrowth(k: CompiledLimit, g: readonly Growth[]): Growth | null {
  // (the common case, every parameter polynomial: the largest sum of exponents; constant factors do not count)
  let polyMax = -Infinity;
  let allPoly = true;
  for (const t of k.terms) {
    let e = 0;
    for (const [i, a] of t.powers) {
      const x = g[i]!;
      if (x.kind !== 'poly' || t.powers.length === 0) {
        allPoly = false;
        break;
      }
      e += a * x.exp;
    }
    if (!allPoly || t.powers.length === 0) {
      allPoly = false;
      break;
    }
    polyMax = Math.max(polyMax, e);
  }
  if (allPoly) return G.poly(polyMax);
  let bound: Growth | null = null;
  try {
    for (const t of k.terms) {
      let x: Growth = G.constant(t.factor);
      for (const [i, a] of t.powers) x = G.mul(x, G.power(g[i]!, G.constant(a)));
      bound = bound === null ? x : G.max(bound, x);
    }
  } catch (e) {
    if (e instanceof EvalError) return null;
    throw e;
  }
  return bound;
}

/**
 * Passes over the limits at most. Each pass lowers some parameter or ends the clipping; the limits of the sheet need a
 * few, and cyclic limits without a fixed cap (m ≤ n·α with α ≤ √m alone) approach their fixed point geometrically,
 * within 2^-64 after this many.
 */
const MAX_PASSES = 64;

/**
 * The growths of `params` clipped to the limits: each parameter lowered to the smallest of its limits, again until none
 * changes (lowering one may lower the limit of another, e.g. α ≤ √m after m ≤ n·α). Every step keeps the class of
 * instances (see the module comment), so the result names the same instances as `growths`.
 */
export function clipToLimits(params: readonly string[], growths: readonly Growth[], constraints: readonly ParamConstraint[]): Growth[] {
  const g = [...growths];
  if (constraints.length === 0) return g;
  for (let pass = 0; pass < MAX_PASSES; pass++) {
    let changed = false;
    for (const c of constraints) {
      const k = compile(params, c);
      if (k === null) continue;
      const cur = g[k.target]!;
      const bound = limitGrowth(k, g);
      if (bound === null) continue;
      // (quick: a polynomial or smaller size within a polynomial limit)
      if (bound.kind === 'poly' && ((cur.kind === 'poly' && cur.exp <= bound.exp) || (bound.exp > 0 && (cur.kind === 'const' || cur.kind === 'log')))) continue;
      const next = G.min(cur, bound);
      if (!sameGrowth(next, cur) && G.compare(next, cur) !== 1) {
        g[k.target] = next;
        changed = true;
      }
    }
    if (!changed) break;
  }
  return g;
}

/** A positive number as TeX: an integer, a simple fraction (denominator ≤ 12) or a short decimal. */
function numberTex(x: number): string {
  for (let q = 1; q <= 12; q++) {
    const p = Math.round(x * q);
    if (Math.abs(p / q - x) < 1e-9) return q === 1 ? String(p) : `${p}/${q}`;
  }
  return G.formatNumber(x, 4);
}

/** LaTeX for a limit, e.g. "t \le m \cdot \alpha", "\alpha \le m^{1/2}". */
export function constraintTex(c: ParamConstraint): string {
  const term = (t: LimitTerm): string => {
    const parts = t.powers.map(([p, a]) => (a === 1 ? identifierTex(p) : `${identifierTex(p)}^{${numberTex(a)}}`));
    if (t.factor !== 1 || parts.length === 0) parts.unshift(numberTex(t.factor));
    return parts.join(' \\cdot ');
  };
  return `${identifierTex(c.param)} \\le ${c.terms.map(term).join(' + ')}`;
}
