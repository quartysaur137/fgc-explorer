/**
 * Engine config and scenario: types and validators (SPEC §3.3, §3.4).
 *
 * Validators are total: they never throw on bad input. Invalid entries are dropped and described in `errors`, so a
 * hand-edited file with one mistake still loads.
 */

// ---------------------------------------------------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------------------------------------------------

export interface ConstantDef {
  readonly value: number;
  readonly min: number;
  readonly max: number;
  readonly label: string;
}

export type FreeParamType = 'int' | 'real' | 'size' | 'fixed';

export interface FreeParamDef {
  /** Canonical identifier (e.g. "k", "delta", "B_med"). */
  readonly name: string;
  readonly type: FreeParamType;
  /** int: the values to try. */
  readonly values?: readonly number[];
  /** real/size: range (numbers or LaTeX expressions in earlier free parameters). For size: range of τ in base^τ. */
  readonly min?: number | string;
  readonly max?: number | string;
  /** size: the base quantity (LaTeX in the source's parameters); default: the source regime's normalizer. */
  readonly base?: string;
  /** fixed: the value (null = unknown constant). */
  readonly value?: number | null;
  readonly note?: string;
}

export interface RowAnnotation {
  /**
   * Problems the annotation was written for ("Family / Variation", case-insensitive). If given and the row with this
   * Reduction ID connects other problems (e.g. the sheet was renumbered), the annotation is ignored.
   */
  readonly match?: { readonly from?: string; readonly to?: string };
  readonly free?: readonly FreeParamDef[];
  /** Abbreviations: name → LaTeX expression (evaluated in order, after free parameters). */
  readonly defs?: Readonly<Record<string, string>>;
  /** Replacement for the From-time formula (LaTeX). */
  readonly from?: string;
  /** Replacement for the Reduction Runtime formula (LaTeX). */
  readonly rt?: string;
  /** Regime spec that the source regime must satisfy (e.g. "m=3/2"). */
  readonly requires?: string;
  /** If present, the row is not used; the text is the reason shown in the UI. */
  readonly skip?: string;
  readonly note?: string;
}

export interface ProblemConfig {
  readonly params?: readonly string[];
  readonly logParams?: readonly string[];
  readonly timeType?: 'poly' | 'exp';
  /** Regimes of interest (regime specs). The first one also fills parameters missing from knob regimes. */
  readonly regimes?: readonly string[];
  readonly note?: string;
}

export type KnobKind = 'LB' | 'UB';

export interface KnobSpec {
  readonly problem: string;
  readonly kind: KnobKind;
  /** Regime spec; required for LB knobs. */
  readonly regime?: string;
  /** Exactly one of exponent / formula. */
  readonly exponent?: number;
  readonly formula?: string;
  readonly note?: string;
}

export interface Knob extends KnobSpec {
  readonly id: string;
  readonly enabled: boolean;
}

/** A knob of the initial scenario, with its Bound ID (a number such as "7", like the sheet's Reduction IDs). */
export interface InitialKnobSpec extends KnobSpec {
  /** Unique among the initial knobs. Missing: the next free number. */
  readonly id?: string;
}

/**
 * A group of knobs in the initial scenario (e.g. "SETH", "Known algorithms"). The groups only describe where the
 * starting knobs come from: once a scenario exists, its knobs are edited one by one.
 */
export interface KnobGroup {
  readonly label: string;
  /** One line shown in the "Initial settings" note; may contain $...$ LaTeX. */
  readonly description?: string;
  /** Whether the group's knobs start switched on (default true). */
  readonly enabled: boolean;
  readonly knobs: readonly InitialKnobSpec[];
}

/**
 * Fresh ids "n+1", "n+2", … where n is the largest whole number among `taken` (knob ids are numbers, as the sheet's
 * Reduction IDs; other ids are allowed and simply skipped).
 * @returns a function giving a new id on each call, never one of `taken` or an earlier result
 */
export function numberedIds(taken: Iterable<string>): () => string {
  const used = new Set(taken);
  let n = 0;
  for (const t of used) if (/^\d+$/.test(t)) n = Math.max(n, Number(t));
  return () => {
    do n += 1;
    while (used.has(String(n)));
    used.add(String(n));
    return String(n);
  };
}

export interface EngineConfig {
  readonly version: 1;
  readonly constants: Readonly<Record<string, ConstantDef>>;
  /** Family-name aliases (typo fixes): alias → canonical. */
  readonly aliases: Readonly<Record<string, string>>;
  readonly problems: Readonly<Record<string, ProblemConfig>>;
  readonly rows: Readonly<Record<string, RowAnnotation>>;
  /** The knobs a fresh (or restored) scenario starts with, in display order. */
  readonly initialKnobs: readonly KnobGroup[];
}

export interface Settings {
  /** Maximum number of reductions in an LB derivation chain. */
  readonly maxHopsLB: number;
  /** Maximum number of reductions in an UB derivation (recursion depth). */
  readonly maxDepthUB: number;
  /** Grid points per continuous free parameter. */
  readonly gridPoints: number;
  /** Rounds of local refinement after the grid search. */
  readonly refineRounds: number;
  /** What to do when a row has no Reduction Runtime formula. */
  readonly unknownRT: 'assume-negligible' | 'block';
  /** Use rows marked as randomized. */
  readonly useRandomized: boolean;
  /** Reduction IDs to ignore. */
  readonly disabledRows: readonly string[];
}

export interface Scenario {
  readonly version: 1;
  /** Values of the config's constants (missing ones use the config default). */
  readonly constants: Readonly<Record<string, number>>;
  readonly knobs: readonly Knob[];
  readonly settings: Settings;
}

export const DEFAULT_SETTINGS: Settings = Object.freeze({
  maxHopsLB: 8,
  maxDepthUB: 4,
  gridPoints: 9,
  refineRounds: 20,
  unknownRT: 'assume-negligible',
  useRandomized: true,
  disabledRows: [],
});

export const EMPTY_CONFIG: EngineConfig = Object.freeze({
  version: 1,
  constants: {},
  aliases: {},
  problems: {},
  rows: {},
  initialKnobs: [],
});

export interface Validated<T> {
  readonly value: T;
  readonly errors: readonly string[];
}

// ---------------------------------------------------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------------------------------------------------

type Json = unknown;

function isObject(x: Json): x is Record<string, Json> {
  return typeof x === 'object' && x !== null && !Array.isArray(x);
}

function isFiniteNumber(x: Json): x is number {
  return typeof x === 'number' && Number.isFinite(x);
}

function optString(o: Record<string, Json>, k: string, path: string, errors: string[]): string | undefined {
  const x = o[k];
  if (x === undefined) return undefined;
  if (typeof x === 'string') return x;
  errors.push(`${path}.${k}: expected a string`);
  return undefined;
}

function stringArray(x: Json, path: string, errors: string[]): string[] | undefined {
  if (x === undefined) return undefined;
  if (Array.isArray(x) && x.every((s) => typeof s === 'string')) return x as string[];
  errors.push(`${path}: expected an array of strings`);
  return undefined;
}

const FREE_TYPES: readonly FreeParamType[] = ['int', 'real', 'size', 'fixed'];

function validateFreeParam(x: Json, path: string, errors: string[]): FreeParamDef | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const name = x['name'];
  const type = x['type'];
  if (typeof name !== 'string' || name === '') {
    errors.push(`${path}.name: expected a non-empty string`);
    return null;
  }
  if (typeof type !== 'string' || !FREE_TYPES.includes(type as FreeParamType)) {
    errors.push(`${path}.type: expected one of ${FREE_TYPES.join(', ')}`);
    return null;
  }
  const out: { -readonly [K in keyof FreeParamDef]: FreeParamDef[K] } = { name, type: type as FreeParamType };
  const note = optString(x, 'note', path, errors);
  if (note !== undefined) out.note = note;
  switch (type) {
    case 'int': {
      const values = x['values'];
      if (!Array.isArray(values) || values.length === 0 || !values.every((v) => Number.isInteger(v))) {
        errors.push(`${path}.values: expected a non-empty array of integers`);
        return null;
      }
      out.values = values as number[];
      break;
    }
    case 'real':
    case 'size': {
      for (const k of ['min', 'max'] as const) {
        const v = x[k];
        if (!isFiniteNumber(v) && typeof v !== 'string') {
          errors.push(`${path}.${k}: expected a number or a LaTeX expression`);
          return null;
        }
        out[k] = v;
      }
      if (type === 'size') {
        const base = optString(x, 'base', path, errors);
        if (base !== undefined) out.base = base;
      }
      break;
    }
    case 'fixed': {
      const v = x['value'];
      if (v !== null && !isFiniteNumber(v)) {
        errors.push(`${path}.value: expected a number or null`);
        return null;
      }
      out.value = v as number | null;
      break;
    }
  }
  return out;
}

function validateRowAnnotation(x: Json, path: string, errors: string[]): RowAnnotation | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const out: { -readonly [K in keyof RowAnnotation]: RowAnnotation[K] } = {};
  if (x['free'] !== undefined) {
    if (!Array.isArray(x['free'])) errors.push(`${path}.free: expected an array`);
    else {
      out.free = (x['free'] as Json[])
        .map((f, i) => validateFreeParam(f, `${path}.free[${i}]`, errors))
        .filter((f): f is FreeParamDef => f !== null);
    }
  }
  if (x['defs'] !== undefined) {
    const d = x['defs'];
    if (!isObject(d) || !Object.values(d).every((s) => typeof s === 'string')) {
      errors.push(`${path}.defs: expected an object of LaTeX strings`);
    } else out.defs = d as Record<string, string>;
  }
  for (const k of ['from', 'rt', 'requires', 'skip', 'note'] as const) {
    const s = optString(x, k, path, errors);
    if (s !== undefined) out[k] = s;
  }
  if (x['match'] !== undefined) {
    const m = x['match'];
    if (!isObject(m) || (m['from'] !== undefined && typeof m['from'] !== 'string') || (m['to'] !== undefined && typeof m['to'] !== 'string')) {
      errors.push(`${path}.match: expected {from?: "Family / Variation", to?: "Family / Variation"}`);
    } else {
      out.match = {
        ...(typeof m['from'] === 'string' ? { from: m['from'] } : {}),
        ...(typeof m['to'] === 'string' ? { to: m['to'] } : {}),
      };
    }
  }
  return out;
}

function validateProblemConfig(x: Json, path: string, errors: string[]): ProblemConfig | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const out: { -readonly [K in keyof ProblemConfig]: ProblemConfig[K] } = {};
  const params = stringArray(x['params'], `${path}.params`, errors);
  if (params !== undefined) out.params = params;
  const logParams = stringArray(x['logParams'], `${path}.logParams`, errors);
  if (logParams !== undefined) out.logParams = logParams;
  const regimes = stringArray(x['regimes'], `${path}.regimes`, errors);
  if (regimes !== undefined) out.regimes = regimes;
  const tt = x['timeType'];
  if (tt !== undefined) {
    if (tt === 'poly' || tt === 'exp') out.timeType = tt;
    else errors.push(`${path}.timeType: expected "poly" or "exp"`);
  }
  const note = optString(x, 'note', path, errors);
  if (note !== undefined) out.note = note;
  return out;
}

/** Validate a knob spec (without id/enabled). */
export function validateKnobSpec(x: Json, path: string, errors: string[]): KnobSpec | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const problem = x['problem'];
  const kind = x['kind'];
  if (typeof problem !== 'string' || problem === '') {
    errors.push(`${path}.problem: expected a problem id ("Family / Variation")`);
    return null;
  }
  if (kind !== 'LB' && kind !== 'UB') {
    errors.push(`${path}.kind: expected "LB" or "UB"`);
    return null;
  }
  const out: { -readonly [K in keyof KnobSpec]: KnobSpec[K] } = { problem, kind };
  const regime = optString(x, 'regime', path, errors);
  if (regime !== undefined) out.regime = regime;
  const formula = optString(x, 'formula', path, errors);
  const exponent = x['exponent'];
  if (exponent !== undefined && !isFiniteNumber(exponent)) {
    errors.push(`${path}.exponent: expected a number`);
    return null;
  }
  if ((exponent === undefined) === (formula === undefined)) {
    errors.push(`${path}: give exactly one of "exponent" and "formula"`);
    return null;
  }
  if (exponent !== undefined) out.exponent = exponent as number;
  if (formula !== undefined) out.formula = formula;
  if (kind === 'LB' && regime === undefined) {
    errors.push(`${path}: an LB knob needs a "regime"`);
    return null;
  }
  const note = optString(x, 'note', path, errors);
  if (note !== undefined) out.note = note;
  return out;
}

// ---------------------------------------------------------------------------------------------------------------------
// Public validators
// ---------------------------------------------------------------------------------------------------------------------

/** Validate an engine config (parsed JSON). Never throws. */
export function validateConfig(json: Json): Validated<EngineConfig> {
  const errors: string[] = [];
  if (!isObject(json)) return { value: EMPTY_CONFIG, errors: ['config: expected a JSON object'] };
  if (json['version'] !== 1) errors.push('config.version: expected 1');

  const constants: Record<string, ConstantDef> = {};
  const c = json['constants'];
  if (c !== undefined) {
    if (!isObject(c)) errors.push('config.constants: expected an object');
    else {
      for (const [name, def] of Object.entries(c)) {
        if (isObject(def) && isFiniteNumber(def['value'])) {
          const value = def['value'];
          const min = isFiniteNumber(def['min']) ? def['min'] : Math.min(0, value);
          const max = isFiniteNumber(def['max']) ? def['max'] : Math.max(1, 2 * value);
          constants[name] = { value, min, max, label: typeof def['label'] === 'string' ? def['label'] : name };
        } else errors.push(`config.constants.${name}: expected {value, min?, max?, label?}`);
      }
    }
  }

  const aliases: Record<string, string> = {};
  const a = json['aliases'];
  if (a !== undefined) {
    if (!isObject(a)) errors.push('config.aliases: expected an object');
    else {
      for (const [k, v] of Object.entries(a)) {
        if (typeof v === 'string') aliases[k] = v;
        else errors.push(`config.aliases.${k}: expected a string`);
      }
    }
  }

  const problems: Record<string, ProblemConfig> = {};
  const p = json['problems'];
  if (p !== undefined) {
    if (!isObject(p)) errors.push('config.problems: expected an object');
    else {
      for (const [k, v] of Object.entries(p)) {
        const pc = validateProblemConfig(v, `config.problems["${k}"]`, errors);
        if (pc) problems[k] = pc;
      }
    }
  }

  const rows: Record<string, RowAnnotation> = {};
  const r = json['rows'];
  if (r !== undefined) {
    if (!isObject(r)) errors.push('config.rows: expected an object');
    else {
      for (const [k, v] of Object.entries(r)) {
        const ra = validateRowAnnotation(v, `config.rows["${k}"]`, errors);
        if (ra) rows[k] = ra;
      }
    }
  }

  // "presets" is the name used by the first version of the app (groups that were toggled by buttons).
  let groupsKey = 'initialKnobs';
  if (json['initialKnobs'] === undefined && json['presets'] !== undefined) {
    groupsKey = 'presets';
    errors.push('config.presets: read as "initialKnobs" (the section was renamed; please rename it in the file)');
  }
  const initialKnobs = validateKnobGroups(json[groupsKey], `config.${groupsKey}`, errors);
  return { value: { version: 1, constants, aliases, problems, rows, initialKnobs }, errors };
}

function validateKnobGroups(x: Json, path: string, errors: string[]): KnobGroup[] {
  if (x === undefined) return [];
  if (!Array.isArray(x)) {
    errors.push(`${path}: expected an array`);
    return [];
  }
  const groups: KnobGroup[] = [];
  const ids = new Set<string>();
  x.forEach((g, i) => {
    const gPath = `${path}[${i}]`;
    if (!isObject(g) || typeof g['label'] !== 'string' || !Array.isArray(g['knobs'])) {
      errors.push(`${gPath}: expected {label, description?, enabled?, knobs: [...]}`);
      return;
    }
    if (g['enabled'] !== undefined && typeof g['enabled'] !== 'boolean') errors.push(`${gPath}.enabled: expected true or false`);
    const knobs: InitialKnobSpec[] = [];
    (g['knobs'] as Json[]).forEach((k, j) => {
      const kPath = `${gPath}.knobs[${j}]`;
      const spec = validateKnobSpec(k, kPath, errors);
      if (spec === null) return;
      const id = uniqueKnobId(k, kPath, ids, errors);
      knobs.push(id !== undefined ? { id, ...spec } : spec);
    });
    const description = optString(g, 'description', gPath, errors);
    groups.push({ label: g['label'], ...(description !== undefined ? { description } : {}), enabled: g['enabled'] !== false, knobs });
  });
  return groups;
}

/**
 * The id of knob `k` (JSON): a number or a non-empty string, added to `ids`. Undefined when absent, invalid or already
 * in `ids` (an error for the latter two), so that the knob gets a fresh number.
 */
function uniqueKnobId(k: Json, path: string, ids: Set<string>, errors: string[]): string | undefined {
  const raw = isObject(k) ? k['id'] : undefined;
  const id = typeof raw === 'number' && Number.isFinite(raw) ? String(raw) : typeof raw === 'string' ? raw.trim() : undefined;
  if (raw !== undefined && !id) errors.push(`${path}.id: expected a number or a non-empty string`);
  if (id && ids.has(id)) errors.push(`${path}.id: ${id} is used by an earlier knob; this one gets a new number`);
  if (!id || ids.has(id)) return undefined;
  ids.add(id);
  return id;
}

function intInRange(x: Json, lo: number, hi: number, fallback: number, path: string, errors: string[]): number {
  if (x === undefined) return fallback;
  if (Number.isInteger(x) && (x as number) >= lo && (x as number) <= hi) return x as number;
  errors.push(`${path}: expected an integer in [${lo}, ${hi}]`);
  return fallback;
}

/** Validate settings (missing fields take defaults). Never throws. */
export function validateSettings(x: Json, errors: string[]): Settings {
  if (x === undefined) return DEFAULT_SETTINGS;
  if (!isObject(x)) {
    errors.push('settings: expected an object');
    return DEFAULT_SETTINGS;
  }
  const d = DEFAULT_SETTINGS;
  const unknownRT = x['unknownRT'] === 'block' || x['unknownRT'] === 'assume-negligible' ? x['unknownRT'] : d.unknownRT;
  if (x['unknownRT'] !== undefined && unknownRT !== x['unknownRT']) errors.push('settings.unknownRT: expected "assume-negligible" or "block"');
  const disabled = stringArray(x['disabledRows'], 'settings.disabledRows', errors) ?? d.disabledRows;
  return {
    maxHopsLB: intInRange(x['maxHopsLB'], 0, 50, d.maxHopsLB, 'settings.maxHopsLB', errors),
    maxDepthUB: intInRange(x['maxDepthUB'], 0, 12, d.maxDepthUB, 'settings.maxDepthUB', errors),
    gridPoints: intInRange(x['gridPoints'], 2, 41, d.gridPoints, 'settings.gridPoints', errors),
    refineRounds: intInRange(x['refineRounds'], 0, 40, d.refineRounds, 'settings.refineRounds', errors),
    unknownRT,
    useRandomized: typeof x['useRandomized'] === 'boolean' ? x['useRandomized'] : d.useRandomized,
    disabledRows: disabled,
  };
}

/**
 * The scenario a first visit (or "Restore initial settings") starts with: every knob of `config.initialKnobs`, switched
 * on or off as its group says, noted with the group's label unless it has its own note; constants at their defaults.
 */
export function initialScenario(config: EngineConfig): Scenario {
  // Knob ids are the Bound IDs of exported bounds CSVs: the config's numbers, else the next free ones.
  const specs = config.initialKnobs.flatMap((group) => group.knobs.map((spec) => ({ group, spec })));
  const next = numberedIds(specs.flatMap(({ spec }) => (spec.id !== undefined ? [spec.id] : [])));
  const knobs: Knob[] = specs.map(({ group, spec }) => {
    const { id, ...rest } = spec;
    return { ...rest, id: id ?? next(), enabled: group.enabled, note: spec.note ?? group.label };
  });
  return { version: 1, constants: {}, knobs, settings: DEFAULT_SETTINGS };
}

/**
 * Validate a scenario (parsed JSON). Never throws. Knobs without an id, or with one an earlier knob has, are numbered
 * after the largest numeric id given (as Bound IDs are).
 */
export function validateScenario(json: Json): Validated<Scenario> {
  const errors: string[] = [];
  if (!isObject(json)) {
    return { value: { version: 1, constants: {}, knobs: [], settings: DEFAULT_SETTINGS }, errors: ['scenario: expected a JSON object'] };
  }
  if (json['version'] !== 1) errors.push('scenario.version: expected 1');
  const constants: Record<string, number> = {};
  const c = json['constants'];
  if (c !== undefined) {
    if (!isObject(c)) errors.push('scenario.constants: expected an object');
    else {
      for (const [k, v] of Object.entries(c)) {
        if (isFiniteNumber(v)) constants[k] = v;
        else errors.push(`scenario.constants.${k}: expected a number`);
      }
    }
  }
  const read: { spec: KnobSpec; id: string | undefined; enabled: boolean }[] = [];
  const ids = new Set<string>();
  const ks = json['knobs'];
  if (ks !== undefined && !Array.isArray(ks)) errors.push('scenario.knobs: expected an array');
  (Array.isArray(ks) ? ks : []).forEach((x, i) => {
    const path = `scenario.knobs[${i}]`;
    const spec = validateKnobSpec(x, path, errors);
    if (spec === null || !isObject(x)) return;
    read.push({ spec, id: uniqueKnobId(x, path, ids, errors), enabled: x['enabled'] !== false });
  });
  const next = numberedIds(ids);
  const knobs: Knob[] = read.map(({ spec, id, enabled }) => ({ ...spec, id: id ?? next(), enabled }));
  const settings = validateSettings(json['settings'], errors);
  return { value: { version: 1, constants, knobs, settings }, errors };
}
