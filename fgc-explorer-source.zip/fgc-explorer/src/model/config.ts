/**
 * Engine config and scenario: types and validators (SPEC §3.3, §3.4).
 *
 * Validators are total: they never throw on bad input. Invalid entries are dropped and described in `errors`, so a
 * hand-edited file with one mistake still loads.
 */

// ---------------------------------------------------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------------------------------------------------

export interface ConstantDef {
  readonly value: number;
  readonly min: number;
  readonly max: number;
  readonly label: string;
}

export type FreeParamType = 'int' | 'real' | 'size' | 'fixed';

export interface FreeParamDef {
  /** Canonical identifier (e.g. "k", "delta", "B_med"). */
  readonly name: string;
  readonly type: FreeParamType;
  /** int: the values to try. */
  readonly values?: readonly number[];
  /** real/size: range (numbers or LaTeX expressions in earlier free parameters). For size: range of τ in base^τ. */
  readonly min?: number | string;
  readonly max?: number | string;
  /** size: the base quantity (LaTeX in the source's parameters); default: the source regime's normalizer. */
  readonly base?: string;
  /** fixed: the value (null = unknown constant). */
  readonly value?: number | null;
  readonly note?: string;
}

export interface RowAnnotation {
  /**
   * Problems the annotation was written for ("Family / Variation", case-insensitive). If given and the row with this
   * Reduction ID connects other problems (e.g. the sheet was renumbered), the annotation is ignored.
   */
  readonly match?: { readonly from?: string; readonly to?: string };
  readonly free?: readonly FreeParamDef[];
  /** Abbreviations: name → LaTeX expression (evaluated in order, after free parameters). */
  readonly defs?: Readonly<Record<string, string>>;
  /** Replacement for the From-time formula (LaTeX). */
  readonly from?: string;
  /** Replacement for the Reduction Runtime formula (LaTeX). */
  readonly rt?: string;
  /** Regime spec that the source regime must satisfy (e.g. "m=3/2"). */
  readonly requires?: string;
  /** If present, the row is not used; the text is the reason shown in the UI. */
  readonly skip?: string;
  readonly note?: string;
}

export interface ProblemConfig {
  readonly params?: readonly string[];
  readonly logParams?: readonly string[];
  readonly timeType?: 'poly' | 'exp';
  /** Regimes of interest (regime specs). The first one also fills parameters missing from knob regimes. */
  readonly regimes?: readonly string[];
  /**
   * Limits that every instance satisfies (SPEC §2.3, §3.7), e.g. "m <= n^2" or "t <= m*alpha: a graph has O(m·α)
   * triangles": every regime is clipped to them.
   */
  readonly constraints?: readonly string[];
  readonly note?: string;
}

export type KnobKind = 'LB' | 'UB';

export interface KnobSpec {
  readonly problem: string;
  readonly kind: KnobKind;
  /** Regime spec; required for LB knobs. */
  readonly regime?: string;
  /** Exactly one of exponent / formula. */
  readonly exponent?: number;
  /**
   * With an exponent c: the power a of the running time 2^{c·L^a} (L = log2 N), i.e. 2^{c·n^a} at a regime of
   * exponential scale (N = 2^n) and 2^{c·log^a n} at a polynomial one; missing: 1 (N^c, 2^{cn}).
   */
  readonly power?: number;
  readonly formula?: string;
  readonly note?: string;
}

export interface Knob extends KnobSpec {
  readonly id: string;
  readonly enabled: boolean;
}

/** A knob of the initial scenario, with its Bound ID ("L7" for a lower bound, "U7" for an upper bound). */
export interface InitialKnobSpec extends KnobSpec {
  /** Unique among the initial knobs. Missing: the next free one of its kind. */
  readonly id?: string;
}

/**
 * A group of knobs in the initial scenario (e.g. "Satisfiability Hypothesis", "Known algorithms"). The groups only describe where the
 * starting knobs come from: once a scenario exists, its knobs are edited one by one.
 */
export interface KnobGroup {
  readonly label: string;
  /** One line shown in the "Initial settings" note; may contain $...$ LaTeX. */
  readonly description?: string;
  /** Whether the group's knobs start switched on (default true). */
  readonly enabled: boolean;
  readonly knobs: readonly InitialKnobSpec[];
}

// ---------------------------------------------------------------------------------------------------------------------
// IDs: Reduction IDs "R1", "R2", …; Bound IDs "L1", "L2", … (lower bounds) and "U1", "U2", … (upper bounds)
// ---------------------------------------------------------------------------------------------------------------------

/**
 * The canonical form of a Reduction ID: "R<n>" for a whole number n written with or without the letter (in either case;
 * leading zeros dropped), also with the suffix "#k" the model gives repeated IDs ("12#2" is "R12#2"), so that sheets
 * numbered before the letters existed keep matching the config's row annotations and the scenario's disabled rows; any
 * other ID is kept as written (trimmed).
 */
export function canonicalRowId(id: string): string {
  const t = id.trim();
  const m = /^[Rr]?0*(\d+)(#\d+)?$/.exec(t);
  return m ? `R${m[1]}${m[2] ?? ''}` : t;
}

/**
 * Fresh Reduction IDs "R<n+1>", "R<n+2>", … where n is the largest number among `taken` (in canonical form).
 * @returns a function giving a new ID on each call, never one of `taken` or an earlier result
 */
export function rowIds(taken: Iterable<string>): () => string {
  const used = new Set([...taken].map(canonicalRowId));
  let n = 0;
  for (const t of used) {
    const m = /^R(\d+)$/.exec(t);
    if (m) n = Math.max(n, Number(m[1]));
  }
  return () => {
    let id: string;
    do id = `R${(n += 1)}`;
    while (used.has(id));
    used.add(id);
    return id;
  };
}

/** The letter of the Bound IDs of each kind of knob. */
export const BOUND_ID_LETTER: Readonly<Record<KnobKind, string>> = { LB: 'L', UB: 'U' };

/**
 * Upper bounds numbered 34 and up by earlier versions (added by the user) become U<n + 334>: after U367, the last
 * initial upper bound when the letters were introduced, in their order.
 */
const LEGACY_UB_OFFSET = 334;

/**
 * The Bound ID that a knob numbered before the letters existed gets. Those versions numbered all knobs together: the
 * initial ones 1–9 (lower bounds, now L1–L9) and 10–33 (upper bounds, now U1–U24), the user's after them. The mapping
 * depends on the number and kind only, so that a knob gets the same ID wherever it was saved (scenario, config, bounds
 * CSV): a lower bound n is L<n>; an upper bound 10–33 is U<n − 9>, one from 34 up U<n + 334>; null for an upper bound
 * below 10 (no initial upper bound had such a number: it gets a fresh ID). Files and saved data of earlier versions
 * thus keep pointing at the same bounds.
 */
export function legacyBoundId(n: number, kind: KnobKind): string | null {
  if (!Number.isInteger(n) || n < 1) return null;
  if (kind === 'LB') return `L${n}`;
  if (n >= 10 && n <= 33) return `U${n - 9}`;
  return n >= 34 ? `U${n + LEGACY_UB_OFFSET}` : null;
}

/**
 * The canonical form of a Bound ID given for a knob of `kind`: "L<n>"/"U<n>" in upper case (leading zeros dropped); a
 * bare number is a Bound ID of earlier versions (legacyBoundId), null if it needs a fresh ID; other text is kept as
 * written (trimmed).
 */
export function canonicalBoundId(id: string, kind: KnobKind): string | null {
  const t = id.trim();
  const bare = /^0*(\d+)$/.exec(t);
  if (bare) return legacyBoundId(Number(bare[1]), kind);
  const lettered = /^([LlUu])0*(\d+)$/.exec(t);
  return lettered ? `${lettered[1]!.toUpperCase()}${lettered[2]}` : t;
}

/**
 * Fresh Bound IDs: for each kind its letter and the next number after the largest one with that letter among `taken`
 * (lower and upper bounds are numbered separately: L1, L2, … and U1, U2, …).
 * @returns a function giving a new ID of the given kind on each call, never one of `taken` or an earlier result
 */
export function boundIds(taken: Iterable<string>): (kind: KnobKind) => string {
  const used = new Set(taken);
  const last: Record<KnobKind, number> = { LB: 0, UB: 0 };
  for (const t of used) {
    for (const kind of ['LB', 'UB'] as const) {
      const m = new RegExp(`^${BOUND_ID_LETTER[kind]}(\\d+)$`).exec(t);
      if (m) last[kind] = Math.max(last[kind], Number(m[1]));
    }
  }
  return (kind) => {
    let id: string;
    do id = `${BOUND_ID_LETTER[kind]}${(last[kind] += 1)}`;
    while (used.has(id));
    used.add(id);
    return id;
  };
}

export interface EngineConfig {
  readonly version: 1;
  readonly constants: Readonly<Record<string, ConstantDef>>;
  /** Family-name aliases (typo fixes): alias → canonical. */
  readonly aliases: Readonly<Record<string, string>>;
  readonly problems: Readonly<Record<string, ProblemConfig>>;
  readonly rows: Readonly<Record<string, RowAnnotation>>;
  /** The knobs a fresh (or restored) scenario starts with, in display order. */
  readonly initialKnobs: readonly KnobGroup[];
}

export interface Settings {
  /**
   * How many regimes in a row that are not of interest (not configured, of a UB knob or pinned) an upper-bound
   * derivation may pass through; otherwise derivations have no length limit (SPEC §6.6).
   */
  readonly maxDepthUB: number;
  /** Grid points per continuous free parameter. */
  readonly gridPoints: number;
  /** Rounds of local refinement after the grid search. */
  readonly refineRounds: number;
  /** What to do when a row has no Reduction Runtime formula. */
  readonly unknownRT: 'assume-negligible' | 'block';
  /** Use rows marked as randomized. */
  readonly useRandomized: boolean;
  /** Reduction IDs to ignore. */
  readonly disabledRows: readonly string[];
}

export interface Scenario {
  readonly version: 1;
  /** Values of the config's constants (missing ones use the config default). */
  readonly constants: Readonly<Record<string, number>>;
  readonly knobs: readonly Knob[];
  /**
   * The problems listed in the left panel (one box each), in order. A knob's problem need not be listed: unlisted ones
   * follow, in the order of their first knob (see problemBoxes). Listing matters for order and for boxes without knobs.
   */
  readonly problems: readonly string[];
  readonly settings: Settings;
}

export const DEFAULT_SETTINGS: Settings = Object.freeze({
  maxDepthUB: 3,
  gridPoints: 9,
  refineRounds: 20,
  unknownRT: 'assume-negligible',
  useRandomized: true,
  disabledRows: [],
});

export const EMPTY_CONFIG: EngineConfig = Object.freeze({
  version: 1,
  constants: {},
  aliases: {},
  problems: {},
  rows: {},
  initialKnobs: [],
});

export interface Validated<T> {
  readonly value: T;
  readonly errors: readonly string[];
}

// ---------------------------------------------------------------------------------------------------------------------
// Validation helpers
// ---------------------------------------------------------------------------------------------------------------------

type Json = unknown;

function isObject(x: Json): x is Record<string, Json> {
  return typeof x === 'object' && x !== null && !Array.isArray(x);
}

function isFiniteNumber(x: Json): x is number {
  return typeof x === 'number' && Number.isFinite(x);
}

function optString(o: Record<string, Json>, k: string, path: string, errors: string[]): string | undefined {
  const x = o[k];
  if (x === undefined) return undefined;
  if (typeof x === 'string') return x;
  errors.push(`${path}.${k}: expected a string`);
  return undefined;
}

function stringArray(x: Json, path: string, errors: string[]): string[] | undefined {
  if (x === undefined) return undefined;
  if (Array.isArray(x) && x.every((s) => typeof s === 'string')) return x as string[];
  errors.push(`${path}: expected an array of strings`);
  return undefined;
}

const FREE_TYPES: readonly FreeParamType[] = ['int', 'real', 'size', 'fixed'];

function validateFreeParam(x: Json, path: string, errors: string[]): FreeParamDef | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const name = x['name'];
  const type = x['type'];
  if (typeof name !== 'string' || name === '') {
    errors.push(`${path}.name: expected a non-empty string`);
    return null;
  }
  if (typeof type !== 'string' || !FREE_TYPES.includes(type as FreeParamType)) {
    errors.push(`${path}.type: expected one of ${FREE_TYPES.join(', ')}`);
    return null;
  }
  const out: { -readonly [K in keyof FreeParamDef]: FreeParamDef[K] } = { name, type: type as FreeParamType };
  const note = optString(x, 'note', path, errors);
  if (note !== undefined) out.note = note;
  switch (type) {
    case 'int': {
      const values = x['values'];
      if (!Array.isArray(values) || values.length === 0 || !values.every((v) => Number.isInteger(v))) {
        errors.push(`${path}.values: expected a non-empty array of integers`);
        return null;
      }
      out.values = values as number[];
      break;
    }
    case 'real':
    case 'size': {
      for (const k of ['min', 'max'] as const) {
        const v = x[k];
        if (!isFiniteNumber(v) && typeof v !== 'string') {
          errors.push(`${path}.${k}: expected a number or a LaTeX expression`);
          return null;
        }
        out[k] = v;
      }
      if (type === 'size') {
        const base = optString(x, 'base', path, errors);
        if (base !== undefined) out.base = base;
      }
      break;
    }
    case 'fixed': {
      const v = x['value'];
      if (v !== null && !isFiniteNumber(v)) {
        errors.push(`${path}.value: expected a number or null`);
        return null;
      }
      out.value = v as number | null;
      break;
    }
  }
  return out;
}

function validateRowAnnotation(x: Json, path: string, errors: string[]): RowAnnotation | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const out: { -readonly [K in keyof RowAnnotation]: RowAnnotation[K] } = {};
  if (x['free'] !== undefined) {
    if (!Array.isArray(x['free'])) errors.push(`${path}.free: expected an array`);
    else {
      out.free = (x['free'] as Json[])
        .map((f, i) => validateFreeParam(f, `${path}.free[${i}]`, errors))
        .filter((f): f is FreeParamDef => f !== null);
    }
  }
  if (x['defs'] !== undefined) {
    const d = x['defs'];
    if (!isObject(d) || !Object.values(d).every((s) => typeof s === 'string')) {
      errors.push(`${path}.defs: expected an object of LaTeX strings`);
    } else out.defs = d as Record<string, string>;
  }
  for (const k of ['from', 'rt', 'requires', 'skip', 'note'] as const) {
    const s = optString(x, k, path, errors);
    if (s !== undefined) out[k] = s;
  }
  if (x['match'] !== undefined) {
    const m = x['match'];
    if (!isObject(m) || (m['from'] !== undefined && typeof m['from'] !== 'string') || (m['to'] !== undefined && typeof m['to'] !== 'string')) {
      errors.push(`${path}.match: expected {from?: "Family / Variation", to?: "Family / Variation"}`);
    } else {
      out.match = {
        ...(typeof m['from'] === 'string' ? { from: m['from'] } : {}),
        ...(typeof m['to'] === 'string' ? { to: m['to'] } : {}),
      };
    }
  }
  return out;
}

function validateProblemConfig(x: Json, path: string, errors: string[]): ProblemConfig | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const out: { -readonly [K in keyof ProblemConfig]: ProblemConfig[K] } = {};
  const params = stringArray(x['params'], `${path}.params`, errors);
  if (params !== undefined) out.params = params;
  const logParams = stringArray(x['logParams'], `${path}.logParams`, errors);
  if (logParams !== undefined) out.logParams = logParams;
  const regimes = stringArray(x['regimes'], `${path}.regimes`, errors);
  if (regimes !== undefined) out.regimes = regimes;
  const constraints = stringArray(x['constraints'], `${path}.constraints`, errors);
  if (constraints !== undefined) out.constraints = constraints;
  const tt = x['timeType'];
  if (tt !== undefined) {
    if (tt === 'poly' || tt === 'exp') out.timeType = tt;
    else errors.push(`${path}.timeType: expected "poly" or "exp"`);
  }
  const note = optString(x, 'note', path, errors);
  if (note !== undefined) out.note = note;
  return out;
}

/** Validate a knob spec (without id/enabled). */
export function validateKnobSpec(x: Json, path: string, errors: string[]): KnobSpec | null {
  if (!isObject(x)) {
    errors.push(`${path}: expected an object`);
    return null;
  }
  const problem = x['problem'];
  const kind = x['kind'];
  if (typeof problem !== 'string' || problem === '') {
    errors.push(`${path}.problem: expected a problem id ("Family / Variation")`);
    return null;
  }
  if (kind !== 'LB' && kind !== 'UB') {
    errors.push(`${path}.kind: expected "LB" or "UB"`);
    return null;
  }
  const out: { -readonly [K in keyof KnobSpec]: KnobSpec[K] } = { problem, kind };
  const regime = optString(x, 'regime', path, errors);
  if (regime !== undefined) out.regime = regime;
  const formula = optString(x, 'formula', path, errors);
  const exponent = x['exponent'];
  if (exponent !== undefined && !isFiniteNumber(exponent)) {
    errors.push(`${path}.exponent: expected a number`);
    return null;
  }
  if ((exponent === undefined) === (formula === undefined)) {
    errors.push(`${path}: give exactly one of "exponent" and "formula"`);
    return null;
  }
  if (exponent !== undefined) out.exponent = exponent as number;
  if (formula !== undefined) out.formula = formula;
  const power = x['power'];
  if (power !== undefined) {
    if (!isFiniteNumber(power) || power <= 0) {
      errors.push(`${path}.power: expected a positive number`);
      return null;
    }
    if (exponent === undefined) {
      errors.push(`${path}.power: only goes with an "exponent" (a formula gives its own power)`);
      return null;
    }
    out.power = power;
  }
  if (kind === 'LB' && regime === undefined) {
    errors.push(`${path}: an LB knob needs a "regime"`);
    return null;
  }
  const note = optString(x, 'note', path, errors);
  if (note !== undefined) out.note = note;
  return out;
}

// ---------------------------------------------------------------------------------------------------------------------
// Public validators
// ---------------------------------------------------------------------------------------------------------------------

/** Validate an engine config (parsed JSON). Never throws. */
export function validateConfig(json: Json): Validated<EngineConfig> {
  const errors: string[] = [];
  if (!isObject(json)) return { value: EMPTY_CONFIG, errors: ['config: expected a JSON object'] };
  if (json['version'] !== 1) errors.push('config.version: expected 1');

  const constants: Record<string, ConstantDef> = {};
  const c = json['constants'];
  if (c !== undefined) {
    if (!isObject(c)) errors.push('config.constants: expected an object');
    else {
      for (const [name, def] of Object.entries(c)) {
        if (isObject(def) && isFiniteNumber(def['value'])) {
          const value = def['value'];
          const min = isFiniteNumber(def['min']) ? def['min'] : Math.min(0, value);
          const max = isFiniteNumber(def['max']) ? def['max'] : Math.max(1, 2 * value);
          constants[name] = { value, min, max, label: typeof def['label'] === 'string' ? def['label'] : name };
        } else errors.push(`config.constants.${name}: expected {value, min?, max?, label?}`);
      }
    }
  }

  const aliases: Record<string, string> = {};
  const a = json['aliases'];
  if (a !== undefined) {
    if (!isObject(a)) errors.push('config.aliases: expected an object');
    else {
      for (const [k, v] of Object.entries(a)) {
        if (typeof v === 'string') aliases[k] = v;
        else errors.push(`config.aliases.${k}: expected a string`);
      }
    }
  }

  const problems: Record<string, ProblemConfig> = {};
  const p = json['problems'];
  if (p !== undefined) {
    if (!isObject(p)) errors.push('config.problems: expected an object');
    else {
      for (const [k, v] of Object.entries(p)) {
        const pc = validateProblemConfig(v, `config.problems["${k}"]`, errors);
        if (pc) problems[k] = pc;
      }
    }
  }

  const rows: Record<string, RowAnnotation> = {};
  const r = json['rows'];
  if (r !== undefined) {
    if (!isObject(r)) errors.push('config.rows: expected an object');
    else {
      for (const [k, v] of Object.entries(r)) {
        const ra = validateRowAnnotation(v, `config.rows["${k}"]`, errors);
        // (keys are Reduction IDs: "106" and "R106" are the same row)
        const id = canonicalRowId(k);
        if (ra && rows[id] !== undefined) errors.push(`config.rows["${k}"]: row ${id} is annotated twice; this one is ignored`);
        else if (ra) rows[id] = ra;
      }
    }
  }

  // "presets" is the name used by the first version of the app (groups that were toggled by buttons).
  let groupsKey = 'initialKnobs';
  if (json['initialKnobs'] === undefined && json['presets'] !== undefined) {
    groupsKey = 'presets';
    errors.push('config.presets: read as "initialKnobs" (the section was renamed; please rename it in the file)');
  }
  const initialKnobs = validateKnobGroups(json[groupsKey], `config.${groupsKey}`, errors);
  return { value: { version: 1, constants, aliases, problems, rows, initialKnobs }, errors };
}

function validateKnobGroups(x: Json, path: string, errors: string[]): KnobGroup[] {
  if (x === undefined) return [];
  if (!Array.isArray(x)) {
    errors.push(`${path}: expected an array`);
    return [];
  }
  const groups: KnobGroup[] = [];
  const ids = new Set<string>();
  x.forEach((g, i) => {
    const gPath = `${path}[${i}]`;
    if (!isObject(g) || typeof g['label'] !== 'string' || !Array.isArray(g['knobs'])) {
      errors.push(`${gPath}: expected {label, description?, enabled?, knobs: [...]}`);
      return;
    }
    if (g['enabled'] !== undefined && typeof g['enabled'] !== 'boolean') errors.push(`${gPath}.enabled: expected true or false`);
    const knobs: InitialKnobSpec[] = [];
    (g['knobs'] as Json[]).forEach((k, j) => {
      const kPath = `${gPath}.knobs[${j}]`;
      const spec = validateKnobSpec(k, kPath, errors);
      if (spec === null) return;
      const id = uniqueKnobId(k, spec.kind, kPath, ids, errors);
      knobs.push(id !== undefined ? { id, ...spec } : spec);
    });
    const description = optString(g, 'description', gPath, errors);
    groups.push({ label: g['label'], ...(description !== undefined ? { description } : {}), enabled: g['enabled'] !== false, knobs });
  });
  return groups;
}

/**
 * The Bound ID of knob `k` (JSON) of `kind`: a non-empty string or a number, in canonical form (canonicalBoundId: a bare
 * number is an ID of earlier versions), added to `ids`. Undefined when absent, invalid, a number without a place among
 * the earlier initial knobs, or already in `ids` (an error for invalid and repeated ones), so that the knob gets a
 * fresh ID.
 */
function uniqueKnobId(k: Json, kind: KnobKind, path: string, ids: Set<string>, errors: string[]): string | undefined {
  const raw = isObject(k) ? k['id'] : undefined;
  const given = typeof raw === 'number' && Number.isFinite(raw) ? String(raw) : typeof raw === 'string' ? raw.trim() : undefined;
  if (raw !== undefined && !given) errors.push(`${path}.id: expected a non-empty string or a number`);
  const id = given ? canonicalBoundId(given, kind) : null;
  if (id !== null && ids.has(id)) errors.push(`${path}.id: ${id} is used by an earlier knob; this one gets a new ID`);
  if (id === null || ids.has(id)) return undefined;
  ids.add(id);
  return id;
}

function intInRange(x: Json, lo: number, hi: number, fallback: number, path: string, errors: string[]): number {
  if (x === undefined) return fallback;
  if (Number.isInteger(x) && (x as number) >= lo && (x as number) <= hi) return x as number;
  errors.push(`${path}: expected an integer in [${lo}, ${hi}]`);
  return fallback;
}

/** Validate settings (missing fields take defaults). Never throws. */
export function validateSettings(x: Json, errors: string[]): Settings {
  if (x === undefined) return DEFAULT_SETTINGS;
  if (!isObject(x)) {
    errors.push('settings: expected an object');
    return DEFAULT_SETTINGS;
  }
  const d = DEFAULT_SETTINGS;
  const unknownRT = x['unknownRT'] === 'block' || x['unknownRT'] === 'assume-negligible' ? x['unknownRT'] : d.unknownRT;
  if (x['unknownRT'] !== undefined && unknownRT !== x['unknownRT']) errors.push('settings.unknownRT: expected "assume-negligible" or "block"');
  // (Reduction IDs: "106" of earlier versions is "R106")
  const disabled = [...new Set((stringArray(x['disabledRows'], 'settings.disabledRows', errors) ?? d.disabledRows).map(canonicalRowId))];
  // (settings.maxHopsLB, the length limit of lower-bound derivations of earlier versions, is ignored: there is none.)
  return {
    maxDepthUB: intInRange(x['maxDepthUB'], 0, 12, d.maxDepthUB, 'settings.maxDepthUB', errors),
    gridPoints: intInRange(x['gridPoints'], 2, 41, d.gridPoints, 'settings.gridPoints', errors),
    refineRounds: intInRange(x['refineRounds'], 0, 40, d.refineRounds, 'settings.refineRounds', errors),
    unknownRT,
    useRandomized: typeof x['useRandomized'] === 'boolean' ? x['useRandomized'] : d.useRandomized,
    disabledRows: disabled,
  };
}

/**
 * The scenario a first visit (or "Restore initial settings") starts with: every knob of `config.initialKnobs`, switched
 * on or off as its group says, noted with the group's label unless it has its own note; constants at their defaults.
 */
export function initialScenario(config: EngineConfig): Scenario {
  // Knob ids are the Bound IDs of exported bounds CSVs: the config's, else the next free ones of their kind.
  const specs = config.initialKnobs.flatMap((group) => group.knobs.map((spec) => ({ group, spec })));
  const next = boundIds(specs.flatMap(({ spec }) => (spec.id !== undefined ? [spec.id] : [])));
  const knobs: Knob[] = specs.map(({ group, spec }) => {
    const { id, ...rest } = spec;
    return { ...rest, id: id ?? next(spec.kind), enabled: group.enabled, note: spec.note ?? group.label };
  });
  return { version: 1, constants: {}, knobs, problems: [], settings: DEFAULT_SETTINGS };
}

/**
 * Validate a scenario (parsed JSON). Never throws. Bound IDs are put in canonical form (canonicalBoundId: the bare
 * numbers of earlier versions become L…/U… IDs); knobs without one, with one an earlier knob has, or with a number that
 * had no place among the earlier initial knobs get the next free ID of their kind (after those of `reserved` too).
 */
export function validateScenario(json: Json, reserved: Iterable<string> = []): Validated<Scenario> {
  const errors: string[] = [];
  if (!isObject(json)) {
    return { value: { version: 1, constants: {}, knobs: [], problems: [], settings: DEFAULT_SETTINGS }, errors: ['scenario: expected a JSON object'] };
  }
  if (json['version'] !== 1) errors.push('scenario.version: expected 1');
  const constants: Record<string, number> = {};
  const c = json['constants'];
  if (c !== undefined) {
    if (!isObject(c)) errors.push('scenario.constants: expected an object');
    else {
      for (const [k, v] of Object.entries(c)) {
        if (isFiniteNumber(v)) constants[k] = v;
        else errors.push(`scenario.constants.${k}: expected a number`);
      }
    }
  }
  const read: { spec: KnobSpec; id: string | undefined; enabled: boolean }[] = [];
  const ids = new Set<string>();
  const ks = json['knobs'];
  if (ks !== undefined && !Array.isArray(ks)) errors.push('scenario.knobs: expected an array');
  (Array.isArray(ks) ? ks : []).forEach((x, i) => {
    const path = `scenario.knobs[${i}]`;
    const spec = validateKnobSpec(x, path, errors);
    if (spec === null || !isObject(x)) return;
    read.push({ spec, id: uniqueKnobId(x, spec.kind, path, ids, errors), enabled: x['enabled'] !== false });
  });
  const next = boundIds([...ids, ...reserved]);
  const knobs: Knob[] = read.map(({ spec, id, enabled }) => ({ ...spec, id: id ?? next(spec.kind), enabled }));
  // Box order (missing in data saved before boxes existed: then the knobs' order decides).
  const problems = [...new Set((stringArray(json['problems'], 'scenario.problems', errors) ?? []).map((p) => p.trim()).filter((p) => p !== ''))];
  const settings = validateSettings(json['settings'], errors);
  return { value: { version: 1, constants, knobs, problems, settings }, errors };
}
