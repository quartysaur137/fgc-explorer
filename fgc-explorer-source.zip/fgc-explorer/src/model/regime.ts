/**
 * Regimes (SPEC §2.3, §3.4, §6.7): growth assignments to a problem's parameters, normalized so that they can be compared.
 */

import * as G from '../growth/growth';
import { EvalError, Growth, Rate } from '../growth/growth';
import { identifierTex } from '../math/ast';
import { assert } from '../util/assert';
import { clipToLimits, ParamConstraint } from './constraints';

// ---------------------------------------------------------------------------------------------------------------------
// Regime specifications ("n=1, m=2, M=poly, k=const:[3,4]")
// ---------------------------------------------------------------------------------------------------------------------

/** The growth of one parameter as written in a regime spec. */
export type ParamSpec =
  | { readonly kind: 'poly'; readonly exp: number }
  | { readonly kind: 'log'; readonly coef: number }
  | { readonly kind: 'polylog' }
  /** Sub-polynomial, N^{o(1)}, not known to be polylogarithmic (e.g. 2^{√log N}). */
  | { readonly kind: 'subpoly' }
  | { readonly kind: 'const'; readonly values: ReadonlyArray<number | null> }
  /** For log-dependent parameters: polynomial (evaluated at N^{LOGDEP_EXPONENT}). */
  | { readonly kind: 'logdep' };

export class SpecError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SpecError';
  }
}

/**
 * Representative exponent at which polynomial log-dependent parameters (e.g. M = N^{O(1)}) are evaluated, relative to
 * the normalizer. It is the same for every regime, so that regimes with equal keys are equal (SPEC §2.6).
 */
export const LOGDEP_EXPONENT = 3;

function parseNumber(s: string): number {
  const t = s.trim();
  const frac = /^(-?\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/.exec(t);
  if (frac) {
    const v = Number(frac[1]) / Number(frac[2]);
    if (Number.isFinite(v)) return v;
  }
  if (/^-?\d+(?:\.\d+)?$|^-?\.\d+$/.test(t)) return Number(t);
  throw new SpecError(`not a number: "${s}"`);
}

/**
 * Parse one parameter growth spec (SPEC §3.4 grammar).
 * @throws SpecError on malformed input.
 */
export function parseParamSpec(text: string): ParamSpec {
  const s = text.trim();
  const [head, arg] = splitOnce(s, ':');
  switch (head.trim()) {
    case 'log':
      return { kind: 'log', coef: arg === null ? 1 : positive(parseNumber(arg), 'log coefficient') };
    case 'polylog':
    case 'sub': // (an old name of polylog)
      if (arg !== null) throw new SpecError(`"${head}" takes no argument`);
      return { kind: 'polylog' };
    case 'subpoly':
      if (arg !== null) throw new SpecError(`"${head}" takes no argument`);
      return { kind: 'subpoly' };
    case 'const': {
      if (arg === null || arg.trim() === '?' || arg.trim() === '') return { kind: 'const', values: [null] };
      const a = arg.trim();
      if (a.startsWith('[')) {
        if (!a.endsWith(']')) throw new SpecError(`unterminated list in "${s}"`);
        const items = a
          .slice(1, -1)
          .split(',')
          .map((x) => x.trim())
          .filter((x) => x !== '');
        if (items.length === 0) throw new SpecError(`empty list in "${s}"`);
        return { kind: 'const', values: items.map((x) => (x === '?' ? null : parseNumber(x))) };
      }
      return { kind: 'const', values: [parseNumber(a)] };
    }
    case 'poly':
      if (arg !== null) throw new SpecError(`"poly" takes no argument (polynomial log-dependent parameters are evaluated at N^${LOGDEP_EXPONENT})`);
      return { kind: 'logdep' };
    default:
      if (arg !== null) throw new SpecError(`unknown growth "${s}"`);
      return { kind: 'poly', exp: positive(parseNumber(s), 'exponent') };
  }
}

function positive(x: number, what: string): number {
  if (!(x > 0)) throw new SpecError(`${what} must be positive, got ${x}`);
  return x;
}

function splitOnce(s: string, sep: string): [string, string | null] {
  const i = s.indexOf(sep);
  return i < 0 ? [s, null] : [s.slice(0, i), s.slice(i + 1)];
}

/**
 * Parse a regime spec "p1=g1, p2=g2, ..." (commas inside [...] do not split).
 * @returns map from parameter name to spec, in written order.
 * @throws SpecError on malformed input or a repeated parameter.
 */
export function parseRegimeSpec(spec: string): Map<string, ParamSpec> {
  const out = new Map<string, ParamSpec>();
  for (const part of splitTopLevel(spec)) {
    if (part.trim() === '') continue;
    const [name, value] = splitOnce(part, '=');
    if (value === null) throw new SpecError(`expected "param=growth", got "${part.trim()}"`);
    const key = name.trim();
    if (key === '') throw new SpecError(`missing parameter name in "${part.trim()}"`);
    if (out.has(key)) throw new SpecError(`parameter ${key} given twice`);
    out.set(key, parseParamSpec(value));
  }
  return out;
}

function splitTopLevel(s: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let cur = '';
  for (const ch of s) {
    if (ch === '[') depth += 1;
    if (ch === ']') depth -= 1;
    if (ch === ',' && depth === 0) {
      parts.push(cur);
      cur = '';
    } else cur += ch;
  }
  parts.push(cur);
  return parts;
}

/** The fraction p/q with the smallest q ≤ 100 for which `ok(p/q)` holds (p near x·q), or null. */
function simpleFraction(x: number, ok: (v: number) => boolean): string | null {
  for (let q = 1; q <= 100; q++) {
    for (const p of [Math.floor(x * q), Math.ceil(x * q)]) {
      if (ok(p / q)) return q === 1 ? String(p) : `${p}/${q}`;
    }
  }
  return null;
}

/** Text for a number in a spec that reads back exactly: a short decimal, a simple fraction (1/3), else every digit. */
function exactNumber(x: number): string {
  const short = G.formatNumber(x, 3);
  if (Number(short) === x) return short;
  return simpleFraction(x, (v) => Math.abs(v - x) <= 1e-12) ?? G.plainNumber(x);
}

/**
 * Text for an exponent or constant of a regime (stored rounded up to 6 decimals, see roundSizeUp) such that the spec
 * names that regime again: a short decimal when exact, else the simplest fraction that rounds up to it (2.142858 is
 * written 15/7), else its 6 decimals.
 */
export function regimeNumberText(v: number): string {
  const short = G.formatNumber(v, 3);
  if (Number(short) === v) return short;
  return simpleFraction(v, (x) => roundSizeUp(x) === v) ?? G.formatNumber(v, 6);
}

/**
 * A regime spec written by an earlier version, whose exponents were rounded to the nearest 6 decimals (e.g. 2.142857
 * for 15/7), with each number of 5 or 6 decimals within 5e-7 of a simple fraction (denominator ≤ 100) written as that
 * fraction, so that it names the regime of the exact value again (regimes now round sizes up: 15/7 is stored as
 * 2.142858). Other text is unchanged.
 */
export function upgradeRoundedSpec(spec: string): string {
  return spec.replace(/(^|[=:\[,\s])(\d+\.\d{5,6})(?=$|[,\]\s])/g, (all, before: string, num: string) => {
    const x = Number(num);
    const f = simpleFraction(x, (v) => Math.abs(v - x) <= 5e-7);
    return f === null || f.indexOf('/') < 0 ? all : `${before}${f}`;
  });
}

/** Inverse of parseParamSpec (canonical text, read back exactly: 1/3 is written 1/3). */
export function formatParamSpec(p: ParamSpec): string {
  switch (p.kind) {
    case 'poly':
      return exactNumber(p.exp);
    case 'log':
      return p.coef === 1 ? 'log' : `log:${exactNumber(p.coef)}`;
    case 'polylog':
      return 'polylog';
    case 'subpoly':
      return 'subpoly';
    case 'const': {
      const f = (x: number | null): string => (x === null ? '?' : exactNumber(x));
      if (p.values.length === 1) return p.values[0] === null ? 'const' : `const:${f(p.values[0]!)}`;
      return `const:[${p.values.map(f).join(',')}]`;
    }
    case 'logdep':
      return 'poly';
  }
}

/** Canonical text of a regime spec map. */
export function formatRegimeSpec(spec: ReadonlyMap<string, ParamSpec>): string {
  return [...spec].map(([k, p]) => `${k}=${formatParamSpec(p)}`).join(', ');
}

/** The growth classes a parameter spec stands for (several for a const list). */
export function specGrowths(p: ParamSpec): Growth[] {
  switch (p.kind) {
    case 'poly':
      return [G.poly(p.exp)];
    case 'log':
      return [G.logClass(1, p.coef)];
    case 'polylog':
      return [G.logClass(Infinity)];
    case 'subpoly':
      return [G.SUBPOLY];
    case 'const':
      return p.values.map((v) => G.constant(v));
    case 'logdep':
      return [G.poly(LOGDEP_EXPONENT)];
  }
}

// ---------------------------------------------------------------------------------------------------------------------
// Normalized regimes
// ---------------------------------------------------------------------------------------------------------------------

const KEY_DECIMALS = 6;

/**
 * `x` rounded up to KEY_DECIMALS decimals, after rounding off floating-point noise (to 9 decimals, so that 0.5 stays 0.5
 * whether it was computed as 0.4999999999 or 0.5000000001). Rounding up keeps derivations sound (SPEC §2.3): the regime
 * stands for sizes at least as large as the exact ones, so a lower bound derived at the exact sizes holds there, and an
 * upper bound taken there holds at the exact sizes (time bounds are nondecreasing in the sizes). Rounding to the nearest
 * value would make both off by up to about 5e-7 times the exponents involved: enough to report a tight pair of bounds
 * as a conflict.
 */
export function roundSizeUp(x: number): number {
  const units = Math.round(x * 1e9);
  const step = 10 ** (9 - KEY_DECIMALS);
  return (Math.ceil(units / step) * step) / 1e9;
}

/** Result of normalizing the parameter growths of a (produced) instance. */
export type Normalization =
  | { readonly kind: 'ok'; readonly regime: Regime; readonly scale: number }
  | { readonly kind: 'degenerate' };

/**
 * A normalized regime of a problem.
 *
 * AF: the set of instances of a problem whose parameter params[i] grows like growths[i] as functions of the scale N,
 *     where N = params[normalizer] (or N = 2^{params[normalizer]} if expScale).
 * RI: params.length === growths.length; params distinct; normalizer is an index of a non-log-dependent parameter;
 *     if !expScale: growths[normalizer] = poly(1), else growths[normalizer] = log(1, 1); no growth is polyUnknown or
 *     super except log-dependent ones being polyUnknown; a sub-polynomial growth that is not of rate zero (qpoly) is
 *     SUBPOLY; key === computeKey().
 * SRE: all fields are readonly; arrays are frozen copies.
 */
export class Regime {
  readonly params: readonly string[];
  readonly growths: readonly Growth[];
  readonly logDep: ReadonlySet<string>;
  readonly normalizer: number;
  readonly expScale: boolean;
  readonly key: string;

  private constructor(params: readonly string[], growths: readonly Growth[], logDep: ReadonlySet<string>, normalizer: number, expScale: boolean) {
    this.params = Object.freeze([...params]);
    this.growths = Object.freeze([...growths]);
    this.logDep = new Set(logDep);
    this.normalizer = normalizer;
    this.expScale = expScale;
    this.key = this.computeKey();
    this.checkRep();
  }

  private checkRep(): void {
    assert(this.params.length === this.growths.length, 'params/growths length mismatch');
    assert(new Set(this.params).size === this.params.length, 'duplicate parameter');
    const g = this.growths[this.normalizer];
    assert(g !== undefined && !this.logDep.has(this.params[this.normalizer]!), 'bad normalizer');
    if (this.expScale) assert(g.kind === 'log' && g.pow === 1 && g.coef !== null && Math.abs(g.coef - 1) < 1e-9, 'exp-scale normalizer must be log2 N');
    else assert(g.kind === 'poly' && Math.abs(g.exp - 1) < 1e-9, 'normalizer must be N');
    this.growths.forEach((x, i) => {
      if (x.kind === 'super' || (x.kind === 'polyUnknown' && !this.logDep.has(this.params[i]!)) || (x.kind === 'qpoly' && x !== G.SUBPOLY)) {
        assert(false, `invalid growth for ${this.params[i]}`);
      }
    });
  }

  /**
   * Normalize raw parameter growths (SPEC §2.3). Sizes below 1 (negative exponents) are clamped to constants;
   * sub-polynomial sizes that are not polylogarithmic (2^{c·L^a}, a < 1, or N^{o(1)}) become N^{o(1)}, and are
   * polylogarithmic for log-dependent parameters. Then every parameter is clipped to the problem's limits (SPEC §2.3,
   * e.g. m ≤ n²: the same instances), before the normalizer is chosen.
   * @param constraints the problem's limits (none by default)
   * @throws EvalError if a non-log-dependent parameter has an unknown polynomial or a superpolynomial growth, or a
   *         log-dependent one is superpolynomial.
   */
  static normalize(params: readonly string[], growths: readonly Growth[], logDep: ReadonlySet<string>, constraints: readonly ParamConstraint[] = []): Normalization {
    assert(params.length === growths.length, 'params/growths length mismatch');
    const nonnegative = growths.map((g) => (g.kind === 'poly' && g.exp < 0 ? G.constant(null) : g.kind === 'const' && g.value !== null && g.value < 1 ? G.constant(null) : g));
    nonnegative.forEach((g, i) => {
      const p = params[i]!;
      if (g.kind === 'super' || (g.kind === 'qpoly' && g.pow > 1)) throw new EvalError(`parameter ${p} would be superpolynomial`);
      if (g.kind === 'polyUnknown' && !logDep.has(p)) throw new EvalError(`parameter ${p} is N^{O(1)} with an unknown exponent`);
      if (g.kind === 'log' && g.coef !== null && g.coef < 0) throw new EvalError(`parameter ${p} would be negative`);
    });
    const clamped = clipToLimits(params, nonnegative, constraints);
    let normalizer = clamped.findIndex((g, i) => !logDep.has(params[i]!) && g.kind === 'poly' && g.exp > 0);
    let expScale = false;
    let scale: number;
    if (normalizer >= 0) {
      scale = (clamped[normalizer] as { exp: number }).exp;
    } else {
      normalizer = clamped.findIndex((g, i) => !logDep.has(params[i]!) && g.kind === 'log' && g.pow === 1 && g.coef !== null && g.coef > 0);
      if (normalizer < 0) return { kind: 'degenerate' };
      expScale = true;
      scale = (clamped[normalizer] as { coef: number }).coef;
    }
    // The growths are rounded as the key is (KEY_DECIMALS), so that regimes with one key are equal: otherwise which of
    // them a key stands for (and what follows from it) would depend on the order of the search. They are rounded up
    // (see roundSizeUp).
    const round = roundSizeUp;
    const normalized = clamped.map((g, i) => {
      // Every key code stands for one growth (class L: every polylogarithmic size is the largest of them, (log N)^{O(1)},
      // which contains all the others; class S: N^{o(1)}).
      if (logDep.has(params[i]!)) {
        if (g.kind === 'poly' || g.kind === 'polyUnknown') return G.poly(LOGDEP_EXPONENT);
        if (g.kind === 'const') return G.constant(null);
        return G.POLYLOG; // (log or qpoly: the logarithm of a sub-polynomial size is polylogarithmic)
      }
      if (g.kind === 'qpoly') return G.SUBPOLY;
      if (g.kind === 'poly') return G.poly(i === normalizer && !expScale ? 1 : round(g.exp / scale));
      if (g.kind === 'const' && g.value !== null) return G.constant(round(g.value));
      if (i === normalizer) return G.logClass(1, 1);
      if (g.kind === 'log') return G.POLYLOG;
      return g;
    });
    return { kind: 'ok', regime: new Regime(params, normalized, logDep, normalizer, expScale), scale };
  }

  /**
   * Build a regime from one growth per parameter (clipped to the problem's limits, see normalize).
   * @throws SpecError if a parameter has no growth or no parameter grows, or if the limits clip the parameter that
   *         measures the regime (then exponents given with the spec, e.g. a knob's, would be read against another
   *         scale); EvalError as for normalize().
   */
  static fromGrowthMap(params: readonly string[], values: ReadonlyMap<string, Growth>, logDep: ReadonlySet<string>, constraints: readonly ParamConstraint[] = []): Regime {
    const growths = params.map((p) => {
      const g = values.get(p);
      if (g === undefined) throw new SpecError(`no growth given for parameter ${p}`);
      return g;
    });
    const n = Regime.normalize(params, growths, logDep, constraints);
    if (constraints.length > 0) {
      const raw = Regime.normalize(params, growths, logDep);
      if (raw.kind === 'ok' && (n.kind === 'degenerate' || n.regime.normalizer !== raw.regime.normalizer || Math.abs(n.scale - raw.scale) > 1e-12)) {
        const limits = constraints.map((c) => c.text).join(', ');
        throw new SpecError(`no instances grow like this: by the limits of the parameters (${limits}), ${raw.regime.normalizerName} cannot grow so fast`);
      }
    }
    if (n.kind === 'degenerate') throw new SpecError('the regime has no growing parameter (all constant or polylogarithmic)');
    return n.regime;
  }

  private computeKey(): string {
    return this.params
      .map((p, i) => {
        const g = this.growths[i]!;
        let code: string;
        if (this.logDep.has(p)) {
          code = g.kind === 'const' ? 'C' : g.kind === 'log' ? 'L' : g.kind === 'super' ? 'X' : 'P';
        } else if (g.kind === 'qpoly') {
          code = 'S';
        } else if (i === this.normalizer && this.expScale) {
          code = 'E';
        } else {
          switch (g.kind) {
            case 'poly':
              code = `p${G.formatNumber(g.exp, KEY_DECIMALS)}`;
              break;
            case 'log':
              code = 'L';
              break;
            case 'const':
              code = g.value === null ? 'c?' : `c${G.formatNumber(g.value, KEY_DECIMALS)}`;
              break;
            default:
              code = 'X';
          }
        }
        return `${p}=${code}`;
      })
      .join('|');
  }

  /** Growth of parameter `p`, or undefined if `p` is not a parameter. */
  growthOf(p: string): Growth | undefined {
    const i = this.params.indexOf(p);
    return i < 0 ? undefined : this.growths[i];
  }

  /** Name of the normalizer parameter. */
  get normalizerName(): string {
    return this.params[this.normalizer]!;
  }

  /** Environment binding each parameter to its growth. */
  env(): Map<string, Growth> {
    return new Map(this.params.map((p, i) => [p, this.growths[i]!]));
  }

  /**
   * True iff, for every parameter mentioned in `req`, this regime's growth is in the spec's class (SPEC §3.3 `requires`
   * and knob regime filters). Polynomial exponents are compared with tolerance 2e-6 (they are rounded up to 6
   * decimals); `log`, `polylog` and `subpoly` are upper bounds, so constants satisfy them.
   */
  satisfies(req: ReadonlyMap<string, ParamSpec>): boolean {
    for (const [p, spec] of req) {
      const g = this.growthOf(p);
      if (g === undefined) return false;
      if (!growthInSpec(g, spec, this.logDep.has(p))) return false;
    }
    return true;
  }

  /**
   * Whether the regime satisfies `req` (see satisfies), also where `req` names polynomial sizes beyond the problem's
   * limits that clip to this regime's (SPEC §2.3): the regime with those sizes, clipped, is this one, the same
   * instances. For the regime filters of formula knobs (a filter α = n matches m = n^{1.5}, α = n^{0.75}).
   */
  satisfiesClipped(req: ReadonlyMap<string, ParamSpec>, constraints: readonly ParamConstraint[]): boolean {
    if (this.satisfies(req)) return true;
    if (constraints.length === 0) return false;
    let substituted = false;
    const growths = this.params.map((p, i) => {
      const spec = req.get(p);
      if (spec === undefined || spec.kind !== 'poly' || this.logDep.has(p) || i === this.normalizer) return this.growths[i]!;
      substituted = true;
      return G.poly(spec.exp);
    });
    if (!substituted) return false;
    for (const [p, spec] of req) {
      if (spec.kind === 'poly' && !this.logDep.has(p) && this.params.indexOf(p) !== this.normalizer) continue;
      if (!this.satisfies(new Map([[p, spec]]))) return false;
    }
    const n = Regime.normalize(this.params, growths, this.logDep, constraints);
    return n.kind === 'ok' && n.regime.key === this.key;
  }

  /** LaTeX description, e.g. "m = n^{2},\ M = n^{O(1)}" (the normalizer is the reference). */
  describeTex(): string {
    const ref = identifierTex(this.normalizerName);
    const parts: string[] = [];
    this.params.forEach((p, i) => {
      if (i === this.normalizer) {
        if (this.expScale) parts.push(`N = 2^{${ref}}`);
        return;
      }
      parts.push(`${identifierTex(p)} = ${growthTex(this.growths[i]!, ref, this.expScale, this.logDep.has(p))}`);
    });
    return parts.length === 0 ? `${ref}` : parts.join(',\\ ');
  }

  /**
   * LaTeX for a running time of rate `r` at this regime, e.g. "n^{2.5}", "2^{0.5n}", "2^{0.5 n^{0.75}}" (with the
   * exponential scale N = 2^n) or "2^{\\log^{2} n}" (power 2 at a polynomial scale); exponent 0 is o(·), the rate zero
   * polylog(n) (poly(n) for exponential scales).
   */
  timeTex(r: Rate, decimals = 4): string {
    const ref = identifierTex(this.normalizerName);
    if (r.power === 0) return this.expScale ? `\\text{poly}(${ref})` : `\\text{polylog}(${ref})`;
    if (!Number.isFinite(r.power)) return '\\infty';
    const e = G.formatNumber(r.exponent, decimals);
    if (G.samePower(r.power, 1)) {
      if (!Number.isFinite(r.exponent)) return '\\infty';
      if (!this.expScale) return e === '0' ? `${ref}^{o(1)}` : `${ref}^{${e}}`;
      return e === '1' ? `2^{${ref}}` : e === '0' ? `2^{o(${ref})}` : `2^{${e}${ref}}`;
    }
    const a = G.formatNumber(r.power, decimals);
    const inner = this.expScale ? `${ref}^{${a}}` : `\\log^{${a}} ${ref}`;
    if (!Number.isFinite(r.exponent)) return `2^{\\omega(${inner})}`;
    if (e === '0') return `2^{o(${inner})}`;
    return e === '1' ? `2^{${inner}}` : `2^{${e}\\,${inner}}`;
  }

  /**
   * A formula for a running time of rate `r` at this regime, with its numbers exactly as stored, that evaluates to that
   * rate again: e.g. "n^{2.5}", "2^{0.5 n}", "2^{0.5 n^{0.75}}", "2^{2 \log^{0.5} n}"; exponent 0 as o(·)
   * ("n^{o(1)}", "2^{o(n)}").
   * @returns null for the rate zero and for a rate without bound
   */
  timeFormula(r: Rate): string | null {
    if (r.power === 0 || !G.finiteRate(r)) return null;
    const n = identifierTex(this.normalizerName);
    const num = G.plainNumber;
    const powerOne = G.samePower(r.power, 1);
    if (powerOne && !this.expScale) return r.exponent === 0 ? `${n}^{o(1)}` : `${n}^{${num(r.exponent)}}`;
    const inner = powerOne ? n : this.expScale ? `${n}^{${num(r.power)}}` : `\\log^{${num(r.power)}} ${n}`;
    if (r.exponent === 0) return `2^{o(${inner})}`;
    return r.exponent === 1 ? `2^{${inner}}` : `2^{${num(r.exponent)} ${inner}}`;
  }

  /**
   * Plain text for a running time of rate `r` at this regime (as timeTex), e.g. "n^2.5", "2^(0.5n)", "2^(0.5n^0.75)",
   * "2^(log^2 n)", "n^o(1)", "polylog(n)".
   * @param name how to write the normalizer (default: its identifier)
   */
  timeText(r: Rate, decimals = 4, name: string = this.normalizerName): string {
    const n = name;
    if (r.power === 0) return this.expScale ? `poly(${n})` : `polylog(${n})`;
    if (!Number.isFinite(r.power)) return '∞';
    const e = G.formatNumber(r.exponent, decimals);
    if (G.samePower(r.power, 1)) {
      if (!Number.isFinite(r.exponent)) return '∞';
      if (!this.expScale) return e === '0' ? `${n}^o(1)` : `${n}^${e}`;
      return e === '1' ? `2^${n}` : e === '0' ? `2^o(${n})` : `2^(${e}${n})`;
    }
    const a = G.formatNumber(r.power, decimals);
    const inner = this.expScale ? `${n}^${a}` : `log^${a} ${n}`;
    if (!Number.isFinite(r.exponent)) return `2^ω(${inner})`;
    if (e === '0') return `2^o(${inner})`;
    return e === '1' ? `2^(${inner})` : `2^(${e}${this.expScale ? '' : ' '}${inner})`;
  }
}

function growthInSpec(g: Growth, spec: ParamSpec, logDep: boolean): boolean {
  switch (spec.kind) {
    case 'poly':
      if (logDep) return g.kind === 'poly' || g.kind === 'polyUnknown';
      // (regimes round exponents up to 6 decimals: e.g. 1/3 becomes 0.333334, which "0.333333" should still match)
      return g.kind === 'poly' && Math.abs(g.exp - spec.exp) < 2e-6;
    case 'log':
    case 'polylog':
      // At most polylogarithmic: constants too (an algorithm for polylogarithmic weights works for constant ones).
      return g.kind === 'log' || g.kind === 'const';
    case 'subpoly':
      // (a polylogarithmic or constant parameter is N^{o(1)} too)
      return g.kind === 'log' || g.kind === 'const' || (!logDep && g.kind === 'qpoly');
    case 'const':
      return g.kind === 'const' && spec.values.some((v) => v === null || (g.value !== null && Math.abs(g.value - v) < 2e-6));
    case 'logdep':
      return g.kind === 'poly' || g.kind === 'polyUnknown';
  }
}

/** LaTeX for the growth of a parameter relative to the normalizer `ref`. */
function growthTex(g: Growth, ref: string, expScale: boolean, logDep: boolean): string {
  if (logDep) {
    if (g.kind === 'const') return 'O(1)';
    if (g.kind === 'log') return expScale ? `\\text{poly}(${ref})` : `\\text{polylog}(${ref})`;
    return expScale ? `2^{O(${ref})}` : `${ref}^{O(1)}`;
  }
  switch (g.kind) {
    case 'const':
      return g.value === null ? 'O(1)' : G.formatNumber(g.value, 3);
    case 'log':
      if (expScale) return g.pow === 1 ? `\\Theta(${ref})` : `\\text{poly}(${ref})`;
      if (g.pow === 1) return `\\Theta(\\log ${ref})`;
      if (g.pow === 0) return `(\\log ${ref})^{o(1)}`;
      return `\\text{polylog}(${ref})`;
    case 'poly':
      if (expScale) return `2^{${G.formatNumber(g.exp, 3)}${ref}}`;
      return Math.abs(g.exp - 1) < 1e-9 ? ref : `${ref}^{${G.formatNumber(g.exp, 3)}}`;
    case 'qpoly':
      return expScale ? `2^{o(${ref})}` : `${ref}^{o(1)}`;
    case 'polyUnknown':
      return `${ref}^{O(1)}`;
    case 'super':
      return '\\infty';
  }
}
