/**
 * The bounds CSV (SPEC §3.5): hypotheses (lower bounds) and algorithms (upper bounds) kept in a spreadsheet, read into
 * scenario knobs and written back. Like the reductions sheet, columns are found by header name (any order; extra columns
 * are ignored). Reading never throws: every problem is reported for its row, and rows with errors are skipped.
 *
 * One row per bound; the problems' order (the left panel's boxes) is the order in which they first appear, and a row
 * with neither "Upper or Lower" nor "Runtime" lists a problem without a bound (an empty box). Files are written box by
 * box.
 */

import { plainNumber } from '../growth/growth';
import { primaryFormula } from '../math/cells';
import { ParseError, parseExpr } from '../math/parser';
import { CsvTable, serializeCsv } from '../util/csv';
import { canonicalProblem, problemBoxes } from './boxes';
import { boundIds, canonicalBoundId, Knob, KnobKind, KnobSpec, validateKnobSpec } from './config';
import { findProblem, Model, Problem, problemIdOf } from './model';
import { parseRegimeSpec, SpecError } from './regime';

export const BOUNDS_COL = {
  family: 'Problem',
  variation: 'Variation',
  id: 'Bound ID',
  kind: 'Upper or Lower',
  runtime: 'Runtime',
  power: 'Power',
  regime: 'Regime',
  enabled: 'Enabled',
  note: 'Note',
} as const;

export const BOUNDS_REQUIRED_COLUMNS: readonly string[] = [BOUNDS_COL.family, BOUNDS_COL.variation, BOUNDS_COL.id, BOUNDS_COL.kind, BOUNDS_COL.runtime];

/** Column order of written files (Power only when a knob has one other than 1). */
const BOUNDS_COLUMNS: readonly string[] = [...BOUNDS_REQUIRED_COLUMNS, BOUNDS_COL.regime, BOUNDS_COL.enabled, BOUNDS_COL.note];
const BOUNDS_COLUMNS_WITH_POWER: readonly string[] = [...BOUNDS_REQUIRED_COLUMNS, BOUNDS_COL.power, BOUNDS_COL.regime, BOUNDS_COL.enabled, BOUNDS_COL.note];

export interface BoundsIssue {
  /** Line of the file (the header is line 1). */
  readonly line: number;
  readonly level: 'error' | 'warning';
  readonly message: string;
}

export interface BoundsImport {
  /**
   * Knobs read from rows without errors, in file order (ids are the Bound IDs in canonical form; blank or repeated
   * ones, and numbers of earlier versions that no initial bound had, get new ones of their kind).
   */
  readonly knobs: readonly Knob[];
  /**
   * The problems of the rows read (with or without a bound), in the order they first appear: the boxes of the left
   * panel. Ids as the model knows them, else "Problem / Variation" as written.
   */
  readonly problems: readonly string[];
  /** Errors (the row was skipped) and warnings (the row was read), in file order. */
  readonly issues: readonly BoundsIssue[];
  /** Required columns that are missing (then no row is read). */
  readonly missingColumns: readonly string[];
}

const squash = (s: string): string => s.replace(/\s+/g, ' ').trim();

/** "Upper"/"Lower" and common synonyms; null if unrecognized. */
export function parseBoundKind(cell: string): KnobKind | null {
  const t = cell.trim().toLowerCase();
  if (['upper', 'u', 'ub', 'upper bound', 'algorithm'].includes(t)) return 'UB';
  if (['lower', 'l', 'lb', 'lower bound', 'hypothesis'].includes(t)) return 'LB';
  return null;
}

/** yes/no-like cell; `fallback` when empty, null when unrecognized. */
function parseYesNo(cell: string, fallback: boolean): boolean | null {
  const t = cell.trim().toLowerCase();
  if (t === '') return fallback;
  if (['yes', 'y', 'true', '1', 'on'].includes(t)) return true;
  if (['no', 'n', 'false', '0', 'off'].includes(t)) return false;
  return null;
}

/** `\Omega(X)` or `\tilde{\Omega}(X)` around a whole formula → X (lower bounds are often written that way). */
export function unwrapOmega(tex: string): string {
  const m = /^\\(?:tilde\{\\Omega\}|widetilde\{\\Omega\}|Omega)\s*(\\left)?\(/.exec(tex);
  if (!m) return tex;
  let depth = 0;
  for (let i = m[0].length - 1; i < tex.length; i++) {
    if (tex[i] === '(') depth += 1;
    else if (tex[i] === ')') {
      depth -= 1;
      if (depth === 0) {
        const rest = tex.slice(i + 1).trim();
        const inner = tex.slice(m[0].length, m[1] ? i - '\\right'.length : i);
        return rest === '' ? inner.trim() : tex;
      }
    }
  }
  return tex;
}

const NUMBER = /^[+-]?(\d+(\.\d*)?|\.\d+)$/;

/** The problem a row names (case-insensitive; the config's family aliases apply, also case-insensitively), or null. */
function lookUp(model: Model | null, family: string, variation: string): Problem | null {
  if (model === null) return null;
  const alias = Object.entries(model.config.aliases).find(([from]) => squash(from).toLowerCase() === family.toLowerCase());
  const fam = alias ? alias[1] : family;
  return findProblem(model, problemIdOf(fam, variation)) ?? findProblem(model, problemIdOf(family, variation)) ?? null;
}

/**
 * Read a bounds CSV.
 * @param model the current model, used to recognize problems and to fill in their main regime; null: no checks
 * @param reserved ids that new numbers must avoid besides the file's own (e.g. the current knobs', when adding to them)
 */
export function readBoundsCsv(text: string, model: Model | null, reserved: Iterable<string> = []): BoundsImport {
  const { table, warnings } = CsvTable.fromText(text);
  const issues: BoundsIssue[] = warnings.map((w) => ({ line: 0, level: 'warning' as const, message: `CSV: ${w}` }));
  const missingColumns = BOUNDS_REQUIRED_COLUMNS.filter((c) => !table.hasColumn(c));
  if (missingColumns.length > 0) return { knobs: [], problems: [], issues, missingColumns };

  const knobs: Knob[] = [];
  const problems = new Set<string>();
  const ids = new Set<string>();
  // The Bound IDs as written and in canonical form (null: a number of an earlier version without a place now). Blank,
  // repeated and such IDs get new ones of their kind after every one in the file (and in `reserved`).
  const given = Array.from({ length: table.rowCount }, (_, i) => {
    const raw = table.get(i, BOUNDS_COL.id).trim();
    const kind = parseBoundKind(table.get(i, BOUNDS_COL.kind));
    return { raw, id: raw === '' || kind === null ? raw : canonicalBoundId(raw, kind) };
  });
  const nextId = boundIds([...given.flatMap((g) => (g.id ? [g.id] : [])), ...reserved]);
  for (let i = 0; i < table.rowCount; i++) {
    const line = i + 2;
    const get = (c: string): string => table.get(i, c);
    const rowIssues: BoundsIssue[] = [];
    const error = (message: string): void => void rowIssues.push({ line, level: 'error', message });
    const warn = (message: string): void => void rowIssues.push({ line, level: 'warning', message });

    const family = squash(get(BOUNDS_COL.family));
    const variation = squash(get(BOUNDS_COL.variation));
    const problem = lookUp(model, family, variation);
    const problemId = problem?.id ?? problemIdOf(family, variation);
    const unknownProblem = (): void => {
      if (family === '' && variation === '') error('no Problem / Variation');
      else if (model !== null && problem === null) warn(`"${problemId}" is not a problem of the current sheet (the bound stays inactive until it is)`);
    };

    // A row without a bound only lists its problem (a box without bounds).
    if (get(BOUNDS_COL.kind).trim() === '' && get(BOUNDS_COL.runtime).trim() === '') {
      unknownProblem();
      const ignored = [BOUNDS_COL.id, BOUNDS_COL.power, BOUNDS_COL.regime, BOUNDS_COL.enabled, BOUNDS_COL.note].filter((c) => get(c).trim() !== '');
      if (ignored.length > 0) warn(`no "${BOUNDS_COL.kind}" and no "${BOUNDS_COL.runtime}": the row only lists the problem (${ignored.join(', ')} ignored)`);
      if (rowIssues.every((x) => x.level !== 'error')) problems.add(problemId);
      issues.push(...rowIssues);
      continue;
    }

    unknownProblem();

    const kind = parseBoundKind(get(BOUNDS_COL.kind));
    if (kind === null) error(`"${BOUNDS_COL.kind}" must be Upper or Lower (got "${get(BOUNDS_COL.kind).trim()}")`);

    const { raw } = given[i]!;
    let id = given[i]!.id ?? raw;
    if (kind !== null) {
      if (raw === '') {
        id = nextId(kind);
        warn(`no Bound ID; using ${id}`);
      } else if (given[i]!.id === null) {
        id = nextId(kind);
        warn(`Bound ID ${raw} becomes ${id} (Bound IDs have a letter now: L… for lower bounds, U… for upper bounds)`);
      } else if (ids.has(id)) {
        const fresh = nextId(kind);
        warn(`Bound ID ${id} is used by an earlier row; this one becomes ${fresh}`);
        id = fresh;
      }
    }

    // Runtime: a plain number is an exponent of the regime's main parameter, anything else a LaTeX runtime.
    const runtimeCell = get(BOUNDS_COL.runtime);
    const tex = (primaryFormula(runtimeCell) ?? runtimeCell).trim();
    let exponent: number | undefined;
    let formula: string | undefined;
    if (tex === '') error('no Runtime');
    else if (NUMBER.test(tex)) {
      exponent = Number(tex);
      if (exponent < 0 || (kind === 'LB' && exponent === 0)) error(`the exponent must be ${kind === 'LB' ? 'positive' : 'nonnegative'} (got ${tex})`);
    } else {
      formula = kind === 'LB' ? unwrapOmega(tex) : tex;
      try {
        parseExpr(formula);
      } catch (e) {
        error(`Runtime "${tex}": ${e instanceof ParseError ? e.message : String(e)}`);
      }
    }

    // Power (of an exponent c: the running time 2^{c·n^a}); empty: 1.
    let power: number | undefined;
    const powerCell = get(BOUNDS_COL.power).trim();
    if (powerCell !== '') {
      if (!NUMBER.test(powerCell) || !(Number(powerCell) > 0)) error(`"${BOUNDS_COL.power}" must be a positive number (got "${powerCell}")`);
      else if (exponent === undefined) error(`"${BOUNDS_COL.power}" goes with a plain exponent in "${BOUNDS_COL.runtime}" (a formula gives its own power)`);
      else if (Number(powerCell) !== 1) power = Number(powerCell);
    }

    // Regime: given, or the problem's main one (an algorithm given as a formula applies to every regime).
    let regime: string | undefined = squash(get(BOUNDS_COL.regime)) || undefined;
    if (regime !== undefined) {
      try {
        const spec = parseRegimeSpec(regime);
        const unknown = problem ? [...spec.keys()].filter((p) => !problem.params.includes(p)) : [];
        if (unknown.length > 0) error(`regime "${regime}": ${unknown.join(', ')} ${unknown.length === 1 ? 'is not a parameter' : 'are not parameters'} of ${problem!.id}`);
      } catch (e) {
        error(`regime "${regime}": ${e instanceof SpecError ? e.message : String(e)}`);
      }
    } else if (kind === 'LB' || exponent !== undefined) {
      regime = problem?.regimeSpecs[0];
      if (regime === undefined) error(`${kind === 'LB' ? 'a lower bound' : 'an exponent'} needs a Regime (the problem's main regime is unknown)`);
    }

    const enabled = parseYesNo(get(BOUNDS_COL.enabled), true);
    if (enabled === null) warn(`"${BOUNDS_COL.enabled}" should be yes or no (got "${get(BOUNDS_COL.enabled).trim()}"); using yes`);
    const note = squash(get(BOUNDS_COL.note));

    if (rowIssues.every((x) => x.level !== 'error') && kind !== null) {
      const specErrors: string[] = [];
      const spec = validateKnobSpec(
        {
          problem: problemId,
          kind,
          ...(regime !== undefined ? { regime } : {}),
          ...(exponent !== undefined ? { exponent } : { formula }),
          ...(power !== undefined ? { power } : {}),
          ...(note !== '' ? { note } : {}),
        },
        `line ${line}`,
        specErrors,
      );
      if (spec === null) specErrors.forEach((m) => error(m));
      else {
        ids.add(id);
        knobs.push({ ...spec, id, enabled: enabled ?? true });
        problems.add(problemId);
      }
    }
    issues.push(...rowIssues);
  }
  return { knobs, problems: [...problems], issues, missingColumns: [] };
}

/** [family, variation] of a knob's problem (as the model spells them when it knows the problem). */
function splitProblem(model: Model | null, problemId: string): [string, string] {
  const p = model ? findProblem(model, problemId) : undefined;
  if (p) return [p.family, p.variation];
  const i = problemId.indexOf(' / ');
  // (an id without " / " names a problem without a family, see problemIdOf)
  return i < 0 ? ['', problemId] : [problemId.slice(0, i), problemId.slice(i + 3)];
}

/**
 * Write knobs as a bounds CSV, box by box (see problemBoxes; a box without knobs becomes a row with only its problem).
 * CRLF line ends, final one included; formulas in $...$; exponents as plain numbers, with a Power column when some
 * exponent knob has a power other than 1.
 * @param problems the box order (the scenario's `problems`)
 */
export function writeBoundsCsv(
  knobs: readonly (KnobSpec & { readonly id: string; readonly enabled: boolean })[],
  model: Model | null,
  problems: readonly string[] = [],
): string {
  const powerOf = (k: KnobSpec): string => (k.exponent !== undefined && k.power !== undefined && k.power !== 1 ? plainNumber(k.power) : '');
  const withPower = knobs.some((k) => powerOf(k) !== '');
  const rows = problemBoxes(problems, knobs, canonicalProblem(model)).flatMap((box) => {
    const [family, variation] = splitProblem(model, box.problem);
    if (box.knobs.length === 0) return [[family, variation, '', '', '', ...(withPower ? [''] : []), '', '', '']];
    return box.knobs.map((k) => [
      family,
      variation,
      k.id,
      k.kind === 'UB' ? 'Upper' : 'Lower',
      k.formula !== undefined ? `$${k.formula}$` : plainNumber(k.exponent!),
      ...(withPower ? [powerOf(k)] : []),
      k.regime ?? '',
      k.enabled ? 'yes' : 'no',
      k.note ?? '',
    ]);
  });
  return `${serializeCsv([[...(withPower ? BOUNDS_COLUMNS_WITH_POWER : BOUNDS_COLUMNS)], ...rows])}\r\n`;
}

/**
 * Knobs after an import: `replace` drops the current ones; otherwise imported knobs replace current knobs with the same
 * id (in place) and the others are appended.
 */
export function mergeKnobs(current: readonly Knob[], imported: readonly Knob[], replace: boolean): Knob[] {
  if (replace) return [...imported];
  const byId = new Map(imported.map((k) => [k.id, k]));
  const kept = current.map((k) => byId.get(k.id) ?? k);
  const currentIds = new Set(current.map((k) => k.id));
  return [...kept, ...imported.filter((k) => !currentIds.has(k.id))];
}

/**
 * Knobs and box order after an import (see mergeKnobs): replacing takes the file's boxes; adding keeps the current boxes
 * and appends the file's new ones.
 * @param canonical the box key of a problem name (canonicalProblem)
 */
export function mergeBounds(
  current: { readonly knobs: readonly Knob[]; readonly problems: readonly string[] },
  imported: { readonly knobs: readonly Knob[]; readonly problems: readonly string[] },
  replace: boolean,
  canonical: (name: string) => string,
): { knobs: Knob[]; problems: string[] } {
  const knobs = mergeKnobs(current.knobs, imported.knobs, replace);
  const before = replace ? [] : problemBoxes(current.problems, current.knobs, canonical).map((b) => b.problem);
  const problems = problemBoxes([...before, ...imported.problems], knobs, canonical).map((b) => b.problem);
  return { knobs, problems };
}
