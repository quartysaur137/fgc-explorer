/**
 * Modal dialogs: the reduction editor (edit or add a row of the sheet and its config annotation) and the help text.
 */

import { primaryFormula } from '../math/cells';
import { BOUNDS_COL, BOUNDS_REQUIRED_COLUMNS, mergeBounds, readBoundsCsv } from '../model/boundsCsv';
import { canonicalProblem, problemBoxes } from '../model/boxes';
import { ParseError, parseFormula, parseList } from '../math/parser';
import { canonicalRowId, initialScenario, RowAnnotation, rowIds, validateConfig } from '../model/config';
import { COL, findProblem, problemIdOf } from '../model/model';
import { h } from './dom';
import { Store } from './store';
import { cellHtml } from './tex';

/**
 * Show a modal with `content`; returns a function that closes it. The focus moves into the dialog, stays there (Tab
 * cycles through its controls), and returns where it was when the dialog closes.
 */
export function openModal(title: string, content: HTMLElement, footer: HTMLElement[] = []): () => void {
  const before = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const close = (): void => {
    overlay.remove();
    document.removeEventListener('keydown', onKey, true);
    before?.focus({ preventScroll: true });
  };
  const focusable = (): HTMLElement[] =>
    [...dialog.querySelectorAll<HTMLElement>('button, [href], input, select, textarea, summary, [tabindex]:not([tabindex="-1"])')].filter(
      (e) => !e.hasAttribute('disabled') && e.offsetParent !== null,
    );
  const onKey = (e: KeyboardEvent): void => {
    if (e.key === 'Escape') close();
    else if (e.key === 'Tab') {
      const items = focusable();
      if (items.length === 0) return;
      const first = items[0]!;
      const last = items[items.length - 1]!;
      if (e.shiftKey && (document.activeElement === first || !dialog.contains(document.activeElement))) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && (document.activeElement === last || !dialog.contains(document.activeElement))) {
        e.preventDefault();
        first.focus();
      }
    }
  };
  const closeButton = h('button', { class: 'icon', title: 'close', 'aria-label': `close ${title}`, on: { click: close } }, '×');
  const dialog = h(
    'div',
    { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    h('div', { class: 'modal-head' }, h('h2', {}, title), closeButton),
    h('div', { class: 'modal-body' }, content),
    h('div', { class: 'modal-foot' }, footer),
  );
  const overlay = h('div', { class: 'modal-overlay', on: { mousedown: (e) => e.target === overlay && close() } }, dialog);
  document.addEventListener('keydown', onKey, true);
  document.body.append(overlay);
  // (the first field, else the close button)
  (dialog.querySelector<HTMLElement>('.modal-body input, .modal-body textarea, .modal-body select') ?? closeButton).focus({ preventScroll: true });
  return close;
}

interface EditorField {
  readonly column: string;
  readonly label: string;
  readonly kind: 'formula' | 'signature' | 'text';
  readonly rows: number;
}

const FIELDS: readonly EditorField[] = [
  { column: COL.toTime, label: 'To-time (signature of the target)', kind: 'signature', rows: 1 },
  { column: COL.fromTime, label: 'From-time (first $...$ is the formula; later "$X = ...$" define abbreviations)', kind: 'formula', rows: 3 },
  { column: COL.rt, label: 'Reduction Runtime', kind: 'formula', rows: 2 },
  { column: COL.restrictions, label: 'Restrictions on to-time (prose)', kind: 'text', rows: 2 },
  { column: COL.randomized, label: 'Randomized? (Yes / empty)', kind: 'text', rows: 1 },
  { column: COL.hypothesis, label: 'Assumption/Hypothesis', kind: 'text', rows: 1 },
];

/** Live check of a cell: parse its primary formula. */
function checkCell(kind: EditorField['kind'], text: string): string {
  if (kind === 'text') return '';
  const f = primaryFormula(text);
  if (f === null) return text.trim() === '' ? '' : 'no $...$ formula (the row will not be used)';
  try {
    if (kind === 'signature') parseList(f);
    else parseFormula(f);
    return '✓ parses';
  } catch (e) {
    return e instanceof ParseError ? `✗ ${e.message}` : String(e);
  }
}

/**
 * Open the editor for row `rowId`, or for a new row when rowId is null.
 * Saving updates the sheet text (and the config's row annotation) through the store.
 */
export function openRowEditor(store: Store, rowId: string | null): void {
  const { model } = store.getDerived();
  const table = model.table;
  const row = rowId === null ? undefined : model.rowsById.get(rowId);
  const index = row?.index;
  const get = (col: string): string => (index === undefined ? '' : table.get(index, col));
  const problemIds = [...model.problems.keys()];
  const nextId = rowIds(model.rows.map((r) => r.id))();

  const inputs = new Map<string, HTMLTextAreaElement | HTMLInputElement>();
  const listId = 'editor-problems';
  const idInput = h('input', { type: 'text', value: row?.id ?? nextId, disabled: row !== undefined });
  // (names with whitespace squashed, as the model reads them: some sheet cells break a family name over two lines, which
  // a text field would join without a space)
  const squash = (x: string): string => x.replace(/\s+/g, ' ').trim();
  const nameOf = (familyCol: string, variationCol: string): string => problemIdOf(squash(get(familyCol)), squash(get(variationCol)));
  const fromInput = h('input', { type: 'text', list: listId, value: row ? nameOf(COL.fromFamily, COL.fromVariation) : '', placeholder: 'Family / Variation' });
  const toInput = h('input', { type: 'text', list: listId, value: row ? nameOf(COL.toFamily, COL.toVariation) : '', placeholder: 'Family / Variation' });
  const annotation = store.get().config.rows[row?.id ?? ''];
  const annInput = h('textarea', { rows: 6, class: 'mono', value: annotation ? JSON.stringify(annotation, null, 2) : '' });
  const annMsg = h('div', { class: 'check-msg' });
  const msg = h('div', { class: 'issue', hidden: true });

  toInput.addEventListener('change', () => {
    const target = model.problems.get(toInput.value.trim().replace(/\s+/g, ' '));
    const sig = inputs.get(COL.toTime)!;
    if (target && target.functions.length > 0 && sig.value.trim() === '') {
      sig.value = `$${target.functions.map((f) => `${f.name}(${f.params.join(', ')})`).join(', ')}$`;
      sig.dispatchEvent(new Event('input'));
    }
  });

  const fieldEls = FIELDS.map((f) => {
    const input = f.rows > 1 ? h('textarea', { rows: f.rows, class: 'mono', value: get(f.column) }) : h('input', { type: 'text', class: 'mono', value: get(f.column) });
    inputs.set(f.column, input);
    const check = h('div', { class: 'check-msg' });
    const preview = h('div', { class: 'preview' });
    const refresh = (): void => {
      const c = checkCell(f.kind, input.value);
      check.textContent = c;
      check.classList.toggle('bad', c.startsWith('✗') || c.startsWith('no '));
      preview.innerHTML = f.kind === 'text' ? '' : cellHtml(input.value);
    };
    input.addEventListener('input', refresh);
    refresh();
    return h('label', { class: 'editor-field' }, h('span', { html: cellHtml(f.label) }), input, check, preview);
  });

  const checkAnnotation = (): RowAnnotation | null | 'error' => {
    const text = annInput.value.trim();
    if (text === '') {
      annMsg.textContent = '';
      return null;
    }
    try {
      const json = JSON.parse(text);
      const v = validateConfig({ version: 1, rows: { x: json } });
      if (v.errors.length > 0) {
        annMsg.textContent = `✗ ${v.errors.join('; ')}`;
        return 'error';
      }
      annMsg.textContent = '✓ valid';
      return v.value.rows['x'] ?? null;
    } catch (e) {
      annMsg.textContent = `✗ ${(e as Error).message}`;
      return 'error';
    }
  };
  annInput.addEventListener('input', () => void checkAnnotation());
  checkAnnotation();

  const save = (): void => {
    const fail = (m: string): void => {
      msg.textContent = m;
      msg.hidden = false;
    };
    const split = (s: string): [string, string] | null => {
      const t = s.replace(/\s+/g, ' ');
      const i = t.indexOf(' / ');
      if (i < 0) {
        // (a name without " / " is a problem without a family)
        const name = t.trim();
        return name === '' || name.startsWith('/') || name.endsWith('/') ? null : ['', name];
      }
      const [family, variation] = [t.slice(0, i).trim(), t.slice(i + 3).trim()];
      return family === '' || variation === '' ? null : [family, variation];
    };
    const from = split(fromInput.value);
    const to = split(toInput.value);
    if (!from || !to) return fail('From and To must be written as "Family / Variation" (or the variation alone for a problem without a family)');
    // A variation alone that is not a problem but the variation of one is most likely that problem without its family.
    for (const [family, variation] of [from, to]) {
      if (family !== '' || findProblem(model, variation) !== undefined) continue;
      const like = [...model.problems.values()].filter((p) => p.variation.toLowerCase() === variation.toLowerCase()).map((p) => `"${p.id}"`);
      if (like.length > 0) return fail(`"${variation}" is the variation of ${like.join(', ')}: write it as "Family / Variation" (a name alone is a problem without a family)`);
    }
    const id = canonicalRowId(idInput.value);
    if (id === '') return fail('the Reduction ID is empty');
    if (row === undefined && model.rowsById.has(id)) return fail(`Reduction ID ${id} already exists`);
    const ann = checkAnnotation();
    if (ann === 'error') return fail('fix the annotation JSON first');
    const values: Record<string, string> = { [COL.id]: id };
    // (name cells are rewritten only when the name changed, so that a cell broken over two lines stays as it is)
    for (const [[familyCol, variationCol], [family, variation]] of [
      [[COL.fromFamily, COL.fromVariation], from],
      [[COL.toFamily, COL.toVariation], to],
    ] as const) {
      if (index !== undefined && squash(get(familyCol)) === family && squash(get(variationCol)) === variation) continue;
      values[familyCol] = family;
      values[variationCol] = variation;
    }
    for (const f of FIELDS) values[f.column] = inputs.get(f.column)!.value;
    let next = table;
    if (index === undefined) next = next.withRow(values);
    else for (const [col, v] of Object.entries(values)) if (next.get(index, col) !== v) next = next.withCell(index, col, v);
    store.update((s) => {
      const rows = { ...s.config.rows };
      if (ann === null) delete rows[id];
      // Remember which problems the annotation is for, so that a renumbered sheet cannot misapply it.
      else rows[id] = { ...ann, match: { from: problemIdOf(from[0], from[1]), to: problemIdOf(to[0], to[1]) } };
      const configChanged = JSON.stringify(rows[id] ?? null) !== JSON.stringify(s.config.rows[id] ?? null);
      return {
        ...s,
        sheetText: next === table ? s.sheetText : next.toText(),
        sheetCustom: s.sheetCustom || next !== table,
        sheetName: next === table ? s.sheetName : `${s.sheetName.replace(/ \(edited\)$/, '')} (edited)`,
        config: configChanged ? { ...s.config, rows } : s.config,
        configCustom: s.configCustom || configChanged,
        // An edited reduction stays selected (with the rest of the selection); a new one is selected alone.
        selection: s.selection.some((x) => x.kind === 'row' && x.id === id) ? s.selection : [{ kind: 'row', id }],
      };
    });
    close();
  };

  const content = h(
    'div',
    { class: 'editor' },
    h('datalist', { id: listId }, problemIds.map((p) => h('option', { value: p }))),
    h('label', { class: 'editor-field' }, h('span', {}, 'Reduction ID'), idInput),
    h('label', { class: 'editor-field' }, h('span', {}, 'From (the problem solved using the target)'), fromInput),
    h('label', { class: 'editor-field' }, h('span', {}, 'To (the problem whose algorithm is used)'), toInput),
    fieldEls,
    h(
      'label',
      { class: 'editor-field' },
      h('span', {}, 'Engine annotation for this row (JSON, optional): free parameters, abbreviations, overrides, requires, skip'),
      annInput,
      annMsg,
      h('div', { class: 'hint mono' }, '{"free": [{"name": "k", "type": "int", "values": [2, 3, 4]}, {"name": "t", "type": "size", "base": "n", "min": 0, "max": 1}], "defs": {"N": "2^{n/2}"}, "requires": "m=2"}'),
    ),
    msg,
  );
  const close = openModal(row ? `Edit reduction ${row.id}` : 'Add a reduction', content, [
    h('button', { on: { click: () => close() } }, 'Cancel'),
    h('button', { class: 'primary', on: { click: save } }, 'Save'),
  ]);
}

/**
 * Show what a bounds CSV contains (counts, problems per row) and let the user replace the current knobs with it or add
 * it to them. Nothing changes until "Import" is pressed.
 * @param onDone called with a summary after importing
 */
export function openBoundsImport(store: Store, fileName: string, text: string, onDone: (message: string) => void): void {
  const { model } = store.getDerived();
  const { knobs: current, problems: currentProblems } = store.get().scenario;
  const canonical = canonicalProblem(model);
  // New IDs for blank Bound IDs avoid the current knobs' (so that adding never replaces one by accident) and the initial
  // settings' (so that adding those later does not either).
  const result = readBoundsCsv(text, model, [...current, ...initialScenario(store.get().config).knobs].map((k) => k.id));
  const { knobs } = result;
  const boxes = problemBoxes(result.problems, knobs, canonical);
  const empty = boxes.filter((b) => b.knobs.length === 0).length;
  const currentBoxes = problemBoxes(currentProblems, current, canonical).length;
  const lb = knobs.filter((k) => k.kind === 'LB').length;
  const off = knobs.filter((k) => !k.enabled).length;
  const errors = result.issues.filter((i) => i.level === 'error');
  const skippedRows = new Set(errors.map((e) => e.line)).size;
  const currentIds = new Set(current.map((k) => k.id));
  const sameId = knobs.filter((k) => currentIds.has(k.id)).length;

  const summary =
    result.missingColumns.length > 0
      ? h(
          'p',
          { class: 'issue' },
          `Missing column${result.missingColumns.length > 1 ? 's' : ''}: ${result.missingColumns.join(', ')}. A bounds CSV needs the columns ${BOUNDS_REQUIRED_COLUMNS.join(', ')} (in any order); ${BOUNDS_COL.regime}, ${BOUNDS_COL.enabled} and ${BOUNDS_COL.note} are optional.`,
        )
      : h(
          'p',
          {},
          `${knobs.length} bound${knobs.length === 1 ? '' : 's'} read for ${boxes.length} problem${boxes.length === 1 ? '' : 's'}: ${lb} lower bound${lb === 1 ? '' : 's'} (hypotheses) and ${knobs.length - lb} upper bound${knobs.length - lb === 1 ? '' : 's'} (algorithms)` +
            `${off > 0 ? `, ${off} switched off` : ''}${empty > 0 ? `; ${empty} problem${empty === 1 ? '' : 's'} listed without bounds` : ''}.` +
            `${skippedRows > 0 ? ` ${skippedRows} row${skippedRows === 1 ? '' : 's'} skipped because of errors (below).` : ''}`,
        );
  const shown = result.issues.slice(0, 200);
  const issues =
    shown.length === 0
      ? null
      : h(
          'ul',
          { class: 'import-issues' },
          shown.map((i) => h('li', { class: i.level }, `${i.level === 'error' ? '✗' : '⚠'} ${i.line > 0 ? `line ${i.line}: ` : ''}${i.message}`)),
          result.issues.length > shown.length ? h('li', {}, `… and ${result.issues.length - shown.length} more`) : null,
        );
  const replace = h('input', { type: 'radio', name: 'bounds-mode', checked: true });
  const add = h('input', { type: 'radio', name: 'bounds-mode' });
  const modes =
    boxes.length === 0
      ? null
      : h(
          'div',
          { class: 'import-modes' },
          h('label', {}, replace, ` Replace the current problems and their bounds (${currentBoxes} problems, ${current.length} bounds)`),
          h('label', {}, add, ` Add to them${sameId > 0 ? ` (${sameId} with the same Bound ID will be replaced)` : ' (no Bound ID is already in use)'}`),
        );
  const doImport = (): void => {
    const next = mergeBounds({ knobs: current, problems: currentProblems }, result, replace.checked, canonical);
    store.update((s) => ({ ...s, scenario: { ...s.scenario, ...next } }));
    close();
    onDone(`imported ${knobs.length} bound${knobs.length === 1 ? '' : 's'} for ${boxes.length} problem${boxes.length === 1 ? '' : 's'} from ${fileName}${replace.checked ? '' : ' (added)'}`);
  };
  const importButton = h('button', { class: 'primary', disabled: boxes.length === 0, on: { click: doImport } }, 'Import');
  const close = openModal(`Import bounds from ${fileName}`, h('div', { class: 'bounds-import' }, summary, modes, issues), [
    h('button', { on: { click: () => close() } }, 'Cancel'),
    importButton,
  ]);
}

export function openHelp(): void {
  const p = (html: string): HTMLElement => h('p', { html });
  openModal(
    'How the explorer works',
    h(
      'div',
      { class: 'help' },
      p('<b>Bounds.</b> The left panel has one box per problem with its bounds (knobs). A <i>lower bound</i> (LB) is a hypothesis: “problem P needs time N<sup>x−o(1)</sup> on instances of this regime”. An <i>algorithm</i> (UB, upper bound) is given as an exponent at a regime or as a runtime formula in P’s parameters (valid in every regime). Unchecked bounds are ignored. ＋ in a box adds a bound for its problem (its regime and formula are checked first), × removes it (or the whole box), and ＋ Problem below the boxes adds a box. <b>n^c</b> turns a bound given by a formula into a plain exponent at a regime (a slider) and <b>ƒ(n)</b> an exponent into a formula; ƒ(n) right after n^c brings the formula back. Number fields refuse values out of range (with a message beside them) and read a decimal comma as a point. The panel starts with the Satisfiability Hypothesis (SETH for CNF-SAT with poly(n) clauses; renamed from SETH in November 2026 after an October 2026 announcement of a 2<sup>o(n)</sup> algorithm for k-SAT, which refutes SETH’s k-SAT form but not this one), the 3SUM and APSP hypotheses, textbook algorithms, and a trivial and the best known algorithms for most problems (each bound’s note says how it works and where it comes from) switched on, and further hypotheses (SETH in its k-SAT form, OV, low-dimension OV, Min-Weight k-Clique, k-Clique, combinatorial BMM, OMv, Hitting Set, ∀∀∃-OV, 3-uniform hyperclique, k-AP, Zero-Weight k-Clique, (min,+)-convolution), the non-combinatorial algorithms (Valiant’s CFG parser, transitive closure by matrix multiplication), the October 2026 algorithms of Alman and Vassilevska Williams (3SUM, APSP, Exact Triangle through sparse lopsided triangles, and related problems) and of Saha and Ye ((min,+)-product and APSP in n<sup>2.9963</sup>), and the October 2026 k-SAT algorithm switched off; the inspector lists these <i>initial settings</i> when nothing is selected, each group with a switch that turns all its bounds on or off at once. Hypotheses are conjectures, so treat them as adjustable reference points. The reductions that need a k-CNF formula with O(n) clauses (sparsification) start from k-SAT, which reduces to CNF-SAT, so only SETH’s k-SAT form gives them anything (e.g. Subset Sum, Bicriteria s,t-Path, low-dimension OV).'),
      p('<b>Search.</b> The field above the graph searches problems and bounds. Type a problem’s name, a Bound ID (U12: exactly that bound) or a word from the bounds’ notes or formulas (an author, “omega”): the left panel keeps the boxes found, with the bounds found highlighted (collapsed boxes holding them open up) and their number at its top, the graph outlines the same problems, and the problems table lists only them. Enter selects the problem whose name the query matches best (equal to it, then having it as a whole word; among equals the first box); for a Bound ID it selects its problem and scrolls to the bound, for a reduction’s ID (R12) it selects that reduction. Esc or Clear ends the search; the box you were looking at stays in view. In the inspector, Bound IDs (in a problem’s list of hypotheses and algorithms, and in derivations) are links: a click scrolls the left panel to that bound and opens its box.'),
      p('<b>Propagation.</b> Each reduction row says: an algorithm for the target with time T gives one for the source with time O(From-time(T) + Reduction Runtime). Lower bounds therefore flow <i>forward</i> (source → target): the target’s exponent x* is the smallest x for which the From-time with T = N′<sup>x</sup> reaches the source’s lower bound (and only if the reduction itself is faster than that bound). Upper bounds flow <i>backward</i>: the source gets max(From-time with the target’s upper bounds, Reduction Runtime). Each problem has one best bound per regime, the same wherever it is used (in its own box, or inside the derivation of another problem), whatever the number of reductions it takes; when several derivations give the same bound, the one with the fewest reductions is shown. In the inspector, open a regime to see the derivations of its bounds and, under them, what each reduction to or from the problem gives there, or why it gives nothing (e.g. its source has no lower bound, the reduction itself is too slow, a call has no upper bound).'),
      p('<b>Cycles.</b> Reductions can form cycles. Usually going around one gives nothing new, but it can improve a bound every time (e.g. a 3SUM hypothesis above n<sup>2</sup> raises itself through Exact Weight 3-Star Detection and back). The bound is then the limit of going around again and again: the nearest fixed point, or ∞ for a lower bound that grows without limit (no polynomial-time algorithm). The derivation shows the cycle and one lap (↻); the Diagnostics tab lists such cycles.'),
      p('<b>Regimes and exponents.</b> Everything is an exponent of a scale N: a regime fixes how each parameter grows (e.g. dense graphs m = n², or d = polylog n for OV). Regimes are normalized so that the first growing parameter is N (for exponential-time problems such as CNF-SAT, N = 2<sup>n</sup>). Parameters such as M (largest value) only count through log M; constant parameters (k, σ, d) are part of the regime because exponents may depend on them. Polylog and N<sup>o(1)</sup> factors are ignored. A regime stands for the instances whose parameters grow at most that fast, and parameters have <i>limits</i> that every instance satisfies, shown in the inspector: a graph has at most n² edges, an arboricity α ≤ √m (and ≥ m/n), at most m·α triangles (so at most n³), a set at most U elements, an intersection at most s, and so on. Every regime is clipped to them (t = n<sup>3.5</sup> becomes t = m·α, which names the same graphs), so no regime stands for instances that cannot exist, and a reduction whose formula claims such instances is read where its instances are. A regime whose instances lie inside another regime of the problem (every parameter growing at most as fast) takes that one’s lower bound, and a regime around another takes its upper bound: such a bound is marked † in the inspector, which names the regime it comes from (e.g. Diameter 2 vs 3 on dense graphs takes the n² of sparse graphs). A problem’s node shows one regime: one with a conflict if there is any, else a pinned one, else among its nice regimes (whole-number exponents such as m = n or m = n², or simple fractions such as n<sup>3/2</sup>) the one whose own bounds say the most (tight, then a gap, a lower bound, an upper bound), whole numbers first among equals. The inspector lists the regimes in the same order; unusual regimes (such as m = n<sup>10/11</sup>) that no other problem’s listed bound goes through are behind “show all”.'),
      p('<b>Running times 2<sup>c·n<sup>a</sup></sup>.</b> Times are more generally 2<sup>c·(log N)<sup>a</sup></sup>: for CNF-SAT, whose N is 2<sup>n</sup>, that is 2<sup>c·n<sup>a</sup></sup>, so besides the exponent c (SETH: c = 1) a bound has a <i>power</i> a, 1 unless set: below 1 the time is subexponential, e.g. 2<sup>n<sup>0.99</sup></sup> or 2<sup>0.5·n<sup>0.75</sup></sup>. Exponent bounds of exponential-time problems have a second slider for a; a formula such as 2^{0.5 n^{0.75}} \\cdot m works for any problem (at polynomial regimes, e.g. n^{\\log n} = 2<sup>log² n</sup>). Bounds are compared power first: a lower bound 2<sup>c·n<sup>a</sup></sup> with a &lt; 1 passes only through reductions whose own time is below it (not split and list, which takes 2<sup>n/2</sup>), and with them powers carry over, the constant scaled by the instance size.'),
      p('<b>Graph and panels.</b> Scroll to zoom and drag to pan, or use − / 100% / + / Fit (100% shows labels at full size). A search dims the problems it does not find. <i>Family boxes</i> draws a box around the problems of each family (off at first: a drag that starts inside a box moves the box rather than the view). Click a problem or a reduction to inspect it; Shift-click (or Ctrl/⌘-click) adds it to the selection or removes it, also in the tables and the inspector, and the inspector then shows a collapsible section for each. Pointing at a problem or reduction, in the graph or at its name or ID (R12) in a panel (also with the keyboard), highlights it in the graph; when it is out of view, a label at the edge of the graph points toward it. A double-click also opens the inspector when it is hidden. Drag the bars between the panels to resize them (double-click a bar: default size); the buttons at the start of the header show or hide the panels, the fourth one shows the graph alone (and brings back the panels that were open), and the moon switches between light and dark mode (at first the app follows your system’s setting). Panel sizes are fitted to the window; below 1100 px the page is one column, with the inspector right after the graph.'),
      p('<b>Focus.</b> Dims everything but the selection, and zooms to what it keeps: <i>neighbours</i> — the problems one reduction away; <i>ancestors &amp; descendants</i> — every problem with a path of reductions to or from it (following the reductions the engine uses, not the dashed ones); <i>bound derivations</i> — the reductions that the best lower bound (orange) and upper bound (blue; purple: both) of each selected problem come from, drawn thick. A bound that comes from a knob on the problem itself marks only the problem. Derivations are those of the regime shown on the node, or of the regime opened in the inspector.'),
      p('<b>Colors.</b> Red: conflict (an upper bound below a lower bound; also a thick double border); green: tight; yellow: both bounds with a gap; orange: lower bound only; blue: upper bound only; grey: nothing. Dashed nodes are dynamic problems (several time functions), which are shown but not propagated. Edge colors show which reductions the displayed bounds use; a loop is a reduction from a problem to itself (from k to k + 1). A node shows the bounds of its problem’s first regime; when that regime fixes a constant parameter in the exponent (k-Clique’s k), it shows the bounds as functions of k if every listed k gives the same simple formula (≥ n^k ≤ n^k), else the status at each k (k=3 tight · 4–6 UB), with the color of the first regime; the inspector lists the bounds at each k.'),
      p('<b>Changing the data.</b> The header has one group of buttons per thing they act on. <i>Reductions</i>: <i>Load…</i> another CSV export of the sheet, <i>Export</i> the sheet with your edits as CSV, <i>＋ Add</i> a reduction (edit one from the inspector → Edit row); free parameters such as “k ≥ 2 free integer parameter” are declared in the row’s annotation. <i>Scenario</i> (hypotheses and algorithms, constants and engine settings) and <i>Config</i> (free parameters, regimes, row annotations, initial settings) load and export as JSON; the scenario is also remembered by this browser, and <i>Reset…</i> forgets it. A file of the other kind is refused, a file with problems asks first, and a load can be undone from its message; Scenario Export includes the pinned regimes. If the app is open in another tab that saves, this one stops saving and offers to reload. Hypotheses and algorithms can be kept in a CSV too (left panel, <i>Bounds CSV</i>: one row per bound with the columns Problem, Variation, Bound ID, Upper or Lower, Runtime, and optionally Power, Regime, Enabled, Note; a plain number as Runtime is an exponent, and Power its power a; the boxes follow the order in which problems first appear, and a row without Upper or Lower and Runtime lists a problem without bounds). A problem that belongs to no family has a blank Problem column in the sheet and in these files; it is named by its variation alone. Reductions have IDs R1, R2, …, lower bounds L1, L2, … and upper bounds U1, U2, … (files of earlier versions, numbered without letters, are read as these).'),
      p('<b>Precision.</b> Bounds are shown with four to eight decimals: enough that rounding never overstates a bound and that a conflict or a gap never looks like equality, so improvements such as 3SUM in n<sup>1.9992</sup> are visible. Free parameters are optimized on a grid with local refinement (accurate to about 10<sup>−6</sup> with the default settings); since this can only make derived bounds weaker, an upper bound below a lower bound is always reported as a conflict, and bounds within 10<sup>−4</sup> count as tight.'),
      p('<b>Limitations.</b> Exponents only; rows whose formulas are prose or “??” are skipped (see the Reductions tab), and the Restrictions column is not read: a row that holds only on special instances is marked “LB only” (it gives lower bounds, no algorithm). The search for upper bounds follows reductions without limit from the regimes it starts from (those configured for each problem, those of its algorithms, and pinned ones), but passes through at most “UB detours” (Settings, 3 by default, at most 5) other regimes in a row: free parameters create too many of those (200 000 within seven reductions). Pin a regime to start a search there. After showing results, the app keeps checking the other regimes of lower bounds for upper bounds for a moment (the status line says so). Las Vegas and deterministic algorithms are not told apart: with the 2026 algorithms on, Superadditivity Testing gets n<sup>1.998</sup> through four reductions (R422, R211, R54, R387) from the Las Vegas algorithm for real inputs (U18), not the deterministic n<sup>1.9992</sup> for 3SUM (U17).'),
    ),
  );
}
