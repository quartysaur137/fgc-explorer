/**
 * Modal dialogs: the reduction editor (edit or add a row of the sheet and its config annotation) and the help text.
 */

import { primaryFormula } from '../math/cells';
import { BOUNDS_COL, BOUNDS_REQUIRED_COLUMNS, mergeBounds, readBoundsCsv } from '../model/boundsCsv';
import { canonicalProblem, problemBoxes } from '../model/boxes';
import { ParseError, parseFormula, parseList } from '../math/parser';
import { RowAnnotation, validateConfig } from '../model/config';
import { COL } from '../model/model';
import { h } from './dom';
import { Store } from './store';
import { cellHtml } from './tex';

/** Show a modal with `content`; returns a function that closes it. */
export function openModal(title: string, content: HTMLElement, footer: HTMLElement[] = []): () => void {
  const close = (): void => {
    overlay.remove();
    document.removeEventListener('keydown', onKey);
  };
  const onKey = (e: KeyboardEvent): void => {
    if (e.key === 'Escape') close();
  };
  const overlay = h(
    'div',
    { class: 'modal-overlay', on: { mousedown: (e) => e.target === overlay && close() } },
    h(
      'div',
      { class: 'modal', role: 'dialog', 'aria-label': title },
      h('div', { class: 'modal-head' }, h('h2', {}, title), h('button', { class: 'icon', title: 'close', on: { click: close } }, '×')),
      h('div', { class: 'modal-body' }, content),
      h('div', { class: 'modal-foot' }, footer),
    ),
  );
  document.addEventListener('keydown', onKey);
  document.body.append(overlay);
  return close;
}

interface EditorField {
  readonly column: string;
  readonly label: string;
  readonly kind: 'formula' | 'signature' | 'text';
  readonly rows: number;
}

const FIELDS: readonly EditorField[] = [
  { column: COL.toTime, label: 'To-time (signature of the target)', kind: 'signature', rows: 1 },
  { column: COL.fromTime, label: 'From-time (first $...$ is the formula; later "$X = ...$" define abbreviations)', kind: 'formula', rows: 3 },
  { column: COL.rt, label: 'Reduction Runtime', kind: 'formula', rows: 2 },
  { column: COL.restrictions, label: 'Restrictions on to-time (prose)', kind: 'text', rows: 2 },
  { column: COL.randomized, label: 'Randomized? (Yes / empty)', kind: 'text', rows: 1 },
  { column: COL.hypothesis, label: 'Assumption/Hypothesis', kind: 'text', rows: 1 },
];

/** Live check of a cell: parse its primary formula. */
function checkCell(kind: EditorField['kind'], text: string): string {
  if (kind === 'text') return '';
  const f = primaryFormula(text);
  if (f === null) return text.trim() === '' ? '' : 'no $...$ formula (the row will not be used)';
  try {
    if (kind === 'signature') parseList(f);
    else parseFormula(f);
    return '✓ parses';
  } catch (e) {
    return e instanceof ParseError ? `✗ ${e.message}` : String(e);
  }
}

/**
 * Open the editor for row `rowId`, or for a new row when rowId is null.
 * Saving updates the sheet text (and the config's row annotation) through the store.
 */
export function openRowEditor(store: Store, rowId: string | null): void {
  const { model } = store.getDerived();
  const table = model.table;
  const row = rowId === null ? undefined : model.rowsById.get(rowId);
  const index = row?.index;
  const get = (col: string): string => (index === undefined ? '' : table.get(index, col));
  const problemIds = [...model.problems.keys()];
  const nextId = String(Math.max(0, ...model.rows.map((r) => Number.parseInt(r.id, 10)).filter(Number.isFinite)) + 1);

  const inputs = new Map<string, HTMLTextAreaElement | HTMLInputElement>();
  const listId = 'editor-problems';
  const idInput = h('input', { type: 'text', value: row?.id ?? nextId, disabled: row !== undefined });
  const fromInput = h('input', { type: 'text', list: listId, value: row ? `${get(COL.fromFamily)} / ${get(COL.fromVariation)}` : '', placeholder: 'Family / Variation' });
  const toInput = h('input', { type: 'text', list: listId, value: row ? `${get(COL.toFamily)} / ${get(COL.toVariation)}` : '', placeholder: 'Family / Variation' });
  const annotation = store.get().config.rows[row?.id ?? ''];
  const annInput = h('textarea', { rows: 6, class: 'mono', value: annotation ? JSON.stringify(annotation, null, 2) : '' });
  const annMsg = h('div', { class: 'check-msg' });
  const msg = h('div', { class: 'issue', hidden: true });

  toInput.addEventListener('change', () => {
    const target = model.problems.get(toInput.value.trim().replace(/\s+/g, ' '));
    const sig = inputs.get(COL.toTime)!;
    if (target && target.functions.length > 0 && sig.value.trim() === '') {
      sig.value = `$${target.functions.map((f) => `${f.name}(${f.params.join(', ')})`).join(', ')}$`;
      sig.dispatchEvent(new Event('input'));
    }
  });

  const fieldEls = FIELDS.map((f) => {
    const input = f.rows > 1 ? h('textarea', { rows: f.rows, class: 'mono', value: get(f.column) }) : h('input', { type: 'text', class: 'mono', value: get(f.column) });
    inputs.set(f.column, input);
    const check = h('div', { class: 'check-msg' });
    const preview = h('div', { class: 'preview' });
    const refresh = (): void => {
      const c = checkCell(f.kind, input.value);
      check.textContent = c;
      check.classList.toggle('bad', c.startsWith('✗') || c.startsWith('no '));
      preview.innerHTML = f.kind === 'text' ? '' : cellHtml(input.value);
    };
    input.addEventListener('input', refresh);
    refresh();
    return h('label', { class: 'editor-field' }, h('span', { html: cellHtml(f.label) }), input, check, preview);
  });

  const checkAnnotation = (): RowAnnotation | null | 'error' => {
    const text = annInput.value.trim();
    if (text === '') {
      annMsg.textContent = '';
      return null;
    }
    try {
      const json = JSON.parse(text);
      const v = validateConfig({ version: 1, rows: { x: json } });
      if (v.errors.length > 0) {
        annMsg.textContent = `✗ ${v.errors.join('; ')}`;
        return 'error';
      }
      annMsg.textContent = '✓ valid';
      return v.value.rows['x'] ?? null;
    } catch (e) {
      annMsg.textContent = `✗ ${(e as Error).message}`;
      return 'error';
    }
  };
  annInput.addEventListener('input', () => void checkAnnotation());
  checkAnnotation();

  const save = (): void => {
    const fail = (m: string): void => {
      msg.textContent = m;
      msg.hidden = false;
    };
    const split = (s: string): [string, string] | null => {
      const i = s.indexOf(' / ');
      return i <= 0 ? null : [s.slice(0, i).trim(), s.slice(i + 3).trim()];
    };
    const from = split(fromInput.value);
    const to = split(toInput.value);
    if (!from || !to) return fail('From and To must be written as "Family / Variation"');
    const id = idInput.value.trim();
    if (id === '') return fail('the Reduction ID is empty');
    if (row === undefined && model.rowsById.has(id)) return fail(`Reduction ID ${id} already exists`);
    const ann = checkAnnotation();
    if (ann === 'error') return fail('fix the annotation JSON first');
    const values: Record<string, string> = {
      [COL.fromFamily]: from[0],
      [COL.fromVariation]: from[1],
      [COL.toFamily]: to[0],
      [COL.toVariation]: to[1],
      [COL.id]: id,
    };
    for (const f of FIELDS) values[f.column] = inputs.get(f.column)!.value;
    let next = table;
    if (index === undefined) next = next.withRow(values);
    else for (const [col, v] of Object.entries(values)) if (next.get(index, col) !== v) next = next.withCell(index, col, v);
    store.update((s) => {
      const rows = { ...s.config.rows };
      if (ann === null) delete rows[id];
      // Remember which problems the annotation is for, so that a renumbered sheet cannot misapply it.
      else rows[id] = { ...ann, match: { from: `${from[0]} / ${from[1]}`, to: `${to[0]} / ${to[1]}` } };
      const configChanged = JSON.stringify(rows[id] ?? null) !== JSON.stringify(s.config.rows[id] ?? null);
      return {
        ...s,
        sheetText: next === table ? s.sheetText : next.toText(),
        sheetCustom: s.sheetCustom || next !== table,
        sheetName: next === table ? s.sheetName : `${s.sheetName.replace(/ \(edited\)$/, '')} (edited)`,
        config: configChanged ? { ...s.config, rows } : s.config,
        configCustom: s.configCustom || configChanged,
        // An edited reduction stays selected (with the rest of the selection); a new one is selected alone.
        selection: s.selection.some((x) => x.kind === 'row' && x.id === id) ? s.selection : [{ kind: 'row', id }],
      };
    });
    close();
  };

  const content = h(
    'div',
    { class: 'editor' },
    h('datalist', { id: listId }, problemIds.map((p) => h('option', { value: p }))),
    h('label', { class: 'editor-field' }, h('span', {}, 'Reduction ID'), idInput),
    h('label', { class: 'editor-field' }, h('span', {}, 'From (the problem solved using the target)'), fromInput),
    h('label', { class: 'editor-field' }, h('span', {}, 'To (the problem whose algorithm is used)'), toInput),
    fieldEls,
    h(
      'label',
      { class: 'editor-field' },
      h('span', {}, 'Engine annotation for this row (JSON, optional): free parameters, abbreviations, overrides, requires, skip'),
      annInput,
      annMsg,
      h('div', { class: 'hint mono' }, '{"free": [{"name": "k", "type": "int", "values": [2, 3, 4]}, {"name": "t", "type": "size", "base": "n", "min": 0, "max": 1}], "defs": {"N": "2^{n/2}"}, "requires": "m=2"}'),
    ),
    msg,
  );
  const close = openModal(row ? `Edit reduction #${row.id}` : 'Add a reduction', content, [
    h('button', { on: { click: () => close() } }, 'Cancel'),
    h('button', { class: 'primary', on: { click: save } }, 'Save'),
  ]);
}

/**
 * Show what a bounds CSV contains (counts, problems per row) and let the user replace the current knobs with it or add
 * it to them. Nothing changes until "Import" is pressed.
 * @param onDone called with a summary after importing
 */
export function openBoundsImport(store: Store, fileName: string, text: string, onDone: (message: string) => void): void {
  const { model } = store.getDerived();
  const { knobs: current, problems: currentProblems } = store.get().scenario;
  const canonical = canonicalProblem(model);
  // New numbers for blank Bound IDs avoid the current knobs', so that adding never replaces one by accident.
  const result = readBoundsCsv(
    text,
    model,
    current.map((k) => k.id),
  );
  const { knobs } = result;
  const boxes = problemBoxes(result.problems, knobs, canonical);
  const empty = boxes.filter((b) => b.knobs.length === 0).length;
  const currentBoxes = problemBoxes(currentProblems, current, canonical).length;
  const lb = knobs.filter((k) => k.kind === 'LB').length;
  const off = knobs.filter((k) => !k.enabled).length;
  const errors = result.issues.filter((i) => i.level === 'error');
  const skippedRows = new Set(errors.map((e) => e.line)).size;
  const currentIds = new Set(current.map((k) => k.id));
  const sameId = knobs.filter((k) => currentIds.has(k.id)).length;

  const summary =
    result.missingColumns.length > 0
      ? h(
          'p',
          { class: 'issue' },
          `Missing column${result.missingColumns.length > 1 ? 's' : ''}: ${result.missingColumns.join(', ')}. A bounds CSV needs the columns ${BOUNDS_REQUIRED_COLUMNS.join(', ')} (in any order); ${BOUNDS_COL.regime}, ${BOUNDS_COL.enabled} and ${BOUNDS_COL.note} are optional.`,
        )
      : h(
          'p',
          {},
          `${knobs.length} bound${knobs.length === 1 ? '' : 's'} read for ${boxes.length} problem${boxes.length === 1 ? '' : 's'}: ${lb} lower bound${lb === 1 ? '' : 's'} (hypotheses) and ${knobs.length - lb} upper bound${knobs.length - lb === 1 ? '' : 's'} (algorithms)` +
            `${off > 0 ? `, ${off} switched off` : ''}${empty > 0 ? `; ${empty} problem${empty === 1 ? '' : 's'} listed without bounds` : ''}.` +
            `${skippedRows > 0 ? ` ${skippedRows} row${skippedRows === 1 ? '' : 's'} skipped because of errors (below).` : ''}`,
        );
  const shown = result.issues.slice(0, 200);
  const issues =
    shown.length === 0
      ? null
      : h(
          'ul',
          { class: 'import-issues' },
          shown.map((i) => h('li', { class: i.level }, `${i.level === 'error' ? '✗' : '⚠'} ${i.line > 0 ? `line ${i.line}: ` : ''}${i.message}`)),
          result.issues.length > shown.length ? h('li', {}, `… and ${result.issues.length - shown.length} more`) : null,
        );
  const replace = h('input', { type: 'radio', name: 'bounds-mode', checked: true });
  const add = h('input', { type: 'radio', name: 'bounds-mode' });
  const modes =
    boxes.length === 0
      ? null
      : h(
          'div',
          { class: 'import-modes' },
          h('label', {}, replace, ` Replace the current problems and their bounds (${currentBoxes} problems, ${current.length} bounds)`),
          h('label', {}, add, ` Add to them${sameId > 0 ? ` (${sameId} with the same Bound ID will be replaced)` : ' (no Bound ID is already in use)'}`),
        );
  const doImport = (): void => {
    const next = mergeBounds({ knobs: current, problems: currentProblems }, result, replace.checked, canonical);
    store.update((s) => ({ ...s, scenario: { ...s.scenario, ...next } }));
    close();
    onDone(`imported ${knobs.length} bound${knobs.length === 1 ? '' : 's'} for ${boxes.length} problem${boxes.length === 1 ? '' : 's'} from ${fileName}${replace.checked ? '' : ' (added)'}`);
  };
  const importButton = h('button', { class: 'primary', disabled: boxes.length === 0, on: { click: doImport } }, 'Import');
  const close = openModal(`Import bounds from ${fileName}`, h('div', { class: 'bounds-import' }, summary, modes, issues), [
    h('button', { on: { click: () => close() } }, 'Cancel'),
    importButton,
  ]);
}

export function openHelp(): void {
  const p = (html: string): HTMLElement => h('p', { html });
  openModal(
    'How the explorer works',
    h(
      'div',
      { class: 'help' },
      p('<b>Bounds.</b> The left panel has one box per problem with its bounds (knobs). A <i>lower bound</i> (LB) is a hypothesis: “problem P needs time N<sup>x−o(1)</sup> on instances of this regime”. An <i>algorithm</i> (UB, upper bound) is given as an exponent at a regime or as a runtime formula in P’s parameters (valid in every regime). Unchecked bounds are ignored. ＋ in a box adds a bound for its problem, × removes it (or the whole box), and ＋ Problem below the boxes adds a box. The panel starts with SETH, the 3SUM and APSP hypotheses and textbook algorithms switched on, and further hypotheses (OV, Min-Weight k-Clique, k-Clique, combinatorial BMM) and the October 2026 algorithms of Alman and Vassilevska Williams switched off; the inspector lists these <i>initial settings</i> when nothing is selected. Hypotheses are conjectures, so treat them as adjustable reference points.'),
      p('<b>Propagation.</b> Each reduction row says: an algorithm for the target with time T gives one for the source with time O(From-time(T) + Reduction Runtime). Lower bounds therefore flow <i>forward</i> (source → target): the target’s exponent x* is the smallest x for which the From-time with T = N′<sup>x</sup> reaches the source’s lower bound (and only if the reduction itself is faster than that bound). Upper bounds flow <i>backward</i>: the source gets max(From-time with the target’s upper bounds, Reduction Runtime).'),
      p('<b>Regimes and exponents.</b> Everything is an exponent of a scale N: a regime fixes how each parameter grows (e.g. dense graphs m = n², or d = polylog n for OV). Regimes are normalized so that the first growing parameter is N (for exponential-time problems such as CNF-SAT, N = 2<sup>n</sup>). Parameters such as M (largest value) only count through log M; constant parameters (k, σ, d) are part of the regime because exponents may depend on them. Polylog and N<sup>o(1)</sup> factors are ignored.'),
      p('<b>Graph and panels.</b> Scroll to zoom and drag to pan, or use − / 100% / + / Fit (100% shows labels at full size). Click a problem or a reduction to inspect it; Shift-click (or Ctrl/⌘-click) adds it to the selection or removes it, also in the tables and the inspector, and the inspector then shows a collapsible section for each. A double-click also opens the inspector when it is hidden. Drag the bars between the panels to resize them (double-click a bar: default size); the buttons at the start of the header show or hide the panels, and the fourth one shows the graph alone.'),
      p('<b>Focus.</b> Dims everything but the selection and: <i>neighbours</i> — the problems one reduction away; <i>ancestors &amp; descendants</i> — every problem with a path of reductions to or from it (following the reductions drawn); <i>bound derivations</i> — the reductions that the best lower bound (orange) and upper bound (blue; purple: both) of each selected problem come from, drawn thick. A bound that comes from a knob on the problem itself marks only the problem. Derivations are those of the regime shown on the node, or of the regime opened in the inspector.'),
      p('<b>Colors.</b> Red: conflict (an upper bound below a lower bound); green: tight; yellow: both bounds with a gap; orange: lower bound only; blue: upper bound only; grey: nothing. Dashed nodes are dynamic problems (several time functions), which are shown but not propagated. Edge colors show which reductions the displayed bounds use.'),
      p('<b>Changing the data.</b> The header has one group of buttons per thing they act on. <i>Reductions</i>: <i>Load…</i> another CSV export of the sheet, <i>Export</i> the sheet with your edits as CSV, <i>＋ Add</i> a reduction (edit one from the inspector → Edit row); free parameters such as “k ≥ 2 free integer parameter” are declared in the row’s annotation. <i>Scenario</i> (hypotheses and algorithms, constants and engine settings) and <i>Config</i> (free parameters, regimes, row annotations, initial settings) load and export as JSON; the scenario is also remembered by this browser, and <i>Reset…</i> forgets it. Hypotheses and algorithms can be kept in a CSV too (left panel, <i>Bounds CSV</i>: one row per bound with the columns Problem, Variation, Bound ID, Upper or Lower, Runtime, and optionally Regime, Enabled, Note; a plain number as Runtime is an exponent; the boxes follow the order in which problems first appear, and a row without Upper or Lower and Runtime lists a problem without bounds).'),
      p('<b>Precision.</b> Bounds are shown with four to eight decimals: enough that rounding never overstates a bound and that a conflict or a gap never looks like equality, so improvements such as 3SUM in n<sup>1.9992</sup> are visible. Free parameters are optimized on a grid with local refinement (accurate to about 10<sup>−6</sup> with the default settings); since this can only make derived bounds weaker, an upper bound below a lower bound is always reported as a conflict, and bounds within 10<sup>−4</sup> count as tight.'),
      p('<b>Limitations.</b> Exponents only; upper bounds use at most “UB depth” reductions; rows whose formulas are prose or “??” are skipped (see the Reductions tab).'),
    ),
  );
}
