/**
 * Minimal DOM construction helpers (no framework).
 */

export type Child = Node | string | number | null | undefined | false;

export interface Attrs {
  class?: string;
  id?: string;
  title?: string;
  style?: string;
  html?: string;
  dataset?: Record<string, string>;
  on?: Partial<{ [K in keyof HTMLElementEventMap]: (ev: HTMLElementEventMap[K]) => void }>;
  [attr: string]: unknown;
}

/** Keys set as DOM properties (their attributes only give initial values, or do not exist, e.g. textarea.value). */
const PROPERTIES = new Set(['value', 'checked', 'selected', 'disabled', 'hidden', 'open']);

/**
 * Create an element.
 * @param attrs class/id/title/style, `html` (trusted innerHTML), `dataset`, `on` (event listeners); `value`,
 *        `checked`, `selected`, `disabled`, `hidden`, `open` are set as properties, everything else as attributes
 */
export function h<K extends keyof HTMLElementTagNameMap>(tag: K, attrs: Attrs = {}, ...children: Array<Child | Child[]>): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    switch (k) {
      case 'class':
        el.className = String(v);
        break;
      case 'style':
        el.setAttribute('style', String(v));
        break;
      case 'html':
        el.innerHTML = String(v);
        break;
      case 'dataset':
        Object.assign(el.dataset, v as Record<string, string>);
        break;
      case 'on':
        for (const [ev, fn] of Object.entries(v as Record<string, EventListener>)) el.addEventListener(ev, fn);
        break;
      default:
        if (PROPERTIES.has(k)) (el as unknown as Record<string, unknown>)[k] = v;
        else el.setAttribute(k, v === true ? '' : String(v));
    }
  }
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  }
  return el;
}

/** Remove all children of `el`. */
export function clear(el: Element): void {
  while (el.firstChild) el.removeChild(el.firstChild);
}

/** Replace the children of `el`. */
export function setChildren(el: Element, ...children: Array<Child | Child[]>): void {
  clear(el);
  for (const c of children.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  }
}

/** Where the keyboard focus was: its element's data-focus-key, else its place under the root and its tag and label. */
type FocusMark = { readonly key: string } | { readonly path: readonly number[]; readonly sig: string };

const focusSig = (el: Element): string => `${el.tagName}|${el.getAttribute('aria-label') ?? el.textContent ?? ''}`;

function focusMark(root: Element, el: HTMLElement): FocusMark {
  const key = el.dataset['focusKey'];
  if (key !== undefined) return { key };
  const path: number[] = [];
  for (let e: Element = el; e !== root && e.parentElement !== null; e = e.parentElement) path.unshift(Array.prototype.indexOf.call(e.parentElement.children, e));
  return { path, sig: focusSig(el) };
}

function findFocusMark(root: Element, m: FocusMark): HTMLElement | null {
  if ('key' in m) {
    for (const e of root.querySelectorAll<HTMLElement>('[data-focus-key]')) if (e.dataset['focusKey'] === m.key) return e;
    return null;
  }
  let e: Element | undefined = root;
  for (const i of m.path) {
    e = e.children[i];
    if (e === undefined) return null;
  }
  return e instanceof HTMLElement && focusSig(e) === m.sig ? e : null;
}

/**
 * Run `rebuild`, which replaces content of `root` with a new version of the same view, keeping the scroll positions of
 * `root` and of the elements that scroll it, and the keyboard focus when it was inside `root`: on the new element with
 * the same `data-focus-key` (give one to controls whose label changes, such as a switch), else on the one in the same
 * place with the same tag and label. Without this, removing the focused element fires focusout during the rebuild; a
 * listener that reads the layout then has the browser's scroll anchoring move the panel up by the height of what was
 * removed above the anchor, and the focus goes to the page.
 */
export function rebuildInPlace(root: HTMLElement, rebuild: () => void): void {
  const scrolls: Array<readonly [Element, number]> = [];
  for (let e: Element | null = root; e !== null; e = e.parentElement) scrolls.push([e, e.scrollTop]);
  const active = document.activeElement;
  const focus = active instanceof HTMLElement && active !== root && root.contains(active) ? focusMark(root, active) : null;
  rebuild();
  // (only where it moved: writing scrollTop would stop a smooth scroll in progress)
  for (const [e, top] of scrolls) if (e.scrollTop !== top) e.scrollTop = top;
  if (focus === null || (document.activeElement !== document.body && document.activeElement !== null)) return;
  findFocusMark(root, focus)?.focus({ preventScroll: true });
}

/** A text with the given [start, end) ranges in <mark> (ranges in order, not overlapping). */
export function markedText(text: string, ranges: ReadonlyArray<readonly [number, number]>): Array<string | HTMLElement> {
  const out: Array<string | HTMLElement> = [];
  let last = 0;
  for (const [start, end] of ranges) {
    if (start > last) out.push(text.slice(last, start));
    out.push(h('mark', {}, text.slice(start, end)));
    last = end;
  }
  if (last < text.length) out.push(text.slice(last));
  return out;
}

const flashTimers = new WeakMap<Element, ReturnType<typeof setTimeout>>();

/** Play the class's animation on an element once (again from the start if it is playing), for `ms` milliseconds. */
export function flash(el: HTMLElement, cls = 'flash', ms = 1200): void {
  clearTimeout(flashTimers.get(el));
  el.classList.remove(cls);
  void el.offsetWidth; // (restarts the animation)
  el.classList.add(cls);
  flashTimers.set(
    el,
    setTimeout(() => el.classList.remove(cls), ms),
  );
}

/** The element that scrolls `el` vertically: itself or its nearest ancestor that can scroll (null if none). */
export function scrollParent(el: HTMLElement): HTMLElement | null {
  for (let e: HTMLElement | null = el; e !== null; e = e.parentElement) {
    const overflow = getComputedStyle(e).overflowY;
    if (overflow === 'auto' || overflow === 'scroll') return e;
  }
  return null;
}

/** How to scroll to something: smoothly, unless the user asked for reduced motion. */
export function scrollBehavior(): ScrollBehavior {
  return typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
}

/** Escape text for HTML. */
export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

/** Trigger a download of `text` as a file. */
export function download(filename: string, text: string, mime = 'text/plain'): void {
  const blob = new Blob([text], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: filename, style: 'display:none' });
  document.body.append(a);
  a.click();
  setTimeout(() => {
    URL.revokeObjectURL(url);
    a.remove();
  }, 0);
}

/** Ask the user for a file and read it as text. */
export function pickFile(accept: string): Promise<{ name: string; text: string } | null> {
  return new Promise((resolve) => {
    const input = h('input', { type: 'file', accept, style: 'display:none' });
    input.addEventListener('change', () => {
      const f = input.files?.[0];
      input.remove();
      if (!f) return resolve(null);
      f.text().then((text) => resolve({ name: f.name, text }), () => resolve(null));
    });
    document.body.append(input);
    input.click();
  });
}
