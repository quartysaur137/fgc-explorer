/**
 * Right panel: details of the selected problem (regimes, bounds, derivations) or reduction (all sheet fields, how the
 * engine reads it, and a probe of its evaluation).
 */

import { Analysis, RegimeSummary, regimesFromSpec } from '../engine/analysis';
import { probeRow } from '../engine/explain';
import { describeTheta } from '../engine/freeparams';
import { lbChain, LBFact } from '../engine/lower';
import { constantEnv } from '../engine/rowEval';
import { UBFact } from '../engine/upper';
import { formatNumber } from '../growth/growth';
import { identifierTex, toTex } from '../math/ast';
import { initialScenario, KnobKind, KnobSpec } from '../model/config';
import { CompiledRow, findProblem, Model, Problem, ROW_STATUS_TEXT } from '../model/model';
import { Regime, SpecError } from '../model/regime';
import { h, setChildren } from './dom';
import { boundDecimals, knobValueHtml, statusBadge } from './format';
import { Store } from './store';
import { cellEl, cellHtml, texEl } from './tex';

export interface InspectorCallbacks {
  selectProblem(id: string): void;
  selectRow(id: string): void;
  editRow(id: string): void;
  addKnob(problemId: string, kind: KnobKind, regimeSpec: string): void;
  /** Replace the scenario by the initial one (after asking). */
  restoreInitialSettings(): void;
}

/** Fields of a row shown in the inspector, in order (others are listed after them). */
const ROW_FIELDS = [
  'Assumption/Hypothesis',
  'To-time (generic)',
  'From-time (generic)',
  'Restrictions on to-time',
  'Reduction Runtime',
  'Type',
  'Randomized?',
  'Model',
  'References',
  'Link',
  'Year',
  'Notes',
  'Implications',
  'Status',
  'Confidence',
  'Source(s) read',
  'Fill Notes',
  'Detailed restriction / derivation notes',
  'Independent spot-check',
];

const HIDDEN_FIELDS = new Set(['From (Problem)', 'From (Variation)', 'To (Problem)', 'To (Variation)', 'Reduction ID']);

/** Regime spec text that reproduces a normalized regime (for knobs and pins). */
export function regimeToSpec(r: Regime): string {
  return r.params
    .map((p, i) => {
      const g = r.growths[i]!;
      if (r.logDep.has(p)) return `${p}=${g.kind === 'const' ? 'const' : g.kind === 'log' ? 'polylog' : 'poly'}`;
      if (i === r.normalizer) return `${p}=${r.expScale ? 'log' : '1'}`;
      switch (g.kind) {
        case 'poly':
          return `${p}=${formatNumber(g.exp, 6)}`;
        case 'log':
          return `${p}=polylog`;
        case 'const':
          return `${p}=const${g.value === null ? '' : `:${formatNumber(g.value, 6)}`}`;
        default:
          return `${p}=1`;
      }
    })
    .join(', ');
}

export class Inspector {
  /** Regime key whose derivations are expanded, per problem. */
  private readonly expanded = new Map<string, string>();
  private showAllRegimes = false;
  private probeRegimeKey: string | null = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly store: Store,
    private readonly cb: InspectorCallbacks,
  ) {
    store.subscribe((changes) => {
      if (changes.has('selection') || changes.has('analysis') || changes.has('model')) this.render();
    });
    this.render();
  }

  render(): void {
    const sel = this.store.get().selection;
    const { model, analysis } = this.store.getDerived();
    if (sel === null) return setChildren(this.root, this.welcome(analysis));
    if (sel.kind === 'problem') {
      const p = model.problems.get(sel.id);
      return setChildren(this.root, p ? this.problemView(p, model, analysis) : h('p', {}, `Unknown problem ${sel.id}`));
    }
    const r = model.rowsById.get(sel.id);
    return setChildren(this.root, r ? this.rowView(r, model, analysis) : h('p', {}, `Unknown reduction ${sel.id}`));
  }

  private welcome(analysis: Analysis): HTMLElement[] {
    const counts = new Map<string, number>();
    for (const s of analysis.summaries.values()) counts.set(s.status, (counts.get(s.status) ?? 0) + 1);
    return [
      h('h2', {}, 'Inspector'),
      h('p', {}, 'Click a problem or a reduction in the graph or in the tables below.'),
      h(
        'ul',
        { class: 'legend' },
        (['conflict', 'tight', 'gap', 'lb', 'ub', 'none'] as const).map((s) => h('li', {}, statusBadge(s), ` ${counts.get(s) ?? 0} problems`)),
      ),
      h('p', { class: 'hint' }, 'Edge colors: orange = used by a lower bound, blue = used by an upper bound, purple = both, dashed = not used by the engine.'),
      this.initialSettings(),
    ];
  }

  /** The knobs the scenario starts with (config.initialKnobs), as a side note, with a way back to them. */
  private initialSettings(): HTMLElement {
    const config = this.store.get().config;
    const groups = config.initialKnobs;
    const { model } = this.store.getDerived();
    // The knobs in the order of the groups, with their Bound IDs.
    const initial = initialScenario(config).knobs;
    let next = 0;
    const knobItem = (k: KnobSpec): HTMLElement => {
      const id = initial[next++]?.id ?? '';
      const problem = findProblem(model, k.problem);
      const name = problem
        ? h('a', { href: '#', on: { click: (e) => { e.preventDefault(); this.cb.selectProblem(problem.id); } } }, problem.id)
        : h('span', { title: 'not a problem of the current sheet' }, k.problem);
      return h('li', {}, h('span', { class: 'knob-id' }, `#${id}`), ' ', h('span', { class: `kind kind-${k.kind}` }, k.kind), ' ', name, ': ', h('span', { html: knobValueHtml(k) }));
    };
    return h(
      'section',
      { class: 'initial-settings', id: 'initial-settings' },
      h('h3', {}, 'Initial settings'),
      h(
        'p',
        { class: 'hint' },
        'The hypotheses and algorithms on the left start as listed here. Hypotheses are conjectures, not theorems: switch them off or change their exponents freely.',
      ),
      groups.length === 0
        ? h('p', { class: 'hint' }, 'The engine config defines no initial knobs.')
        : h(
            'ul',
            { class: 'initial-groups' },
            groups.map((g) =>
              h(
                'li',
                {},
                h('span', { class: `onoff ${g.enabled ? 'on' : 'off'}` }, g.enabled ? 'on' : 'off'),
                h('b', {}, g.label),
                g.description ? h('span', { class: 'muted', html: ` — ${cellHtml(g.description)}` }) : null,
                h(
                  'details',
                  {},
                  h('summary', { class: 'small' }, `${g.knobs.length} knob${g.knobs.length === 1 ? '' : 's'}`),
                  h('ul', { class: 'initial-knobs' }, g.knobs.map(knobItem)),
                ),
              ),
            ),
          ),
      h('button', { on: { click: () => this.cb.restoreInitialSettings() } }, 'Restore initial settings'),
    );
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Problem view
  // -------------------------------------------------------------------------------------------------------------------

  private problemView(p: Problem, model: Model, analysis: Analysis): HTMLElement[] {
    const summary = analysis.summaries.get(p.id);
    const out: HTMLElement[] = [
      h('div', { class: 'family' }, cellEl(p.family)),
      h('h2', {}, cellEl(p.variation), ' ', summary && p.isStatic ? statusBadge(summary.status) : null),
      h(
        'div',
        { class: 'meta' },
        p.functions.length > 0
          ? texEl(p.functions.map((f) => `${identifierTex(f.name)}(${f.params.map(identifierTex).join(', ')})`).join(',\\ '))
          : h('em', {}, 'no signature'),
        h('span', { class: 'hint' }, ` (signature from ${p.signatureSource === 'to-time' ? 'the To-time column' : p.signatureSource})`),
        p.logParams.size > 0 ? h('div', { class: 'hint' }, `log-dependent: ${[...p.logParams].join(', ')}`) : null,
        p.timeType === 'exp' ? h('div', { class: 'hint' }, 'exponential-time problem: exponents are with respect to 2^n') : null,
      ),
    ];
    if (!p.isStatic) {
      out.push(h('p', { class: 'note' }, 'This problem has several time functions (preprocessing / update / query) or no signature; it is shown but not propagated.'));
    } else if (summary) {
      out.push(this.regimesTable(p, summary.regimes, analysis));
      out.push(this.pinForm(p));
    }
    out.push(this.rowList('Reductions from this problem (algorithms for the targets give algorithms here)', p.asSource, model, 'target'));
    out.push(this.rowList('Reductions to this problem (hardness of the sources transfers here)', p.asTarget, model, 'source'));
    return out;
  }

  private regimesTable(p: Problem, regimes: readonly RegimeSummary[], analysis: Analysis): HTMLElement {
    const limit = this.showAllRegimes ? regimes.length : 12;
    const expandedKey = this.expanded.get(p.id) ?? null;
    const rows: HTMLElement[] = [];
    for (const s of regimes.slice(0, limit)) {
      const isOpen = s.regime.key === expandedKey;
      const d = boundDecimals(s.lb?.exponent, s.ub?.exponent);
      rows.push(
        h(
          'tr',
          {
            class: `regime-row ${isOpen ? 'open' : ''}`,
            title: 'click to show the derivations',
            on: {
              click: () => {
                this.expanded.set(p.id, isOpen ? '' : s.regime.key);
                this.render();
              },
            },
          },
          h('td', {}, texEl(s.regime.describeTex()), h('div', { class: 'origins' }, s.origins.join(', '))),
          h('td', { class: 'num' }, s.lb ? texEl(s.regime.timeTex(s.lb.exponent, d)) : '—'),
          h('td', { class: 'num' }, s.ub ? texEl(s.regime.timeTex(s.ub.exponent, d)) : s.ubComputed ? '—' : h('span', { class: 'hint', title: 'not computed (too many regimes); open to compute' }, '?')),
          h('td', {}, statusBadge(s.status)),
        ),
      );
      if (isOpen) rows.push(h('tr', { class: 'derivation-row' }, h('td', { colspan: 4 }, this.derivations(p, s, analysis))));
    }
    return h(
      'div',
      { class: 'regimes' },
      h('h3', {}, `Regimes (${regimes.length})`),
      h('table', { class: 'grid' }, h('thead', {}, h('tr', {}, h('th', {}, 'regime'), h('th', {}, 'lower'), h('th', {}, 'upper'), h('th', {}, 'status'))), h('tbody', {}, rows)),
      regimes.length > limit
        ? h('button', { class: 'link', on: { click: () => ((this.showAllRegimes = true), this.render()) } }, `show all ${regimes.length} regimes`)
        : null,
    );
  }

  private derivations(p: Problem, s: RegimeSummary, analysis: Analysis): HTMLElement {
    const spec = regimeToSpec(s.regime);
    let ub = s.ub;
    if (!s.ubComputed) ub = analysis.upper.query(p.id, s.regime);
    return h(
      'div',
      { class: 'derivations' },
      h('div', { class: 'spec' }, 'regime spec: ', h('code', {}, spec)),
      h(
        'div',
        { class: 'buttons' },
        h('button', { on: { click: () => this.cb.addKnob(p.id, 'LB', spec) } }, '＋ LB knob here'),
        h('button', { on: { click: () => this.cb.addKnob(p.id, 'UB', spec) } }, '＋ UB knob here'),
      ),
      h('h4', {}, 'Lower bound'),
      s.lb ? this.lbDerivation(s.lb, analysis) : h('p', { class: 'hint' }, 'none'),
      h('h4', {}, 'Upper bound'),
      ub ? h('ul', { class: 'tree' }, this.ubDerivation(ub, analysis, 0)) : h('p', { class: 'hint' }, 'none'),
    );
  }

  private knobText(analysis: Analysis, knobId: string): string {
    const k = analysis.scenario.knobs.find((x) => x.id === knobId);
    if (!k) return 'knob';
    return `${k.note ? `${k.note}: ` : ''}${k.kind} knob${k.formula ? ` (${k.formula})` : ''}`;
  }

  private problemLink(id: string): HTMLElement {
    const p = this.store.getDerived().model.problems.get(id);
    return h(
      'a',
      { href: '#', on: { click: (e) => (e.preventDefault(), this.cb.selectProblem(id)) } },
      p ? cellEl(p.variation) : id,
    );
  }

  private rowLink(id: string): HTMLElement {
    return h('a', { href: '#', on: { click: (e) => (e.preventDefault(), this.cb.selectRow(id)) } }, `#${id}`);
  }

  private lbDerivation(f: LBFact, analysis: Analysis): HTMLElement {
    const model = this.store.getDerived().model;
    const chain = lbChain(f);
    return h(
      'ol',
      { class: 'chain' },
      chain.map((x) => {
        const row = x.origin.kind === 'row' ? model.rowsById.get(x.origin.rowId) : undefined;
        return h(
          'li',
          {},
          this.problemLink(x.problem),
          ' ',
          texEl(`\\ge ${x.regime.timeTex(x.exponent, boundDecimals(x.exponent, undefined))}`),
          ' at ',
          texEl(x.regime.describeTex()),
          h(
            'div',
            { class: 'via' },
            x.origin.kind === 'knob'
              ? h('span', { class: 'knob-ref' }, this.knobText(analysis, x.origin.knobId))
              : h(
                  'span',
                  {},
                  'via reduction ',
                  this.rowLink(x.origin.rowId),
                  row && row.free.length > 0 ? ` with ${describeTheta(row.free, x.origin.theta)}` : '',
                  x.origin.rtExponent === null ? ' (reduction runtime unknown: assumed negligible)' : '',
                  ' from:',
                ),
          ),
        );
      }),
    );
  }

  private ubDerivation(f: UBFact, analysis: Analysis, depth: number): HTMLElement {
    const model = this.store.getDerived().model;
    const row = f.origin.kind === 'row' ? model.rowsById.get(f.origin.rowId) : undefined;
    return h(
      'li',
      {},
      this.problemLink(f.problem),
      ' ',
      texEl(`\\le ${f.regime.timeTex(f.exponent, boundDecimals(undefined, f.exponent))}`),
      depth > 0 ? [' at ', texEl(f.regime.describeTex())] : null,
      h(
        'div',
        { class: 'via' },
        f.origin.kind === 'knob'
          ? h('span', { class: 'knob-ref' }, this.knobText(analysis, f.origin.knobId))
          : h(
              'span',
              {},
              'via reduction ',
              this.rowLink(f.origin.rowId),
              row && row.free.length > 0 ? ` with ${describeTheta(row.free, f.origin.theta)}` : '',
              f.origin.rtExponent === null ? ' (reduction runtime unknown)' : ` (reduction itself: exponent ${formatNumber(f.origin.rtExponent, 3)})`,
              f.origin.children.length > 0 ? ', using:' : ' (calls on constant-size instances only)',
            ),
      ),
      f.origin.kind === 'row' && f.origin.children.length > 0 ? h('ul', {}, f.origin.children.map((c) => this.ubDerivation(c, analysis, depth + 1))) : null,
    );
  }

  private pinForm(p: Problem): HTMLElement {
    const pinned = this.store.get().pinned[p.id] ?? [];
    const input = h('input', { type: 'text', class: 'mono', placeholder: p.regimeSpecs[0] ?? 'n=1' });
    const msg = h('span', { class: 'issue', hidden: true });
    const pin = (): void => {
      const spec = input.value.trim();
      try {
        regimesFromSpec(p, spec);
      } catch (e) {
        msg.textContent = e instanceof SpecError ? e.message : String(e);
        msg.hidden = false;
        return;
      }
      this.store.update((s) => ({ ...s, pinned: { ...s.pinned, [p.id]: [...(s.pinned[p.id] ?? []), spec] } }));
    };
    return h(
      'div',
      { class: 'pin' },
      h('h3', {}, 'Pin a regime'),
      h('div', { class: 'row' }, input, h('button', { on: { click: pin } }, 'Pin'), msg),
      pinned.length > 0
        ? h(
            'ul',
            {},
            pinned.map((spec, i) =>
              h(
                'li',
                {},
                h('code', {}, spec),
                ' ',
                h(
                  'button',
                  {
                    class: 'icon',
                    title: 'unpin',
                    on: {
                      click: () =>
                        this.store.update((s) => ({ ...s, pinned: { ...s.pinned, [p.id]: (s.pinned[p.id] ?? []).filter((_, j) => j !== i) } })),
                    },
                  },
                  '×',
                ),
              ),
            ),
          )
        : null,
    );
  }

  private rowList(title: string, ids: readonly string[], model: Model, show: 'source' | 'target'): HTMLElement {
    return h(
      'div',
      { class: 'rowlist' },
      h('h3', {}, `${title} (${ids.length})`),
      h(
        'ul',
        {},
        ids.map((id) => {
          const r = model.rowsById.get(id);
          if (!r) return null;
          return h(
            'li',
            { class: r.status === 'ok' ? '' : 'unused' },
            this.rowLink(id),
            ' ',
            this.problemLink(show === 'target' ? r.target : r.source),
            r.status === 'ok' ? '' : h('span', { class: 'hint' }, ` (${ROW_STATUS_TEXT[r.status]})`),
          );
        }),
      ),
    );
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Row view
  // -------------------------------------------------------------------------------------------------------------------

  private rowView(r: CompiledRow, model: Model, analysis: Analysis): HTMLElement[] {
    const disabled = analysis.scenario.settings.disabledRows.includes(r.id);
    const out: HTMLElement[] = [
      h('div', { class: 'family' }, `Reduction #${r.id}`),
      h('h2', {}, this.problemLink(r.source), ' → ', this.problemLink(r.target)),
      h(
        'div',
        { class: 'meta' },
        h('span', { class: `badge row-${r.status}` }, ROW_STATUS_TEXT[r.status]),
        r.randomized ? h('span', { class: 'badge' }, 'randomized') : null,
        disabled ? h('span', { class: 'badge' }, 'disabled in this scenario') : null,
      ),
      r.messages.length > 0 ? h('ul', { class: 'messages' }, r.messages.map((m) => h('li', {}, m))) : null,
      h(
        'div',
        { class: 'buttons' },
        h('button', { on: { click: () => this.cb.editRow(r.id) } }, 'Edit row'),
        h(
          'button',
          {
            on: {
              click: () =>
                this.store.update((s) => {
                  const rows = s.scenario.settings.disabledRows;
                  const next = rows.includes(r.id) ? rows.filter((x) => x !== r.id) : [...rows, r.id];
                  return { ...s, scenario: { ...s.scenario, settings: { ...s.scenario.settings, disabledRows: next } } };
                }),
            },
          },
          disabled ? 'Enable in scenario' : 'Disable in scenario',
        ),
      ),
      this.engineView(r, model, analysis),
      this.fieldsView(r, model),
    ].filter((x): x is HTMLElement => x !== null);
    return out;
  }

  private engineView(r: CompiledRow, model: Model, analysis: Analysis): HTMLElement {
    const facts: LBFact[] = [];
    for (const m of analysis.lower.facts.values()) for (const f of m.values()) if (f.origin.kind === 'row' && f.origin.rowId === r.id) facts.push(f);
    const use = analysis.rowUse.get(r.id);
    return h(
      'div',
      { class: 'engine' },
      h('h3', {}, 'How the engine reads this row'),
      r.from
        ? h(
            'div',
            {},
            h('div', { class: 'label' }, `From-time${r.fromOverridden ? ' (config override)' : ''}:`),
            h('ul', {}, r.from.alternatives.map((a, i) => h('li', {}, i > 0 ? '⊆ ' : '', texEl(toTex(a))))),
          )
        : h('p', { class: 'hint' }, 'no From-time formula'),
      h('div', {}, h('span', { class: 'label' }, `Reduction runtime${r.rtOverridden ? ' (override)' : ''}: `), r.rt ? texEl(toTex(r.rt.alternatives[0]!)) : h('em', {}, 'unknown')),
      r.free.length > 0
        ? h(
            'div',
            {},
            h('span', { class: 'label' }, 'Free parameters: '),
            h(
              'ul',
              {},
              r.free.map((f) =>
                h(
                  'li',
                  {},
                  texEl(identifierTex(f.def.name)),
                  ` ${f.def.type}`,
                  f.def.type === 'int' ? ` ∈ {${f.def.values!.join(', ')}}` : '',
                  f.def.type === 'real' ? ` ∈ [${f.def.min}, ${f.def.max}]` : '',
                  f.def.type === 'size' ? ` = (${f.def.base ?? 'N'})^τ, τ ∈ [${f.def.min}, ${f.def.max}]` : '',
                  f.def.type === 'fixed' ? ` = ${f.def.value ?? 'unknown constant'}` : '',
                  f.def.note ? h('span', { class: 'hint' }, ` — ${f.def.note}`) : '',
                ),
              ),
            ),
          )
        : null,
      r.defs.length > 0
        ? h(
            'div',
            {},
            h('span', { class: 'label' }, 'Abbreviations: '),
            h('ul', {}, r.defs.map((d) => h('li', {}, texEl(`${identifierTex(d.name)} = ${d.alternatives.map(toTex).join(' = ')}`), h('span', { class: 'hint' }, ` (${d.origin})`)))),
          )
        : null,
      r.requiresText ? h('div', {}, h('span', { class: 'label' }, 'Applies only when the source regime satisfies: '), h('code', {}, r.requiresText)) : null,
      r.annotation?.note ? h('div', { class: 'hint' }, `Config note: ${r.annotation.note}`) : null,
      h(
        'div',
        {},
        h('span', { class: 'label' }, 'In the current scenario: '),
        `${use?.lb ?? 0} displayed lower bound(s), ${use?.ub ?? 0} upper-bound derivation step(s) use this row.`,
      ),
      facts.length > 0
        ? h(
            'ul',
            { class: 'facts' },
            facts.slice(0, 10).map((f) => h('li', {}, texEl(`\\ge ${f.regime.timeTex(f.exponent, boundDecimals(f.exponent, undefined))}`), ' at ', texEl(f.regime.describeTex()))),
            facts.length > 10 ? h('li', { class: 'hint' }, `… ${facts.length - 10} more`) : null,
          )
        : null,
      r.status === 'ok' ? this.probeView(r, model, analysis) : null,
    );
  }

  private probeView(r: CompiledRow, model: Model, analysis: Analysis): HTMLElement {
    const summary = analysis.summaries.get(r.source);
    const regimes = summary?.regimes ?? [];
    if (regimes.length === 0) return h('div');
    const chosen = regimes.find((s) => s.regime.key === this.probeRegimeKey) ?? regimes[0]!;
    const select = h(
      'select',
      {
        on: {
          change: (e) => {
            this.probeRegimeKey = (e.target as HTMLSelectElement).value;
            this.render();
          },
        },
      },
      regimes.slice(0, 40).map((s) => h('option', { value: s.regime.key, selected: s === chosen }, s.regime.key)),
    );
    const probes = probeRow(model, r, chosen.regime, constantEnv(model, analysis.scenario.constants), analysis.scenario.settings);
    return h(
      'div',
      { class: 'probe' },
      h('h4', {}, 'Probe: produced instances at a source regime'),
      select,
      h(
        'table',
        { class: 'grid small' },
        h('thead', {}, h('tr', {}, h('th', {}, 'free params'), h('th', {}, 'calls (target regime, scale)'), h('th', {}, 'RT'), h('th', {}, 'F at T=N′'))),
        h(
          'tbody',
          {},
          probes.map((p) =>
            h(
              'tr',
              {},
              h('td', {}, describeTheta(r.free, p.theta) || '—'),
              h(
                'td',
                {},
                p.error
                  ? h('span', { class: 'issue' }, p.error)
                  : p.calls.map((c) => h('div', {}, c.regime ? [texEl(c.regime.describeTex()), ` (normalizer = N^${formatNumber(c.scale, 3)})`] : 'constant-size instance')),
              ),
              h('td', { class: 'num' }, p.rtExponent === null ? '?' : formatNumber(p.rtExponent, 3)),
              h('td', { class: 'num' }, p.overheadAtOne === null ? '' : formatNumber(p.overheadAtOne, 3)),
            ),
          ),
        ),
      ),
    );
  }

  private fieldsView(r: CompiledRow, model: Model): HTMLElement {
    const table = model.table;
    const cols = [...ROW_FIELDS.filter((c) => table.hasColumn(c)), ...table.columns.filter((c) => !ROW_FIELDS.includes(c) && !HIDDEN_FIELDS.has(c))];
    return h(
      'div',
      { class: 'fields' },
      h('h3', {}, 'Sheet fields'),
      h(
        'dl',
        {},
        cols.flatMap((c) => {
          const v = table.get(r.index, c);
          if (v.trim() === '') return [];
          const isLink = /^https?:\/\//.test(v.trim());
          return [h('dt', {}, c), h('dd', {}, isLink ? h('a', { href: v.trim(), target: '_blank', rel: 'noopener' }, v.trim()) : h('span', { html: cellHtml(v) }))];
        }),
      ),
    );
  }
}
