/**
 * Right panel: details of the selected problems (regimes, bounds, derivations) and reductions (all sheet fields, how
 * the engine reads them, and a probe of their evaluation). Several selected items get one collapsible section each.
 */

import { Analysis, clippedRegimes, CONFLICT_TOL, RegimeSummary, regimesFromSpec, rowUsable, upperOnDemand } from '../engine/analysis';
import { probeRow } from '../engine/explain';
import { describeTheta } from '../engine/freeparams';
import { explainLower, lbChain, LBFact } from '../engine/lower';
import { constantEnv } from '../engine/rowEval';
import { UBFact, ubParts } from '../engine/upper';
import { compareRates, formatNumber, Rate } from '../growth/growth';
import { identifierTex, toTex } from '../math/ast';
import { canonicalProblem } from '../model/boxes';
import { initialScenario, KnobKind, KnobSpec } from '../model/config';
import { constraintTex } from '../model/constraints';
import { CompiledRow, findProblem, Model, Problem, ROW_STATUS_TEXT } from '../model/model';
import { Regime, SpecError } from '../model/regime';
import { h, rebuildInPlace, setChildren } from './dom';
import { boundDecimals, knobRegime, knobValueHtml, problemLabel, regimeToSpec, shownUb, statusBadge } from './format';
import { problemBoundsLine } from './paramFamily';
import { refAttrs } from './hover';
import { isAdditive, itemKey, SelectionItem, withRegime } from './selection';
import { Store } from './store';
import { cellEl, cellHtml, plainText, texEl } from './tex';

export interface InspectorCallbacks {
  /** A click on a problem link; `additive` when Shift, Ctrl or ⌘ was held. */
  selectProblem(id: string, additive: boolean): void;
  selectRow(id: string, additive: boolean): void;
  /** Remove one item from the selection. */
  deselect(item: SelectionItem): void;
  clearSelection(): void;
  editRow(id: string): void;
  /** Show a bound (by Bound ID) in its problem's box in the left panel. */
  revealKnob(id: string): void;
  /** Open the form for a new bound in a problem's box, its kind and regime prefilled (an empty regime: the main one). */
  addKnob(problemId: string, kind: KnobKind, regimeSpec: string): void;
  /** Replace the scenario by the initial one (after asking). */
  restoreInitialSettings(): void;
}

/** Fields of a row shown in the inspector, in order (others are listed after them). */
/**
 * A mark after a bound of a regime that comes from another regime of the problem (RegimeSummary: the lower bound of a
 * regime it contains, the upper bound of one that contains it, SPEC §2.3), saying which.
 */
function carriedMark(s: RegimeSummary, kind: 'lb' | 'ub'): HTMLElement | null {
  const f = kind === 'lb' ? s.lb : s.ub;
  if (f === null || f.regime.key === s.regime.key) return null;
  const title =
    kind === 'lb'
      ? `carried over from the regime ${regimeToSpec(f.regime)}, which this one contains (its instances are among these)`
      : `carried over from the regime ${regimeToSpec(f.regime)}, which contains this one (its algorithms solve these instances)`;
  return h('span', { class: 'carried', title }, '†');
}

/**
 * A mark after an upper bound whose search reached the limit of problem regimes (UB_LIMITS.nodes), so that it may be weaker
 * than the settings allow (null otherwise; the status line warns as well).
 */
function capMark(analysis: Analysis, problem: string, s: RegimeSummary): HTMLElement | null {
  if (s.ub === null || analysis.upper.capped.length + analysis.upperOverlay.capped.length === 0) return null;
  if (!analysis.upper.reachedCapAt(problem, s.ub.regime) && !analysis.upperOverlay.reachedCapAt(problem, s.ub.regime)) return null;
  return h('span', { class: 'cap-mark', title: 'the search for this upper bound reached its limit of problem regimes: it may be weaker than these settings allow' }, ' ⚠');
}

const ROW_FIELDS = [
  'Assumption/Hypothesis',
  'To-time (generic)',
  'From-time (generic)',
  'Restrictions on to-time',
  'Reduction Runtime',
  'Type',
  'Randomized?',
  'Model',
  'References',
  'Link',
  'Year',
  'Notes',
  'Implications',
  'Status',
  'Confidence',
  'Source(s) read',
  'Fill Notes',
  'Detailed restriction / derivation notes',
  'Independent spot-check',
];

const HIDDEN_FIELDS = new Set(['From (Problem)', 'From (Variation)', 'To (Problem)', 'To (Variation)', 'Reduction ID']);

/** At most this many regimes of a problem are listed before "show all". */
const MAX_LISTED_REGIMES = 12;

/** "through 3 reductions (the one shown takes 2)": an equally good derivation, against the one shown. */
function throughText(n: number, shown: number): string {
  const count = (k: number): string => `${k} reduction${k === 1 ? '' : 's'}`;
  return `through ${count(n)} (the one shown ${shown === 0 ? 'is given directly' : `takes ${count(shown)}`})`;
}

/** "2", "2 and 3", "2, 3 and 5". */
function listText(items: readonly string[]): string {
  return items.length <= 1 ? (items[0] ?? '') : `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
}

/** The mark of a derivation item that is one lap of a cycle (its bound has changed since). */
function lapMark(): HTMLElement {
  return h('span', { class: 'lap-mark', title: 'one lap of the cycle above (bounds as they were then)' }, '↻ ');
}

export class Inspector {
  /** Problems whose regimes are all listed (not only the first ones). */
  private readonly allRegimes = new Set<string>();
  /** Source regime of the probe, per reduction. */
  private readonly probeRegime = new Map<string, string>();
  /** Items whose section is collapsed (when several are selected), by itemKey. */
  private readonly collapsed = new Set<string>();
  /** Open lists of the reductions that could give a bound ("lb#problem#regime key", "ub#…"). */
  private readonly whyOpen = new Set<string>();
  /** The initial-settings groups whose list of knobs is open ("index:label"). */
  private readonly openKnobLists = new Set<string>();
  /** The items (itemKey) the view was last built for: a render for the same ones is a new version of the same view. */
  private renderedView: string | null = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly store: Store,
    private readonly cb: InspectorCallbacks,
  ) {
    store.subscribe((changes) => {
      if (changes.has('selection') || changes.has('analysis') || changes.has('model')) this.render();
    });
    this.render();
  }

  render(): void {
    const sel = this.store.get().selection;
    const view = sel.map(itemKey).join('\n');
    const same = view === this.renderedView;
    this.renderedView = view;
    // A new version of the same view (a new analysis, e.g. after a group switch; a section opened) stays where it was
    // scrolled to, with the focus on the same control.
    if (same) rebuildInPlace(this.root, () => this.build(sel));
    else this.build(sel);
  }

  private build(sel: readonly SelectionItem[]): void {
    const { analysis } = this.store.getDerived();
    if (sel.length === 0) return setChildren(this.root, this.welcome(analysis));
    if (sel.length === 1) return setChildren(this.root, this.itemView(sel[0]!, true));
    setChildren(
      this.root,
      h(
        'div',
        { class: 'multi-head' },
        h('h2', {}, `${sel.length} selected`),
        h(
          'div',
          { class: 'buttons' },
          h('button', { class: 'link', on: { click: () => this.setCollapsed(sel, false) } }, 'Expand all'),
          h('button', { class: 'link', on: { click: () => this.setCollapsed(sel, true) } }, 'Collapse all'),
          h('button', { class: 'link', title: 'select nothing', on: { click: () => this.cb.clearSelection() } }, 'Clear'),
        ),
        h('p', { class: 'hint' }, 'Shift-click (or Ctrl/⌘-click) a problem or reduction to add it or to remove it.'),
      ),
      sel.map((item) => this.itemSection(item)),
    );
  }

  private setCollapsed(items: readonly SelectionItem[], collapsed: boolean): void {
    for (const x of items) {
      if (collapsed) this.collapsed.add(itemKey(x));
      else this.collapsed.delete(itemKey(x));
    }
    this.render();
  }

  /** One selected item among several: a collapsible section (its body is built only while open). */
  private itemSection(item: SelectionItem): HTMLElement {
    const key = itemKey(item);
    const open = !this.collapsed.has(key);
    const remove = h(
      'button',
      {
        class: 'icon',
        title: 'remove from the selection',
        'aria-label': 'remove from the selection',
        on: {
          click: (e) => {
            e.preventDefault();
            e.stopPropagation();
            this.cb.deselect(item);
          },
        },
      },
      '×',
    );
    const details = h(
      'details',
      { class: `item item-${item.kind}`, open },
      h('summary', {}, h('span', { class: 'item-title', ...refAttrs(item) }, this.itemTitle(item)), remove),
      open ? h('div', { class: 'item-body' }, this.itemView(item, false)) : null,
    );
    details.addEventListener('toggle', () => {
      if (details.open === !this.collapsed.has(key)) return; // not a change by the user
      if (details.open) this.collapsed.delete(key);
      else this.collapsed.add(key);
      this.render();
    });
    return details;
  }

  /** Short title of an item: a problem with its status and bounds, or a reduction with its ends. */
  private itemTitle(item: SelectionItem): (HTMLElement | string)[] {
    const { model, analysis } = this.store.getDerived();
    if (item.kind === 'problem') {
      const p = model.problems.get(item.id);
      if (!p) return [item.id];
      const summary = analysis.summaries.get(p.id);
      return [
        h('b', {}, problemLabel(p)),
        h('span', { class: 'muted' }, p.family === '' ? ' ' : ` · ${plainText(p.family)} `),
        summary && p.isStatic ? statusBadge(summary.status) : '',
        summary?.primary ? h('span', { class: 'mono small' }, ` ${problemBoundsLine(analysis, summary)}`) : '',
      ];
    }
    const r = model.rowsById.get(item.id);
    if (!r) return [`Reduction ${item.id}`];
    const name = (id: string): string => {
      const p = model.problems.get(id);
      return p ? problemLabel(p) : id;
    };
    return [h('b', {}, r.id), ` ${name(r.source)} → ${name(r.target)} `, h('span', { class: `badge row-${r.status}` }, ROW_STATUS_TEXT[r.status])];
  }

  /** The details of an item; `full` adds its heading (a single selection has no section title). */
  private itemView(item: SelectionItem, full: boolean): HTMLElement[] {
    const { model, analysis } = this.store.getDerived();
    if (item.kind === 'problem') {
      const p = model.problems.get(item.id);
      return p ? this.problemView(p, item.regime, model, analysis, full) : [h('p', {}, `Unknown problem ${item.id}`)];
    }
    const r = model.rowsById.get(item.id);
    return r ? this.rowView(r, model, analysis, full) : [h('p', {}, `Unknown reduction ${item.id}`)];
  }

  private welcome(analysis: Analysis): HTMLElement[] {
    const counts = new Map<string, number>();
    let dynamic = 0;
    for (const s of analysis.summaries.values()) {
      if (s.problem.isStatic) counts.set(s.status, (counts.get(s.status) ?? 0) + 1);
      else dynamic += 1;
    }
    return [
      h('h2', {}, 'Inspector'),
      h('p', {}, 'Click a problem or a reduction in the graph or in the tables below; Shift-click (or Ctrl/⌘-click) to select several.'),
      h(
        'ul',
        { class: 'legend' },
        (['conflict', 'tight', 'gap', 'lb', 'ub', 'none'] as const).map((s) => h('li', {}, statusBadge(s), ` ${counts.get(s) ?? 0} problems`)),
        dynamic > 0 ? h('li', { title: 'dynamic and multi-function problems are shown (dashed in the graph) but not analyzed' }, h('span', { class: 'badge' }, 'dynamic'), ` ${dynamic} problems`) : null,
      ),
      h('p', { class: 'hint' }, 'Edge colors: orange = used by a lower bound, blue = used by an upper bound, purple = both, dashed = not used by the engine.'),
      this.initialSettings(),
    ];
  }

  /** The knobs the scenario starts with (config.initialKnobs), as a side note, with a way back to them. */
  private initialSettings(): HTMLElement {
    const config = this.store.get().config;
    const groups = config.initialKnobs;
    const { model } = this.store.getDerived();
    // The knobs in the order of the groups, with their Bound IDs (links to those the left panel has, for the same
    // problem: a knob of the user's may have the ID, e.g. from a bounds CSV).
    const initial = initialScenario(config).knobs;
    const problemOf = (name: string): string => findProblem(model, name)?.id ?? name;
    const current = new Map(this.store.get().scenario.knobs.map((k) => [k.id, problemOf(k.problem)]));
    let next = 0;
    const knobItem = (k: KnobSpec): HTMLElement => {
      const id = initial[next++]?.id ?? '';
      const problem = findProblem(model, k.problem);
      const name = problem
        ? h('a', { href: '#', ...refAttrs({ kind: 'problem', id: problem.id }), on: { click: (e) => { e.preventDefault(); this.cb.selectProblem(problem.id, isAdditive(e)); } } }, problem.id)
        : h('span', { title: 'not a problem of the current sheet' }, k.problem);
      const regime = k.exponent !== undefined ? knobRegime(model, k) : null;
      return h(
        'li',
        {},
        current.get(id) === problemOf(k.problem) ? this.knobLink(id, problem?.id, 'knob-id') : h('span', { class: 'knob-id', title: 'not in the left panel' }, id),
        ' ',
        h('span', { class: `kind kind-${k.kind}` }, k.kind),
        ' ',
        name,
        ': ',
        h('span', { html: knobValueHtml(k, regime) }),
      );
    };
    // Each group's switch shows whether its knobs on the left are on (all, some or none) and switches them all at once.
    const groupIds: string[][] = [];
    let at = 0;
    for (const g of groups) {
      groupIds.push(initial.slice(at, at + g.knobs.length).map((k) => k.id));
      at += g.knobs.length;
    }
    const groupSwitch = (g: (typeof groups)[number], ids: readonly string[], key: string): HTMLElement => {
      const problems = new Map(g.knobs.map((k, i) => [ids[i]!, problemOf(k.problem)]));
      const present = this.store.get().scenario.knobs.filter((k) => problems.get(k.id) === problemOf(k.problem));
      if (present.length === 0) return h('span', { class: 'onoff', title: 'its knobs are not in the left panel (removed, or replaced by a scenario or bounds file)' }, '—');
      const on = present.filter((k) => k.enabled).length;
      const state = on === present.length ? 'on' : on === 0 ? 'off' : 'some';
      const turnOn = state !== 'on';
      return h(
        'button',
        {
          class: `onoff ${state}`,
          // (its label changes when it is switched: the focus finds it again by this key)
          dataset: { focusKey: `switch:${key}` },
          'aria-pressed': state === 'on' ? 'true' : state === 'off' ? 'false' : 'mixed',
          'aria-label': `${g.label}: ${state === 'some' ? `${on} of ${present.length} knobs on` : state}; switch all ${turnOn ? 'on' : 'off'}`,
          title: `${state === 'some' ? `${on} of ${present.length} of its knobs are on` : `its knobs are ${state}`} (it starts ${g.enabled ? 'on' : 'off'}); click to switch all ${present.length} ${turnOn ? 'on' : 'off'}`,
          on: {
            click: () =>
              this.store.update((s) => ({
                ...s,
                scenario: { ...s.scenario, knobs: s.scenario.knobs.map((k) => (problems.get(k.id) === problemOf(k.problem) ? { ...k, enabled: turnOn } : k)) },
              })),
          },
        },
        state,
      );
    };
    return h(
      'section',
      { class: 'initial-settings', id: 'initial-settings' },
      h('h3', {}, 'Initial settings'),
      h(
        'p',
        { class: 'hint' },
        'The hypotheses and algorithms on the left start as listed here. Hypotheses are conjectures, not theorems: switch them off or change their exponents freely. The switch before a group switches all its knobs on the left at once.',
      ),
      groups.length === 0
        ? h('p', { class: 'hint' }, 'The engine config defines no initial knobs.')
        : h(
            'ul',
            { class: 'initial-groups' },
            groups.map((g, gi) => {
              const key = `${gi}:${g.label}`;
              // (a list of knobs stays open when the view is built again, e.g. after a switch)
              const list = h(
                'details',
                { open: this.openKnobLists.has(key) },
                h('summary', { class: 'small' }, `${g.knobs.length} knob${g.knobs.length === 1 ? '' : 's'}`),
                h('ul', { class: 'initial-knobs' }, g.knobs.map(knobItem)),
              );
              list.addEventListener('toggle', () => {
                if (list.open) this.openKnobLists.add(key);
                else this.openKnobLists.delete(key);
              });
              return h(
                'li',
                {},
                groupSwitch(g, groupIds[gi]!, key),
                h('b', {}, g.label),
                g.description ? h('span', { class: 'muted', html: ` — ${cellHtml(g.description)}` }) : null,
                list,
              );
            }),
          ),
      h('button', { on: { click: () => this.cb.restoreInitialSettings() } }, 'Restore initial settings'),
    );
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Problem view
  // -------------------------------------------------------------------------------------------------------------------

  private problemView(p: Problem, regimeKey: string | undefined, model: Model, analysis: Analysis, full: boolean): HTMLElement[] {
    const summary = analysis.summaries.get(p.id);
    const out: HTMLElement[] = [
      ...(full
        ? [
            // (problems without a family have no family line)
            ...(p.family === '' ? [] : [h('div', { class: 'family' }, cellEl(p.family))]),
            h('h2', {}, cellEl(p.variation), ' ', summary && p.isStatic ? statusBadge(summary.status) : null),
          ]
        : []),
      h(
        'div',
        { class: 'meta' },
        p.functions.length > 0
          ? texEl(p.functions.map((f) => `${identifierTex(f.name)}(${f.params.map(identifierTex).join(', ')})`).join(',\\ '))
          : h('em', {}, 'no signature'),
        h('span', { class: 'hint' }, ` (signature from ${p.signatureSource === 'to-time' ? 'the To-time column' : p.signatureSource})`),
        p.logParams.size > 0 ? h('div', { class: 'hint' }, `log-dependent: ${[...p.logParams].join(', ')}`) : null,
        p.constraints.length > 0
          ? h(
              'div',
              { class: 'hint limits', title: 'what every instance satisfies: regimes are clipped to these limits, so none stands for instances that cannot exist' },
              'limits: ',
              p.constraints.flatMap((c, i) => [i > 0 ? ', ' : '', h('span', { class: 'limit', title: c.reason ?? c.text }, texEl(constraintTex(c)))]),
            )
          : null,
        p.timeType === 'exp'
          ? h('div', { class: 'hint', html: 'exponential-time problem: running times 2<sup>c·n<sup>a</sup></sup> with exponent c and power a (1 unless a bound sets it)' })
          : null,
      ),
    ];
    if (!p.isStatic) {
      out.push(h('p', { class: 'note' }, 'This problem has several time functions (preprocessing / update / query) or no signature; it is shown but not propagated.'));
      const list = this.knobList(p, model);
      if (list.knobs > 0) out.push(list.el);
    } else if (summary) {
      out.push(this.regimesTable(p, summary.regimes, regimeKey, analysis));
      out.push(this.knobList(p, model).el);
      out.push(this.pinForm(p));
    }
    out.push(this.rowList('Reductions from this problem (algorithms for the targets give algorithms here)', p.asSource, model, 'target'));
    out.push(this.rowList('Reductions to this problem (hardness of the sources transfers here)', p.asTarget, model, 'source'));
    return out;
  }

  /**
   * The problem's regimes with their bounds, in the order of display (SPEC §6.7): the first is the one the graph shows;
   * by default only those listed (RegimeSummary.listed: nice ones, configured, of knobs, and those other listed bounds
   * are derived through), at most 12. Clicking one opens its derivations, and makes it the regime whose derivations
   * the graph draws in the "bound derivations" focus (by default the first one).
   */
  private regimesTable(p: Problem, regimes: readonly RegimeSummary[], regimeKey: string | undefined, analysis: Analysis): HTMLElement {
    const all = this.allRegimes.has(p.id);
    const listed = regimes.filter((s) => s.listed);
    let shown = all ? [...regimes] : listed.slice(0, MAX_LISTED_REGIMES);
    // (an opened regime is listed in any case, in its place)
    const open = regimes.find((s) => s.regime.key === regimeKey);
    if (open !== undefined && !shown.includes(open)) shown = regimes.filter((s) => shown.includes(s) || s === open);
    const rows: HTMLElement[] = [];
    for (const s of shown) {
      const isOpen = s === open;
      const ubShown = s.ub ? shownUb(s.lb, s.ub) : null;
      const d = boundDecimals(s.lb ?? undefined, ubShown ?? undefined);
      const first = s === regimes[0];
      rows.push(
        h(
          'tr',
          {
            class: `regime-row ${isOpen ? 'open' : ''} ${s.listed ? '' : 'unlisted'}`,
            title: isOpen ? 'click to close the derivations' : 'click to show the derivations (also drawn in the graph in the "bound derivations" focus)',
            on: {
              click: () => this.store.update((st) => ({ ...st, selection: withRegime(st.selection, p.id, isOpen ? undefined : s.regime.key) })),
            },
          },
          h(
            'td',
            {},
            texEl(s.regime.describeTex()),
            h(
              'div',
              { class: 'origins' },
              s.origins.join(', '),
              first ? h('span', { class: 'in-graph', title: 'the graph’s label and color show this regime’s bounds' }, ' · in the graph') : null,
            ),
          ),
          h('td', { class: 'num' }, s.lb ? [texEl(s.regime.timeTex(s.lb, d)), carriedMark(s, 'lb')] : '—'),
          h(
            'td',
            { class: 'num' },
            ubShown
              ? [texEl(s.regime.timeTex(ubShown, d)), carriedMark(s, 'ub'), capMark(analysis, p.id, s)]
              : s.ubComputed
                ? '—'
                : h('span', { class: 'hint', title: 'not computed yet (the other regimes are being checked in the background); open the regime to compute it now' }, '?'),
          ),
          h('td', {}, statusBadge(s.status)),
        ),
      );
      if (isOpen) rows.push(h('tr', { class: 'derivation-row' }, h('td', { colspan: 4 }, this.derivations(p, s, analysis))));
    }
    const beyond = listed.filter((s) => !shown.includes(s)).length;
    const unusual = regimes.filter((s) => !s.listed && !shown.includes(s)).length;
    const more = [
      beyond > 0 ? `${beyond} beyond the first ${MAX_LISTED_REGIMES}` : '',
      unusual > 0 ? `${unusual} with unusual exponents that no listed bound of another problem is derived through` : '',
    ].filter((x) => x !== '');
    return h(
      'div',
      { class: 'regimes' },
      h('h3', {}, shown.length < regimes.length ? `Regimes (${shown.length} of ${regimes.length})` : `Regimes (${regimes.length})`),
      h('table', { class: 'grid' }, h('thead', {}, h('tr', {}, h('th', {}, 'regime'), h('th', {}, 'lower'), h('th', {}, 'upper'), h('th', {}, 'status'))), h('tbody', {}, rows)),
      more.length > 0
        ? h(
            'p',
            { class: 'hint more-regimes' },
            `${beyond + unusual} more (${more.join('; ')}). `,
            h('button', { class: 'link', on: { click: () => (this.allRegimes.add(p.id), this.render()) } }, `show all ${regimes.length}`),
          )
        : all && (listed.length < regimes.length || listed.length > MAX_LISTED_REGIMES)
          ? h('p', { class: 'hint more-regimes' }, h('button', { class: 'link', on: { click: () => (this.allRegimes.delete(p.id), this.render()) } }, 'show fewer'))
          : null,
    );
  }

  private derivations(p: Problem, s: RegimeSummary, analysis: Analysis): HTMLElement {
    const spec = regimeToSpec(s.regime);
    // (not computed yet: its own, unless one carried over from a regime that contains it is better)
    const own = s.ubComputed ? null : upperOnDemand(analysis, p.id, s.regime);
    const ub = own !== null && (s.ub === null || compareRates(own, s.ub, 1e-9) < 0) ? own : s.ub;
    const from = (f: { readonly regime: Regime } | null, kind: 'lb' | 'ub'): HTMLElement | null =>
      f === null || f.regime.key === s.regime.key
        ? null
        : h(
            'p',
            { class: 'hint carried-note' },
            'From the regime ',
            texEl(f.regime.describeTex()),
            kind === 'lb'
              ? ', which this one contains: its instances are instances here too, so its lower bound holds here.'
              : ', which contains this one: its algorithms solve every instance here.',
          );
    return h(
      'div',
      { class: 'derivations' },
      h('div', { class: 'spec' }, 'regime spec: ', h('code', {}, spec)),
      h(
        'div',
        { class: 'buttons' },
        h('button', { title: 'add a lower bound at this regime (in the problem’s box on the left)', on: { click: () => this.cb.addKnob(p.id, 'LB', spec) } }, '＋ Lower bound here'),
        h('button', { title: 'add an algorithm at this regime (in the problem’s box on the left)', on: { click: () => this.cb.addKnob(p.id, 'UB', spec) } }, '＋ Algorithm here'),
      ),
      h('h4', {}, 'Lower bound'),
      from(s.lb, 'lb'),
      s.lb ? this.lbDerivation(s.lb, analysis) : h('p', { class: 'hint' }, 'none'),
      this.whySection(p, s.regime, 'lb', analysis),
      h('h4', {}, 'Upper bound'),
      from(ub, 'ub'),
      ub ? this.ubDerivation(ub, analysis) : h('p', { class: 'hint' }, 'none'),
      this.whySection(p, s.regime, 'ub', analysis),
    );
  }

  /**
   * The hypotheses and algorithms of a problem (its box in the left panel), each with its Bound ID (a click shows it
   * there), kind, value, whether it is off, and note; and buttons for new ones.
   */
  private knobList(p: Problem, model: Model): { el: HTMLElement; knobs: number } {
    const canonical = canonicalProblem(model);
    const knobs = this.store.get().scenario.knobs.filter((k) => canonical(k.problem) === p.id);
    const el = h(
      'div',
      { class: 'knob-list' },
      h('h3', { title: 'the lower bounds (hypotheses) and algorithms set for this problem: its box in the left panel' }, `Hypotheses & algorithms (${knobs.length})`),
      knobs.length === 0
        ? h('p', { class: 'hint' }, 'None set for this problem (only bounds derived through reductions).')
        : h(
            'ul',
            {},
            knobs.map((k) =>
              h(
                'li',
                { class: k.enabled ? '' : 'off', title: k.enabled ? '' : 'switched off: ignored' },
                this.knobLink(k.id, p.id),
                ' ',
                h('span', { class: `kind kind-${k.kind}` }, k.kind),
                ' ',
                h('span', { html: knobValueHtml(k, k.exponent !== undefined ? knobRegime(model, k) : null) }),
                k.enabled ? null : h('span', { class: 'onoff' }, 'off'),
                k.note ? h('div', { class: 'knob-note', title: k.note }, k.note) : null,
              ),
            ),
          ),
      p.isStatic
        ? h(
            'div',
            { class: 'buttons' },
            h('button', { class: 'link', title: 'add a lower bound (hypothesis) for this problem, in its box on the left', on: { click: () => this.cb.addKnob(p.id, 'LB', '') } }, '＋ Lower bound'),
            h('button', { class: 'link', title: 'add an algorithm (upper bound) for this problem, in its box on the left', on: { click: () => this.cb.addKnob(p.id, 'UB', '') } }, '＋ Algorithm'),
          )
        : null,
    );
    return { el, knobs: knobs.length };
  }

  /**
   * A Bound ID as a link: a click shows the bound in its problem's box in the left panel; pointing at it highlights
   * that problem in the graph.
   */
  private knobLink(id: string, problem: string | undefined, cls = 'knob-link'): HTMLElement {
    return h(
      'a',
      {
        href: '#',
        class: cls,
        title: `show bound ${id} in its problem’s box on the left`,
        ...(problem !== undefined ? refAttrs({ kind: 'problem', id: problem }) : {}),
        on: {
          click: (e) => {
            e.preventDefault();
            this.cb.revealKnob(id);
          },
        },
      },
      id,
    );
  }

  /** A knob as the end of a derivation: "U3 (UB knob n^2 d; Known algorithms)", its note shortened (in full on hover). */
  private knobRef(analysis: Analysis, knobId: string): HTMLElement {
    const k = analysis.scenario.knobs.find((x) => x.id === knobId);
    if (!k) return h('span', { class: 'knob-ref' }, `knob ${knobId}`);
    const note = k.note ? (k.note.length > 60 ? `${k.note.slice(0, 57).trimEnd()}…` : k.note) : '';
    const text = ` (${k.kind} knob${k.formula ? ` ${k.formula}` : ''}${note ? `; ${note}` : ''})`;
    const problem = findProblem(this.store.getDerived().model, k.problem)?.id;
    // (a knob deleted since the analysis has no box to show)
    const id = this.store.get().scenario.knobs.some((x) => x.id === k.id) ? this.knobLink(k.id, problem) : k.id;
    return h('span', { class: 'knob-ref', ...(k.note ? { title: k.note } : {}) }, id, text);
  }

  private problemLink(id: string): HTMLElement {
    const p = this.store.getDerived().model.problems.get(id);
    return h(
      'a',
      {
        href: '#',
        title: 'select (Shift-click: add to the selection); pointing at it highlights it in the graph',
        ...refAttrs({ kind: 'problem', id }),
        on: { click: (e) => (e.preventDefault(), this.cb.selectProblem(id, isAdditive(e))) },
      },
      p ? cellEl(p.variation) : id,
    );
  }

  private rowLink(id: string): HTMLElement {
    return h(
      'a',
      {
        href: '#',
        title: 'select (Shift-click: add to the selection); pointing at it highlights it in the graph',
        ...refAttrs({ kind: 'row', id }),
        on: { click: (e) => (e.preventDefault(), this.cb.selectRow(id, isAdditive(e))) },
      },
      id,
    );
  }

  /** "A →R1 B →R2 A": the problems of a cycle and the reductions between them. */
  private cycleText(steps: ReadonlyArray<{ readonly problem: string; readonly rowId: string }>, last: string): (HTMLElement | string)[] {
    const out: (HTMLElement | string)[] = [];
    for (const x of steps) out.push(this.problemLink(x.problem), ' →', this.rowLink(x.rowId), ' ');
    out.push(this.problemLink(last));
    return out;
  }

  private lbDerivation(f: LBFact, analysis: Analysis): HTMLElement {
    const model = this.store.getDerived().model;
    const chain = lbChain(f);
    // The facts of a cycle's lap (after a limit, down to its base) are history: the bounds there have changed since.
    const lap = new Set<LBFact>();
    const bases = new Set<LBFact>();
    for (const x of chain) {
      if (x.origin.kind !== 'cycle') continue;
      bases.add(x.origin.base);
      for (let g: LBFact = x.origin.closing; g !== x.origin.base && g.origin.kind === 'row'; g = g.origin.parent) lap.add(g);
    }
    return h(
      'ol',
      { class: 'chain' },
      chain.map((x, i) => {
        const current = analysis.lower.facts.get(x.problem)?.get(x.regime.key);
        const stale = i > 0 && !lap.has(x) && !bases.has(x) && current !== undefined && compareRates(current, x, 1e-9) > 0;
        return h(
          'li',
          { class: lap.has(x) ? 'lap' : '' },
          lap.has(x) ? lapMark() : null,
          this.problemLink(x.problem),
          ' ',
          texEl(`\\ge ${x.regime.timeTex(x, boundDecimals(x, undefined))}`),
          ' at ',
          texEl(x.regime.describeTex()),
          stale
            ? h('span', { class: 'hint', title: 'a better lower bound was found for it later; with it, the bounds above stay the same' }, ' (its best: ', texEl(`\\ge ${x.regime.timeTex(current, boundDecimals(current, undefined))}`), ')')
            : null,
          h('div', { class: 'via' }, this.lbVia(x, analysis, model)),
        );
      }),
    );
  }

  private lbVia(x: LBFact, analysis: Analysis, model: Model): HTMLElement {
    switch (x.origin.kind) {
      case 'knob':
        return this.knobRef(analysis, x.origin.knobId);
      case 'row': {
        const row = model.rowsById.get(x.origin.rowId);
        return h(
          'span',
          {},
          'via reduction ',
          this.rowLink(x.origin.rowId),
          row && row.free.length > 0 ? ` with ${describeTheta(row.free, x.origin.theta)}` : '',
          x.origin.rt === null ? ' (reduction runtime unknown: assumed negligible)' : '',
          ' from:',
        );
      }
      case 'cycle': {
        // The lap, in derivation order: from the base around to the closing fact.
        const steps: Array<{ problem: string; rowId: string }> = [];
        for (let g: LBFact = x.origin.closing; g !== x.origin.base && g.origin.kind === 'row'; g = g.origin.parent) {
          steps.unshift({ problem: g.origin.parent.problem, rowId: g.origin.rowId });
        }
        return h(
          'span',
          { class: 'cycle-ref' },
          'limit of going around the cycle ',
          this.cycleText(steps, x.problem),
          x.exponent === Infinity
            ? ` again and again: each lap raises the bound, without limit${x.power === 1 ? ' (no polynomial-time algorithm)' : ''}. One lap (↻), from:`
            : ' again and again: each lap raises the bound, towards this limit. One lap (↻), from:',
        );
      }
    }
  }

  /**
   * An upper bound's derivation as a numbered list, like a lower bound's chain: the bound, then the bounds its calls
   * use, depth first. A bound used more than once is listed once; a reduction whose calls use other bounds than the
   * next item names their numbers.
   */
  private ubDerivation(f: UBFact, analysis: Analysis): HTMLElement {
    const model = this.store.getDerived().model;
    const order: UBFact[] = [];
    const numberOf = new Map<UBFact, number>();
    // Below the limit of a cycle, the bounds are as they were when it was found (no notes about better ones since);
    // the lap itself is marked ↻.
    const historical = new Set<UBFact>();
    const lap = new Set<UBFact>();
    const visit = (g: UBFact, past: boolean): void => {
      if (numberOf.has(g)) return;
      numberOf.set(g, order.length + 1);
      order.push(g);
      if (past) historical.add(g);
      if (g.origin.kind === 'cycle') g.origin.lap.forEach((x) => lap.add(x));
      for (const c of ubParts(g)) visit(c, past || g.origin.kind === 'cycle');
    };
    visit(f, false);
    return h(
      'ol',
      { class: 'chain' },
      order.map((g, i) => {
        const current = i > 0 && !historical.has(g) ? analysis.upperOverlay.known(g.problem, g.regime) : undefined;
        const stale = current !== undefined && current !== null && compareRates(current, g, 1e-9) < 0;
        return h(
          'li',
          { class: lap.has(g) ? 'lap' : '' },
          lap.has(g) ? lapMark() : null,
          this.problemLink(g.problem),
          ' ',
          texEl(`\\le ${g.regime.timeTex(g, boundDecimals(undefined, g))}`),
          ' at ',
          texEl(g.regime.describeTex()),
          stale
            ? h('span', { class: 'hint', title: 'a better upper bound was found for it later; with it, the bounds above stay the same' }, ' (its best: ', texEl(`\\le ${g.regime.timeTex(current, boundDecimals(undefined, current))}`), ')')
            : null,
          h('div', { class: 'via' }, this.ubVia(g, i + 1, numberOf, analysis, model)),
        );
      }),
    );
  }

  /** How the upper bound numbered `self` in its list is derived, naming the items it uses unless it is just the next. */
  private ubVia(g: UBFact, self: number, numberOf: ReadonlyMap<UBFact, number>, analysis: Analysis, model: Model): HTMLElement {
    const uses = (parts: readonly UBFact[]): string => {
      const numbers = parts.map((c) => numberOf.get(c)!);
      return numbers.length === 1 && numbers[0] === self + 1 ? ':' : ` ${listText(numbers.map(String))}`;
    };
    switch (g.origin.kind) {
      case 'knob':
        return this.knobRef(analysis, g.origin.knobId);
      case 'row': {
        const row = model.rowsById.get(g.origin.rowId);
        return h(
          'span',
          {},
          'via reduction ',
          this.rowLink(g.origin.rowId),
          row && row.free.length > 0 ? ` with ${describeTheta(row.free, g.origin.theta)}` : '',
          ...(g.origin.rt === null ? [' (reduction runtime unknown)'] : [' (reduction itself: ', texEl(g.regime.timeTex(g.origin.rt, 3)), ')']),
          g.origin.children.length > 0 ? `, using${uses(g.origin.children)}` : ' (calls on constant-size instances only)',
        );
      }
      case 'cycle': {
        const steps = g.origin.lap.map((x) => ({ problem: x.problem, rowId: x.origin.kind === 'row' ? x.origin.rowId : '?' }));
        return h(
          'span',
          { class: 'cycle-ref' },
          'limit of going around the cycle ',
          this.cycleText(steps, g.origin.base.problem),
          ` again and again: each lap lowers the bound, towards this limit. One lap (↻), from an earlier bound of this problem${uses([g.origin.lap[0]!])}`,
        );
      }
    }
  }

  /**
   * A collapsed list of the reductions that could give this bound, each with what it gives or why it gives nothing
   * (computed when opened).
   */
  private whySection(p: Problem, regime: Regime, kind: 'lb' | 'ub', analysis: Analysis): HTMLElement {
    const key = `${kind}#${p.id}#${regime.key}`;
    const rows = kind === 'ub' ? p.asSource : p.asTarget;
    const title = kind === 'ub' ? `Reductions from this problem here (${rows.length})` : `Reductions to this problem here (${rows.length})`;
    const open = this.whyOpen.has(key);
    const details = h(
      'details',
      { class: 'why', open },
      h('summary', { title: kind === 'ub' ? 'what each reduction from this problem gives for its upper bound at this regime, or why it gives none' : 'what each reduction to this problem gives for its lower bound at this regime, or why it gives none' }, title),
      open ? (kind === 'ub' ? this.ubWhy(p, regime, analysis) : this.lbWhy(p, regime, analysis)) : null,
    );
    details.addEventListener('toggle', () => {
      if (details.open === this.whyOpen.has(key)) return;
      if (details.open) this.whyOpen.add(key);
      else this.whyOpen.delete(key);
      this.render();
    });
    return details;
  }

  /** Why a row the engine does not use is not used. */
  private unusableText(row: CompiledRow, analysis: Analysis): string {
    if (row.status !== 'ok') return `not used: ${ROW_STATUS_TEXT[row.status]}`;
    const st = analysis.scenario.settings;
    if (st.disabledRows.includes(row.id)) return 'switched off in the settings';
    if (row.randomized && !st.useRandomized) return 'randomized (excluded in the settings)';
    return 'not used';
  }

  private ubWhy(p: Problem, regime: Regime, analysis: Analysis): HTMLElement {
    const items = analysis.upperOverlay.explain(p.id, regime);
    if (items.length === 0) return h('p', { class: 'hint' }, 'No reduction starts at this problem.');
    const tex = (x: Rate): HTMLElement => texEl(`${regime.timeTex(x, boundDecimals(undefined, x))}`);
    const best = analysis.upperOverlay.known(p.id, regime) ?? null;
    return h(
      'ul',
      { class: 'why-list' },
      items.map(({ row, verdict: v }) => {
        let text: (HTMLElement | string)[];
        switch (v.kind) {
          case 'used':
            text = ['gives this bound'];
            break;
          case 'weaker': {
            const same = best !== null && compareRates(best, v.fact, CONFLICT_TOL) === 0;
            text = ['gives ≤ ', tex(v.fact), same ? ` too, ${throughText(v.fact.steps, best.steps)}` : ''];
            break;
          }
          case 'skipped':
            text = ['would take at least ', tex(v.optimistic), ' even if its calls were free: not better'];
            break;
          case 'no-call-bound':
            text = v.searched
              ? ['no upper bound for ', this.problemLink(v.target), ' at ', texEl(v.regime.describeTex())]
              : [
                  'no upper bound found for ',
                  this.problemLink(v.target),
                  ' at ',
                  texEl(v.regime.describeTex()),
                  ': the search stopped short there or below (it passes through at most “UB detours”, see Settings, regimes in a row besides those it starts from: configured, of algorithms, or pinned); pin that regime to search it fully',
                ];
            break;
          case 'not-searched':
            text = ['not searched: this regime is too many reductions away from those the search for upper bounds starts from (configured, of algorithms, or pinned; only its knobs count; see “UB detours” in the settings)'];
            break;
          case 'not-applicable':
            text = [v.reason];
            break;
          case 'unusable':
            text = [this.unusableText(row, analysis)];
            break;
        }
        return h('li', { class: `why-${v.kind}` }, this.rowLink(row.id), ' → ', this.problemLink(row.target), ': ', text);
      }),
    );
  }

  private lbWhy(p: Problem, regime: Regime, analysis: Analysis): HTMLElement {
    const { model } = this.store.getDerived();
    const sc = analysis.scenario;
    const items = explainLower(model, analysis.lower, p.id, regime, {
      settings: sc.settings,
      constants: constantEnv(model, sc.constants),
      usable: (r) => rowUsable(r, sc),
    });
    if (items.length === 0) return h('p', { class: 'hint' }, 'No reduction leads to this problem.');
    const tex = (x: Rate, r: Regime = regime): HTMLElement => texEl(`${r.timeTex(x, boundDecimals(x, undefined))}`);
    const current = analysis.lower.facts.get(p.id)?.get(regime.key);
    return h(
      'ul',
      { class: 'why-list' },
      items.map(({ row, verdict: v }) => {
        let text: (HTMLElement | string)[];
        switch (v.kind) {
          case 'used':
            text = ['gives this bound'];
            break;
          case 'weaker': {
            const same = current !== undefined && compareRates(current, v.fact, CONFLICT_TOL) === 0;
            text = ['gives ≥ ', tex(v.fact), same ? ` too, ${throughText(v.fact.hops, current.hops)}` : ''];
            break;
          }
          case 'no-source-bound':
            text = ['no lower bound for ', this.problemLink(row.source)];
            break;
          case 'elsewhere':
            text = [
              `the lower bounds of its source lead to other regimes of this problem (`,
              ...v.regimes.slice(0, 3).flatMap((r, i) => [i > 0 ? '; ' : '', texEl(r.describeTex())]),
              v.regimes.length > 3 ? `; ${v.regimes.length - 3} more` : '',
              ')',
            ];
            break;
          case 'fails':
            text = [v.reason, ' (from ', this.problemLink(v.from.problem), ' ', texEl(`\\ge ${v.from.regime.timeTex(v.from, boundDecimals(v.from, undefined))}`), ' at ', texEl(v.from.regime.describeTex()), ')'];
            break;
          case 'unusable':
            text = [this.unusableText(row, analysis)];
            break;
        }
        return h('li', { class: `why-${v.kind}` }, this.rowLink(row.id), ' ← ', this.problemLink(row.source), ': ', text);
      }),
    );
  }

  private pinForm(p: Problem): HTMLElement {
    const pinned = this.store.get().pinned[p.id] ?? [];
    const input = h('input', { type: 'text', class: 'mono', placeholder: p.regimeSpecs[0] ?? 'n=1' });
    const msg = h('span', { class: 'issue', hidden: true });
    const pin = (): void => {
      const spec = input.value.trim();
      const fail = (m: string): void => {
        msg.textContent = m;
        msg.hidden = false;
      };
      if (spec === '') return fail(`give a regime, e.g. ${p.regimeSpecs[0] ?? 'n=1'}`);
      let regimes: Regime[];
      try {
        regimes = regimesFromSpec(p, spec);
      } catch (e) {
        return fail(e instanceof SpecError ? e.message : String(e));
      }
      // (a spec for regimes pinned already, written the same or otherwise, adds nothing)
      const keys = new Set(regimes.map((r) => r.key));
      const same = (this.store.get().pinned[p.id] ?? []).find((x) => {
        try {
          const rs = regimesFromSpec(p, x);
          return rs.length === keys.size && rs.every((r) => keys.has(r.key));
        } catch {
          return false;
        }
      });
      if (same !== undefined) return fail(`pinned already (${same})`);
      msg.hidden = true;
      this.store.update((s) => ({ ...s, pinned: { ...s.pinned, [p.id]: [...(s.pinned[p.id] ?? []), spec] } }));
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') pin();
    });
    return h(
      'div',
      { class: 'pin' },
      h('h3', {}, 'Pin a regime'),
      h('div', { class: 'row' }, input, h('button', { on: { click: pin } }, 'Pin'), msg),
      pinned.length > 0
        ? h(
            'ul',
            {},
            pinned.map((spec, i) =>
              h(
                'li',
                {},
                h('code', {}, spec),
                ...clippedRegimes(p, spec).map((r) => h('span', { class: 'hint', title: 'clipped to the problem’s limits (the same instances)' }, ' → ', h('code', {}, regimeToSpec(r)))),
                ' ',
                h(
                  'button',
                  {
                    class: 'icon',
                    title: 'unpin',
                    'aria-label': `unpin ${spec}`,
                    on: {
                      click: () =>
                        this.store.update((s) => ({ ...s, pinned: { ...s.pinned, [p.id]: (s.pinned[p.id] ?? []).filter((_, j) => j !== i) } })),
                    },
                  },
                  '×',
                ),
              ),
            ),
          )
        : null,
    );
  }

  private rowList(title: string, ids: readonly string[], model: Model, show: 'source' | 'target'): HTMLElement {
    return h(
      'div',
      { class: 'rowlist' },
      h('h3', {}, `${title} (${ids.length})`),
      h(
        'ul',
        {},
        ids.map((id) => {
          const r = model.rowsById.get(id);
          if (!r) return null;
          return h(
            'li',
            { class: r.status === 'ok' ? '' : 'unused' },
            this.rowLink(id),
            ' ',
            this.problemLink(show === 'target' ? r.target : r.source),
            r.status === 'ok' ? '' : h('span', { class: 'hint' }, ` (${ROW_STATUS_TEXT[r.status]})`),
          );
        }),
      ),
    );
  }

  // -------------------------------------------------------------------------------------------------------------------
  // Row view
  // -------------------------------------------------------------------------------------------------------------------

  private rowView(r: CompiledRow, model: Model, analysis: Analysis, full: boolean): HTMLElement[] {
    const disabled = analysis.scenario.settings.disabledRows.includes(r.id);
    return [
      full ? h('div', { class: 'family' }, `Reduction ${r.id}`) : null,
      h(full ? 'h2' : 'div', { class: full ? '' : 'row-ends' }, this.problemLink(r.source), ' → ', this.problemLink(r.target)),
      h(
        'div',
        { class: 'meta' },
        h('span', { class: `badge row-${r.status}` }, ROW_STATUS_TEXT[r.status]),
        r.randomized ? h('span', { class: 'badge' }, 'randomized') : null,
        disabled ? h('span', { class: 'badge' }, 'disabled in this scenario') : null,
      ),
      r.messages.length > 0 ? h('ul', { class: 'messages' }, r.messages.map((m) => h('li', {}, m))) : null,
      h(
        'div',
        { class: 'buttons' },
        h('button', { on: { click: () => this.cb.editRow(r.id) } }, 'Edit row'),
        h(
          'button',
          {
            on: {
              click: () =>
                this.store.update((s) => {
                  const rows = s.scenario.settings.disabledRows;
                  const next = rows.includes(r.id) ? rows.filter((x) => x !== r.id) : [...rows, r.id];
                  return { ...s, scenario: { ...s.scenario, settings: { ...s.scenario.settings, disabledRows: next } } };
                }),
            },
          },
          disabled ? 'Enable in scenario' : 'Disable in scenario',
        ),
      ),
      this.engineView(r, model, analysis),
      this.fieldsView(r, model),
    ].filter((x): x is HTMLElement => x !== null);
  }

  private engineView(r: CompiledRow, model: Model, analysis: Analysis): HTMLElement {
    const facts: LBFact[] = [];
    for (const m of analysis.lower.facts.values()) for (const f of m.values()) if (f.origin.kind === 'row' && f.origin.rowId === r.id) facts.push(f);
    const use = analysis.rowUse.get(r.id);
    return h(
      'div',
      { class: 'engine' },
      h('h3', {}, 'How the engine reads this row'),
      r.from
        ? h(
            'div',
            {},
            h('div', { class: 'label' }, `From-time${r.fromOverridden ? ' (config override)' : ''}:`),
            h('ul', {}, r.from.alternatives.map((a, i) => h('li', {}, i > 0 ? '⊆ ' : '', texEl(toTex(a))))),
          )
        : h('p', { class: 'hint' }, 'no From-time formula'),
      h('div', {}, h('span', { class: 'label' }, `Reduction runtime${r.rtOverridden ? ' (override)' : ''}: `), r.rt ? texEl(toTex(r.rt.alternatives[0]!)) : h('em', {}, 'unknown')),
      r.free.length > 0
        ? h(
            'div',
            {},
            h('span', { class: 'label' }, 'Free parameters: '),
            h(
              'ul',
              {},
              r.free.map((f) =>
                h(
                  'li',
                  {},
                  texEl(identifierTex(f.def.name)),
                  ` ${f.def.type}`,
                  f.def.type === 'int' ? ` ∈ {${f.def.values!.join(', ')}}` : '',
                  f.def.type === 'real' ? ` ∈ [${f.def.min}, ${f.def.max}]` : '',
                  f.def.type === 'size' ? ` = (${f.def.base ?? 'N'})^τ, τ ∈ [${f.def.min}, ${f.def.max}]` : '',
                  f.def.type === 'fixed' ? ` = ${f.def.value ?? 'unknown constant'}` : '',
                  f.def.note ? h('span', { class: 'hint' }, ` — ${f.def.note}`) : '',
                ),
              ),
            ),
          )
        : null,
      r.defs.length > 0
        ? h(
            'div',
            {},
            h('span', { class: 'label' }, 'Abbreviations: '),
            h('ul', {}, r.defs.map((d) => h('li', {}, texEl(`${identifierTex(d.name)} = ${d.alternatives.map(toTex).join(' = ')}`), h('span', { class: 'hint' }, ` (${d.origin})`)))),
          )
        : null,
      r.requiresText ? h('div', {}, h('span', { class: 'label' }, 'Applies only when the source regime satisfies: '), h('code', {}, r.requiresText)) : null,
      r.lowerOnly
        ? h(
            'div',
            {},
            h('span', { class: 'label' }, 'Lower bounds only: '),
            'it holds only on special instances of its target (see its Restrictions), so it carries hardness to the target but gives no algorithm for the source (the config marks it lowerOnly).',
          )
        : null,
      r.annotation?.note ? h('div', { class: 'hint' }, `Config note: ${r.annotation.note}`) : null,
      h(
        'div',
        {},
        h('span', { class: 'label' }, 'In the current scenario: '),
        `${use?.lb ?? 0} displayed lower bound(s), ${use?.ub ?? 0} upper-bound derivation step(s) use this row.`,
      ),
      facts.length > 0
        ? h(
            'ul',
            { class: 'facts' },
            facts.slice(0, 10).map((f) => h('li', {}, texEl(`\\ge ${f.regime.timeTex(f, boundDecimals(f, undefined))}`), ' at ', texEl(f.regime.describeTex()))),
            facts.length > 10 ? h('li', { class: 'hint' }, `… ${facts.length - 10} more`) : null,
          )
        : null,
      r.status === 'ok' ? this.probeView(r, model, analysis) : null,
    );
  }

  private probeView(r: CompiledRow, model: Model, analysis: Analysis): HTMLElement {
    const summary = analysis.summaries.get(r.source);
    const regimes = summary?.regimes ?? [];
    if (regimes.length === 0) return h('div');
    const chosen = regimes.find((s) => s.regime.key === this.probeRegime.get(r.id)) ?? regimes[0]!;
    const select = h(
      'select',
      {
        on: {
          change: (e) => {
            this.probeRegime.set(r.id, (e.target as HTMLSelectElement).value);
            this.render();
          },
        },
      },
      regimes.slice(0, 40).map((s) => h('option', { value: s.regime.key, selected: s === chosen }, s.regime.key)),
    );
    const probes = probeRow(model, r, chosen.regime, constantEnv(model, analysis.scenario.constants), analysis.scenario.settings);
    return h(
      'div',
      { class: 'probe' },
      h('h4', {}, 'Probe: produced instances at a source regime'),
      select,
      h(
        'table',
        { class: 'grid small' },
        h('thead', {}, h('tr', {}, h('th', {}, 'free params'), h('th', {}, 'calls (target regime, scale)'), h('th', {}, 'RT'), h('th', {}, 'F at T=N′'))),
        h(
          'tbody',
          {},
          probes.map((p) =>
            h(
              'tr',
              {},
              h('td', {}, describeTheta(r.free, p.theta) || '—'),
              h(
                'td',
                {},
                p.error
                  ? h('span', { class: 'issue' }, p.error)
                  : p.calls.map((c) => h('div', {}, c.regime ? [texEl(c.regime.describeTex()), ` (normalizer = N^${formatNumber(c.scale, 3)})`] : 'constant-size instance')),
              ),
              h('td', { class: 'num' }, p.rt === null ? '?' : texEl(chosen.regime.timeTex(p.rt, 3))),
              h('td', { class: 'num' }, p.overheadAtOne === null ? '' : formatNumber(p.overheadAtOne, 3)),
            ),
          ),
        ),
      ),
    );
  }

  private fieldsView(r: CompiledRow, model: Model): HTMLElement {
    const table = model.table;
    const cols = [...ROW_FIELDS.filter((c) => table.hasColumn(c)), ...table.columns.filter((c) => !ROW_FIELDS.includes(c) && !HIDDEN_FIELDS.has(c))];
    return h(
      'div',
      { class: 'fields' },
      h('h3', {}, 'Sheet fields'),
      h(
        'dl',
        {},
        cols.flatMap((c) => {
          const v = table.get(r.index, c);
          if (v.trim() === '') return [];
          const isLink = /^https?:\/\//.test(v.trim());
          return [h('dt', {}, c), h('dd', {}, isLink ? h('a', { href: v.trim(), target: '_blank', rel: 'noopener' }, v.trim()) : h('span', { html: cellHtml(v) }))];
        }),
      ),
    );
  }
}
