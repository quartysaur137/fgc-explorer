/**
 * The store: owns the AppState, the derived model and analysis, and notifies views of changes.
 *
 * Every state change goes through update(); recomputation is decided by comparing the old and new state, so views
 * never call the engine themselves.
 */

import { analyze, Analysis } from '../engine/analysis';
import { buildModel, Model } from '../model/model';
import { CsvTable } from '../util/csv';
import { AppState, persist } from './state';

export type Change = 'model' | 'analysis' | 'scenario' | 'scenario-structure' | 'selection' | 'prefs' | 'busy';

export interface Derived {
  readonly table: CsvTable;
  readonly sheetWarnings: readonly string[];
  readonly model: Model;
  readonly analysis: Analysis;
}

type Listener = (changes: ReadonlySet<Change>) => void;

/** Shape of the scenario that the scenario panel renders (it re-renders only when this changes). */
function structureKey(s: AppState): string {
  return JSON.stringify([
    s.scenario.knobs.map((k) => [k.id, k.kind, k.problem, k.exponent === undefined ? 'f' : 'e']),
    s.scenario.problems,
    Object.keys(s.config.constants),
    s.scenario.settings,
  ]);
}

export class Store {
  private state: AppState;
  private derived: Derived;
  private readonly listeners = new Set<Listener>();
  private analysisTimer: ReturnType<typeof setTimeout> | null = null;
  private persistTimer: ReturnType<typeof setTimeout> | null = null;
  private busyFlag = false;

  /**
   * @param fallback state to use if `initial` cannot be analyzed (e.g. a saved scenario that triggers an engine bug):
   *        the app must always start, so that the user can reset it
   */
  constructor(initial: AppState, fallback?: () => AppState, private readonly onError: (message: string) => void = () => {}) {
    try {
      this.state = initial;
      this.derived = Store.derive(initial);
    } catch (e) {
      if (!fallback) throw e;
      this.onError(`could not restore the saved state (${(e as Error).message}); using the defaults`);
      this.state = fallback();
      this.derived = Store.derive(this.state);
    }
  }

  private static derive(s: AppState): Derived {
    const { table, warnings } = CsvTable.fromText(s.sheetText);
    const model = buildModel(table, s.config);
    return { table, sheetWarnings: warnings, model, analysis: analyze(model, s.scenario, new Map(Object.entries(s.pinned))) };
  }

  get(): AppState {
    return this.state;
  }

  getDerived(): Derived {
    return this.derived;
  }

  get busy(): boolean {
    return this.busyFlag;
  }

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit(changes: Set<Change>): void {
    if (changes.size === 0) return;
    for (const fn of this.listeners) fn(changes);
  }

  /**
   * Apply `fn` to the state.
   * @param debounce when true, the analysis is recomputed after a short pause (for sliders and typing)
   */
  update(fn: (s: AppState) => AppState, debounce = false): void {
    const prev = this.state;
    const next = fn(prev);
    if (next === prev) return;
    const modelChanged0 = next.sheetText !== prev.sheetText || next.config !== prev.config;
    if (modelChanged0) {
      // Build first: if the new sheet or config breaks the engine, keep the old state.
      try {
        const derived = Store.derive(next);
        this.state = next;
        if (this.analysisTimer !== null) clearTimeout(this.analysisTimer);
        this.analysisTimer = null;
        this.derived = derived;
        this.busyFlag = false;
      } catch (e) {
        this.onError(`the change was not applied: ${(e as Error).message}`);
        return;
      }
    } else {
      this.state = next;
    }
    const changes = new Set<Change>();
    // A new model invalidates the analysis: it was recomputed synchronously above, so that views never see a
    // mismatched pair.
    const modelChanged = modelChanged0;
    if (modelChanged) changes.add('model').add('analysis').add('busy');
    if (next.scenario !== prev.scenario) changes.add('scenario');
    if (structureKey(next) !== structureKey(prev)) changes.add('scenario-structure');
    if (next.selection !== prev.selection) changes.add('selection');
    if (next.prefs !== prev.prefs) changes.add('prefs');
    const needsAnalysis = !modelChanged && (next.scenario !== prev.scenario || next.pinned !== prev.pinned);
    this.emit(changes);
    if (needsAnalysis) this.scheduleAnalysis(debounce ? 250 : 0);
    this.schedulePersist();
  }

  private scheduleAnalysis(delay: number): void {
    if (this.analysisTimer !== null) clearTimeout(this.analysisTimer);
    this.busyFlag = true;
    this.emit(new Set<Change>(['busy']));
    this.analysisTimer = setTimeout(() => {
      this.analysisTimer = null;
      // Let the browser paint the busy indicator before the (synchronous) computation.
      requestAnimationFrame(() =>
        setTimeout(() => {
          const s = this.state;
          try {
            const analysis = analyze(this.derived.model, s.scenario, new Map(Object.entries(s.pinned)), this.derived.analysis);
            this.derived = { ...this.derived, analysis };
          } catch (e) {
            this.onError(`analysis failed: ${(e as Error).message}`);
          }
          this.busyFlag = this.analysisTimer !== null;
          this.emit(new Set<Change>(['analysis', 'busy']));
        }, 0),
      );
    }, delay);
  }

  private schedulePersist(): void {
    if (this.persistTimer !== null) clearTimeout(this.persistTimer);
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      persist(this.state);
    }, 500);
  }
}
