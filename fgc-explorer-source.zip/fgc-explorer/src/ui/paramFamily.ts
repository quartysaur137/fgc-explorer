/**
 * Bounds of problems with a constant parameter in the exponent (SPEC §7): k-Clique, k-OV, Zero-Weight k-Clique, Klee's
 * measure problem in d dimensions, … The views show one line of bounds per problem, from its first regime; for such a
 * problem that regime fixes the parameter (k = 3), and its n^ω would read as k-Clique's bound. Their line shows the
 * bounds as functions of the parameter instead, when every listed value gives the same simple function (k-OV under SETH:
 * n^k), and otherwise only the status at each value (tight at k = 3, an upper bound at k = 4–6).
 */

import { Analysis, ProblemSummary, Status, statusOf, upperOnDemand } from '../engine/analysis';
import { simpleDenominator } from '../engine/regimeRank';
import { formatNumber, Rate } from '../growth/growth';
import { identifierTex } from '../math/ast';
import { Regime } from '../model/regime';
import { boundsLine } from './format';
import { texToPlain } from './tex';

/** The bounds of a problem at one value of the parameter. */
export interface FamilyMember {
  readonly value: number;
  readonly regime: Regime;
  readonly lb: Rate | null;
  readonly ub: Rate | null;
  readonly status: Status;
}

/** A problem's listed regimes that differ from its first one only in the value of one constant parameter. */
export interface ParamFamily {
  /** The parameter's name, e.g. "k". */
  readonly param: string;
  /** By increasing value. */
  readonly members: readonly FamilyMember[];
}

/** The value of parameter i of a regime if it is a constant with a value (k = 3), else null. */
function constantValue(r: Regime, i: number): number | null {
  const g = r.growths[i]!;
  return g.kind === 'const' && g.value !== null ? g.value : null;
}

/** Whether two regimes of a problem agree except in parameter i. */
function sameExcept(a: Regime, b: Regime, i: number): boolean {
  if (a.params.length !== b.params.length || a.normalizer !== b.normalizer || a.expScale !== b.expScale) return false;
  return a.params.every((p, j) => b.params[j] === p && (j === i || JSON.stringify(a.growths[j]) === JSON.stringify(b.growths[j])));
}

const sameRate = (a: Rate | null, b: Rate | null): boolean =>
  a === null || b === null ? a === b : a.power === b.power && (a.exponent === b.exponent || Math.abs(a.exponent - b.exponent) <= 1e-6);

/**
 * The family of a problem's first regime along a constant parameter whose value changes its bounds (an exponent, or
 * whether there is a bound: Min-Weight k-Cycle is n^3 at every k, with a lower bound at k = 3 only), the one with the
 * most listed values if several do. Null if there is none, e.g. when every value gives the same bounds (edit distance
 * for several alphabet sizes). Upper bounds the analysis left out (beyond its first regimes) are computed here.
 */
export function paramFamily(analysis: Analysis, s: ProblemSummary): ParamFamily | null {
  const first = s.primary;
  if (first === null || !s.problem.isStatic) return null;
  const r0 = first.regime;
  let best: ParamFamily | null = null;
  r0.params.forEach((param, i) => {
    if (i === r0.normalizer || r0.logDep.has(param) || constantValue(r0, i) === null) return;
    const members = s.regimes
      .filter((r) => r.listed && sameExcept(r.regime, r0, i) && constantValue(r.regime, i) !== null)
      .map((r): FamilyMember => {
        const ub = r.ubComputed ? r.ub : upperOnDemand(analysis, s.problem.id, r.regime);
        return { value: constantValue(r.regime, i)!, regime: r.regime, lb: r.lb, ub, status: r.ubComputed ? r.status : statusOf(r.lb, ub) };
      })
      .sort((a, b) => a.value - b.value);
    if (members.length < 2) return;
    const m0 = members[0]!;
    const varies = members.some((m) => m.status !== m0.status || !sameRate(m.lb, m0.lb) || !sameRate(m.ub, m0.ub));
    if (varies && (best === null || members.length > best.members.length)) best = { param, members };
  });
  return best;
}

/**
 * Values as short text: runs of three or more consecutive integers as ranges ("2–6, 8"). Compact (graph labels): runs
 * of two as well, no spaces, and more than four items as the first and last with an ellipsis ("6…21").
 */
export function valuesText(values: readonly number[], compact = false): string {
  const sorted = [...new Set(values)].sort((a, b) => a - b);
  const out: string[] = [];
  for (let i = 0; i < sorted.length; ) {
    let j = i;
    while (j + 1 < sorted.length && Number.isInteger(sorted[j]!) && sorted[j + 1] === sorted[j]! + 1) j++;
    if (j - i >= (compact ? 1 : 2)) out.push(`${formatNumber(sorted[i]!, 6)}–${formatNumber(sorted[j]!, 6)}`);
    else for (let t = i; t <= j; t++) out.push(formatNumber(sorted[t]!, 6));
    i = j + 1;
  }
  if (compact && out.length > 4) return `${formatNumber(sorted[0]!, 6)}…${formatNumber(sorted[sorted.length - 1]!, 6)}`;
  return out.join(compact ? ',' : ', ');
}

/** A number as a simple fraction "p/q" (q ≤ 6), with its sign, or null. */
function fraction(x: number): { p: number; q: number } | null {
  const q = simpleDenominator(Math.abs(x), 6, 1e-6);
  return Number.isFinite(q) ? { p: Math.round(x * q), q } : null;
}

/** "k", "2k", "k/2", "2ωk/3", "ω/3", "3" for the term p/q · (ω?) · (variable?); "" for 0. */
function term(f: { p: number; q: number }, omega: boolean, variable: string): string {
  if (f.p === 0) return '';
  const p = Math.abs(f.p);
  const factors = `${omega ? 'ω' : ''}${variable}`;
  const head = factors === '' ? String(p) : `${p === 1 ? '' : p}${factors}`;
  return `${f.p < 0 ? '−' : ''}${head}${f.q === 1 ? '' : `/${f.q}`}`;
}

/** x as a term in the variable: a simple fraction, or one times ω (when ω is given), or null. */
function recognize(x: number, omega: number | undefined, variable: string): string | null {
  if (Math.abs(x) <= 1e-9) return '';
  const plain = fraction(x);
  if (plain !== null) return term(plain, false, variable);
  const times = omega !== undefined && omega > 0 ? fraction(x / omega) : null;
  return times !== null ? term(times, true, variable) : null;
}

/**
 * The exponent a·v + b through the points (values[i], exponents[i]) as text in the variable, e.g. "k", "ωk/3",
 * "k − 1", or null if they are not on one line (three points at least), or the coefficients are not simple fractions
 * (or such fractions of ω).
 */
export function affineExponent(values: readonly number[], exponents: readonly number[], variable: string, omega?: number): string | null {
  if (values.length < 3 || values.length !== exponents.length || exponents.some((e) => !Number.isFinite(e))) return null;
  const n = values.length - 1;
  const a = (exponents[n]! - exponents[0]!) / (values[n]! - values[0]!);
  const b = exponents[0]! - a * values[0]!;
  if (values.some((v, i) => Math.abs(a * v + b - exponents[i]!) > 2e-6 * Math.max(1, Math.abs(exponents[i]!)))) return null;
  const ta = recognize(a, omega, variable);
  const tb = recognize(b, omega, '');
  if (ta === null || tb === null) return null;
  if (ta === '') return tb === '' ? '0' : tb;
  if (tb === '') return ta;
  return tb.startsWith('−') ? `${ta} − ${tb.slice(1)}` : `${ta} + ${tb}`;
}

const STATUS_WORD: Readonly<Record<Status, string>> = {
  conflict: 'conflict',
  tight: 'tight',
  gap: 'gap',
  lb: 'lower bound',
  ub: 'upper bound',
  none: 'no bound',
};
const STATUS_SHORT: Readonly<Record<Status, string>> = { conflict: 'conflict', tight: 'tight', gap: 'gap', lb: 'LB', ub: 'UB', none: 'none' };

/**
 * The line of a family: "≥ n^k  ≤ n^k  (k = 2–6, 8)" when each bound is the same simple function of the parameter at
 * every value (or absent at every value), else the statuses, "k = 3: tight · k = 4–6: upper bound". Compact (graph
 * labels, about as wide as a line of numbers): "≥ n^k  ≤ n^k", "k=3 tight · 4–6 UB".
 */
export function familyLine(f: ParamFamily, omega?: number, compact = false): string {
  const name = texToPlain(identifierTex(f.param));
  const values = f.members.map((m) => m.value);
  const side = (rates: readonly (Rate | null)[]): { none: boolean; text: string | null } => {
    if (rates.every((r) => r === null)) return { none: true, text: null };
    if (rates.some((r) => r === null || r.power !== 1)) return { none: false, text: null };
    return { none: false, text: affineExponent(values, rates.map((r) => r!.exponent), name, omega) };
  };
  const lb = side(f.members.map((m) => m.lb));
  const ub = side(f.members.map((m) => m.ub));
  const expScale = f.members[0]!.regime.expScale;
  if (!expScale && (lb.none || lb.text !== null) && (ub.none || ub.text !== null) && !(lb.none && ub.none)) {
    const base = texToPlain(identifierTex(f.members[0]!.regime.normalizerName));
    const power = (e: string): string => `${base}^${/^([A-Za-zω]|\d+)$/.test(e) ? e : `(${e})`}`;
    const parts = [lb.text !== null ? `≥ ${power(lb.text)}` : '', ub.text !== null ? `≤ ${power(ub.text)}` : ''].filter((x) => x !== '');
    return compact ? parts.join('  ') : `${parts.join('  ')}  (${name} = ${valuesText(values)})`;
  }
  const groups = new Map<Status, number[]>();
  for (const m of f.members) groups.set(m.status, [...(groups.get(m.status) ?? []), m.value]);
  if (compact) return `${name}=${[...groups].map(([status, vs]) => `${valuesText(vs, true)} ${STATUS_SHORT[status]}`).join(' · ')}`;
  return [...groups].map(([status, vs]) => `${name} = ${valuesText(vs)}: ${STATUS_WORD[status]}`).join(' · ');
}

/** The value of ω in the analysis (the scenario's, else the config's). */
function omegaOf(analysis: Analysis): number | undefined {
  return analysis.scenario.constants['omega'] ?? analysis.model.constants.get('omega')?.value;
}

/**
 * The line of bounds the views show for a problem: its family's (familyLine; compact in the graph) when its first
 * regime fixes a constant parameter in the exponent, else the bounds at its first regime (boundsLine).
 */
export function problemBoundsLine(analysis: Analysis, s: ProblemSummary | null, compact = false): string {
  if (s === null) return '';
  const f = paramFamily(analysis, s);
  return f === null ? boundsLine(s.primary) : familyLine(f, omegaOf(analysis), compact);
}
