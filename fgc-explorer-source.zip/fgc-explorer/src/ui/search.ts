/**
 * The search (SPEC §7): one text, typed above the graph, finds problems by their name and bounds (knobs) by their
 * Bound ID, note or running time. The graph marks the problems found (by name or through a bound), the left panel
 * shows only their boxes and highlights the bounds found, and the problems table lists only them. Enter selects the
 * problem of the bound with that Bound ID (and shows the bound), the reduction with that ID ("R12"), or the problem
 * found that the query names best (bestProblem).
 */

import { canonicalProblem } from '../model/boxes';
import { canonicalRowId, Knob } from '../model/config';
import { Model, Problem } from '../model/model';
import { problemLabel } from './format';
import { plainText } from './tex';

/** The search text as compared: trimmed and in lower case ('' when there is no search). */
export function searchQuery(text: string): string {
  return text.trim().toLowerCase();
}

/** The texts searched, in lower case and separated by newlines (which no query contains), per problem and per knob. */
const searchTexts = new WeakMap<object, string>();

function searchText(x: object, texts: () => readonly string[]): string {
  let t = searchTexts.get(x);
  if (t === undefined) {
    t = texts()
      .map((s) => s.toLowerCase())
      .join('\n');
    searchTexts.set(x, t);
  }
  return t;
}

/**
 * Whether a problem's name contains the query (case ignored): "Family / Variation" as in the sheet, or as shown (its
 * family and its variation as plain text, so that "k-clique" finds "$k$-Clique"). The empty query matches nothing.
 */
export function problemMatches(p: Problem, query: string): boolean {
  return query !== '' && searchText(p, () => [p.id, plainText(p.family), problemLabel(p)]).includes(query);
}

/**
 * Whether a bound matches the query: its Bound ID is the query (U12, l3: case ignored), or its note or running time
 * contains it. The empty query matches nothing.
 */
export function knobMatches(k: Pick<Knob, 'id' | 'note' | 'formula'>, query: string): boolean {
  if (query === '') return false;
  return k.id.toLowerCase() === query || searchText(k, () => [k.note ?? '', k.formula ?? '']).includes(query);
}

export interface SearchResult {
  /** The query (see searchQuery); '' when there is no search: then nothing is found and nothing is filtered. */
  readonly query: string;
  /**
   * The problems found, by their name or through one of their bounds: model ids (box keys, see canonicalProblem; for a
   * problem that is not in the sheet, its name with the spaces squashed).
   */
  readonly problems: ReadonlySet<string>;
  /** The bounds found (Bound IDs). */
  readonly knobs: ReadonlySet<string>;
  /** The bound whose Bound ID is the query, and its problem's box key: Enter goes there. */
  readonly exact: { readonly id: string; readonly problem: string } | null;
}

/** No search: nothing found, nothing filtered. */
export const NO_SEARCH: SearchResult = { query: '', problems: new Set(), knobs: new Set(), exact: null };

/** Box keys of problem names (canonicalProblem), remembered per model and name. */
const keysByModel = new WeakMap<Model, Map<string, string>>();

function boxKeys(model: Model): (name: string) => string {
  let keys = keysByModel.get(model);
  if (keys === undefined) keysByModel.set(model, (keys = new Map()));
  const known = keys;
  const canonical = canonicalProblem(model);
  return (name) => {
    let key = known.get(name);
    if (key === undefined) known.set(name, (key = canonical(name)));
    return key;
  };
}

/**
 * Search the problems of a model and the bounds of a scenario.
 * @param names further problem names, e.g. those of the scenario's boxes: those that are not problems of the sheet are
 *        found by the name given (as are the problems of the bounds)
 */
export function search(text: string, model: Model, knobs: readonly Pick<Knob, 'id' | 'problem' | 'note' | 'formula'>[], names: readonly string[] = []): SearchResult {
  const query = searchQuery(text);
  if (query === '') return NO_SEARCH;
  const problems = new Set<string>();
  const found = new Set<string>();
  let exact: SearchResult['exact'] = null;
  for (const p of model.problems.values()) if (problemMatches(p, query)) problems.add(p.id);
  const canonical = boxKeys(model);
  for (const name of [...names, ...knobs.map((k) => k.problem)]) {
    const key = canonical(name);
    if (!model.problems.has(key) && key.toLowerCase().includes(query)) problems.add(key);
  }
  for (const k of knobs) {
    if (!knobMatches(k, query)) continue;
    const key = canonical(k.problem);
    found.add(k.id);
    problems.add(key);
    if (exact === null && k.id.toLowerCase() === query) exact = { id: k.id, problem: key };
  }
  return { query, problems, knobs: found, exact };
}

/**
 * The problem Enter selects when the query is neither a Bound ID nor a reduction's ID: of the problems of the model
 * found, the one whose name the query matches best — the name shown (its variation) equal to the query, then having it
 * as a whole word (or words: "apsp" in "Directed, Weighted APSP", not "triangle" in "Triangles"), then its family
 * equal to it or having it as a whole word, then a name containing it anywhere, then found through a bound only — and
 * among equals the first in `order` (the left panel's boxes), then the first in the sheet.
 */
export function bestProblem(result: SearchResult, model: Model, order: readonly string[]): string | null {
  const q = result.query;
  const escaped = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const word = new RegExp(`(^|[^a-z0-9])${escaped}($|[^a-z0-9])`);
  const box = new Map(order.map((p, i) => [p, i]));
  let best: { readonly id: string; readonly key: readonly number[] } | null = null;
  let index = 0;
  for (const p of model.problems.values()) {
    const i = index++;
    if (!result.problems.has(p.id)) continue;
    const shown = problemLabel(p).toLowerCase();
    const family = plainText(p.family).toLowerCase();
    const how = !problemMatches(p, q) ? 4 : shown === q ? 0 : word.test(shown) ? 1 : word.test(family) ? 2 : 3;
    const key = [how, box.get(p.id) ?? order.length, i];
    if (best === null || before(key, best.key)) best = { id: p.id, key };
  }
  return best?.id ?? null;
}

/** Whether `a` comes before `b` (lexicographically). */
function before(a: readonly number[], b: readonly number[]): boolean {
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return a[i]! < b[i]!;
  return false;
}

/** The reduction a query names as "R12" (or "r12"), if the model has it: Enter in a search selects it. */
export function reductionOf(query: string, model: Model): string | null {
  const id = /^r\d+$/i.test(query.trim()) ? canonicalRowId(query) : null;
  return id !== null && model.rowsById.has(id) ? id : null;
}

/** Where the query occurs in a text (case ignored), as [start, end) ranges that do not overlap, in order. */
export function matchRanges(text: string, query: string): Array<readonly [number, number]> {
  const out: Array<readonly [number, number]> = [];
  if (query === '') return out;
  const lower = text.toLowerCase();
  // (lower-casing keeps the length of the texts met here; if it did not, the ranges would be off: then mark nothing)
  if (lower.length !== text.length) return out;
  for (let i = lower.indexOf(query); i >= 0; i = lower.indexOf(query, i + query.length)) out.push([i, i + query.length]);
  return out;
}
