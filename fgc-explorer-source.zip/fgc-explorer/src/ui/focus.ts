/**
 * Focus modes of the graph (SPEC §7): which problems and reductions stay visible around the selection, and the
 * derivations of the selected problems' best bounds.
 */

import { Analysis, boundDerivations } from '../engine/analysis';
import { Selection } from './selection';

export type FocusMode = 'off' | 'neighbours' | 'lineage' | 'derivations';

export const FOCUS_MODES: readonly { readonly mode: FocusMode; readonly label: string; readonly title: string }[] = [
  { mode: 'off', label: 'off', title: 'show everything' },
  { mode: 'neighbours', label: 'neighbours', title: 'the selection and the problems one reduction away' },
  { mode: 'lineage', label: 'ancestors & descendants', title: 'the selection and every problem with a path of reductions to or from it' },
  {
    mode: 'derivations',
    label: 'bound derivations',
    title: 'the reductions that the best lower bound (orange) and upper bound (blue) of each selected problem come from',
  },
];

export function isFocusMode(x: unknown): x is FocusMode {
  return FOCUS_MODES.some((m) => m.mode === x);
}

/** A reduction drawn in the graph: row id, source and target problem ids. */
export interface FocusLink {
  readonly id: string;
  readonly source: string;
  readonly target: string;
}

export interface Kept {
  readonly problems: ReadonlySet<string>;
  readonly rows: ReadonlySet<string>;
}

/** Problems reachable from `start` (included) along `next`. */
function reach(start: Iterable<string>, next: ReadonlyMap<string, readonly FocusLink[]>, end: 'source' | 'target'): Set<string> {
  const seen = new Set(start);
  const queue = [...seen];
  while (queue.length > 0) {
    for (const link of next.get(queue.pop()!) ?? []) {
      const p = link[end];
      if (!seen.has(p)) {
        seen.add(p);
        queue.push(p);
      }
    }
  }
  return seen;
}

/**
 * What stays visible around the selection.
 *  - neighbours: each selected problem with its reductions and the problems at their other end; each selected reduction
 *    with its two problems;
 *  - lineage: each selected problem with all its ancestors (problems with a path of reductions to it) and descendants
 *    (problems reached from it) and the reductions on those paths; a selected reduction with the ancestors of its source
 *    and the descendants of its target.
 */
export function keptAround(mode: 'neighbours' | 'lineage', selection: Selection, links: readonly FocusLink[]): Kept {
  const problems = new Set<string>();
  const rows = new Set<string>();
  const out = new Map<string, FocusLink[]>();
  const into = new Map<string, FocusLink[]>();
  const byId = new Map<string, FocusLink>();
  for (const l of links) {
    byId.set(l.id, l);
    out.set(l.source, [...(out.get(l.source) ?? []), l]);
    into.set(l.target, [...(into.get(l.target) ?? []), l]);
  }
  // Problems whose ancestors / descendants are wanted.
  const up = new Set<string>();
  const down = new Set<string>();
  for (const item of selection) {
    if (item.kind === 'problem') {
      problems.add(item.id);
      up.add(item.id);
      down.add(item.id);
    } else {
      const l = byId.get(item.id);
      if (!l) continue;
      rows.add(l.id);
      problems.add(l.source).add(l.target);
      up.add(l.source);
      down.add(l.target);
    }
  }
  if (mode === 'neighbours') {
    for (const item of selection) {
      if (item.kind !== 'problem') continue;
      for (const l of [...(out.get(item.id) ?? []), ...(into.get(item.id) ?? [])]) {
        rows.add(l.id);
        problems.add(l.source).add(l.target);
      }
    }
    return { problems, rows };
  }
  const ancestors = reach(up, into, 'source');
  const descendants = reach(down, out, 'target');
  for (const p of [...ancestors, ...descendants]) problems.add(p);
  // A reduction into an ancestor (its source is then one too) lies on a path to the selection, and a reduction out of a
  // descendant on a path from it.
  for (const l of links) if (ancestors.has(l.target) || descendants.has(l.source)) rows.add(l.id);
  return { problems, rows };
}

/** The derivations of the best bounds of the selected problems (each at its chosen regime, else its primary one). */
export interface Derivations {
  readonly lb: Kept;
  readonly ub: Kept;
}

export function selectionDerivations(selection: Selection, analysis: Analysis): Derivations {
  const lb = { problems: new Set<string>(), rows: new Set<string>() };
  const ub = { problems: new Set<string>(), rows: new Set<string>() };
  const add = (to: typeof lb, path: Kept | null): void => {
    if (!path) return;
    path.problems.forEach((p) => to.problems.add(p));
    path.rows.forEach((r) => to.rows.add(r));
  };
  for (const item of selection) {
    if (item.kind !== 'problem') continue;
    const d = boundDerivations(analysis, item.id, item.regime);
    add(lb, d.lb);
    add(ub, d.ub);
  }
  return { lb, ub };
}
