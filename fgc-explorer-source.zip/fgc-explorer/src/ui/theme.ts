/**
 * Light and dark mode (SPEC §7). By default the page follows the system's setting; the header's toggle switches what
 * is shown, and a choice that agrees with the system goes back to following it (so the toggle never has a state that
 * looks the same as another one).
 */

/** "system": follow the operating system's light or dark setting. */
export type Theme = 'system' | 'light' | 'dark';

export function isTheme(x: unknown): x is Theme {
  return x === 'system' || x === 'light' || x === 'dark';
}

/** Whether the page is dark under `theme` when the system is dark or not. */
export function isDark(theme: Theme, systemDark: boolean): boolean {
  return theme === 'dark' || (theme === 'system' && systemDark);
}

/** The theme after the toggle: the other look, kept as "system" when that is what the system shows. */
export function toggleTheme(theme: Theme, systemDark: boolean): Theme {
  const dark = !isDark(theme, systemDark);
  if (dark === systemDark) return 'system';
  return dark ? 'dark' : 'light';
}
