/**
 * Application state (immutable), its defaults, and browser persistence.
 */

import { boundIds, canonicalBoundId, canonicalRowId, checkScenarioConstants, DEFAULT_SETTINGS, EngineConfig, initialScenario, Knob, KnobKind, KnobSpec, Scenario, validateConfig, validateScenario } from '../model/config';
import { upgradeRoundedSpec } from '../model/regime';
import { FocusMode, isFocusMode } from './focus';
import { DEFAULT_PANELS, defaultPanels, PanelPrefs, validatePanelPrefs } from './panels';
import { Selection } from './selection';
import { isTheme, Theme } from './theme';

export type BottomTab = 'problems' | 'rows' | 'diagnostics';

export interface UiPrefs {
  /** Group problems into compound nodes by family. */
  readonly groupFamilies: boolean;
  /** Show rows that are not used in propagation. */
  readonly showUnusedRows: boolean;
  /** What stays visible around the selection (the rest is dimmed); see focus.ts. */
  readonly focus: FocusMode;
  readonly bottomTab: BottomTab;
  readonly search: string;
  /** Sizes and visibility of the side and bottom panels. */
  readonly panels: PanelPrefs;
  /** Light or dark mode, or following the system (see theme.ts). */
  readonly theme: Theme;
}

export interface AppState {
  /** The sheet (CSV text) and where it came from. */
  readonly sheetText: string;
  readonly sheetName: string;
  /** True when the sheet differs from the embedded default (loaded or edited). */
  readonly sheetCustom: boolean;
  readonly config: EngineConfig;
  readonly configCustom: boolean;
  readonly scenario: Scenario;
  /** Problem id → pinned regime specs. */
  readonly pinned: Readonly<Record<string, readonly string[]>>;
  readonly selection: Selection;
  readonly prefs: UiPrefs;
}

/** The name of the built-in sheet (the status line shortens it to "built-in sheet"). */
export const BUILT_IN_SHEET_NAME = 'FGC_Reductions_filled.csv (built in)';

export const DEFAULT_PREFS: UiPrefs = {
  // (off since format 10: with the boxes drawn, a drag that starts inside a box moves the box instead of panning)
  groupFamilies: false,
  showUnusedRows: true,
  focus: 'off',
  bottomTab: 'problems',
  search: '',
  panels: DEFAULT_PANELS,
  theme: 'system',
};

/**
 * A fresh Bound ID for a knob of `kind`: its letter and the next number after the largest one with that letter among
 * `knobs` (L1, L2, … for lower bounds; U1, U2, … for upper bounds).
 */
export function newKnobId(knobs: readonly Knob[], kind: KnobKind): string {
  return boundIds(knobs.map((k) => k.id))(kind);
}

// ---------------------------------------------------------------------------------------------------------------------
// Persistence (localStorage; every access may fail, e.g. in private windows)
// ---------------------------------------------------------------------------------------------------------------------

/** (index.html reads the saved theme under this key before the page is drawn.) */
const KEY = 'fgc-explorer.v1';

/**
 * Version of the saved data. Data without it was written by the first version, whose knobs came from preset buttons
 * and whose config called its initial knobs "presets". Format 2 was written before Bound IDs were numbers (it named
 * them, e.g. "seth/cnf-sat"); formats 2 and 3 limited the length of upper-bound derivations with settings.maxDepthUB (4
 * by default), which now limits only their detours through regimes the search does not start from (3 by default). Formats 3 and 4
 * numbered Bound IDs 1, 2, … (and all formats Reduction IDs likewise); format 5 writes L1, … / U1, … and R1, … (the
 * validators convert the old numbers, see legacyBoundId and canonicalRowId). Formats 5 and 6 added initial knob groups
 * (GROUPS_ADDED_IN); format 7 the limits of parameters (a custom config saved before gets the built-in ones, see
 * withLimitsOf); format 8 the problems of rows R320–R365, with their hypotheses (GROUPS_ADDED_IN), algorithms in groups
 * that existed (KNOBS_ADDED_IN), and config entries (ENTRIES_ADDED_IN); format 9 the algorithms and config entries of
 * the two problems that the trivial reductions R366–R431 gave a signature (All-Edges Exact Triangle and #All-Edges
 * Monochromatic Triangle). Format 10 turned the family boxes off by default: data saved before has them off (on was the
 * default then, so a saved "on" is no choice; see initialState), later data keeps its setting. Format 11 added the
 * problems of rows R432–R462 (k-AP Detection, k-GeomBase, Lopsided All-Edges Sparse Triangle, #Exact Triangle,
 * Zero-Weight k-Clique, …) with two hypotheses (GROUPS_ADDED_IN), their algorithms (KNOBS_ADDED_IN) and config entries
 * (ENTRIES_ADDED_IN), and renamed the group "SETH" (GROUPS_RENAMED_IN). Format 12 added the config entries of rows R434
 * (4-AP Detection to 3-uniform 4-hyperclique, back), R463–R465 (from k to k + 1) and R118 (even k only), Chan's Weighted
 * Depth algorithm for d = 5, 6 (U441), and changed the entry of k-GeomBase (k ≥ 4 only); the same mechanism repairs the
 * row entries of the first version of format 11, numbered before rows R435 and R453 were removed (ENTRIES_CHANGED_IN).
 * Format 13 (the review of November 2026) added k-SAT and Low-Dimension OV with their hypotheses, the (min,+)-convolution
 * hypothesis and the October 2026 k-SAT algorithm (GROUPS_ADDED_IN, ENTRIES_ADDED_IN; also the entries of rows R169 and
 * R170, now skipped, of the new rows R467, R469 and R470, and the limit n ≤ N of four problems on compressed texts),
 * changed built-in bounds (KNOBS_CHANGED_IN: n^{ωk/3} only where 3
 * divides k, μ < 0.5275, Max-Weight Rectangle for d ≤ 6), the entries of rows R106 (lower bounds only), R256, R344 and
 * R350 (from k-SAT and Low-Dimension OV) and of CNF-SAT (ENTRIES_CHANGED_IN), and the default of ω
 * (CONSTANTS_CHANGED_IN). Format 14 renamed the group "SETH (k-SAT form)" "Satisfiability Hypothesis (k-SAT)"
 * (GROUPS_RENAMED_IN), changed the notes of L1, L16 and U442 (KNOBS_CHANGED_IN: a change of the note alone counts) and
 * the default of ω to 9/4 (CONSTANTS_CHANGED_IN).
 */
const FORMAT = 14;

/**
 * The built-in initial knob groups each format added (their labels): the groups are added to a custom config saved
 * before that format (unless one of their knobs' Bound IDs is there for the same problem: a label alone may be the
 * user's own group), and their knobs, with the Bound IDs of the initial settings, to the knobs saved before it (a saved
 * knob that has one of those IDs moves to a new one).
 */
export const GROUPS_ADDED_IN: Readonly<Record<number, readonly string[]>> = {
  5: ['Trivial algorithms', 'Best known algorithms', 'Non-combinatorial algorithms'],
  6: ['Saha & Ye 2026'],
  8: ['OMv conjecture', 'Hitting Set hypothesis', '∀∀∃-OV hypothesis', '3-uniform hyperclique hypothesis'],
  11: ['k-AP hypothesis', 'Zero-Weight k-Clique hypothesis'],
  // (labels as they are now: format 14 renamed "SETH (k-SAT form)")
  13: ['Satisfiability Hypothesis (k-SAT)', '(min,+)-convolution hypothesis', 'Low-dimension OV hypothesis', 'Subexponential k-SAT (Oct 2026)'],
};

export interface GroupRename {
  /** The label before. */
  readonly from: string;
  /** The label since. */
  readonly to: string;
  /** The description the group had before. */
  readonly description: string;
}

/**
 * The built-in initial knob groups each format renamed. A custom config saved before that format has the group under its
 * old label: it gets the new label where its knobs show that it is the built-in group (a knob with the Bound ID of one
 * of the built-in group's knobs, for the same problem; a label alone may be the user's own group), and the new
 * description where it has the old one. A saved knob of the group whose note is the old label (the default note) gets
 * its new default note. Format 2 named the initial knobs after the labels of then (format2InitialIds).
 */
export const GROUPS_RENAMED_IN: Readonly<Record<number, readonly GroupRename[]>> = {
  11: [{ from: 'SETH', to: 'Satisfiability Hypothesis', description: 'CNF-SAT needs $2^{(1-o(1))n}$ time' }],
  14: [
    {
      from: 'SETH (k-SAT form)',
      to: 'Satisfiability Hypothesis (k-SAT)',
      description:
        'for every $\\varepsilon > 0$ some $k$ makes $k$-SAT on $n$ variables need $2^{(1-\\varepsilon)n}$ time ($O(n)$ clauses suffice, by sparsification); the reductions that need sparsified formulas start from $k$-SAT. A $2^{o(n)}$ algorithm for $k$-SAT announced in October 2026 (a preprint, not yet refereed; below) would refute it, but not the CNF form above',
    },
  ],
};

/** Bound IDs U<from>, …, U<to>. */
function ubIds(from: number, to: number): string[] {
  return Array.from({ length: to - from + 1 }, (_, i) => `U${from + i}`);
}

/**
 * The knobs each format added to built-in groups that existed before (their Bound IDs in the built-in config): they are
 * added to the same groups of a custom config saved before that format (where the group is, unless the knob is there
 * already: the same Bound ID for the same problem), and to the knobs saved before it, like the knobs of added groups.
 */
export const KNOBS_ADDED_IN: Readonly<Record<number, readonly string[]>> = {
  8: ubIds(370, 418),
  9: ubIds(419, 422),
  11: ubIds(423, 440),
  12: ['U441'],
};

/** A built-in knob as it was before a format changed it (KNOBS_CHANGED_IN), and the label of its group then. */
export interface ChangedKnob {
  readonly old: KnobSpec;
  readonly group: string;
}

/**
 * The built-in knobs each format changed (by Bound ID), as they were before. A knob saved before that format (in the
 * scenario, or in the initial knobs of a custom config) with that Bound ID for that problem that is still that bound
 * (problem, kind, formula or exponent, power, regime) becomes the bound of the built-in config; it stays switched on or
 * off, and keeps its note unless the note was the old default (the knob's old note, else its group's label); a knob whose
 * bound stayed the same and whose note changed gets the new note the same way. Format 13: n^{ωk/3} (U14) needs 3 | k;
 * μ < 0.5275 (U273, U304, U307, U417); Chan's O(N^d) for Max-Weight Rectangle for every d ≤ 6 (U359). Format 14: the
 * notes of L1 and L16 (what the power a of the Satisfiability Hypothesis means, as in arXiv:2611.02650) and of U442
 * (whose algorithms these are: Anthropic's and OpenAI's).
 */
export const KNOBS_CHANGED_IN: Readonly<Record<number, Readonly<Record<string, ChangedKnob>>>> = {
  13: {
    U14: {
      old: {
        problem: 'Clique / k-Clique',
        kind: 'UB',
        formula: 'n^{\\omega k/3}',
      },
      group: 'Known algorithms',
    },
    U273: {
      old: {
        problem: 'All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP',
        kind: 'UB',
        formula: 'n^{2.5277}',
        regime: 'M=polylog',
        note: 'Zwick 2002: O~(n^{2+mu}) for small integer weights, mu < 0.527661 (Vassilevska Williams-Xu-Xu-Zhou 2024); general M: O~(M^{1/(4-omega)} n^{2+1/(4-omega)}) Ref: U. Zwick, All pairs shortest paths using bridging sets and rectangular matrix multiplication, JACM 2002; mu < 0.527661 from V. Vassilevska Williams, Y. Xu, Z. Xu, R. Zhou, New bounds for matrix multiplication: from alpha to omega, SODA 2024 https://arxiv.org/abs/cs/0008011',
      },
      group: 'Best known algorithms',
    },
    U288: {
      old: {
        problem: 'Minimum Witness / All Pairs Minimum Witness (APMW)',
        kind: 'UB',
        formula: 'M^{2} n^{2.5286}',
        regime: 'M=polylog',
        note: 'Small weights: for each of the O(M^2) value pairs (a, s) one Boolean minimum-witness product of [w(i,k)=a] and [w(k,j) <= s] (Czumaj-Kowaluk-Lingas 2007: O(n^{2+lambda}), omega(1,lambda,1)=1+2lambda, = n^{2.5286}); answer for (i,j) = min over a with s = -w(i,j)-a-1. For M=const (Boolean APMW) this is n^{2.5286}. [medium confidence] Ref: A. Czumaj, M. Kowaluk, A. Lingas, Faster algorithms for finding lowest common ancestors in directed acyclic graphs, Theor. Comput. Sci. 380(1-2) 2007; exponent 2.5286 as quoted by Grandoni et al., SODA 2021 https://arxiv.org/abs/2007.08914',
      },
      group: 'Best known algorithms',
    },
    U304: {
      old: {
        problem: 'Graph Metrics / Directed Median',
        kind: 'UB',
        formula: 'n^{2.5277}',
        regime: 'M=polylog',
        note: 'Directed APSP for small weights (Zwick 2002, O~(n^{2+mu}), mu < 0.527661), then row sums; AGV15: an O~(M n^omega) Median algorithm is open Ref: U. Zwick, All pairs shortest paths using bridging sets and rectangular matrix multiplication, JACM 2002; mu < 0.527661 from V. Vassilevska Williams, Y. Xu, Z. Xu, R. Zhou, New bounds for matrix multiplication: from alpha to omega, SODA 2024 https://arxiv.org/abs/cs/0008011',
      },
      group: 'Best known algorithms',
    },
    U307: {
      old: {
        problem: 'Vertex Centrality / All-Nodes Median Parity',
        kind: 'UB',
        formula: 'n^{2.5277}',
        regime: 'M=polylog',
        note: 'Small-weight directed APSP (Zwick 2002, O~(n^{2+mu}), mu < 0.527661), then parities of row sums Ref: U. Zwick, All pairs shortest paths using bridging sets and rectangular matrix multiplication, JACM 2002; mu < 0.527661 from V. Vassilevska Williams, Y. Xu, Z. Xu, R. Zhou, New bounds for matrix multiplication: from alpha to omega, SODA 2024 https://arxiv.org/abs/cs/0008011',
      },
      group: 'Best known algorithms',
    },
    U359: {
      old: {
        problem: 'Geometric Covering Problems / Max-Weight Rectangle',
        kind: 'UB',
        formula: 'N^{d} + N \\log N',
        regime: 'd=const:[2,3,4]',
        note: 'Barbay-Chan-Navarro-Perez-Lantero 2014: O(N^2) for d = 2; for d >= 3 reduction to Weighted Depth of orthants in 2d dimensions solved by Chan 2013 in O(N^d) (BDT16: best known, tight under the Max-Weight k-Clique hypothesis). N log N term covers d = 1. Ref: J. Barbay, T. M. Chan, G. Navarro, P. Perez-Lantero, Maximum-weight planar boxes in O(n^2) time (and better), Inf. Process. Lett. 114(8), 2014; T. M. Chan, Klee\'s measure problem made easy, FOCS 2013 (as summarized in A. Backurs, N. Dikkala, C. Tzamos, Tight hardness results for maximum weight rectangles, ICALP 2016) https://arxiv.org/abs/1602.05837',
      },
      group: 'Best known algorithms',
    },
    U417: {
      old: {
        problem: 'All-Pairs Shortest Paths (APSP) / Directed, Unweighted APSP',
        kind: 'UB',
        formula: 'n^{2.5277}',
        note: 'Zwick 2002: O~(n^{2+mu}) for directed graphs with small integer weights (here unweighted), mu < 0.527661 (Vassilevska Williams-Xu-Xu-Zhou, SODA 2024), as for the small-weight APSP knob U273. Ref: U. Zwick, All pairs shortest paths using bridging sets and rectangular matrix multiplication, JACM 49(3) 2002 https://arxiv.org/abs/cs/0008011',
      },
      group: 'Best known algorithms',
    },
  },
  14: {
    L1: {
      old: {
        problem: 'Boolean Satisfiability / CNF-SAT',
        kind: 'LB',
        regime: 'n=log, m=polylog',
        exponent: 1,
        note: 'Satisfiability Hypothesis: SETH for CNF-SAT with poly(n) clauses (Impagliazzo-Paturi 2001, in the CNF form used by Williams 2005). Named "SETH" before November 2026.',
      },
      group: 'Satisfiability Hypothesis',
    },
    L16: {
      old: {
        problem: 'Boolean Satisfiability / k-SAT',
        kind: 'LB',
        regime: 'n=log, m=log',
        exponent: 1,
        note: 'SETH (Impagliazzo-Paturi 2001) as usually stated, for k-SAT; with the sparsification lemma (Impagliazzo-Paturi-Zane 2001) for k-CNF with O(n) clauses. It implies the CNF form (L1) through R466, and the low-dimension OV hypothesis through R467.',
      },
      group: 'SETH (k-SAT form)',
    },
    U442: {
      old: {
        problem: 'Boolean Satisfiability / k-SAT',
        kind: 'UB',
        formula: '2^{o(n)}',
        note: 'Hexagon 2610.00577 (Oct 2026, unrefereed): #k-SAT in 2^{O(k^2 n log log n / sqrt(log n))}, i.e. 2^{o(n)} for every constant k (its Theorem 1 and Corollary 5). It reaches no other problem: every row from k-SAT points away from it.',
      },
      group: 'Subexponential k-SAT (Oct 2026)',
    },
  },
};

/**
 * The constants whose built-in default each format changed, with the value before: a custom config saved before that
 * still has the old value gets the new one. Format 13: ω < 2.371339 (Alman, Duan, Vassilevska Williams, Xu, Xu, Zhou,
 * SODA 2025), was 2.371552. Format 14: ω ≤ 9/4 (an OpenAI manuscript of October 2026, not yet refereed), was 2.371339.
 */
export const CONSTANTS_CHANGED_IN: Readonly<Record<number, Readonly<Record<string, number>>>> = {
  13: { omega: 2.371552 },
  14: { omega: 2.371339 },
};

/**
 * The problems and rows each format added to the built-in config (keys of `problems` and `rows`): a custom config saved
 * before that format gets their entries where it has none of its own (e.g. the free parameters of the new rows).
 */
export const ENTRIES_ADDED_IN: Readonly<Record<number, { readonly problems: readonly string[]; readonly rows: readonly string[] }>> = {
  8: {
    problems: [
      'Matrix-Vector Multiplication / OMv',
      'Multiphase Problem',
      'Dynamic Subgraph Connectivity',
      'Regular Expression Pattern Matching',
      'Longest Common Subsequence / k-LCS',
      'Tree Edit Distance',
      'String Matching in Labeled Graphs',
      'CFG Problems / Language Edit Distance',
      'k-Dominating Set',
      'Orthogonal Vectors / Hitting Set',
      'Bicriteria s,t-Path',
      'LowRankLWS',
      'Subset Chain',
      'Orthogonal Vectors / ∀∀∃-OV',
      'Global-Frechet Polyline Simplification',
      'Local-Hausdorff Polyline Simplification',
      'Bichromatic Hamming Close Pair / Approximate Bichromatic Hamming Close Pair',
      'Approximate Attention Computation',
      'Euclidean Closest Pair',
      'Earth Mover Distance',
      "Geometric Covering Problems / Klee's Measure Problem",
      'Clique / 3-Uniform k-Hyperclique',
      'Vertex Reachability / Transitive Closure',
      'All-Pairs Bottleneck Paths (APBP)',
      'Boolean Satisfiability / MAX-2-SAT',
      'Dyck-2 s-t Reachability',
      'All-Pairs Shortest Paths (APSP) / Directed, Unweighted APSP',
    ],
    rows: ['R324', 'R325', 'R326', 'R339', 'R340', 'R341', 'R344', 'R350', 'R351', 'R352', 'R361', 'R363', 'R365'],
  },
  9: {
    problems: ['Graph Triangle Problems / All-Edges Exact Triangle', 'Graph Triangle Problems / #All-Edges Monochromatic Triangle'],
    rows: [],
  },
  11: {
    problems: [
      'k-AP Detection',
      'Geometric Base / k-GeomBase',
      'Graph Triangle Problems / Lopsided All-Edges Sparse Triangle',
      'Graph Triangle Problems / #Exact Triangle',
      'Clique / Zero-Weight k-Clique',
    ],
    rows: ['R453'],
  },
  12: { problems: [], rows: ['R118', 'R434', 'R463', 'R464', 'R465'] },
  13: {
    problems: [
      'Boolean Satisfiability / k-SAT',
      'Orthogonal Vectors / Low-Dimension OV',
      'CFG Problems / CFG Recognition',
      'RNA Folding / RNA Folding',
      'Grammar-Compressed Linear Algebra / Grammar-Compressed Square-Matrix-Vector Multiplication',
      'Grammar-Compressed Linear Algebra / Grammar-Compressed Vector Inner Product',
    ],
    rows: ['R169', 'R170', 'R467', 'R469', 'R470'],
  },
};

/** The entry of row R453 in format 11 (Exact Triangle to Lopsided All-Edges Sparse Triangle, R455 before the renumbering). */
const LOPSIDED_ENTRY_11 = {
  match: { from: 'Graph Triangle Problems / Exact Triangle', to: 'Graph Triangle Problems / Lopsided All-Edges Sparse Triangle' },
  free: [
    {
      name: 'd',
      type: 'size',
      base: 'n',
      min: 1 / 18,
      max: 1 / 18,
      note: 'middle part n^{1/18}, the largest for which Theorem 1 applies (the reduction allows 16 <= d <= n)',
    },
    { name: 'g', type: 'size', base: 'n', min: 0, max: 1 / 36, note: 'number of groups, 1 <= g <= sqrt(d)' },
  ],
  note: 'd is fixed to n^{1/18} so that the produced instances are in the regime of Theorem 1 (knob U440)',
};

/**
 * The entries of the built-in config that each format changed or removed, as they were before (problems by name, rows by
 * Reduction ID): a custom config saved before that format whose entry is still that one (the same JSON, ignoring the
 * order of keys: not edited) gets the format's built-in entry, or loses it where the built-in config has none any more.
 * An entry listed by several formats is compared with its version of the first format after the saved one. Format 12
 * lists k-GeomBase for k ≥ 4 only (Fischer 2026; k = 3 is GeomBase), at M = n; and the first version of format 11
 * numbered rows R432–R464 before two of them were removed: its entries for R435 (k-GeomBase to GeomBase, removed), R453
 * (4-AP Detection to 3-uniform 4-hyperclique, now R434) and R455 (now R453) do not fit the rows of those IDs.
 */
export const ENTRIES_CHANGED_IN: Readonly<Record<number, { readonly problems: Readonly<Record<string, unknown>>; readonly rows: Readonly<Record<string, unknown>> }>> = {
  12: {
    problems: {
      'Geometric Base / k-GeomBase': {
        logParams: [],
        regimes: ['n=1, M=1, k=const:[3,4,5,6]', 'n=1, M=3, k=const:[3,4,5,6]'],
        constraints: ['n <= M: each of the k lines holds at most 2M + 1 integer points'],
        note: 'M (largest absolute x-coordinate) is a size parameter here, not only a bit length: k-AP Detection gives hard instances at M = n, GeomBase (3SUM) at M = n^{O(1)}',
      },
    },
    rows: {
      R435: {
        match: { from: 'Geometric Base / k-GeomBase', to: 'Geometric Base / GeomBase' },
        requires: 'k=const:[3]',
        note: 'only k = 3: a k-GeomBase instance with more lines is not a GeomBase instance',
      },
      R453: {
        match: { from: 'k-AP Detection', to: 'Clique / 3-Uniform k-Hyperclique' },
        requires: 'k=const:[4]',
        note: 'only k = 4: for k >= 5 the target of Lemma 5.7 is the (k-1)-uniform k-hyperclique problem',
      },
      R455: LOPSIDED_ENTRY_11,
    },
  },
  13: {
    problems: {
      'Boolean Satisfiability / CNF-SAT': {
        params: ['n', 'm'],
        timeType: 'exp',
        regimes: ['n=log, m=polylog'],
        note: 'n = #variables, m = #clauses; regime: time 2^{cn} with m = poly(n) (after sparsification m = O(n))',
      },
    },
    rows: {
      R106: {
        match: { from: 'Graph Triangle Problems / Triangle Listing', to: 'Graph Subgraph Problems / 4-Cycle Listing' },
        free: [{ name: 'delta', type: 'real', min: 0, max: 1 }],
        requires: 'm=3/2',
        note: 'the From-time is stated for Theta(sqrt n)-regular triangle-listing instances (m = n^{3/2})',
      },
      R256: {
        match: { from: 'Boolean Satisfiability / CNF-SAT', to: 'The Subset-Sum Problem / Subset Sum' },
        free: [
          { name: 'epsilon', type: 'real', min: 1e-9, max: 1, note: 'epsilon > 0: the reduction does not exist at 0 (its bounds are approached as epsilon tends to 0)' },
          { name: 'c_epsilon', type: 'fixed', value: null, note: 'constant depending only on epsilon and the clause width' },
        ],
      },
      R344: {
        match: { from: 'Boolean Satisfiability / CNF-SAT', to: 'Bicriteria s,t-Path' },
        free: [
          { name: 'beta', type: 'real', min: 0, max: 1, note: 'fraction of the variables encoded into the Subset Sum instances' },
          {
            name: 'epsilon',
            type: 'fixed',
            value: 1e-12,
            note: 'small constant > 0 of the Subset Sum reduction, fixed at 1e-12: a smaller epsilon is always better, and the reduction needs epsilon > 0 (2^{epsilon beta n} instances; at beta = 1 the graph has 2^{epsilon n} vertices)',
          },
        ],
      },
      R350: {
        match: { from: 'Orthogonal Vectors / OV', to: 'Bichromatic Hamming Close Pair / Approximate Bichromatic Hamming Close Pair' },
        free: [{ name: 'gamma', type: 'real', min: 1e-9, max: 1, note: 'growth exponent of the red set (Merlin messages); gamma > 0, with a gap that shrinks as gamma tends to 0' }],
        requires: 'd=log',
        note: 'logarithmic OV dimension (the app does not separate it from polylogarithmic)',
      },
    },
  },
};

/** The labels of the groups added after saved data of `format`. */
function groupsAddedAfter(format: number): string[] {
  return Object.entries(GROUPS_ADDED_IN).flatMap(([f, labels]) => (Number(f) > format ? labels : []));
}

/** The Bound IDs of the knobs added to existing groups after saved data of `format`. */
function knobsAddedAfter(format: number): Set<string> {
  return new Set(Object.entries(KNOBS_ADDED_IN).flatMap(([f, ids]) => (Number(f) > format ? ids : [])));
}

/** The config entries added after saved data of `format`. */
function entriesAddedAfter(format: number): { problems: string[]; rows: string[] } {
  const later = Object.entries(ENTRIES_ADDED_IN).filter(([f]) => Number(f) > format);
  return { problems: later.flatMap(([, e]) => e.problems), rows: later.flatMap(([, e]) => e.rows) };
}

/** The entries changed after saved data of `format`, as they were in that format (ENTRIES_CHANGED_IN). */
function entriesChangedAfter(format: number): { problems: Map<string, unknown>; rows: Map<string, unknown> } {
  const out = { problems: new Map<string, unknown>(), rows: new Map<string, unknown>() };
  for (const [, e] of Object.entries(ENTRIES_CHANGED_IN)
    .filter(([f]) => Number(f) > format)
    .sort(([a], [b]) => Number(a) - Number(b))) {
    for (const [name, old] of Object.entries(e.problems)) if (!out.problems.has(name)) out.problems.set(name, old);
    for (const [id, old] of Object.entries(e.rows)) if (!out.rows.has(id)) out.rows.set(id, old);
  }
  return out;
}

/** The built-in knobs changed after saved data of `format`, as they were in that format (KNOBS_CHANGED_IN). */
function knobsChangedAfter(format: number): Map<string, ChangedKnob> {
  const out = new Map<string, ChangedKnob>();
  for (const [, e] of Object.entries(KNOBS_CHANGED_IN)
    .filter(([f]) => Number(f) > format)
    .sort(([a], [b]) => Number(a) - Number(b))) {
    for (const [id, ch] of Object.entries(e)) if (!out.has(id)) out.set(id, ch);
  }
  return out;
}

/** The constants whose default changed after saved data of `format`, with their value in that format. */
function constantsChangedAfter(format: number): Map<string, number> {
  const out = new Map<string, number>();
  for (const [, e] of Object.entries(CONSTANTS_CHANGED_IN)
    .filter(([f]) => Number(f) > format)
    .sort(([a], [b]) => Number(a) - Number(b))) {
    for (const [name, old] of Object.entries(e)) if (!out.has(name)) out.set(name, old);
  }
  return out;
}

/** The renames of groups after saved data of `format`, in order. */
function groupsRenamedAfter(format: number): GroupRename[] {
  return Object.entries(GROUPS_RENAMED_IN)
    .filter(([f]) => Number(f) > format)
    .sort(([a], [b]) => Number(a) - Number(b))
    .flatMap(([, renames]) => renames);
}

/** The label a built-in group had in format 2 (before every rename). */
function labelInFormat2(label: string): string {
  return groupsRenamedAfter(2)
    .reverse()
    .reduce((l, r) => (r.to === l ? r.from : l), label);
}

/** The default of settings.maxDepthUB before format 4. */
const OLD_DEFAULT_DEPTH_UB = 4;

interface Persisted {
  format?: number;
  sheetText?: string;
  sheetName?: string;
  config?: unknown;
  scenario?: unknown;
  pinned?: Record<string, string[]>;
  prefs?: Partial<UiPrefs>;
}

function read(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Persisted) : {};
  } catch {
    return {};
  }
}

/** False once another tab saved over this one's data (see stopSaving): this tab then saves nothing more. */
let saving = true;

/** The key under which the app saves its data (another tab's saves show as storage events for it). */
export const STORAGE_KEY = KEY;

/** Stop saving (another tab saved newer data, which this tab would overwrite). */
export function stopSaving(): void {
  saving = false;
}

/**
 * What a JSON file holds, judged by its shape: a scenario (a `knobs` list), an engine config (`initialKnobs` or the old
 * `presets`, or `problems` / `rows` / `constants` without `knobs`), or something else.
 */
export function jsonKind(json: unknown): 'scenario' | 'config' | 'other' {
  if (typeof json !== 'object' || json === null || Array.isArray(json)) return 'other';
  const x = json as Record<string, unknown>;
  if (Array.isArray(x['knobs'])) return 'scenario';
  if (Array.isArray(x['initialKnobs']) || Array.isArray(x['presets'])) return 'config';
  const isObject = (v: unknown): boolean => typeof v === 'object' && v !== null && !Array.isArray(v);
  if (isObject(x['problems']) || isObject(x['rows']) || isObject(x['constants'])) return 'config';
  return 'other';
}

/**
 * Save the parts of the state worth keeping (the sheet and config only when customized).
 * @returns whether they were saved, not saved because another tab saved newer data (stopSaving), or not saved because
 *          the browser refused (storage full or unavailable)
 */
export function persist(state: AppState): 'saved' | 'stopped' | 'failed' {
  if (!saving) return 'stopped';
  const data: Persisted = {
    format: FORMAT,
    scenario: state.scenario,
    pinned: state.pinned as Record<string, string[]>,
    prefs: {
      groupFamilies: state.prefs.groupFamilies,
      showUnusedRows: state.prefs.showUnusedRows,
      focus: state.prefs.focus,
      bottomTab: state.prefs.bottomTab,
      panels: state.prefs.panels,
      theme: state.prefs.theme,
    },
  };
  if (state.sheetCustom) {
    data.sheetText = state.sheetText;
    data.sheetName = state.sheetName;
  }
  if (state.configCustom) data.config = state.config;
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
    return 'saved';
  } catch {
    // storage full or unavailable: the session still works, it just is not remembered
    return 'failed';
  }
}

/** `config` (JSON) with the initial knobs of `source` (JSON) in place of its own "presets" / "initialKnobs". */
function withInitialKnobsOf(config: unknown, source: unknown): unknown {
  if (typeof config !== 'object' || config === null || Array.isArray(config)) return config;
  const { presets: _old, ...rest } = config as Record<string, unknown>;
  const initialKnobs = typeof source === 'object' && source !== null ? (source as Record<string, unknown>)['initialKnobs'] : undefined;
  return { ...rest, initialKnobs };
}

/**
 * The knobs of format-2 data with Bound IDs. Format 2 named the initial knobs "<group>/<variation>" (e.g.
 * "seth/cnf-sat", "known-algorithms/edit-distance") and knobs added in the app "k…". A knob whose id is not a Bound ID
 * (L… or U…) gets the ID of the initial knob it was if no other knob has that ID yet, and otherwise the next ID of its
 * kind after those of the knobs and of the initial settings. Bound IDs, and the order of the knobs, are kept.
 */
export function numberFormat2Ids(knobs: readonly Knob[], config: EngineConfig): readonly Knob[] {
  const initialIds = initialScenario(config).knobs.map((k) => k.id);
  const idOf = new Map(format2InitialIds(config).map((old, i) => [old, initialIds[i]!]));
  const isBoundId = (id: string) => /^[LU]\d+$/.test(id);
  const taken = new Set(knobs.filter((k) => isBoundId(k.id)).map((k) => k.id));
  const ids = knobs.map((k) => {
    if (isBoundId(k.id)) return k.id;
    const n = idOf.get(k.id);
    if (n === undefined || taken.has(n)) return undefined;
    taken.add(n);
    return n;
  });
  const next = boundIds([...taken, ...initialIds]);
  return knobs.map((k, i) => (ids[i] === k.id ? k : { ...k, id: ids[i] ?? next(k.kind) }));
}

/**
 * `config` (JSON) with the built-in groups of `source` (JSON) that were renamed under their new labels (GROUPS_RENAMED_IN):
 * a group with an old label that has a knob of the renamed built-in group (the same Bound ID for the same problem) gets
 * the new label, and the new description if it has the old one.
 */
function withGroupsRenamed(config: unknown, source: unknown, renames: readonly GroupRename[]): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config)?.['initialKnobs'];
  const theirs = fields(source)?.['initialKnobs'];
  if (renames.length === 0 || !Array.isArray(own) || !Array.isArray(theirs)) return config;
  const knobsOf = (g: unknown): Record<string, unknown>[] => {
    const knobs = fields(g)?.['knobs'];
    return Array.isArray(knobs) ? knobs.flatMap((k) => (fields(k) ? [fields(k)!] : [])) : [];
  };
  const idOf = (k: Record<string, unknown>): string | null => {
    const raw = String(k['id'] ?? '').trim();
    return raw === '' ? null : canonicalBoundId(raw, k['kind'] === 'LB' ? 'LB' : 'UB');
  };
  const problemOf = (k: Record<string, unknown>): string => String(k['problem'] ?? '').trim();
  let changed = false;
  const groups = own.map((g) => {
    const group = fields(g);
    const rename = renames.find((r) => group?.['label'] === r.from);
    const builtIn = rename && theirs.map(fields).find((t) => t?.['label'] === rename.to);
    if (!group || !rename || !builtIn) return g;
    const same = knobsOf(group).some((o) => knobsOf(builtIn).some((k) => idOf(o) !== null && idOf(o) === idOf(k) && problemOf(o) === problemOf(k)));
    if (!same) return g;
    changed = true;
    const description = group['description'] === rename.description ? builtIn['description'] : group['description'];
    return { ...group, label: rename.to, ...(description === undefined ? {} : { description }) };
  });
  return changed ? { ...fields(config)!, initialKnobs: groups } : config;
}

/** Whether two knobs of config JSON are the same bound: problem, kind, formula or exponent, power and regime. */
function sameKnobJson(a: Record<string, unknown>, b: Record<string, unknown>): boolean {
  const text = (x: unknown): string => (x === undefined || x === null ? '' : String(x).trim());
  return (
    text(a['problem']) === text(b['problem']) &&
    a['kind'] === b['kind'] &&
    text(a['formula']) === text(b['formula']) &&
    text(a['exponent']) === text(b['exponent']) &&
    text(a['power'] ?? 1) === text(b['power'] ?? 1) &&
    text(a['regime']) === text(b['regime'])
  );
}

/**
 * `config` (JSON) with the groups of `source` (JSON) with these labels appended to its initial knobs, unless it has
 * one of their knobs already: the same Bound ID (as the validator reads it, e.g. the bare numbers of earlier versions)
 * for the same problem (a label alone may be the user's own group), or all of them as the same bounds (added earlier
 * without IDs the config had for other knobs, and saved again by an earlier version). A knob of an appended group whose Bound ID the
 * config has for another knob comes without it (it gets the next free one).
 */
function withGroupsAdded(config: unknown, source: unknown, labels: readonly string[]): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config)?.['initialKnobs'];
  const theirs = fields(source)?.['initialKnobs'];
  if (!Array.isArray(own) || !Array.isArray(theirs)) return config;
  const knobsOf = (g: unknown): Record<string, unknown>[] => {
    const knobs = fields(g)?.['knobs'];
    return Array.isArray(knobs) ? knobs.flatMap((k) => (fields(k) ? [fields(k)!] : [])) : [];
  };
  const idOf = (k: Record<string, unknown>): string | null => {
    const raw = String(k['id'] ?? '').trim();
    return raw === '' ? null : canonicalBoundId(raw, k['kind'] === 'LB' ? 'LB' : 'UB');
  };
  const ownJson = own.flatMap(knobsOf);
  const ownKnobs = ownJson.map((k) => ({ id: idOf(k), problem: String(k['problem'] ?? '').trim() }));
  const ownIds = new Set(ownKnobs.map((k) => k.id));
  const present = (k: Record<string, unknown>): boolean => ownKnobs.some((o) => o.id !== null && o.id === idOf(k) && o.problem === String(k['problem'] ?? '').trim());
  // (all of a group's knobs there as the same bounds, e.g. added earlier without an ID the config had for another knob)
  const allThere = (knobs: Record<string, unknown>[]): boolean => knobs.length > 0 && knobs.every((k) => ownJson.some((o) => sameKnobJson(o, k)));
  const added = theirs
    .filter((g) => {
      const label = fields(g)?.['label'];
      return typeof label === 'string' && labels.includes(label) && !knobsOf(g).some(present) && !allThere(knobsOf(g));
    })
    .map((g) => ({ ...fields(g)!, knobs: knobsOf(g).map(({ id, ...k }) => (ownIds.has(idOf({ ...k, id })) ? k : { ...k, id })) }));
  return added.length === 0 ? config : { ...fields(config)!, initialKnobs: [...own, ...added] };
}

/**
 * `config` (JSON) with the knobs of `source` (JSON) that have these Bound IDs appended to its groups of the same label
 * (KNOBS_ADDED_IN; of several such groups, to the one with the other knobs of the built-in group, else the first): not
 * where it has no such group, nor when it has the knob already (the same Bound ID for the same problem, or the same
 * bound). A knob whose Bound ID the config has for another knob comes without it (it gets the next free one).
 */
function withKnobsAdded(config: unknown, source: unknown, ids: ReadonlySet<string>): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config)?.['initialKnobs'];
  const theirs = fields(source)?.['initialKnobs'];
  if (ids.size === 0 || !Array.isArray(own) || !Array.isArray(theirs)) return config;
  const knobsOf = (g: unknown): Record<string, unknown>[] => {
    const knobs = fields(g)?.['knobs'];
    return Array.isArray(knobs) ? knobs.flatMap((k) => (fields(k) ? [fields(k)!] : [])) : [];
  };
  const idOf = (k: Record<string, unknown>): string | null => {
    const raw = String(k['id'] ?? '').trim();
    return raw === '' ? null : canonicalBoundId(raw, k['kind'] === 'LB' ? 'LB' : 'UB');
  };
  const problemOf = (k: Record<string, unknown>): string => String(k['problem'] ?? '').trim();
  const ownKnobs = own.flatMap(knobsOf);
  const ownIds = new Set(ownKnobs.map(idOf));
  // (a knob is there with its Bound ID for its problem, or as the same bound, e.g. added earlier without an ID the config
  // had for another knob)
  const there = (k: Record<string, unknown>): boolean => ownKnobs.some((o) => (idOf(o) !== null && idOf(o) === idOf(k) && problemOf(o) === problemOf(k)) || sameKnobJson(o, k));
  const extras = new Map<number, Record<string, unknown>[]>();
  for (const source of theirs) {
    const label = fields(source)?.['label'];
    if (typeof label !== 'string') continue;
    const extra = knobsOf(source)
      .filter((k) => ids.has(idOf(k) ?? '') && !there(k))
      .map(({ id, ...k }) => (ownIds.has(idOf({ ...k, id })) ? k : { ...k, id }));
    if (extra.length === 0) continue;
    // Into one group of that label: the one holding the built-in group's other knobs (a config may also have a group of
    // the user's with the same label), else the first.
    const candidates = own.flatMap((g, i) => (fields(g)?.['label'] === label ? [i] : []));
    const holder = candidates.find((i) => knobsOf(own[i]).some((o) => knobsOf(source).some((k) => idOf(o) !== null && idOf(o) === idOf(k) && problemOf(o) === problemOf(k))));
    const target = holder ?? candidates[0];
    if (target === undefined) continue;
    extras.set(target, [...(extras.get(target) ?? []), ...extra]);
  }
  if (extras.size === 0) return config;
  const groups = own.map((g, i) => (extras.has(i) ? { ...fields(g)!, knobs: [...knobsOf(g), ...extras.get(i)!] } : g));
  return { ...fields(config)!, initialKnobs: groups };
}

/**
 * `config` (JSON) with the entries of `source` (JSON) for these problems and rows where it has none (ENTRIES_ADDED_IN;
 * problems matched by name, ignoring case and spacing).
 */
function withEntriesAdded(config: unknown, source: unknown, keys: { readonly problems: readonly string[]; readonly rows: readonly string[] }): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config);
  if (own === null || (keys.problems.length === 0 && keys.rows.length === 0)) return config;
  const squash = (s: string): string => s.toLowerCase().replace(/\s+/g, ' ').trim();
  let changed = false;
  const merge = (field: 'problems' | 'rows', wanted: readonly string[], same: (a: string, b: string) => boolean): Record<string, unknown> => {
    const mine: Record<string, unknown> = { ...(fields(own[field]) ?? {}) };
    const theirs = fields(fields(source)?.[field]) ?? {};
    for (const key of wanted) {
      if (theirs[key] === undefined || Object.keys(mine).some((k) => same(k, key))) continue;
      mine[key] = theirs[key];
      changed = true;
    }
    return mine;
  };
  const problems = merge('problems', keys.problems, (a, b) => squash(a) === squash(b));
  const rows = merge('rows', keys.rows, (a, b) => canonicalRowId(a) === canonicalRowId(b));
  return changed ? { ...own, problems, rows } : config;
}

/** Whether two JSON values are equal, ignoring the order of object keys. */
function sameJson(a: unknown, b: unknown): boolean {
  if (Array.isArray(a) || Array.isArray(b)) return Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((x, i) => sameJson(x, b[i]));
  if (typeof a === 'object' && a !== null && typeof b === 'object' && b !== null) {
    const ka = Object.keys(a).filter((k) => (a as Record<string, unknown>)[k] !== undefined);
    const kb = Object.keys(b).filter((k) => (b as Record<string, unknown>)[k] !== undefined);
    return ka.length === kb.length && ka.every((k) => sameJson((a as Record<string, unknown>)[k], (b as Record<string, unknown>)[k]));
  }
  return a === b;
}

/**
 * `config` (JSON) with the entries of `source` (JSON) in place of its entries that are still the old built-in ones of
 * `changed` (ENTRIES_CHANGED_IN; problems matched by name, ignoring case and spacing, rows by Reduction ID), and without
 * those that the built-in config no longer has. Entries the user edited are kept.
 */
function withEntriesChanged(config: unknown, source: unknown, changed: { readonly problems: ReadonlyMap<string, unknown>; readonly rows: ReadonlyMap<string, unknown> }): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config);
  if (own === null || (changed.problems.size === 0 && changed.rows.size === 0)) return config;
  const squash = (s: string): string => s.toLowerCase().replace(/\s+/g, ' ').trim();
  let replaced = false;
  const update = (field: 'problems' | 'rows', olds: ReadonlyMap<string, unknown>, same: (a: string, b: string) => boolean): Record<string, unknown> | undefined => {
    const mine = fields(own[field]);
    if (mine === null) return undefined;
    const theirs = fields(fields(source)?.[field]) ?? {};
    const out: Record<string, unknown> = { ...mine };
    for (const [key, old] of olds) {
      const k = Object.keys(out).find((x) => same(x, key));
      if (k === undefined || !sameJson(out[k], old)) continue;
      if (theirs[key] === undefined) delete out[k];
      else out[k] = theirs[key];
      replaced = true;
    }
    return out;
  };
  const problems = update('problems', changed.problems, (a, b) => squash(a) === squash(b));
  const rows = update('rows', changed.rows, (a, b) => canonicalRowId(a) === canonicalRowId(b));
  if (!replaced) return config;
  return { ...own, ...(problems === undefined ? {} : { problems }), ...(rows === undefined ? {} : { rows }) };
}

/**
 * `config` (JSON) with the knobs of `source` (JSON) in place of its initial knobs that are still the old built-in ones of
 * `changed` (KNOBS_CHANGED_IN: the same Bound ID, as the validator reads it, for the same problem, and the same bound);
 * a note of its own (not the old built-in one) is kept.
 */
function withKnobsChanged(config: unknown, source: unknown, changed: ReadonlyMap<string, ChangedKnob>): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config)?.['initialKnobs'];
  const theirs = fields(source)?.['initialKnobs'];
  if (changed.size === 0 || !Array.isArray(own) || !Array.isArray(theirs)) return config;
  const idOf = (k: Record<string, unknown>): string | null => {
    const raw = String(k['id'] ?? '').trim();
    return raw === '' ? null : canonicalBoundId(raw, k['kind'] === 'LB' ? 'LB' : 'UB');
  };
  const problemOf = (k: Record<string, unknown>): string => String(k['problem'] ?? '').trim();
  const builtIn = theirs.flatMap((g) => {
    const knobs = fields(g)?.['knobs'];
    return Array.isArray(knobs) ? knobs.flatMap((k) => (fields(k) ? [fields(k)!] : [])) : [];
  });
  let replaced = false;
  const groups = own.map((g) => {
    const knobs = fields(g)?.['knobs'];
    if (!Array.isArray(knobs)) return g;
    const next = knobs.map((k) => {
      const mine = fields(k);
      const id = mine === null ? null : idOf(mine);
      const ch = id === null ? undefined : changed.get(id);
      if (mine === null || ch === undefined || problemOf(mine) !== ch.old.problem || !sameKnobJson(mine, ch.old as unknown as Record<string, unknown>)) return k;
      const now = builtIn.find((b) => idOf(b) === id && problemOf(b) === ch.old.problem);
      if (now === undefined) return k;
      // (when only the note changed, a knob without the old note, e.g. one without a note, keeps what it has)
      if (sameKnobJson(now, ch.old as unknown as Record<string, unknown>) && mine['note'] !== ch.old.note) return k;
      replaced = true;
      const ownNote = mine['note'] !== undefined && mine['note'] !== ch.old.note ? { note: mine['note'] } : {};
      const { note: _n, ...bound } = now;
      return { ...bound, ...(now['note'] !== undefined ? { note: now['note'] } : {}), ...ownNote, id: mine['id'] };
    });
    return { ...fields(g)!, knobs: next };
  });
  return replaced ? { ...fields(config)!, initialKnobs: groups } : config;
}

/** `config` (JSON) with the constants of `source` (JSON) whose value in it is still the old default of `changed`. */
function withConstantsChanged(config: unknown, source: unknown, changed: ReadonlyMap<string, number>): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(fields(config)?.['constants']);
  const theirs = fields(fields(source)?.['constants']);
  if (own === null || theirs === null || changed.size === 0) return config;
  let replaced = false;
  const constants: Record<string, unknown> = { ...own };
  for (const [name, old] of changed) {
    const mine = fields(own[name]);
    const now = fields(theirs[name]);
    if (mine === null || now === null || mine['value'] !== old) continue;
    constants[name] = { ...mine, value: now['value'] };
    replaced = true;
  }
  return replaced ? { ...fields(config)!, constants } : config;
}

/**
 * `config` (JSON) with the limits of parameters (`constraints`) of `source` (JSON) for the problems that have none in
 * it (problems matched by name, ignoring case and spacing): a config saved before the limits existed (format 7).
 */
function withLimitsOf(config: unknown, source: unknown): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config);
  const theirs = fields(fields(source)?.['problems']);
  if (own === null || theirs === null) return config;
  const problems: Record<string, unknown> = { ...(fields(own['problems']) ?? {}) };
  const squash = (s: string): string => s.toLowerCase().replace(/\s+/g, ' ').trim();
  let added = false;
  for (const [name, entry] of Object.entries(theirs)) {
    const limits = fields(entry)?.['constraints'];
    if (!Array.isArray(limits)) continue;
    const key = Object.keys(problems).find((k) => squash(k) === squash(name)) ?? name;
    const mine = fields(problems[key]) ?? {};
    if (mine['constraints'] !== undefined) continue;
    problems[key] = { ...mine, constraints: limits };
    added = true;
  }
  return added ? { ...own, problems } : config;
}

/** The ids format 2 gave the knobs of `config.initialKnobs`, in order (its initialScenario). */
function format2InitialIds(config: EngineConfig): string[] {
  const slug = (s: string) =>
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'x';
  const ids: string[] = [];
  for (const group of config.initialKnobs) {
    for (const spec of group.knobs) {
      const variation = spec.problem.includes(' / ') ? spec.problem.slice(spec.problem.indexOf(' / ') + 3) : spec.problem;
      const base = `${slug(labelInFormat2(group.label))}/${slug(variation)}`;
      let id = base;
      for (let k = 2; ids.includes(id); k++) id = `${base}-${k}`;
      ids.push(id);
    }
  }
  return ids;
}

export function forgetPersisted(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {
    // ignore
  }
}

/** The built-in state (no saved data). */
export function defaultState(defaultSheet: string, defaultConfigJson: unknown): AppState {
  const config = validateConfig(defaultConfigJson).value;
  return {
    sheetText: defaultSheet,
    sheetName: BUILT_IN_SHEET_NAME,
    sheetCustom: false,
    config,
    configCustom: false,
    scenario: initialScenario(config),
    pinned: {},
    selection: [],
    prefs: { ...DEFAULT_PREFS, panels: windowPanels() },
  };
}

/** Default panels for the current window (DEFAULT_PANELS outside a browser). */
function windowPanels(): PanelPrefs {
  return typeof window === 'undefined' ? DEFAULT_PANELS : defaultPanels(window.innerWidth, window.innerHeight);
}

export interface StartupMessage {
  readonly text: string;
  readonly error: boolean;
}

/**
 * The initial state: embedded defaults, overridden by what this browser saved earlier.
 * @returns the state and messages about saved data that could not be used (or was upgraded)
 */
export function initialState(defaultSheet: string, defaultConfigJson: unknown): { state: AppState; messages: StartupMessage[] } {
  const messages: StartupMessage[] = [];
  const saved = read();
  const fromFirstVersion = saved.format === undefined;
  const defConfig = validateConfig(defaultConfigJson);
  if (defConfig.errors.length > 0) messages.push({ text: `built-in config: ${defConfig.errors.join('; ')}`, error: true });
  let config = defConfig.value;
  let configCustom = false;
  const beforeFormat5 = !fromFirstVersion && saved.format! < 5;
  const beforeFormat10 = fromFirstVersion || saved.format! < 10;
  // The initial knob groups added since the saved data was written, and the knobs added to the groups there were.
  const addedGroups = fromFirstVersion ? [] : groupsAddedAfter(saved.format!);
  const addedKnobIds = fromFirstVersion ? new Set<string>() : knobsAddedAfter(saved.format!);
  const renames = fromFirstVersion ? [] : groupsRenamedAfter(saved.format!);
  const changedKnobs = fromFirstVersion ? new Map<string, ChangedKnob>() : knobsChangedAfter(saved.format!);
  if (saved.config !== undefined) {
    // The first version could not edit its presets, so they were the built-in ones: take today's initial knobs instead.
    // A config saved earlier gets the initial knob groups and knobs added since, the entries of the problems and rows
    // added since (e.g. the free parameters of new rows), and the built-in entries changed since in place of its old
    // ones where it did not edit them.
    const withGroups = fromFirstVersion
      ? withInitialKnobsOf(saved.config, defaultConfigJson)
      : addedGroups.length > 0
        ? withGroupsAdded(saved.config, defaultConfigJson, addedGroups)
        : saved.config;
    const upgraded = withConstantsChanged(
      withKnobsChanged(
        withEntriesChanged(
          withEntriesAdded(
            withKnobsAdded(withGroupsRenamed(withGroups, defaultConfigJson, renames), defaultConfigJson, addedKnobIds),
            defaultConfigJson,
            entriesAddedAfter(fromFirstVersion ? 0 : saved.format!),
          ),
          defaultConfigJson,
          entriesChangedAfter(fromFirstVersion ? 0 : saved.format!),
        ),
        defaultConfigJson,
        changedKnobs,
      ),
      defaultConfigJson,
      constantsChangedAfter(fromFirstVersion ? 0 : saved.format!),
    );
    // (and the limits of parameters, which configs saved before format 7 do not have)
    const json = fromFirstVersion || saved.format! < 7 ? withLimitsOf(upgraded, defaultConfigJson) : upgraded;
    // As when a config file is loaded, its valid parts are used (e.g. after IDs that became equal with their letters).
    if (typeof json === 'object' && json !== null && !Array.isArray(json)) {
      const v = validateConfig(json);
      config = v.value;
      configCustom = true;
      if (v.errors.length > 0) messages.push({ text: `saved config: ${v.errors.length} problem(s), the rest is used (${v.errors[0]})`, error: true });
    } else messages.push({ text: 'saved config ignored (invalid)', error: true });
  }
  let scenario = initialScenario(config);
  if (saved.scenario !== undefined && fromFirstVersion) {
    messages.push({
      text: 'This version starts from new initial settings (no preset buttons; more knobs, some switched off), so the knobs saved by the previous version were replaced. Sheet edits are kept.',
      error: false,
    });
  } else if (saved.scenario !== undefined) {
    // (new IDs avoid those of the initial knobs, also of the groups added since, which are appended below)
    const initial = scenario.knobs;
    const v = validateScenario(saved.scenario, initial.map((k) => k.id));
    const c = checkScenarioConstants(v.value, config);
    scenario = c.value;
    const errors = [...v.errors, ...c.errors];
    if (errors.length > 0) messages.push({ text: `saved scenario: ${errors.length} problem(s) ignored (${errors[0]})`, error: true });
    if ((saved.format === 2 || saved.format === 3) && scenario.settings.maxDepthUB === OLD_DEFAULT_DEPTH_UB) {
      // The old default (a limit on whole derivations) becomes the new one (a limit on detours only).
      scenario = { ...scenario, settings: { ...scenario.settings, maxDepthUB: DEFAULT_SETTINGS.maxDepthUB } };
    }
    if (saved.format === 2) scenario = { ...scenario, knobs: numberFormat2Ids(scenario.knobs, config) };
    if (beforeFormat5) {
      // Regimes written with exponents rounded to the nearest (e.g. by "＋ Algorithm here"), as fractions again (§6.7).
      const knobs = scenario.knobs.map((k) => (k.regime === undefined || upgradeRoundedSpec(k.regime) === k.regime ? k : { ...k, regime: upgradeRoundedSpec(k.regime) }));
      scenario = { ...scenario, knobs };
    }
    // The knobs of the groups added since, with the Bound IDs the initial settings give them (those of the built-in
    // config, or of the saved one, to which the groups were added above), unless the saved knobs have one already: the
    // same Bound ID for the same problem (e.g. data of this version saved again by an earlier one). A saved knob with
    // the Bound ID of an added one (one the user added) moves to the next free ID of its kind, so that the initial
    // settings name the knobs of the left panel.
    // The knobs added to groups that existed are recognized by what they are (a custom config may give them other IDs).
    const groupOf = config.initialKnobs.flatMap((g) => g.knobs.map(() => g.label));
    const has = (k: Knob): boolean => scenario.knobs.some((s) => s.id === k.id && s.problem === k.problem);
    const builtInAdded = addedKnobIds.size === 0 ? [] : initialScenario(defConfig.value).knobs.filter((k) => addedKnobIds.has(k.id));
    const isAddedKnob = (k: Knob): boolean =>
      builtInAdded.some((b) => b.problem === k.problem && b.kind === k.kind && b.formula === k.formula && b.regime === k.regime && b.exponent === k.exponent);
    const added = initial.flatMap((k, i) => ((addedGroups.includes(groupOf[i]!) || isAddedKnob(k)) && !has(k) ? [{ knob: k, group: groupOf[i]! }] : []));
    const appended = added.map((a) => a.knob);
    const addedIds = new Set(appended.map((k) => k.id));
    const next = boundIds([...scenario.knobs, ...initial].map((k) => k.id));
    const moved: string[] = [];
    const kept = scenario.knobs.map((k) => {
      if (!addedIds.has(k.id)) return k;
      const id = next(k.kind);
      moved.push(`${k.id} is now ${id}`);
      return { ...k, id };
    });
    // A knob of a renamed group with the old label as its note (the default note) gets its new default note.
    const renamedNote = (k: Knob): string | undefined => {
      if (!renames.some((r) => r.from === k.note)) return undefined;
      const i = initial.findIndex((b, j) => renames.some((r) => r.from === k.note && r.to === groupOf[j]) && b.id === k.id && b.problem === k.problem);
      return i < 0 ? undefined : initial[i]!.note;
    };
    const notes = kept.map((k) => renamedNote(k) ?? k.note);
    const relabeled = kept.map((k, i) => (notes[i] === k.note ? k : { ...k, note: notes[i] }));
    // The built-in bounds changed since (KNOBS_CHANGED_IN), where the saved knob is still the old one: it becomes the
    // bound of the initial settings, keeps its switch, and its note unless that was the old default.
    const updated: string[] = [];
    const builtInKnobs = changedKnobs.size === 0 ? [] : initialScenario(defConfig.value).knobs;
    const current = relabeled.map((k) => {
      const ch = changedKnobs.get(k.id);
      if (ch === undefined || k.problem !== ch.old.problem || !sameKnobJson(k as unknown as Record<string, unknown>, ch.old as unknown as Record<string, unknown>)) return k;
      const now = builtInKnobs.find((b) => b.id === k.id && b.problem === k.problem);
      const oldDefaultNote = ch.old.note ?? ch.group;
      // (the bound, or only its note, may have changed: then only a knob with the old default note has something to update)
      const sameBound = now !== undefined && sameKnobJson(now as unknown as Record<string, unknown>, ch.old as unknown as Record<string, unknown>);
      if (now === undefined || (sameBound && (now.note === oldDefaultNote || k.note !== oldDefaultNote))) return k;
      updated.push(k.id);
      const { id: _id, enabled: _on, note: _note, formula: _f, exponent: _e, power: _p, regime: _r, ...others } = k;
      return {
        ...others,
        id: k.id,
        problem: now.problem,
        kind: now.kind,
        ...(now.formula !== undefined ? { formula: now.formula } : {}),
        ...(now.exponent !== undefined ? { exponent: now.exponent } : {}),
        ...(now.power !== undefined ? { power: now.power } : {}),
        ...(now.regime !== undefined ? { regime: now.regime } : {}),
        enabled: k.enabled,
        ...(k.note === undefined || k.note === oldDefaultNote ? (now.note !== undefined ? { note: now.note } : {}) : { note: k.note }),
      };
    });
    if (updated.length > 0) {
      messages.push({ text: `This version updates ${updated.length} built-in bound${updated.length === 1 ? '' : 's'} you had as they were: ${updated.join(', ')} (see their notes).`, error: false });
    }
    scenario = { ...scenario, knobs: [...current, ...appended] };
    const on = appended.filter((k) => k.enabled).length;
    const labels = [...new Set(added.map((a) => a.group))].join(', ');
    // (before format 5 every Bound ID changed anyway)
    const movedText = moved.length > 0 && !beforeFormat5 ? ` They take Bound IDs your knobs had: ${moved.join(', ')}.` : '';
    const lbs = appended.filter((k) => k.kind === 'LB').length;
    const ubs = appended.length - lbs;
    const what = [lbs > 0 ? `${lbs} hypothes${lbs === 1 ? 'is' : 'es'}` : '', ubs > 0 ? `${ubs} algorithm${ubs === 1 ? '' : 's'}` : ''].filter((x) => x !== '').join(' and ');
    const adds = appended.length > 0 ? `This version adds ${what} to your knobs (${labels}; ${on === 0 ? 'switched off' : `${on} switched on`}).${movedText}` : '';
    if (beforeFormat5) {
      messages.push({
        text: `IDs have letters now: Reduction IDs are R1, R2, …, Bound IDs L1, L2, … for lower bounds and U1, U2, … for upper bounds (your saved knobs keep their place: the initial ones as listed under Initial settings).${adds ? ` ${adds}` : ''}`,
        error: false,
      });
    } else if (adds) messages.push({ text: adds, error: false });
  }
  const sheetCustom = typeof saved.sheetText === 'string' && saved.sheetText.length > 0;
  return {
    state: {
      sheetText: sheetCustom ? saved.sheetText! : defaultSheet,
      sheetName: sheetCustom ? (saved.sheetName ?? 'saved sheet') : BUILT_IN_SHEET_NAME,
      sheetCustom,
      config,
      configCustom,
      scenario,
      pinned: beforeFormat5 ? Object.fromEntries(Object.entries(saved.pinned ?? {}).map(([p, specs]) => [p, specs.map(upgradeRoundedSpec)])) : (saved.pinned ?? {}),
      selection: [],
      prefs: {
        ...DEFAULT_PREFS,
        ...(saved.prefs ?? {}),
        search: '',
        // Before format 10 the family boxes were on by default, so a saved "on" was most likely never chosen: data saved
        // then gets the new default (off), as does a value that is not a boolean.
        groupFamilies: !beforeFormat10 && typeof saved.prefs?.groupFamilies === 'boolean' ? saved.prefs.groupFamilies : DEFAULT_PREFS.groupFamilies,
        // Earlier versions did not save it (it was true or false).
        focus: isFocusMode(saved.prefs?.focus) ? saved.prefs.focus : 'off',
        panels: validatePanelPrefs(saved.prefs?.panels, windowPanels()),
        theme: isTheme(saved.prefs?.theme) ? saved.prefs.theme : 'system',
      },
    },
    messages,
  };
}
