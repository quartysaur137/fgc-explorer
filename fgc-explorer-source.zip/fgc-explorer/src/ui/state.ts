/**
 * Application state (immutable), its defaults, and browser persistence.
 */

import { boundIds, canonicalBoundId, canonicalRowId, DEFAULT_SETTINGS, EngineConfig, initialScenario, Knob, KnobKind, Scenario, validateConfig, validateScenario } from '../model/config';
import { upgradeRoundedSpec } from '../model/regime';
import { FocusMode, isFocusMode } from './focus';
import { DEFAULT_PANELS, defaultPanels, PanelPrefs, validatePanelPrefs } from './panels';
import { Selection } from './selection';
import { isTheme, Theme } from './theme';

export type BottomTab = 'problems' | 'rows' | 'diagnostics';

export interface UiPrefs {
  /** Group problems into compound nodes by family. */
  readonly groupFamilies: boolean;
  /** Show rows that are not used in propagation. */
  readonly showUnusedRows: boolean;
  /** What stays visible around the selection (the rest is dimmed); see focus.ts. */
  readonly focus: FocusMode;
  readonly bottomTab: BottomTab;
  readonly search: string;
  /** Sizes and visibility of the side and bottom panels. */
  readonly panels: PanelPrefs;
  /** Light or dark mode, or following the system (see theme.ts). */
  readonly theme: Theme;
}

export interface AppState {
  /** The sheet (CSV text) and where it came from. */
  readonly sheetText: string;
  readonly sheetName: string;
  /** True when the sheet differs from the embedded default (loaded or edited). */
  readonly sheetCustom: boolean;
  readonly config: EngineConfig;
  readonly configCustom: boolean;
  readonly scenario: Scenario;
  /** Problem id → pinned regime specs. */
  readonly pinned: Readonly<Record<string, readonly string[]>>;
  readonly selection: Selection;
  readonly prefs: UiPrefs;
}

/** The name of the built-in sheet (the status line shortens it to "built-in sheet"). */
export const BUILT_IN_SHEET_NAME = 'FGC_Reductions_filled.csv (built in)';

export const DEFAULT_PREFS: UiPrefs = {
  // (off since format 10: with the boxes drawn, a drag that starts inside a box moves the box instead of panning)
  groupFamilies: false,
  showUnusedRows: true,
  focus: 'off',
  bottomTab: 'problems',
  search: '',
  panels: DEFAULT_PANELS,
  theme: 'system',
};

/**
 * A fresh Bound ID for a knob of `kind`: its letter and the next number after the largest one with that letter among
 * `knobs` (L1, L2, … for lower bounds; U1, U2, … for upper bounds).
 */
export function newKnobId(knobs: readonly Knob[], kind: KnobKind): string {
  return boundIds(knobs.map((k) => k.id))(kind);
}

// ---------------------------------------------------------------------------------------------------------------------
// Persistence (localStorage; every access may fail, e.g. in private windows)
// ---------------------------------------------------------------------------------------------------------------------

/** (index.html reads the saved theme under this key before the page is drawn.) */
const KEY = 'fgc-explorer.v1';

/**
 * Version of the saved data. Data without it was written by the first version, whose knobs came from preset buttons
 * and whose config called its initial knobs "presets". Format 2 was written before Bound IDs were numbers (it named
 * them, e.g. "seth/cnf-sat"); formats 2 and 3 limited the length of upper-bound derivations with settings.maxDepthUB (4
 * by default), which now limits only their detours through regimes the search does not start from (3 by default). Formats 3 and 4
 * numbered Bound IDs 1, 2, … (and all formats Reduction IDs likewise); format 5 writes L1, … / U1, … and R1, … (the
 * validators convert the old numbers, see legacyBoundId and canonicalRowId). Formats 5 and 6 added initial knob groups
 * (GROUPS_ADDED_IN); format 7 the limits of parameters (a custom config saved before gets the built-in ones, see
 * withLimitsOf); format 8 the problems of rows R320–R365, with their hypotheses (GROUPS_ADDED_IN), algorithms in groups
 * that existed (KNOBS_ADDED_IN), and config entries (ENTRIES_ADDED_IN); format 9 the algorithms and config entries of
 * the two problems that the trivial reductions R366–R431 gave a signature (All-Edges Exact Triangle and #All-Edges
 * Monochromatic Triangle). Format 10 turned the family boxes off by default: data saved before has them off (on was the
 * default then, so a saved "on" is no choice; see initialState), later data keeps its setting.
 */
const FORMAT = 10;

/**
 * The built-in initial knob groups each format added (their labels): the groups are added to a custom config saved
 * before that format (unless one of their knobs' Bound IDs is there for the same problem: a label alone may be the
 * user's own group), and their knobs, with the Bound IDs of the initial settings, to the knobs saved before it (a saved
 * knob that has one of those IDs moves to a new one).
 */
export const GROUPS_ADDED_IN: Readonly<Record<number, readonly string[]>> = {
  5: ['Trivial algorithms', 'Best known algorithms', 'Non-combinatorial algorithms'],
  6: ['Saha & Ye 2026'],
  8: ['OMv conjecture', 'Hitting Set hypothesis', '∀∀∃-OV hypothesis', '3-uniform hyperclique hypothesis'],
};

/** Bound IDs U<from>, …, U<to>. */
function ubIds(from: number, to: number): string[] {
  return Array.from({ length: to - from + 1 }, (_, i) => `U${from + i}`);
}

/**
 * The knobs each format added to built-in groups that existed before (their Bound IDs in the built-in config): they are
 * added to the same groups of a custom config saved before that format (where the group is, unless the knob is there
 * already: the same Bound ID for the same problem), and to the knobs saved before it, like the knobs of added groups.
 */
export const KNOBS_ADDED_IN: Readonly<Record<number, readonly string[]>> = {
  8: ubIds(370, 418),
  9: ubIds(419, 422),
};

/**
 * The problems and rows each format added to the built-in config (keys of `problems` and `rows`): a custom config saved
 * before that format gets their entries where it has none of its own (e.g. the free parameters of the new rows).
 */
export const ENTRIES_ADDED_IN: Readonly<Record<number, { readonly problems: readonly string[]; readonly rows: readonly string[] }>> = {
  8: {
    problems: [
      'Matrix-Vector Multiplication / OMv',
      'Multiphase Problem',
      'Dynamic Subgraph Connectivity',
      'Regular Expression Pattern Matching',
      'Longest Common Subsequence / k-LCS',
      'Tree Edit Distance',
      'String Matching in Labeled Graphs',
      'CFG Problems / Language Edit Distance',
      'k-Dominating Set',
      'Orthogonal Vectors / Hitting Set',
      'Bicriteria s,t-Path',
      'LowRankLWS',
      'Subset Chain',
      'Orthogonal Vectors / ∀∀∃-OV',
      'Global-Frechet Polyline Simplification',
      'Local-Hausdorff Polyline Simplification',
      'Bichromatic Hamming Close Pair / Approximate Bichromatic Hamming Close Pair',
      'Approximate Attention Computation',
      'Euclidean Closest Pair',
      'Earth Mover Distance',
      "Geometric Covering Problems / Klee's Measure Problem",
      'Clique / 3-Uniform k-Hyperclique',
      'Vertex Reachability / Transitive Closure',
      'All-Pairs Bottleneck Paths (APBP)',
      'Boolean Satisfiability / MAX-2-SAT',
      'Dyck-2 s-t Reachability',
      'All-Pairs Shortest Paths (APSP) / Directed, Unweighted APSP',
    ],
    rows: ['R324', 'R325', 'R326', 'R339', 'R340', 'R341', 'R344', 'R350', 'R351', 'R352', 'R361', 'R363', 'R365'],
  },
  9: {
    problems: ['Graph Triangle Problems / All-Edges Exact Triangle', 'Graph Triangle Problems / #All-Edges Monochromatic Triangle'],
    rows: [],
  },
};

/** The labels of the groups added after saved data of `format`. */
function groupsAddedAfter(format: number): string[] {
  return Object.entries(GROUPS_ADDED_IN).flatMap(([f, labels]) => (Number(f) > format ? labels : []));
}

/** The Bound IDs of the knobs added to existing groups after saved data of `format`. */
function knobsAddedAfter(format: number): Set<string> {
  return new Set(Object.entries(KNOBS_ADDED_IN).flatMap(([f, ids]) => (Number(f) > format ? ids : [])));
}

/** The config entries added after saved data of `format`. */
function entriesAddedAfter(format: number): { problems: string[]; rows: string[] } {
  const later = Object.entries(ENTRIES_ADDED_IN).filter(([f]) => Number(f) > format);
  return { problems: later.flatMap(([, e]) => e.problems), rows: later.flatMap(([, e]) => e.rows) };
}

/** The default of settings.maxDepthUB before format 4. */
const OLD_DEFAULT_DEPTH_UB = 4;

interface Persisted {
  format?: number;
  sheetText?: string;
  sheetName?: string;
  config?: unknown;
  scenario?: unknown;
  pinned?: Record<string, string[]>;
  prefs?: Partial<UiPrefs>;
}

function read(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Persisted) : {};
  } catch {
    return {};
  }
}

/** Save the parts of the state worth keeping (the sheet and config only when customized). */
export function persist(state: AppState): void {
  const data: Persisted = {
    format: FORMAT,
    scenario: state.scenario,
    pinned: state.pinned as Record<string, string[]>,
    prefs: {
      groupFamilies: state.prefs.groupFamilies,
      showUnusedRows: state.prefs.showUnusedRows,
      focus: state.prefs.focus,
      bottomTab: state.prefs.bottomTab,
      panels: state.prefs.panels,
      theme: state.prefs.theme,
    },
  };
  if (state.sheetCustom) {
    data.sheetText = state.sheetText;
    data.sheetName = state.sheetName;
  }
  if (state.configCustom) data.config = state.config;
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // storage full or unavailable: the session still works, it just is not remembered
  }
}

/** `config` (JSON) with the initial knobs of `source` (JSON) in place of its own "presets" / "initialKnobs". */
function withInitialKnobsOf(config: unknown, source: unknown): unknown {
  if (typeof config !== 'object' || config === null || Array.isArray(config)) return config;
  const { presets: _old, ...rest } = config as Record<string, unknown>;
  const initialKnobs = typeof source === 'object' && source !== null ? (source as Record<string, unknown>)['initialKnobs'] : undefined;
  return { ...rest, initialKnobs };
}

/**
 * The knobs of format-2 data with Bound IDs. Format 2 named the initial knobs "<group>/<variation>" (e.g.
 * "seth/cnf-sat", "known-algorithms/edit-distance") and knobs added in the app "k…". A knob whose id is not a Bound ID
 * (L… or U…) gets the ID of the initial knob it was if no other knob has that ID yet, and otherwise the next ID of its
 * kind after those of the knobs and of the initial settings. Bound IDs, and the order of the knobs, are kept.
 */
export function numberFormat2Ids(knobs: readonly Knob[], config: EngineConfig): readonly Knob[] {
  const initialIds = initialScenario(config).knobs.map((k) => k.id);
  const idOf = new Map(format2InitialIds(config).map((old, i) => [old, initialIds[i]!]));
  const isBoundId = (id: string) => /^[LU]\d+$/.test(id);
  const taken = new Set(knobs.filter((k) => isBoundId(k.id)).map((k) => k.id));
  const ids = knobs.map((k) => {
    if (isBoundId(k.id)) return k.id;
    const n = idOf.get(k.id);
    if (n === undefined || taken.has(n)) return undefined;
    taken.add(n);
    return n;
  });
  const next = boundIds([...taken, ...initialIds]);
  return knobs.map((k, i) => (ids[i] === k.id ? k : { ...k, id: ids[i] ?? next(k.kind) }));
}

/** Whether two knobs of config JSON are the same bound: problem, kind, formula or exponent, power and regime. */
function sameKnobJson(a: Record<string, unknown>, b: Record<string, unknown>): boolean {
  const text = (x: unknown): string => (x === undefined || x === null ? '' : String(x).trim());
  return (
    text(a['problem']) === text(b['problem']) &&
    a['kind'] === b['kind'] &&
    text(a['formula']) === text(b['formula']) &&
    text(a['exponent']) === text(b['exponent']) &&
    text(a['power'] ?? 1) === text(b['power'] ?? 1) &&
    text(a['regime']) === text(b['regime'])
  );
}

/**
 * `config` (JSON) with the groups of `source` (JSON) with these labels appended to its initial knobs, unless it has
 * one of their knobs already: the same Bound ID (as the validator reads it, e.g. the bare numbers of earlier versions)
 * for the same problem (a label alone may be the user's own group), or all of them as the same bounds (added earlier
 * without IDs the config had for other knobs, and saved again by an earlier version). A knob of an appended group whose Bound ID the
 * config has for another knob comes without it (it gets the next free one).
 */
function withGroupsAdded(config: unknown, source: unknown, labels: readonly string[]): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config)?.['initialKnobs'];
  const theirs = fields(source)?.['initialKnobs'];
  if (!Array.isArray(own) || !Array.isArray(theirs)) return config;
  const knobsOf = (g: unknown): Record<string, unknown>[] => {
    const knobs = fields(g)?.['knobs'];
    return Array.isArray(knobs) ? knobs.flatMap((k) => (fields(k) ? [fields(k)!] : [])) : [];
  };
  const idOf = (k: Record<string, unknown>): string | null => {
    const raw = String(k['id'] ?? '').trim();
    return raw === '' ? null : canonicalBoundId(raw, k['kind'] === 'LB' ? 'LB' : 'UB');
  };
  const ownJson = own.flatMap(knobsOf);
  const ownKnobs = ownJson.map((k) => ({ id: idOf(k), problem: String(k['problem'] ?? '').trim() }));
  const ownIds = new Set(ownKnobs.map((k) => k.id));
  const present = (k: Record<string, unknown>): boolean => ownKnobs.some((o) => o.id !== null && o.id === idOf(k) && o.problem === String(k['problem'] ?? '').trim());
  // (all of a group's knobs there as the same bounds, e.g. added earlier without an ID the config had for another knob)
  const allThere = (knobs: Record<string, unknown>[]): boolean => knobs.length > 0 && knobs.every((k) => ownJson.some((o) => sameKnobJson(o, k)));
  const added = theirs
    .filter((g) => {
      const label = fields(g)?.['label'];
      return typeof label === 'string' && labels.includes(label) && !knobsOf(g).some(present) && !allThere(knobsOf(g));
    })
    .map((g) => ({ ...fields(g)!, knobs: knobsOf(g).map(({ id, ...k }) => (ownIds.has(idOf({ ...k, id })) ? k : { ...k, id })) }));
  return added.length === 0 ? config : { ...fields(config)!, initialKnobs: [...own, ...added] };
}

/**
 * `config` (JSON) with the knobs of `source` (JSON) that have these Bound IDs appended to its groups of the same label
 * (KNOBS_ADDED_IN; of several such groups, to the one with the other knobs of the built-in group, else the first): not
 * where it has no such group, nor when it has the knob already (the same Bound ID for the same problem, or the same
 * bound). A knob whose Bound ID the config has for another knob comes without it (it gets the next free one).
 */
function withKnobsAdded(config: unknown, source: unknown, ids: ReadonlySet<string>): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config)?.['initialKnobs'];
  const theirs = fields(source)?.['initialKnobs'];
  if (ids.size === 0 || !Array.isArray(own) || !Array.isArray(theirs)) return config;
  const knobsOf = (g: unknown): Record<string, unknown>[] => {
    const knobs = fields(g)?.['knobs'];
    return Array.isArray(knobs) ? knobs.flatMap((k) => (fields(k) ? [fields(k)!] : [])) : [];
  };
  const idOf = (k: Record<string, unknown>): string | null => {
    const raw = String(k['id'] ?? '').trim();
    return raw === '' ? null : canonicalBoundId(raw, k['kind'] === 'LB' ? 'LB' : 'UB');
  };
  const problemOf = (k: Record<string, unknown>): string => String(k['problem'] ?? '').trim();
  const ownKnobs = own.flatMap(knobsOf);
  const ownIds = new Set(ownKnobs.map(idOf));
  // (a knob is there with its Bound ID for its problem, or as the same bound, e.g. added earlier without an ID the config
  // had for another knob)
  const there = (k: Record<string, unknown>): boolean => ownKnobs.some((o) => (idOf(o) !== null && idOf(o) === idOf(k) && problemOf(o) === problemOf(k)) || sameKnobJson(o, k));
  const extras = new Map<number, Record<string, unknown>[]>();
  for (const source of theirs) {
    const label = fields(source)?.['label'];
    if (typeof label !== 'string') continue;
    const extra = knobsOf(source)
      .filter((k) => ids.has(idOf(k) ?? '') && !there(k))
      .map(({ id, ...k }) => (ownIds.has(idOf({ ...k, id })) ? k : { ...k, id }));
    if (extra.length === 0) continue;
    // Into one group of that label: the one holding the built-in group's other knobs (a config may also have a group of
    // the user's with the same label), else the first.
    const candidates = own.flatMap((g, i) => (fields(g)?.['label'] === label ? [i] : []));
    const holder = candidates.find((i) => knobsOf(own[i]).some((o) => knobsOf(source).some((k) => idOf(o) !== null && idOf(o) === idOf(k) && problemOf(o) === problemOf(k))));
    const target = holder ?? candidates[0];
    if (target === undefined) continue;
    extras.set(target, [...(extras.get(target) ?? []), ...extra]);
  }
  if (extras.size === 0) return config;
  const groups = own.map((g, i) => (extras.has(i) ? { ...fields(g)!, knobs: [...knobsOf(g), ...extras.get(i)!] } : g));
  return { ...fields(config)!, initialKnobs: groups };
}

/**
 * `config` (JSON) with the entries of `source` (JSON) for these problems and rows where it has none (ENTRIES_ADDED_IN;
 * problems matched by name, ignoring case and spacing).
 */
function withEntriesAdded(config: unknown, source: unknown, keys: { readonly problems: readonly string[]; readonly rows: readonly string[] }): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config);
  if (own === null || (keys.problems.length === 0 && keys.rows.length === 0)) return config;
  const squash = (s: string): string => s.toLowerCase().replace(/\s+/g, ' ').trim();
  let changed = false;
  const merge = (field: 'problems' | 'rows', wanted: readonly string[], same: (a: string, b: string) => boolean): Record<string, unknown> => {
    const mine: Record<string, unknown> = { ...(fields(own[field]) ?? {}) };
    const theirs = fields(fields(source)?.[field]) ?? {};
    for (const key of wanted) {
      if (theirs[key] === undefined || Object.keys(mine).some((k) => same(k, key))) continue;
      mine[key] = theirs[key];
      changed = true;
    }
    return mine;
  };
  const problems = merge('problems', keys.problems, (a, b) => squash(a) === squash(b));
  const rows = merge('rows', keys.rows, (a, b) => canonicalRowId(a) === canonicalRowId(b));
  return changed ? { ...own, problems, rows } : config;
}

/**
 * `config` (JSON) with the limits of parameters (`constraints`) of `source` (JSON) for the problems that have none in
 * it (problems matched by name, ignoring case and spacing): a config saved before the limits existed (format 7).
 */
function withLimitsOf(config: unknown, source: unknown): unknown {
  const fields = (x: unknown): Record<string, unknown> | null => (typeof x === 'object' && x !== null && !Array.isArray(x) ? (x as Record<string, unknown>) : null);
  const own = fields(config);
  const theirs = fields(fields(source)?.['problems']);
  if (own === null || theirs === null) return config;
  const problems: Record<string, unknown> = { ...(fields(own['problems']) ?? {}) };
  const squash = (s: string): string => s.toLowerCase().replace(/\s+/g, ' ').trim();
  let added = false;
  for (const [name, entry] of Object.entries(theirs)) {
    const limits = fields(entry)?.['constraints'];
    if (!Array.isArray(limits)) continue;
    const key = Object.keys(problems).find((k) => squash(k) === squash(name)) ?? name;
    const mine = fields(problems[key]) ?? {};
    if (mine['constraints'] !== undefined) continue;
    problems[key] = { ...mine, constraints: limits };
    added = true;
  }
  return added ? { ...own, problems } : config;
}

/** The ids format 2 gave the knobs of `config.initialKnobs`, in order (its initialScenario). */
function format2InitialIds(config: EngineConfig): string[] {
  const slug = (s: string) =>
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'x';
  const ids: string[] = [];
  for (const group of config.initialKnobs) {
    for (const spec of group.knobs) {
      const variation = spec.problem.includes(' / ') ? spec.problem.slice(spec.problem.indexOf(' / ') + 3) : spec.problem;
      const base = `${slug(group.label)}/${slug(variation)}`;
      let id = base;
      for (let k = 2; ids.includes(id); k++) id = `${base}-${k}`;
      ids.push(id);
    }
  }
  return ids;
}

export function forgetPersisted(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {
    // ignore
  }
}

/** The built-in state (no saved data). */
export function defaultState(defaultSheet: string, defaultConfigJson: unknown): AppState {
  const config = validateConfig(defaultConfigJson).value;
  return {
    sheetText: defaultSheet,
    sheetName: BUILT_IN_SHEET_NAME,
    sheetCustom: false,
    config,
    configCustom: false,
    scenario: initialScenario(config),
    pinned: {},
    selection: [],
    prefs: { ...DEFAULT_PREFS, panels: windowPanels() },
  };
}

/** Default panels for the current window (DEFAULT_PANELS outside a browser). */
function windowPanels(): PanelPrefs {
  return typeof window === 'undefined' ? DEFAULT_PANELS : defaultPanels(window.innerWidth, window.innerHeight);
}

export interface StartupMessage {
  readonly text: string;
  readonly error: boolean;
}

/**
 * The initial state: embedded defaults, overridden by what this browser saved earlier.
 * @returns the state and messages about saved data that could not be used (or was upgraded)
 */
export function initialState(defaultSheet: string, defaultConfigJson: unknown): { state: AppState; messages: StartupMessage[] } {
  const messages: StartupMessage[] = [];
  const saved = read();
  const fromFirstVersion = saved.format === undefined;
  const defConfig = validateConfig(defaultConfigJson);
  if (defConfig.errors.length > 0) messages.push({ text: `built-in config: ${defConfig.errors.join('; ')}`, error: true });
  let config = defConfig.value;
  let configCustom = false;
  const beforeFormat5 = !fromFirstVersion && saved.format! < 5;
  const beforeFormat10 = fromFirstVersion || saved.format! < 10;
  // The initial knob groups added since the saved data was written, and the knobs added to the groups there were.
  const addedGroups = fromFirstVersion ? [] : groupsAddedAfter(saved.format!);
  const addedKnobIds = fromFirstVersion ? new Set<string>() : knobsAddedAfter(saved.format!);
  if (saved.config !== undefined) {
    // The first version could not edit its presets, so they were the built-in ones: take today's initial knobs instead.
    // A config saved earlier gets the initial knob groups and knobs added since, and the entries of the problems and
    // rows added since (e.g. the free parameters of new rows).
    const withGroups = fromFirstVersion
      ? withInitialKnobsOf(saved.config, defaultConfigJson)
      : addedGroups.length > 0
        ? withGroupsAdded(saved.config, defaultConfigJson, addedGroups)
        : saved.config;
    const upgraded = withEntriesAdded(withKnobsAdded(withGroups, defaultConfigJson, addedKnobIds), defaultConfigJson, entriesAddedAfter(fromFirstVersion ? 0 : saved.format!));
    // (and the limits of parameters, which configs saved before format 7 do not have)
    const json = fromFirstVersion || saved.format! < 7 ? withLimitsOf(upgraded, defaultConfigJson) : upgraded;
    // As when a config file is loaded, its valid parts are used (e.g. after IDs that became equal with their letters).
    if (typeof json === 'object' && json !== null && !Array.isArray(json)) {
      const v = validateConfig(json);
      config = v.value;
      configCustom = true;
      if (v.errors.length > 0) messages.push({ text: `saved config: ${v.errors.length} problem(s), the rest is used (${v.errors[0]})`, error: true });
    } else messages.push({ text: 'saved config ignored (invalid)', error: true });
  }
  let scenario = initialScenario(config);
  if (saved.scenario !== undefined && fromFirstVersion) {
    messages.push({
      text: 'This version starts from new initial settings (no preset buttons; more knobs, some switched off), so the knobs saved by the previous version were replaced. Sheet edits are kept.',
      error: false,
    });
  } else if (saved.scenario !== undefined) {
    // (new IDs avoid those of the initial knobs, also of the groups added since, which are appended below)
    const initial = scenario.knobs;
    const v = validateScenario(saved.scenario, initial.map((k) => k.id));
    scenario = v.value;
    if (v.errors.length > 0) messages.push({ text: `saved scenario: ${v.errors.length} problem(s) ignored`, error: true });
    if ((saved.format === 2 || saved.format === 3) && scenario.settings.maxDepthUB === OLD_DEFAULT_DEPTH_UB) {
      // The old default (a limit on whole derivations) becomes the new one (a limit on detours only).
      scenario = { ...scenario, settings: { ...scenario.settings, maxDepthUB: DEFAULT_SETTINGS.maxDepthUB } };
    }
    if (saved.format === 2) scenario = { ...scenario, knobs: numberFormat2Ids(scenario.knobs, config) };
    if (beforeFormat5) {
      // Regimes written with exponents rounded to the nearest (e.g. by "＋ Algorithm here"), as fractions again (§6.7).
      const knobs = scenario.knobs.map((k) => (k.regime === undefined || upgradeRoundedSpec(k.regime) === k.regime ? k : { ...k, regime: upgradeRoundedSpec(k.regime) }));
      scenario = { ...scenario, knobs };
    }
    // The knobs of the groups added since, with the Bound IDs the initial settings give them (those of the built-in
    // config, or of the saved one, to which the groups were added above), unless the saved knobs have one already: the
    // same Bound ID for the same problem (e.g. data of this version saved again by an earlier one). A saved knob with
    // the Bound ID of an added one (one the user added) moves to the next free ID of its kind, so that the initial
    // settings name the knobs of the left panel.
    // The knobs added to groups that existed are recognized by what they are (a custom config may give them other IDs).
    const groupOf = config.initialKnobs.flatMap((g) => g.knobs.map(() => g.label));
    const has = (k: Knob): boolean => scenario.knobs.some((s) => s.id === k.id && s.problem === k.problem);
    const builtInAdded = addedKnobIds.size === 0 ? [] : initialScenario(defConfig.value).knobs.filter((k) => addedKnobIds.has(k.id));
    const isAddedKnob = (k: Knob): boolean =>
      builtInAdded.some((b) => b.problem === k.problem && b.kind === k.kind && b.formula === k.formula && b.regime === k.regime && b.exponent === k.exponent);
    const added = initial.flatMap((k, i) => ((addedGroups.includes(groupOf[i]!) || isAddedKnob(k)) && !has(k) ? [{ knob: k, group: groupOf[i]! }] : []));
    const appended = added.map((a) => a.knob);
    const addedIds = new Set(appended.map((k) => k.id));
    const next = boundIds([...scenario.knobs, ...initial].map((k) => k.id));
    const moved: string[] = [];
    const kept = scenario.knobs.map((k) => {
      if (!addedIds.has(k.id)) return k;
      const id = next(k.kind);
      moved.push(`${k.id} is now ${id}`);
      return { ...k, id };
    });
    scenario = { ...scenario, knobs: [...kept, ...appended] };
    const on = appended.filter((k) => k.enabled).length;
    const labels = [...new Set(added.map((a) => a.group))].join(', ');
    // (before format 5 every Bound ID changed anyway)
    const movedText = moved.length > 0 && !beforeFormat5 ? ` They take Bound IDs your knobs had: ${moved.join(', ')}.` : '';
    const lbs = appended.filter((k) => k.kind === 'LB').length;
    const ubs = appended.length - lbs;
    const what = [lbs > 0 ? `${lbs} hypothes${lbs === 1 ? 'is' : 'es'}` : '', ubs > 0 ? `${ubs} algorithm${ubs === 1 ? '' : 's'}` : ''].filter((x) => x !== '').join(' and ');
    const adds = appended.length > 0 ? `This version adds ${what} to your knobs (${labels}; ${on === 0 ? 'switched off' : `${on} switched on`}).${movedText}` : '';
    if (beforeFormat5) {
      messages.push({
        text: `IDs have letters now: Reduction IDs are R1, R2, …, Bound IDs L1, L2, … for lower bounds and U1, U2, … for upper bounds (your saved knobs keep their place: the initial ones as listed under Initial settings).${adds ? ` ${adds}` : ''}`,
        error: false,
      });
    } else if (adds) messages.push({ text: adds, error: false });
  }
  const sheetCustom = typeof saved.sheetText === 'string' && saved.sheetText.length > 0;
  return {
    state: {
      sheetText: sheetCustom ? saved.sheetText! : defaultSheet,
      sheetName: sheetCustom ? (saved.sheetName ?? 'saved sheet') : BUILT_IN_SHEET_NAME,
      sheetCustom,
      config,
      configCustom,
      scenario,
      pinned: beforeFormat5 ? Object.fromEntries(Object.entries(saved.pinned ?? {}).map(([p, specs]) => [p, specs.map(upgradeRoundedSpec)])) : (saved.pinned ?? {}),
      selection: [],
      prefs: {
        ...DEFAULT_PREFS,
        ...(saved.prefs ?? {}),
        search: '',
        // Before format 10 the family boxes were on by default, so a saved "on" was most likely never chosen: data saved
        // then gets the new default (off), as does a value that is not a boolean.
        groupFamilies: !beforeFormat10 && typeof saved.prefs?.groupFamilies === 'boolean' ? saved.prefs.groupFamilies : DEFAULT_PREFS.groupFamilies,
        // Earlier versions did not save it (it was true or false).
        focus: isFocusMode(saved.prefs?.focus) ? saved.prefs.focus : 'off',
        panels: validatePanelPrefs(saved.prefs?.panels, windowPanels()),
        theme: isTheme(saved.prefs?.theme) ? saved.prefs.theme : 'system',
      },
    },
    messages,
  };
}
