/**
 * Application state (immutable), its defaults, and browser persistence.
 */

import { EngineConfig, initialScenario, Knob, numberedIds, Scenario, validateConfig, validateScenario } from '../model/config';
import { FocusMode, isFocusMode } from './focus';
import { DEFAULT_PANELS, defaultPanels, PanelPrefs, validatePanelPrefs } from './panels';
import { Selection } from './selection';

export type BottomTab = 'problems' | 'rows' | 'diagnostics';

export interface UiPrefs {
  /** Group problems into compound nodes by family. */
  readonly groupFamilies: boolean;
  /** Show rows that are not used in propagation. */
  readonly showUnusedRows: boolean;
  /** What stays visible around the selection (the rest is dimmed); see focus.ts. */
  readonly focus: FocusMode;
  readonly bottomTab: BottomTab;
  readonly search: string;
  /** Sizes and visibility of the side and bottom panels. */
  readonly panels: PanelPrefs;
}

export interface AppState {
  /** The sheet (CSV text) and where it came from. */
  readonly sheetText: string;
  readonly sheetName: string;
  /** True when the sheet differs from the embedded default (loaded or edited). */
  readonly sheetCustom: boolean;
  readonly config: EngineConfig;
  readonly configCustom: boolean;
  readonly scenario: Scenario;
  /** Problem id → pinned regime specs. */
  readonly pinned: Readonly<Record<string, readonly string[]>>;
  readonly selection: Selection;
  readonly prefs: UiPrefs;
}

/** The name of the built-in sheet (the status line shortens it to "built-in sheet"). */
export const BUILT_IN_SHEET_NAME = 'FGC_Reductions_filled.csv (built in)';

export const DEFAULT_PREFS: UiPrefs = { groupFamilies: true, showUnusedRows: true, focus: 'off', bottomTab: 'problems', search: '', panels: DEFAULT_PANELS };

/** A fresh knob id: the next number after the largest numeric id in `knobs` (ids are numbers, as Bound IDs). */
export function newKnobId(knobs: readonly Knob[]): string {
  return numberedIds(knobs.map((k) => k.id))();
}

// ---------------------------------------------------------------------------------------------------------------------
// Persistence (localStorage; every access may fail, e.g. in private windows)
// ---------------------------------------------------------------------------------------------------------------------

const KEY = 'fgc-explorer.v1';

/**
 * Version of the saved data. Data without it was written by the first version, whose knobs came from preset buttons
 * and whose config called its initial knobs "presets". Format 2 was written before Bound IDs were numbers.
 */
const FORMAT = 3;

interface Persisted {
  format?: number;
  sheetText?: string;
  sheetName?: string;
  config?: unknown;
  scenario?: unknown;
  pinned?: Record<string, string[]>;
  prefs?: Partial<UiPrefs>;
}

function read(): Persisted {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Persisted) : {};
  } catch {
    return {};
  }
}

/** Save the parts of the state worth keeping (the sheet and config only when customized). */
export function persist(state: AppState): void {
  const data: Persisted = {
    format: FORMAT,
    scenario: state.scenario,
    pinned: state.pinned as Record<string, string[]>,
    prefs: {
      groupFamilies: state.prefs.groupFamilies,
      showUnusedRows: state.prefs.showUnusedRows,
      focus: state.prefs.focus,
      bottomTab: state.prefs.bottomTab,
      panels: state.prefs.panels,
    },
  };
  if (state.sheetCustom) {
    data.sheetText = state.sheetText;
    data.sheetName = state.sheetName;
  }
  if (state.configCustom) data.config = state.config;
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    // storage full or unavailable: the session still works, it just is not remembered
  }
}

/** `config` (JSON) with the initial knobs of `source` (JSON) in place of its own "presets" / "initialKnobs". */
function withInitialKnobsOf(config: unknown, source: unknown): unknown {
  if (typeof config !== 'object' || config === null || Array.isArray(config)) return config;
  const { presets: _old, ...rest } = config as Record<string, unknown>;
  const initialKnobs = typeof source === 'object' && source !== null ? (source as Record<string, unknown>)['initialKnobs'] : undefined;
  return { ...rest, initialKnobs };
}

/**
 * The knobs of format-2 data with numbers as ids. Format 2 named the initial knobs "<group>/<variation>" (e.g.
 * "seth/cnf-sat", "known-algorithms/edit-distance") and knobs added in the app "k…". A knob whose id is not a number
 * gets the number of the initial knob it was if no other knob has that number yet, and otherwise the next number after
 * those of the knobs and of the initial settings. Ids that are numbers, and the order of the knobs, are kept.
 */
export function numberFormat2Ids(knobs: readonly Knob[], config: EngineConfig): readonly Knob[] {
  const initialIds = initialScenario(config).knobs.map((k) => k.id);
  const numberOf = new Map(format2InitialIds(config).map((old, i) => [old, initialIds[i]!]));
  const isNumber = (id: string) => /^\d+$/.test(id);
  const taken = new Set(knobs.filter((k) => isNumber(k.id)).map((k) => k.id));
  const ids = knobs.map((k) => {
    if (isNumber(k.id)) return k.id;
    const n = numberOf.get(k.id);
    if (n === undefined || taken.has(n)) return undefined;
    taken.add(n);
    return n;
  });
  const next = numberedIds([...taken, ...initialIds]);
  return knobs.map((k, i) => (ids[i] === k.id ? k : { ...k, id: ids[i] ?? next() }));
}

/** The ids format 2 gave the knobs of `config.initialKnobs`, in order (its initialScenario). */
function format2InitialIds(config: EngineConfig): string[] {
  const slug = (s: string) =>
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '') || 'x';
  const ids: string[] = [];
  for (const group of config.initialKnobs) {
    for (const spec of group.knobs) {
      const variation = spec.problem.includes(' / ') ? spec.problem.slice(spec.problem.indexOf(' / ') + 3) : spec.problem;
      const base = `${slug(group.label)}/${slug(variation)}`;
      let id = base;
      for (let k = 2; ids.includes(id); k++) id = `${base}-${k}`;
      ids.push(id);
    }
  }
  return ids;
}

export function forgetPersisted(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {
    // ignore
  }
}

/** The built-in state (no saved data). */
export function defaultState(defaultSheet: string, defaultConfigJson: unknown): AppState {
  const config = validateConfig(defaultConfigJson).value;
  return {
    sheetText: defaultSheet,
    sheetName: BUILT_IN_SHEET_NAME,
    sheetCustom: false,
    config,
    configCustom: false,
    scenario: initialScenario(config),
    pinned: {},
    selection: [],
    prefs: { ...DEFAULT_PREFS, panels: windowPanels() },
  };
}

/** Default panels for the current window (DEFAULT_PANELS outside a browser). */
function windowPanels(): PanelPrefs {
  return typeof window === 'undefined' ? DEFAULT_PANELS : defaultPanels(window.innerWidth, window.innerHeight);
}

export interface StartupMessage {
  readonly text: string;
  readonly error: boolean;
}

/**
 * The initial state: embedded defaults, overridden by what this browser saved earlier.
 * @returns the state and messages about saved data that could not be used (or was upgraded)
 */
export function initialState(defaultSheet: string, defaultConfigJson: unknown): { state: AppState; messages: StartupMessage[] } {
  const messages: StartupMessage[] = [];
  const saved = read();
  const fromFirstVersion = saved.format === undefined;
  const defConfig = validateConfig(defaultConfigJson);
  if (defConfig.errors.length > 0) messages.push({ text: `built-in config: ${defConfig.errors.join('; ')}`, error: true });
  let config = defConfig.value;
  let configCustom = false;
  if (saved.config !== undefined) {
    // The first version could not edit its presets, so they were the built-in ones: take today's initial knobs instead.
    const json = fromFirstVersion ? withInitialKnobsOf(saved.config, defaultConfigJson) : saved.config;
    const v = validateConfig(json);
    if (v.errors.length === 0) {
      config = v.value;
      configCustom = true;
    } else messages.push({ text: 'saved config ignored (invalid)', error: true });
  }
  let scenario = initialScenario(config);
  if (saved.scenario !== undefined && fromFirstVersion) {
    messages.push({
      text: 'This version starts from new initial settings (no preset buttons; more knobs, some switched off), so the knobs saved by the previous version were replaced. Sheet edits are kept.',
      error: false,
    });
  } else if (saved.scenario !== undefined) {
    const v = validateScenario(saved.scenario);
    scenario = v.value;
    if (v.errors.length > 0) messages.push({ text: `saved scenario: ${v.errors.length} problem(s) ignored`, error: true });
    if (saved.format === 2) {
      const knobs = numberFormat2Ids(scenario.knobs, config);
      if (knobs.some((k, i) => k !== scenario.knobs[i])) {
        scenario = { ...scenario, knobs };
        messages.push({
          text: 'Bound IDs are numbers now, like Reduction IDs: your saved knobs were renumbered (the initial ones as listed under Initial settings).',
          error: false,
        });
      }
    }
  }
  const sheetCustom = typeof saved.sheetText === 'string' && saved.sheetText.length > 0;
  return {
    state: {
      sheetText: sheetCustom ? saved.sheetText! : defaultSheet,
      sheetName: sheetCustom ? (saved.sheetName ?? 'saved sheet') : BUILT_IN_SHEET_NAME,
      sheetCustom,
      config,
      configCustom,
      scenario,
      pinned: saved.pinned ?? {},
      selection: [],
      prefs: {
        ...DEFAULT_PREFS,
        ...(saved.prefs ?? {}),
        search: '',
        // Earlier versions did not save it (it was true or false).
        focus: isFocusMode(saved.prefs?.focus) ? saved.prefs.focus : 'off',
        panels: validatePanelPrefs(saved.prefs?.panels, windowPanels()),
      },
    },
    messages,
  };
}
