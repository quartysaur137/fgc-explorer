/**
 * Compact placement of the reductions graph (SPEC §7).
 *
 * A plain force-directed layout of ~200 problems in ~40 families spreads them over a huge area (family boxes get
 * stretched by their many outside edges), so labels are unreadable when the whole graph is shown. Instead:
 *  1. the members of each family are packed in rows inside a box (ordered so that linked members sit together);
 *  2. the family boxes and the problems without a family are placed by a force-directed layout of the "unit" graph
 *     (one node per box, one edge per linked pair of units);
 *  3. remaining overlaps between units are removed (so no two problems ever overlap), the arrangement is stretched
 *     toward the shape of the graph panel, and units slide toward the center until they touch.
 * This makes the problems cover about a third of the drawing instead of about 6 %, so at "fit" the labels are ~3 times
 * larger.
 *
 * The module is pure apart from the (seeded) force layout, which runs in a headless Cytoscape instance.
 */

import cytoscape from 'cytoscape';
import fcose from 'cytoscape-fcose';
import { assert } from '../util/assert';

cytoscape.use(fcose);

export interface Point {
  readonly x: number;
  readonly y: number;
}

/** A node to place: its size, and the group it is packed with (null: placed on its own). */
export interface BoxNode {
  readonly id: string;
  readonly group: string | null;
  readonly w: number;
  readonly h: number;
}

export interface Link {
  readonly source: string;
  readonly target: string;
}

export interface CompactLayoutOptions {
  /** Space between packed nodes, and between units. */
  readonly gap: number;
  /** Space between a group's box border and its members. */
  readonly groupPadding: number;
  /** Extra space above a group's box for its title. */
  readonly groupTitle: number;
  /** Width of each group's title (it is centered above the box, which is widened to make room if needed). */
  readonly groupTitleWidth?: ReadonlyMap<string, number>;
  /** Preferred width / height of a packed group. */
  readonly aspect: number;
  /** Preferred width / height of the whole layout (e.g. the graph panel's); default: whatever the forces give. */
  readonly targetAspect?: number;
  /** Seed of the force layout's random choices (the same inputs and seed give the same result). */
  readonly seed: number;
  /**
   * The units of an earlier layout (CompactLayout.units). If at least half of today's units are among them, the layout
   * is incremental: units of unchanged size stay exactly where they were, and only new or resized units are placed
   * (next to the units they are linked to) and moved out of the way.
   */
  readonly previous?: ReadonlyMap<string, UnitBox>;
}

/** A unit's center and size. */
export interface UnitBox {
  readonly x: number;
  readonly y: number;
  readonly w: number;
  readonly h: number;
}

/** A packed group: its box (including padding, excluding the title) relative to the unit center. */
export interface GroupBox {
  readonly x1: number;
  readonly y1: number;
  readonly x2: number;
  readonly y2: number;
}

export interface CompactLayout {
  /** Center of every node. */
  readonly positions: ReadonlyMap<string, Point>;
  /** Center and size of every unit, by unit id (for incremental relayouts). */
  readonly units: ReadonlyMap<string, UnitBox>;
  /** Box of every group (absolute coordinates, padding included, title excluded). */
  readonly groupBoxes: ReadonlyMap<string, GroupBox>;
}

/** Unit id of a group or of a node placed on its own. */
export function unitId(node: BoxNode): string {
  return node.group === null ? `n:${node.id}` : `g:${node.group}`;
}

// ---------------------------------------------------------------------------------------------------------------------
// 1. Packing a group
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Order members so that linked ones are adjacent: breadth-first over links inside the group, starting from the
 * best-connected member; ties and further starts by id.
 */
export function orderMembers(members: readonly BoxNode[], links: readonly Link[]): BoxNode[] {
  const ids = new Set(members.map((m) => m.id));
  const adj = new Map<string, Set<string>>(members.map((m) => [m.id, new Set<string>()]));
  for (const l of links) {
    if (l.source !== l.target && ids.has(l.source) && ids.has(l.target)) {
      adj.get(l.source)!.add(l.target);
      adj.get(l.target)!.add(l.source);
    }
  }
  const byId = new Map(members.map((m) => [m.id, m]));
  const remaining = [...members].sort((a, b) => adj.get(b.id)!.size - adj.get(a.id)!.size || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  const seen = new Set<string>();
  const out: BoxNode[] = [];
  for (const start of remaining) {
    if (seen.has(start.id)) continue;
    seen.add(start.id);
    const queue = [start.id];
    while (queue.length > 0) {
      const id = queue.shift()!;
      out.push(byId.get(id)!);
      const next = [...adj.get(id)!].filter((n) => !seen.has(n)).sort();
      for (const n of next) {
        seen.add(n);
        queue.push(n);
      }
    }
  }
  return out;
}

export interface PackedGroup {
  /** Size of the members' area (without padding). */
  readonly w: number;
  readonly h: number;
  /** Member centers relative to the area's center. */
  readonly offsets: ReadonlyMap<string, Point>;
}

/** Pack `members` (in this order) in rows, choosing the row width whose box is closest to the aspect ratio. */
export function packRows(members: readonly BoxNode[], gap: number, aspect: number): PackedGroup {
  assert(members.length > 0, 'packRows: no members');
  let best: { score: number; rows: BoxNode[][]; w: number; h: number } | null = null;
  const widest = Math.max(...members.map((m) => m.w));
  const total = members.reduce((s, m) => s + m.w, 0) + gap * (members.length - 1);
  // Candidate row widths: from the widest member to everything in one row.
  const steps = Math.min(members.length, 24);
  for (let i = 0; i <= steps; i++) {
    const limit = widest + ((total - widest) * i) / steps;
    const rows: BoxNode[][] = [];
    let row: BoxNode[] = [];
    let rowW = 0;
    for (const m of members) {
      const add = row.length === 0 ? m.w : rowW + gap + m.w;
      if (row.length > 0 && add > limit + 1e-9) {
        rows.push(row);
        row = [m];
        rowW = m.w;
      } else {
        row.push(m);
        rowW = add;
      }
    }
    rows.push(row);
    const w = Math.max(...rows.map((r) => r.reduce((s, m) => s + m.w, 0) + gap * (r.length - 1)));
    const h = rows.reduce((s, r) => s + Math.max(...r.map((m) => m.h)), 0) + gap * (rows.length - 1);
    // Prefer the aspect ratio, then the smaller area.
    const score = Math.abs(Math.log(w / h / aspect)) + (w * h) / 1e9;
    if (best === null || score < best.score) best = { score, rows, w, h };
  }
  const { rows, w, h } = best!;
  const offsets = new Map<string, Point>();
  let y = -h / 2;
  for (const r of rows) {
    const rowH = Math.max(...r.map((m) => m.h));
    const rowW = r.reduce((s, m) => s + m.w, 0) + gap * (r.length - 1);
    let x = -rowW / 2;
    for (const m of r) {
      offsets.set(m.id, { x: x + m.w / 2, y: y + rowH / 2 });
      x += m.w + gap;
    }
    y += rowH + gap;
  }
  return { w, h, offsets };
}

// ---------------------------------------------------------------------------------------------------------------------
// 3. Overlap removal
// ---------------------------------------------------------------------------------------------------------------------

export interface Rect {
  readonly id: string;
  x: number;
  y: number;
  readonly w: number;
  readonly h: number;
}

function overlapping(a: Rect, b: Rect, gap: number): { ox: number; oy: number } | null {
  const ox = (a.w + b.w) / 2 + gap - Math.abs(a.x - b.x);
  const oy = (a.h + b.h) / 2 + gap - Math.abs(a.y - b.y);
  return ox > 1e-9 && oy > 1e-9 ? { ox, oy } : null;
}

/** True iff some two rectangles are closer than `gap` in both directions. */
export function hasOverlap(rects: readonly Rect[], gap: number): boolean {
  for (let i = 0; i < rects.length; i++) for (let j = i + 1; j < rects.length; j++) if (overlapping(rects[i]!, rects[j]!, gap)) return true;
  return false;
}

/**
 * Move rectangles (in place) until no two are closer than `gap`: pairwise pushes along the axis of least overlap, and
 * if that does not settle, spreading all centers apart (which always ends: far enough apart nothing overlaps).
 */
export function removeOverlaps(rects: Rect[], gap: number): void {
  for (let iter = 0; iter < 300; iter++) {
    let moved = false;
    for (let i = 0; i < rects.length; i++) {
      for (let j = i + 1; j < rects.length; j++) {
        const a = rects[i]!;
        const b = rects[j]!;
        const o = overlapping(a, b, gap);
        if (o === null) continue;
        moved = true;
        if (o.ox <= o.oy) {
          const dir = a.x < b.x || (a.x === b.x && i < j) ? -1 : 1;
          a.x += (dir * o.ox) / 2;
          b.x -= (dir * o.ox) / 2;
        } else {
          const dir = a.y < b.y || (a.y === b.y && i < j) ? -1 : 1;
          a.y += (dir * o.oy) / 2;
          b.y -= (dir * o.oy) / 2;
        }
      }
    }
    if (!moved) return;
  }
  const cx = rects.reduce((s, r) => s + r.x, 0) / rects.length;
  const cy = rects.reduce((s, r) => s + r.y, 0) / rects.length;
  for (let k = 0; hasOverlap(rects, gap); k++) {
    assert(k < 200, 'removeOverlaps: did not converge');
    for (const r of rects) {
      r.x = cx + (r.x - cx) * 1.1;
      r.y = cy + (r.y - cy) * 1.1;
    }
  }
}

/**
 * Slide rectangles (in place) toward their common center, one axis at a time, as far as they can go without coming
 * closer than `gap` to another rectangle. Rectangles never pass each other, so the arrangement is kept; overlap-free
 * input stays overlap-free.
 */
export function compactTowardCenter(rects: Rect[], gap: number, passes = 6): void {
  if (rects.length < 2) return;
  for (let pass = 0; pass < passes; pass++) {
    for (const axis of ['x', 'y'] as const) {
      const other = axis === 'x' ? 'y' : 'x';
      const size = (r: Rect): number => (axis === 'x' ? r.w : r.h);
      const otherSize = (r: Rect): number => (axis === 'x' ? r.h : r.w);
      const c = rects.reduce((s, r) => s + r[axis], 0) / rects.length;
      const order = [...rects].sort((a, b) => Math.abs(a[axis] - c) - Math.abs(b[axis] - c));
      for (const r of order) {
        const dir = r[axis] < c ? 1 : -1;
        // Farthest position toward the center: the center itself, or where r touches a rectangle in its way.
        let target = c;
        for (const o of rects) {
          if (o === r) continue;
          const sideBySide = Math.abs(o[other] - r[other]) >= (otherSize(o) + otherSize(r)) / 2 + gap - 1e-9;
          if (sideBySide) continue;
          const d = (size(o) + size(r)) / 2 + gap;
          if (dir > 0 && o[axis] >= r[axis]) target = Math.min(target, o[axis] - d);
          if (dir < 0 && o[axis] <= r[axis]) target = Math.max(target, o[axis] + d);
        }
        if ((dir > 0 && target > r[axis]) || (dir < 0 && target < r[axis])) r[axis] = target;
      }
    }
  }
}

/**
 * Move `r` (in place) to the free position nearest to where it is: one where it is at least `gap` away from every rectangle
 * of `others`. Candidates are the positions touching a side of another rectangle (level with `r` or with it) and, always
 * free, the positions just outside all of them.
 */
export function placeNear(r: Rect, others: readonly Rect[], gap: number): void {
  const free = (): boolean => others.every((o) => overlapping(r, o, gap) === null);
  if (others.length === 0 || free()) return;
  const target = { x: r.x, y: r.y };
  const candidates: Point[] = [];
  for (const o of others) {
    const dx = (o.w + r.w) / 2 + gap;
    const dy = (o.h + r.h) / 2 + gap;
    candidates.push(
      { x: o.x - dx, y: target.y },
      { x: o.x + dx, y: target.y },
      { x: target.x, y: o.y - dy },
      { x: target.x, y: o.y + dy },
      { x: o.x - dx, y: o.y },
      { x: o.x + dx, y: o.y },
      { x: o.x, y: o.y - dy },
      { x: o.x, y: o.y + dy },
    );
  }
  const b = boundsOf(others);
  candidates.push(
    { x: b.x2 + gap + r.w / 2, y: target.y },
    { x: b.x1 - gap - r.w / 2, y: target.y },
    { x: target.x, y: b.y2 + gap + r.h / 2 },
    { x: target.x, y: b.y1 - gap - r.h / 2 },
  );
  const dist = (c: Point): number => Math.hypot(c.x - target.x, c.y - target.y);
  candidates.sort((p, q) => dist(p) - dist(q));
  for (const c of candidates) {
    r.x = c.x;
    r.y = c.y;
    if (free()) return;
  }
  assert(false, 'placeNear: the outside positions are always free');
}

/** Bounding box of rectangles. */
export function boundsOf(rects: readonly Rect[]): { x1: number; y1: number; x2: number; y2: number } {
  return {
    x1: Math.min(...rects.map((r) => r.x - r.w / 2)),
    x2: Math.max(...rects.map((r) => r.x + r.w / 2)),
    y1: Math.min(...rects.map((r) => r.y - r.h / 2)),
    y2: Math.max(...rects.map((r) => r.y + r.h / 2)),
  };
}

/** Scale the centers (in place) anisotropically so that the arrangement's width / height moves to `aspect`. */
function stretchToAspect(rects: Rect[], aspect: number): void {
  const b = boundsOf(rects);
  const current = (b.x2 - b.x1) / Math.max(1e-9, b.y2 - b.y1);
  const f = Math.sqrt(aspect / current);
  const cx = (b.x1 + b.x2) / 2;
  const cy = (b.y1 + b.y2) / 2;
  for (const r of rects) {
    r.x = cx + (r.x - cx) * f;
    r.y = cy + (r.y - cy) / f;
  }
}

// ---------------------------------------------------------------------------------------------------------------------
// 2. Placing the units, and the whole layout
// ---------------------------------------------------------------------------------------------------------------------

/** Deterministic pseudo-random numbers in [0, 1) (mulberry32). */
export function seededRandom(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

interface Unit {
  readonly id: string;
  readonly w: number;
  readonly h: number;
}

/** Force-directed placement of the units from scratch (seeded fcose in a headless Cytoscape). */
function placeUnits(units: readonly Unit[], links: ReadonlyMap<string, number>, opts: CompactLayoutOptions): Map<string, Point> {
  const cy = cytoscape({
    headless: true,
    styleEnabled: true,
    style: [{ selector: 'node', style: { width: 'data(w)', height: 'data(h)', shape: 'rectangle' } }] as unknown as cytoscape.StylesheetJson,
  });
  try {
    cy.add(units.map((u) => ({ group: 'nodes' as const, data: { id: u.id, w: u.w, h: u.h }, position: { x: 0, y: 0 } })));
    let k = 0;
    for (const [key, count] of links) {
      const [a, b] = key.split('\u0000') as [string, string];
      cy.add({ group: 'edges', data: { id: `e${k++}`, source: a, target: b, count } });
    }
    const random = Math.random;
    Math.random = seededRandom(opts.seed);
    try {
      cy.layout({
        name: 'fcose',
        quality: 'proof',
        randomize: true,
        animate: false,
        fit: false,
        packComponents: true,
        nodeDimensionsIncludeLabels: false,
        uniformNodeDimensions: false,
        nodeRepulsion: () => 4500,
        // Units linked by many rows are pulled closer.
        idealEdgeLength: (e: cytoscape.EdgeSingular) => Math.max(opts.gap * 2, 60 / Math.sqrt(e.data('count') as number)),
        edgeElasticity: () => 0.45,
        gravity: 0.6,
        numIter: 2500,
        tile: true,
        tilingPaddingVertical: opts.gap,
        tilingPaddingHorizontal: opts.gap,
      } as cytoscape.LayoutOptions).run();
    } finally {
      Math.random = random;
    }
    const out = new Map<string, Point>();
    cy.nodes().forEach((n) => {
      out.set(n.id(), { ...n.position() });
    });
    return out;
  } finally {
    cy.destroy();
  }
}

/**
 * Place `nodes` compactly (see the module comment).
 * @returns centers of all nodes, of all units, and the boxes of the groups; no two nodes are closer than opts.gap
 */
export function compactLayout(nodes: readonly BoxNode[], links: readonly Link[], opts: CompactLayoutOptions): CompactLayout {
  const groups = new Map<string, BoxNode[]>();
  for (const n of nodes) {
    if (n.group === null) continue;
    const list = groups.get(n.group) ?? [];
    list.push(n);
    groups.set(n.group, list);
  }
  // Units: one per group (its packed members, padding and title) and one per node without a group.
  const units: Unit[] = [];
  const packed = new Map<string, PackedGroup>();
  for (const [g, members] of [...groups].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))) {
    const p = packRows(orderMembers(members, links), opts.gap, opts.aspect);
    packed.set(g, p);
    const titleW = opts.groupTitleWidth?.get(g) ?? 0;
    units.push({ id: `g:${g}`, w: Math.max(p.w + 2 * opts.groupPadding, titleW), h: p.h + 2 * opts.groupPadding + opts.groupTitle });
  }
  for (const n of nodes) if (n.group === null) units.push({ id: unitId(n), w: n.w, h: n.h });
  if (units.length === 0) return { positions: new Map(), units: new Map(), groupBoxes: new Map() };

  // Links between units, counted.
  const unitOf = new Map(nodes.map((n) => [n.id, unitId(n)]));
  const unitLinks = new Map<string, number>();
  for (const l of links) {
    const a = unitOf.get(l.source);
    const b = unitOf.get(l.target);
    if (a === undefined || b === undefined || a === b) continue;
    const key = a < b ? `${a}\u0000${b}` : `${b}\u0000${a}`;
    unitLinks.set(key, (unitLinks.get(key) ?? 0) + 1);
  }

  const previous = opts.previous;
  const known = previous ? units.filter((u) => previous.has(u.id)).length : 0;
  const rects = previous !== undefined && known >= units.length / 2 ? placeIncrementally(units, unitLinks, previous, opts.gap) : placeFresh(units, unitLinks, opts);

  const unitCenters = new Map<string, Point>(rects.map((r) => [r.id, { x: r.x, y: r.y }]));
  const positions = new Map<string, Point>();
  const groupBoxes = new Map<string, GroupBox>();
  for (const n of nodes) {
    const c = unitCenters.get(unitId(n))!;
    if (n.group === null) {
      positions.set(n.id, c);
      continue;
    }
    // The members' area sits below the title.
    const p = packed.get(n.group)!;
    const off = p.offsets.get(n.id)!;
    positions.set(n.id, { x: c.x + off.x, y: c.y + opts.groupTitle / 2 + off.y });
  }
  for (const [g, p] of packed) {
    const c = unitCenters.get(`g:${g}`)!;
    const cyArea = c.y + opts.groupTitle / 2;
    groupBoxes.set(g, {
      x1: c.x - p.w / 2 - opts.groupPadding,
      x2: c.x + p.w / 2 + opts.groupPadding,
      y1: cyArea - p.h / 2 - opts.groupPadding,
      y2: cyArea + p.h / 2 + opts.groupPadding,
    });
  }
  return { positions, units: new Map(rects.map((r) => [r.id, { x: r.x, y: r.y, w: r.w, h: r.h }])), groupBoxes };
}

/** Units placed from scratch: forces, then no overlaps, the target shape, and sliding together. */
function placeFresh(units: readonly Unit[], links: ReadonlyMap<string, number>, opts: CompactLayoutOptions): Rect[] {
  const centers = placeUnits(units, links, opts);
  const rects: Rect[] = units.map((u) => ({ id: u.id, w: u.w, h: u.h, ...(centers.get(u.id) ?? { x: 0, y: 0 }) }));
  removeOverlaps(rects, opts.gap);
  if (opts.targetAspect !== undefined) {
    stretchToAspect(rects, opts.targetAspect);
    removeOverlaps(rects, opts.gap);
  }
  compactTowardCenter(rects, opts.gap);
  return rects;
}

/**
 * Units placed around an earlier layout: those of unchanged size stay exactly where they were; new ones start at the
 * center of the units they are linked to (else of the drawing), resized ones at their old center, and each of these
 * (largest first) goes to the nearest free position.
 */
function placeIncrementally(units: readonly Unit[], links: ReadonlyMap<string, number>, previous: ReadonlyMap<string, UnitBox>, gap: number): Rect[] {
  const old = [...previous.values()];
  const center: Point = { x: old.reduce((s, p) => s + p.x, 0) / old.length, y: old.reduce((s, p) => s + p.y, 0) / old.length };
  const neighbours = new Map<string, string[]>();
  for (const key of links.keys()) {
    const [a, b] = key.split('\u0000') as [string, string];
    neighbours.set(a, [...(neighbours.get(a) ?? []), b]);
    neighbours.set(b, [...(neighbours.get(b) ?? []), a]);
  }
  const kept: Rect[] = [];
  const moving: Rect[] = [];
  for (const u of units) {
    const p = previous.get(u.id);
    if (p !== undefined && Math.abs(p.w - u.w) < 1e-6 && Math.abs(p.h - u.h) < 1e-6) {
      kept.push({ id: u.id, w: u.w, h: u.h, x: p.x, y: p.y });
      continue;
    }
    const linked = (neighbours.get(u.id) ?? []).map((n) => previous.get(n)).filter((q): q is UnitBox => q !== undefined);
    const at =
      p ?? (linked.length > 0 ? { x: linked.reduce((s, q) => s + q.x, 0) / linked.length, y: linked.reduce((s, q) => s + q.y, 0) / linked.length } : center);
    moving.push({ id: u.id, w: u.w, h: u.h, x: at.x, y: at.y });
  }
  const placed = [...kept];
  for (const r of moving.sort((a, b) => b.w * b.h - a.w * a.h || (a.id < b.id ? -1 : 1))) {
    placeNear(r, placed, gap);
    placed.push(r);
  }
  // Keep the units' order (as in `units`).
  const byId = new Map(placed.map((r) => [r.id, r]));
  return units.map((u) => byId.get(u.id)!);
}
