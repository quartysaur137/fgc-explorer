/**
 * Entry point of the browser app: wires the store to the views and the header actions.
 */

import builtInSheet from '../../data/FGC_Reductions_filled.csv';
import builtInConfig from '../../data/default-config.json';
import { initialScenario, validateConfig, validateScenario } from '../model/config';
import { REQUIRED_COLUMNS } from '../model/model';
import { CsvTable } from '../util/csv';
import { writeBoundsCsv } from '../model/boundsCsv';
import { openBoundsImport, openHelp, openRowEditor } from './dialogs';
import { download, h, pickFile } from './dom';
import { formatDuration } from './format';
import { GraphView } from './graph';
import { Inspector } from './inspector';
import { Panels } from './panels';
import { ScenarioPanel } from './scenarioPanel';
import { BUILT_IN_SHEET_NAME, defaultState, forgetPersisted, initialState, persist, Selection } from './state';
import { Store } from './store';
import { TablesView } from './tables';

function el<T extends HTMLElement = HTMLElement>(selector: string): T {
  const e = document.querySelector<T>(selector);
  if (!e) throw new Error(`missing element ${selector}`);
  return e;
}

/** A transient message; longer ones stay longer (about 16 characters per second, at least 3.5 s, errors 8 s). */
function toast(message: string, isError = false): void {
  const t = h('div', { class: `toast ${isError ? 'error' : ''}` }, message);
  document.body.append(t);
  setTimeout(() => t.remove(), Math.max(isError ? 8000 : 3500, 60 * message.length));
}

function main(): void {
  const { state, messages } = initialState(builtInSheet, builtInConfig);
  const store = new Store(state, () => defaultState(builtInSheet, builtInConfig), (m) => toast(m, true));
  messages.forEach((m) => toast(m.text, m.error));
  // Save right away, so that upgraded (or replaced) saved data is stored in the current format.
  persist(store.get());

  const select = (selection: Selection, reveal = false): void => {
    store.update((s) => ({ ...s, selection }));
    if (reveal && selection) graph.reveal(selection);
  };

  const graph = new GraphView(el('#graph'), {
    onSelectProblem: (id) => select({ kind: 'problem', id }),
    onSelectRow: (id) => select({ kind: 'row', id }),
    onClear: () => select(null),
    onOpen: () => panels.toggle('right', true),
  });
  const panels = new Panels(
    {
      main: el('main'),
      center: el('#center'),
      splitters: { left: el('#split-left'), right: el('#split-right'), bottom: el('#split-bottom') },
      toggles: { left: el('#btn-panel-left'), right: el('#btn-panel-right'), bottom: el('#btn-panel-bottom') },
      maximize: el('#btn-panel-all'),
    },
    store,
  );
  const scenario = new ScenarioPanel(el('#left'), store, {
    selectProblem: (id) => select({ kind: 'problem', id }, true),
    // The note is part of the inspector's view when nothing is selected.
    showInitialSettings: () => {
      panels.toggle('right', true);
      select(null);
      document.getElementById('initial-settings')?.scrollIntoView({ block: 'start', behavior: 'smooth' });
    },
    importBounds: async () => {
      const f = await pickFile('.csv,text/csv');
      if (f) openBoundsImport(store, f.name, f.text, (m) => toast(m));
    },
    exportBounds: () => download('fgc-bounds.csv', writeBoundsCsv(store.get().scenario.knobs, store.getDerived().model), 'text/csv'),
  });
  new Inspector(el('#right'), store, {
    selectProblem: (id) => select({ kind: 'problem', id }, true),
    selectRow: (id) => select({ kind: 'row', id }, true),
    editRow: (id) => openRowEditor(store, id),
    addKnob: (problemId, kind, spec) => scenario.prefill(problemId, kind, spec),
    restoreInitialSettings: () => {
      if (!confirm('Replace the current hypotheses, algorithms, constants and engine settings by the initial ones? Sheet edits and pinned regimes are kept.')) return;
      store.update((s) => ({ ...s, scenario: initialScenario(s.config) }));
      toast('initial settings restored');
    },
  });
  new TablesView(el('#bottom-tabs'), el('#bottom-body'), store, {
    selectProblem: (id) => select({ kind: 'problem', id }, true),
    selectRow: (id) => select({ kind: 'row', id }, true),
  });

  const renderGraph = (): void => {
    const s = store.get();
    const d = store.getDerived();
    graph.render(d.model, d.analysis, s.prefs, s.selection);
  };
  const status = el('#status');
  const renderStatus = (): void => {
    const { model, analysis } = store.getDerived();
    const used = model.rows.filter((r) => r.status === 'ok').length;
    const lbFacts = [...analysis.lower.facts.values()].reduce((n, m) => n + m.size, 0);
    const sheetName = store.get().sheetName;
    const stats = `${used}/${model.rows.length} reductions used · ${lbFacts} lower-bound facts · ${formatDuration(analysis.elapsedMs)}`;
    status.textContent = store.busy ? 'computing…' : `${sheetName.replace(BUILT_IN_SHEET_NAME, 'built-in sheet')} · ${stats}`;
    status.title = store.busy ? '' : `${sheetName} · ${stats}`; // in full: the line may be cut off
    document.body.classList.toggle('busy', store.busy);
  };
  store.subscribe((changes) => {
    if (changes.has('model') || changes.has('analysis') || changes.has('prefs') || changes.has('selection')) renderGraph();
    if (changes.has('busy') || changes.has('analysis') || changes.has('model')) renderStatus();
  });
  renderGraph();
  renderStatus();

  // Toolbar
  const search = el<HTMLInputElement>('#search');
  search.addEventListener('input', () => store.update((s) => ({ ...s, prefs: { ...s.prefs, search: search.value } })));
  search.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const id = graph.firstMatch();
      if (id) select({ kind: 'problem', id }, true);
    }
  });
  const toggle = (id: string, key: 'groupFamilies' | 'showUnusedRows' | 'focus'): void => {
    const box = el<HTMLInputElement>(id);
    box.checked = store.get().prefs[key];
    box.addEventListener('change', () => store.update((s) => ({ ...s, prefs: { ...s.prefs, [key]: box.checked } })));
  };
  toggle('#opt-group', 'groupFamilies');
  toggle('#opt-unused', 'showUnusedRows');
  toggle('#opt-focus', 'focus');
  el('#btn-layout').addEventListener('click', () => graph.relayout());
  el('#btn-fit').addEventListener('click', () => graph.fit());
  el('#btn-zoom-in').addEventListener('click', () => graph.zoom(1.25));
  el('#btn-zoom-out').addEventListener('click', () => graph.zoom(0.8));
  el('#btn-zoom-100').addEventListener('click', () => graph.zoom(1, 1));

  // Header actions (one segment each for the reductions sheet, the scenario and the engine config)
  el('#btn-load-sheet').addEventListener('click', async () => {
    const f = await pickFile('.csv,text/csv');
    if (!f) return;
    const { table, warnings } = CsvTable.fromText(f.text);
    const missing = REQUIRED_COLUMNS.filter((c) => !table.hasColumn(c));
    if (missing.length > 0) return toast(`${f.name}: missing columns ${missing.join(', ')}`, true);
    store.update((s) => ({ ...s, sheetText: f.text, sheetName: f.name, sheetCustom: true, selection: null }));
    toast(`loaded ${f.name} (${table.rowCount} rows${warnings.length ? `, ${warnings.length} CSV warnings` : ''})`);
  });
  el('#btn-export-sheet').addEventListener('click', () => {
    download('FGC_Reductions_edited.csv', store.getDerived().model.table.toText(), 'text/csv');
  });
  el('#btn-load-scenario').addEventListener('click', async () => {
    const f = await pickFile('.json,application/json');
    if (!f) return;
    try {
      const v = validateScenario(JSON.parse(f.text));
      store.update((s) => ({ ...s, scenario: v.value }));
      toast(v.errors.length ? `scenario loaded with ${v.errors.length} problem(s): ${v.errors[0]}` : `loaded ${f.name}`, v.errors.length > 0);
    } catch (e) {
      toast(`${f.name}: ${(e as Error).message}`, true);
    }
  });
  el('#btn-export-scenario').addEventListener('click', () => download('fgc-scenario.json', JSON.stringify(store.get().scenario, null, 2), 'application/json'));
  el('#btn-load-config').addEventListener('click', async () => {
    const f = await pickFile('.json,application/json');
    if (!f) return;
    try {
      const v = validateConfig(JSON.parse(f.text));
      store.update((s) => ({ ...s, config: v.value, configCustom: true }));
      toast(v.errors.length ? `config loaded with ${v.errors.length} problem(s): ${v.errors[0]}` : `loaded ${f.name}`, v.errors.length > 0);
    } catch (e) {
      toast(`${f.name}: ${(e as Error).message}`, true);
    }
  });
  el('#btn-export-config').addEventListener('click', () => download('fgc-engine-config.json', JSON.stringify(store.get().config, null, 2), 'application/json'));
  el('#btn-add-row').addEventListener('click', () => openRowEditor(store, null));
  el('#btn-help').addEventListener('click', () => openHelp());
  el('#btn-reset').addEventListener('click', () => {
    if (!confirm('Forget this browser’s saved scenario, edits and loaded sheet, and go back to the built-in defaults?')) return;
    forgetPersisted();
    location.reload();
  });

  // The graph follows its container (window resizes, panels dragged, shown or hidden), once per frame.
  let resizeQueued = false;
  new ResizeObserver(() => {
    if (resizeQueued) return;
    resizeQueued = true;
    requestAnimationFrame(() => {
      resizeQueued = false;
      graph.resize();
    });
  }).observe(el('#graph'));
  // Handle for automated tests and the browser console.
  (window as unknown as { fgcExplorer: unknown }).fgcExplorer = { store, graph };
}

main();
