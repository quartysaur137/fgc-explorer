/**
 * Entry point of the browser app: wires the store to the views and the header actions.
 */

import builtInSheet from '../../data/FGC_Reductions_filled.csv';
import builtInConfig from '../../data/default-config.json';
import { boxOrder, canonicalProblem } from '../model/boxes';
import { checkScenarioConstants, initialScenario, isNotice, Knob, validateConfig, validateScenario } from '../model/config';
import { findProblem, REQUIRED_COLUMNS } from '../model/model';
import { regimesFromSpec } from '../engine/analysis';
import { Expr, freeIdentifiers } from '../math/ast';
import { parseExpr } from '../math/parser';
import { CsvTable } from '../util/csv';
import { writeBoundsCsv } from '../model/boundsCsv';
import { openBoundsImport, openHelp, openRowEditor } from './dialogs';
import { download, h, pickFile, scrollBehavior, setChildren } from './dom';
import { FOCUS_MODES, FocusMode } from './focus';
import { formatDuration } from './format';
import { GraphView } from './graph';
import { panelHover } from './hover';
import { Inspector } from './inspector';
import { Panels } from './panels';
import { ScenarioPanel } from './scenarioPanel';
import { bestProblem, reductionOf, search } from './search';
import { clickSelect, sameItem, SelectionItem } from './selection';
import { BUILT_IN_SHEET_NAME, defaultState, forgetPersisted, initialState, isSaving, jsonKind, persist, resumeSaving, STORAGE_KEY, stopSaving, storedEquals, whenSavingStops } from './state';
import { Store } from './store';
import { TablesView } from './tables';
import { isDark, toggleTheme } from './theme';

/**
 * Whether the messages that only describe an upgrade of saved data (built-in bounds a new version added or updated) are
 * shown when the page loads. Off while the app is being deployed: every visitor would see them once after each update.
 * Problems with saved data, and changes to what the user made (their bounds' IDs taken by new built-in ones, their edited
 * sheet left without the new built-in rows), are always shown.
 */
const SHOW_UPGRADE_NOTES = false;

function el<T extends HTMLElement = HTMLElement>(selector: string): T {
  const e = document.querySelector<T>(selector);
  if (!e) throw new Error(`missing element ${selector}`);
  return e;
}

/**
 * The messages at the bottom of the page, in one stack (newest at the bottom), so that none covers another: three
 * notices at startup used to appear at the same spot, and the longest hid the others until they expired.
 */
function messageStack(): HTMLElement {
  let stack = document.getElementById('toasts');
  if (stack === null) {
    stack = h('div', { id: 'toasts', class: 'toasts', 'aria-live': 'polite' });
    document.body.append(stack);
  }
  return stack;
}

/** A transient message; longer ones stay longer (about 16 characters per second, at least 3.5 s, errors 8 s). */
function toast(message: string, isError = false): void {
  const t = h('div', { class: `toast ${isError ? 'error' : ''}` }, message);
  messageStack().append(t);
  setTimeout(() => t.remove(), Math.max(isError ? 8000 : 3500, 60 * message.length));
}

/**
 * The message of the last load (a file loaded or imported) or removals (×), with its Undo; `edits` counts the changes
 * made since (of the scenario, the sheet or the config), which the Undo of a load would revert too.
 */
let undoMessage: { el: HTMLElement; kind: 'load' | 'removal'; texts: string[]; undo: () => void; edits: number } | null = null;

/**
 * Say what a load or a removal did, with Undo: the message stays until it is closed, undone, or replaced by the message
 * of the next one (whose Undo then goes back to before that one). Removals in a row share one message, whose Undo puts
 * back all of them (each × used to replace the message, so that only the last one could be undone). The Undo of a load
 * restores the state from before it, so when something was changed since, it asks first ("Undo the load and the 2
 * changes made since?"): it used to revert later edits without a word. The Undo of a removal keeps later edits.
 */
function undoToast(message: string, undo: () => void, kind: 'load' | 'removal' = 'load'): void {
  if (kind === 'removal' && undoMessage?.kind === 'removal' && undoMessage.el.isConnected) {
    const before = undoMessage.undo;
    undoMessage.undo = () => {
      undo();
      before();
    };
    undoMessage.texts.push(message);
    undoMessage.el.querySelector('.toast-text')!.textContent = undoMessage.texts.join(' ');
    return;
  }
  undoMessage?.el.remove();
  const t = h('div', { class: 'toast load', role: 'status' }, h('span', { class: 'toast-text' }, message), ' ');
  const entry = { el: t, kind, texts: [message], undo, edits: 0 };
  const done = (): void => {
    t.remove();
    if (undoMessage === entry) undoMessage = null;
  };
  t.append(
    h(
      'button',
      {
        class: 'link toast-action',
        on: {
          click: () => {
            const n = entry.edits;
            if (kind === 'load' && n > 0 && !confirm(`${entry.texts.join(' ')}\n\nUndo the load and the ${n === 1 ? 'change' : `${n} changes`} made since?`)) return;
            done();
            entry.undo();
          },
        },
      },
      'Undo',
    ),
    h('button', { class: 'link toast-close', title: 'close (what was done stays)', 'aria-label': 'close this message', on: { click: done } }, '×'),
  );
  messageStack().append(t);
  undoMessage = entry;
}

function main(): void {
  const { state, messages } = initialState(builtInSheet, builtInConfig);
  const store = new Store(state, () => defaultState(builtInSheet, builtInConfig), (m) => toast(m, true));
  messages.filter((m) => m.error || m.own === true || SHOW_UPGRADE_NOTES).forEach((m) => toast(m.text, m.error));
  // Save right away, so that upgraded (or replaced) saved data is stored in the current format; not when it holds the
  // same already (a second tab would otherwise rewrite the first one's data and stop that tab's saving for nothing).
  persist(store.get(), { ifChanged: true });
  // (the edits made after a load, which its Undo would revert too: see undoToast)
  store.subscribe((changes) => {
    if (undoMessage !== null && (changes.has('scenario') || changes.has('model'))) undoMessage.edits += 1;
  });

  /**
   * A click on a problem or reduction: it alone is selected, or, when `additive` (Shift, Ctrl or ⌘ held), it is added to
   * the selection or removed from it. `reveal` centers the graph on it (clicks outside the graph).
   */
  const pick = (item: SelectionItem, additive: boolean, reveal = false): void => {
    store.update((s) => ({ ...s, selection: clickSelect(s.selection, item, additive) }));
    if (reveal) graph.reveal(item);
  };
  const problem = (id: string): SelectionItem => ({ kind: 'problem', id });
  const row = (id: string): SelectionItem => ({ kind: 'row', id });
  const clearSelection = (): void => store.update((s) => (s.selection.length === 0 ? s : { ...s, selection: [] }));

  const graph = new GraphView(el('#graph'), {
    onSelectProblem: (id, additive) => pick(problem(id), additive),
    onSelectRow: (id, additive) => pick(row(id), additive),
    onClear: clearSelection,
    onOpen: () => panels.toggle('right', true),
  });
  const panels = new Panels(
    {
      main: el('main'),
      center: el('#center'),
      splitters: { left: el('#split-left'), right: el('#split-right'), bottom: el('#split-bottom') },
      toggles: { left: el('#btn-panel-left'), right: el('#btn-panel-right'), bottom: el('#btn-panel-bottom') },
      maximize: el('#btn-panel-all'),
    },
    store,
  );
  const scenario = new ScenarioPanel(el('#left'), store, {
    selectProblem: (id, additive) => pick(problem(id), additive, true),
    // (without scrolling: in a narrow window the field is far above the left panel)
    focusSearch: () => el('#search').focus({ preventScroll: true }),
    // The note is part of the inspector's view when nothing is selected.
    showInitialSettings: () => {
      panels.toggle('right', true);
      clearSelection();
      document.getElementById('initial-settings')?.scrollIntoView({ block: 'start', behavior: 'smooth' });
    },
    importBounds: async () => {
      const f = await pickFile('.csv,text/csv');
      if (f) openBoundsImport(store, f.name, f.text, (m, undo) => undoToast(m, undo));
    },
    exportBounds: () => {
      const { knobs, problems } = store.get().scenario;
      download('fgc-bounds.csv', writeBoundsCsv(knobs, store.getDerived().model, problems), 'text/csv');
    },
    // (as for a load: the message stays, with Undo, until closed or replaced)
    removed: (message, undo) => undoToast(message, undo, 'removal'),
  });
  /** Show a bound in its problem's box in the left panel (opened if hidden). */
  const revealKnob = (id: string): void => {
    panels.toggle('left', true);
    if (!scenario.revealKnob(id)) toast(`bound ${id} is not in the left panel`, true);
  };
  new Inspector(el('#right'), store, {
    selectProblem: (id, additive) => pick(problem(id), additive, true),
    selectRow: (id, additive) => pick(row(id), additive, true),
    deselect: (item) => store.update((s) => ({ ...s, selection: s.selection.filter((x) => !sameItem(x, item)) })),
    clearSelection,
    editRow: (id) => openRowEditor(store, id),
    revealKnob,
    addKnob: (problemId, kind, spec) => {
      panels.toggle('left', true);
      scenario.prefill(problemId, kind, spec);
    },
    restoreInitialSettings: () => {
      if (!confirm('Replace the current hypotheses, algorithms, constants and engine settings by the initial ones? Sheet edits and pinned regimes are kept.')) return;
      store.update((s) => ({ ...s, scenario: initialScenario(s.config) }));
      toast('initial settings restored');
    },
  });
  new TablesView(el('#bottom-tabs'), el('#bottom-body'), store, {
    selectProblem: (id, additive) => pick(problem(id), additive, true),
    selectRow: (id, additive) => pick(row(id), additive, true),
  });
  // Pointing at a problem's name or a reduction's ID in a panel highlights it in the graph.
  for (const panel of [el('#left'), el('#right'), el('#bottom-body')]) panelHover(panel, (item) => graph.hover(item));

  const renderGraph = (): void => {
    const s = store.get();
    const d = store.getDerived();
    graph.render(d.model, d.analysis, s.prefs, s.selection);
  };
  /**
   * The banner of a tab that stopped saving (another tab saved over its data, or kept its version since): it sits above
   * the header, which stays usable, and offers to reload, to export this tab's scenario, or to keep this tab's version
   * (saved over the other one's, which then stops saving in turn); closed, the "not saving" badge shows it again.
   */
  const showStaleBanner = (): void => {
    if (isSaving() || document.querySelector('.stale-banner') !== null) return;
    const banner = h(
      'div',
      { class: 'stale-banner', role: 'alert' },
      h(
        'span',
        {},
        h('span', { class: 'long' }, 'This app was changed in another tab or window. Changes made here are no longer saved, so that they do not overwrite those.'),
        h('span', { class: 'short' }, 'Changed in another tab: not saving here.'),
      ),
      h(
        'button',
        { title: 'load the other tab’s data (the changes made here are lost)', on: { click: () => location.reload() } },
        h('span', { class: 'long' }, 'Reload with the newest data'),
        h('span', { class: 'short' }, 'Reload'),
      ),
      h(
        'button',
        {
          title: 'download this tab’s scenario (knobs, constants, settings, pins) as a file; edits of the sheet or config: export them with Reductions ▸ Export and Config ▸ Export',
          on: { click: exportScenario },
        },
        h('span', { class: 'long' }, 'Export this tab’s scenario (not sheet or config)'),
        h('span', { class: 'short' }, 'Export scenario only'),
      ),
      h(
        'button',
        {
          title: 'save this tab’s data over the other tab’s, and keep saving here (the other tab then stops saving)',
          on: {
            click: () => {
              resumeSaving();
              persist(store.get());
              banner.remove();
              renderStatus();
              toast('This tab’s version is saved; another tab open with the app stops saving.');
            },
          },
        },
        h('span', { class: 'long' }, 'Keep this tab’s version'),
        h('span', { class: 'short' }, 'Keep this version'),
      ),
      h('button', { class: 'icon close', title: 'close (changes made here stay unsaved; the “not saving” badge shows this again)', 'aria-label': 'close this message', on: { click: () => banner.remove() } }, '×'),
    );
    document.body.prepend(banner);
  };
  const status = el('#status');
  const renderStatus = (): void => {
    const { model, analysis } = store.getDerived();
    const used = model.rows.filter((r) => r.status === 'ok').length;
    const lbFacts = [...analysis.lower.facts.values()].reduce((n, m) => n + m.size, 0);
    const sheetName = store.get().sheetName;
    const stats = `${used}/${model.rows.length} reductions used · ${lbFacts} lower-bound facts · ${formatDuration(analysis.elapsedMs)}`;
    // A search that reached one of its limits may have missed bounds: say so here, not only in Diagnostics.
    // (the on-demand searches are shared by analyses: only those behind this analysis's regimes count)
    const upperLimit = analysis.upper.capped.length > 0 || analysis.overlayCapped > 0;
    const lowerLimit = analysis.lower.capped.length > 0;
    // The states and warnings come first, as short badges (the line has little room in narrow windows), the one that
    // matters most first: not saving, then the search limits, then completing; each says in full what it means as its
    // tooltip, and so does the whole line. "Not saving" is a button that shows the banner again (closed, its actions
    // were gone for good).
    const states: Array<{ text: string; full: string; cls: string; click?: () => void }> = [];
    if (!isSaving()) {
      states.push({ text: '⚠ not saving', full: 'not saving: the app was changed in another tab or window; click for what you can do', cls: 'warn', click: () => showStaleBanner() });
    }
    if (upperLimit) {
      states.push({
        text: '⚠ UB limit',
        full: 'Upper-bound search limit reached: some upper bounds may be weaker than these settings allow and may depend on the order of computation (marked ⚠; Diagnostics)',
        cls: 'warn',
      });
    }
    if (lowerLimit) {
      states.push({ text: '⚠ LB limit', full: 'Lower-bound search limit reached: some lower bounds may be weaker than these settings allow (Diagnostics)', cls: 'warn' });
    }
    if (!analysis.complete) {
      states.push({
        text: 'completing…',
        full: 'checking the other regimes of lower bounds for upper bounds: conflicts and statuses may still change',
        cls: 'pending',
      });
    }
    const badge = (x: (typeof states)[number]): HTMLElement =>
      x.click !== undefined
        ? h('button', { class: `status-badge ${x.cls}`, title: x.full, on: { click: x.click } }, x.text)
        : h('span', { class: `status-badge ${x.cls}`, title: x.full }, x.text);
    if (store.busy) {
      setChildren(status, [...states.filter((x) => x.click !== undefined).map(badge), h('span', { class: 'status-badge pending' }, 'computing…')]);
      status.title = '';
    } else {
      setChildren(status, [...states.map(badge), h('span', { class: 'status-text' }, `${sheetName.replace(BUILT_IN_SHEET_NAME, 'built-in sheet')} · ${stats}`)]);
      status.title = [...states.map((x) => x.full), `${sheetName} · ${stats}`].join(' · ');
    }
    status.classList.toggle('warn', !store.busy && states.some((x) => x.cls === 'warn'));
    document.body.classList.toggle('busy', store.busy);
  };
  // The focus mode (toolbar) and the legend of its "bound derivations" mode, over the graph.
  const focus = el<HTMLSelectElement>('#opt-focus');
  setChildren(
    focus,
    FOCUS_MODES.map((m) => h('option', { value: m.mode, title: m.title }, m.label)),
  );
  const showFocus = (): void => {
    focus.value = store.get().prefs.focus;
    focus.title = `focus: ${FOCUS_MODES.find((m) => m.mode === focus.value)?.title ?? ''} (the rest is dimmed)`;
  };
  focus.addEventListener('change', () => store.update((s) => ({ ...s, prefs: { ...s.prefs, focus: focus.value as FocusMode } })));
  // Light / dark mode: the preference goes on <html> (the CSS follows it), the toggle shows it, the graph takes up the
  // colors. "system" also follows changes of the system's setting.
  const themeButton = el<HTMLButtonElement>('#btn-theme');
  const systemDark = typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  let shownDark: boolean | null = null;
  const applyTheme = (): void => {
    const theme = store.get().prefs.theme;
    if (theme === 'system') delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = theme;
    const dark = isDark(theme, systemDark?.matches ?? false);
    themeButton.setAttribute('aria-pressed', String(dark));
    themeButton.title = `${dark ? 'Dark' : 'Light'} mode (${theme === 'system' ? 'as set in your system' : 'your choice'}); click for ${dark ? 'light' : 'dark'} mode`;
    if (dark !== shownDark) {
      shownDark = dark;
      graph.refreshColors();
    }
  };
  themeButton.addEventListener('click', () =>
    store.update((s) => ({ ...s, prefs: { ...s.prefs, theme: toggleTheme(s.prefs.theme, systemDark?.matches ?? false) } })),
  );
  systemDark?.addEventListener('change', applyTheme);
  const legend = el('#graph-legend');
  const legendNote = el('#graph-legend-note');
  const renderLegend = (): void => {
    const s = store.get();
    legend.hidden = s.prefs.focus !== 'derivations';
    // One short line, so that it hides little of the graph (Help explains the details).
    legendNote.textContent = s.selection.some((x) => x.kind === 'problem') ? '' : '· select a problem';
  };
  store.subscribe((changes) => {
    if (changes.has('model') || changes.has('analysis') || changes.has('prefs') || changes.has('selection')) renderGraph();
    if (changes.has('busy') || changes.has('analysis') || changes.has('model')) renderStatus();
    if (changes.has('prefs') || changes.has('selection')) renderLegend();
    if (changes.has('prefs')) {
      showFocus();
      applyTheme();
    }
  });
  renderGraph();
  renderStatus();
  renderLegend();
  showFocus();
  applyTheme();

  // Toolbar. The search filters the left panel's boxes and the problems table too (it is a preference: the store keeps
  // it, and the field shows it, e.g. after the left panel's Clear).
  const searchInput = el<HTMLInputElement>('#search');
  const setSearch = (text: string): void => store.update((s) => (s.prefs.search === text ? s : { ...s, prefs: { ...s.prefs, search: text } }));
  searchInput.addEventListener('input', () => setSearch(searchInput.value));
  store.subscribe((changes) => {
    if (changes.has('prefs') && searchInput.value !== store.get().prefs.search) searchInput.value = store.get().prefs.search;
  });
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && searchInput.value !== '') {
      e.preventDefault();
      setSearch('');
    }
    if (e.key !== 'Enter') return;
    // A Bound ID: select its problem and show the bound in the left panel; a reduction's ID: select it; else select the
    // problem found that the query names best.
    const s = store.get();
    const { model } = store.getDerived();
    const result = search(s.prefs.search, model, s.scenario.knobs);
    const { exact } = result;
    const reduction = reductionOf(s.prefs.search, model);
    if (exact !== null) {
      // (the left panel first: opening it narrows the graph, which then centers the problem)
      revealKnob(exact.id);
      if (model.problems.has(exact.problem)) pick(problem(exact.problem), e.shiftKey, true);
    } else if (reduction !== null) pick(row(reduction), e.shiftKey, true);
    else {
      const id = bestProblem(result, model, boxOrder(s.scenario.problems, s.scenario.knobs, canonicalProblem(model)));
      if (id) pick(problem(id), e.shiftKey, true);
    }
  });
  const toggle = (id: string, key: 'groupFamilies' | 'showUnusedRows'): void => {
    const box = el<HTMLInputElement>(id);
    box.checked = store.get().prefs[key];
    box.addEventListener('change', () => store.update((s) => ({ ...s, prefs: { ...s.prefs, [key]: box.checked } })));
  };
  toggle('#opt-group', 'groupFamilies');
  toggle('#opt-unused', 'showUnusedRows');
  el('#btn-layout').addEventListener('click', () => graph.relayout());
  el('#btn-fit').addEventListener('click', () => graph.fit());
  el('#btn-zoom-in').addEventListener('click', () => graph.zoom(1.25));
  el('#btn-zoom-out').addEventListener('click', () => graph.zoom(0.8));
  el('#btn-zoom-100').addEventListener('click', () => graph.zoom(1, 1));

  // Header actions (one segment each for the reductions sheet, the scenario and the engine config)
  el('#btn-load-sheet').addEventListener('click', async () => {
    const f = await pickFile('.csv,text/csv');
    if (!f) return;
    const { table, warnings } = CsvTable.fromText(f.text);
    const missing = REQUIRED_COLUMNS.filter((c) => !table.hasColumn(c));
    if (missing.length > 0) return toast(`${f.name}: missing columns ${missing.join(', ')}`, true);
    const before = { sheetText: store.get().sheetText, sheetName: store.get().sheetName, sheetCustom: store.get().sheetCustom };
    store.update((s) => ({ ...s, sheetText: f.text, sheetName: f.name, sheetCustom: true, selection: [] }));
    undoToast(`loaded ${f.name} (${table.rowCount} rows${warnings.length ? `, ${warnings.length} CSV warnings` : ''})`, () =>
      store.update((s) => ({ ...s, ...before, selection: [] })),
    );
  });
  el('#btn-export-sheet').addEventListener('click', () => {
    download('FGC_Reductions_edited.csv', store.getDerived().model.table.toText(), 'text/csv');
  });
  /** How many reductions of the sheet (From-time or runtime) and bounds of the scenario use a constant. */
  const constantUses = (name: string): { rows: number; knobs: number } => {
    const mentions = (alternatives: readonly Expr[] | undefined): boolean => (alternatives ?? []).some((a) => new Set(freeIdentifiers(a)).has(name));
    const rows = store.getDerived().model.rows.filter((r) => mentions(r.from?.alternatives) || mentions(r.rt?.alternatives)).length;
    const knobs = store.get().scenario.knobs.filter((k) => {
      try {
        return k.formula !== undefined && new Set(freeIdentifiers(parseExpr(k.formula))).has(name);
      } catch {
        return false;
      }
    }).length;
    return { rows, knobs };
  };
  /** The sections of an engine config: a config file without some of them is merged into the current config. */
  const CONFIG_SECTIONS = ['constants', 'aliases', 'problems', 'rows', 'initialKnobs'] as const;
  /** The parsed JSON of a file, or undefined (with a message) if it is not JSON (a file holding null gives null). */
  const parseJson = (name: string, text: string): unknown => {
    try {
      return JSON.parse(text) as unknown;
    } catch (e) {
      toast(`${name}: not a JSON file (${(e as Error).message}); nothing changed`, true);
      return undefined;
    }
  };
  el('#btn-load-scenario').addEventListener('click', async () => {
    const f = await pickFile('.json,application/json');
    if (!f) return;
    const json = parseJson(f.name, f.text);
    if (json === undefined) return;
    // A file of another kind would leave an empty scenario: refused, before anything changes.
    const kind = jsonKind(json);
    if (kind !== 'scenario') {
      toast(`${f.name}: ${kind === 'config' ? 'this is an engine config; load it with Config ▸ Load' : 'not a scenario (it has no "knobs" list)'}. Nothing changed.`, true);
      return;
    }
    // (new Bound IDs, e.g. for the numbered knobs of earlier versions, avoid those of the initial settings)
    const read = validateScenario(json, initialScenario(store.get().config).knobs.map((k) => k.id));
    const checked = checkScenarioConstants(read.value, store.get().config);
    // (a setting lowered to a new maximum is said in the message after loading, not asked about)
    const notices = read.errors.filter(isNotice);
    const v = { value: checked.value, errors: [...read.errors, ...checked.errors].filter((e) => !isNotice(e)) };
    if (v.errors.length > 0 && !confirm(`${f.name} has ${v.errors.length} problem(s), e.g. ${v.errors[0]}.\n\nLoad what is valid in it (${v.value.knobs.length} bound(s)) in place of the current scenario?`)) return;
    const before = { scenario: store.get().scenario, pinned: store.get().pinned };
    // Pinned regimes saved with the scenario (since November 2026) replace the current ones; a file without them keeps them.
    const pins = pinsOf((json as Record<string, unknown>)['pinned']);
    store.update((s) => ({ ...s, scenario: v.value, ...(pins !== null ? { pinned: pins.pinned } : {}) }));
    if (pins !== null) v.errors.push(...pins.errors);
    const issues = knobIssuesOf(v.value.knobs);
    undoToast(
      `loaded ${f.name}: ${v.value.knobs.length} bound(s)` +
        (v.errors.length > 0 ? `, ${v.errors.length} problem(s) dropped or repaired` : '') +
        (issues > 0 ? `, ${issues} bound(s) the engine cannot use (see their boxes and Diagnostics)` : '') +
        notices.map((n) => `; ${n.replace(/ \(.*$/, '')}`).join(''),
      () => store.update((s) => ({ ...s, ...before })),
    );
  });
  /** The pinned regimes of a scenario file (problem → regime specs), valid ones only; null if it has none. */
  const pinsOf = (x: unknown): { pinned: Record<string, string[]>; errors: string[] } | null => {
    if (x === undefined) return null;
    const errors: string[] = [];
    const pinned: Record<string, string[]> = {};
    if (typeof x !== 'object' || x === null || Array.isArray(x)) return { pinned, errors: ['scenario.pinned: expected an object (problem → regime specs)'] };
    const { model } = store.getDerived();
    for (const [name, specs] of Object.entries(x as Record<string, unknown>)) {
      const p = findProblem(model, name);
      if (p === undefined || !p.isStatic) {
        errors.push(`scenario.pinned: "${name}" is not a static problem of the sheet`);
        continue;
      }
      const ok = (Array.isArray(specs) ? specs : []).filter((spec): spec is string => {
        try {
          return typeof spec === 'string' && regimesFromSpec(p, spec).length > 0;
        } catch {
          errors.push(`scenario.pinned["${name}"]: ${String(spec)} is not a regime of it`);
          return false;
        }
      });
      if (ok.length > 0) pinned[p.id] = [...new Set(ok)];
    }
    return { pinned, errors };
  };
  /** How many enabled knobs name a problem the model does not have, or have a regime or formula that does not parse. */
  const knobIssuesOf = (knobs: readonly Knob[]): number => {
    const { model } = store.getDerived();
    return knobs.filter((k) => {
      if (!k.enabled) return false;
      const p = findProblem(model, k.problem);
      if (p === undefined) return true;
      try {
        if (k.regime !== undefined && k.regime.trim() !== '' && p.isStatic) regimesFromSpec(p, k.regime);
        if (k.formula !== undefined) parseExpr(k.formula);
        return false;
      } catch {
        return true;
      }
    }).length;
  };
  // (with the pinned regimes, so that a shared file shows the same picture)
  const exportScenario = (): void => {
    const s = store.get();
    const pinned = Object.fromEntries(Object.entries(s.pinned).filter(([, specs]) => specs.length > 0));
    download('fgc-scenario.json', JSON.stringify({ ...s.scenario, ...(Object.keys(pinned).length > 0 ? { pinned } : {}) }, null, 2), 'application/json');
  };
  el('#btn-export-scenario').addEventListener('click', exportScenario);
  el('#btn-load-config').addEventListener('click', async () => {
    const f = await pickFile('.json,application/json');
    if (!f) return;
    const json = parseJson(f.name, f.text);
    if (json === undefined) return;
    const kind = jsonKind(json);
    if (kind !== 'config') {
      toast(`${f.name}: ${kind === 'scenario' ? 'this is a scenario; load it with Scenario ▸ Load' : 'not an engine config (it has no "initialKnobs", "problems", "rows" or "constants")'}. Nothing changed.`, true);
      return;
    }
    // A file without some of the sections (e.g. only "constants") is merged into the current config, after asking: the
    // entries of its keyed sections (constants, aliases, problems, rows) replace those of the same name, its initial
    // settings replace the current ones, and everything else stays. (It used to replace the whole config, problems and
    // rows too; then each section it had: a file with one row entry dropped the other 52.)
    const x = json as Record<string, unknown>;
    const has = (k: string): boolean => x[k] !== undefined || (k === 'initialKnobs' && x['presets'] !== undefined);
    const present = CONFIG_SECTIONS.filter(has);
    const absent = CONFIG_SECTIONS.filter((k) => !has(k));
    let input: unknown = json;
    if (absent.length > 0) {
      const list = (ks: readonly string[]): string => ks.map((k) => `"${k}"`).join(', ');
      const keyed = present.filter((k) => k !== 'initialKnobs');
      const entries = keyed.map((k) => {
        const n = typeof x[k] === 'object' && x[k] !== null && !Array.isArray(x[k]) ? Object.keys(x[k] as object).length : 0;
        return `${n} ${k === 'problems' ? `problem entr${n === 1 ? 'y' : 'ies'}` : k === 'rows' ? `row entr${n === 1 ? 'y' : 'ies'}` : k === 'aliases' ? `alias${n === 1 ? '' : 'es'}` : `constant${n === 1 ? '' : 's'}`}`;
      });
      const what = [...entries, ...(present.includes('initialKnobs') ? ['the initial settings'] : [])].join(', ');
      if (!confirm(`${f.name} is part of an engine config (${list(present)}, no ${list(absent)}).\n\nMerge it into the current config? Its ${what} replace those of the same name; everything else stays.`)) return;
      const current = store.get().config as unknown as Record<string, unknown>;
      const merged: Record<string, unknown> = { ...current, version: x['version'] ?? 1 };
      for (const k of keyed) {
        const theirs = x[k];
        merged[k] = typeof theirs === 'object' && theirs !== null && !Array.isArray(theirs) ? { ...(current[k] as object), ...(theirs as object) } : theirs;
      }
      if (x['initialKnobs'] !== undefined) merged['initialKnobs'] = x['initialKnobs'];
      else if (x['presets'] !== undefined) {
        delete merged['initialKnobs'];
        merged['presets'] = x['presets'];
      }
      input = merged;
    }
    const v = validateConfig(input);
    if (v.errors.length > 0 && !confirm(`${f.name} has ${v.errors.length} problem(s), e.g. ${v.errors[0]}.\n\nUse what is valid in it ${absent.length > 0 ? 'in the current' : 'in place of the current'} engine config?`)) return;
    // A constant that formulas use and the new config lacks: its rows would be blocked, its bounds refused.
    const lost = Object.keys(store.get().config.constants)
      .filter((c) => v.value.constants[c] === undefined)
      .map((c) => ({ c, ...constantUses(c) }))
      .filter((u) => u.rows + u.knobs > 0);
    if (lost.length > 0 && !confirm(`${f.name} has no ${lost.map((u) => `constant ${u.c}, which ${u.rows} reduction${u.rows === 1 ? '' : 's'} and ${u.knobs} bound${u.knobs === 1 ? '' : 's'} use`).join('; ')}: those reductions would not be used, and those bounds would be refused.\n\nLoad it anyway?`)) return;
    const before = { config: store.get().config, configCustom: store.get().configCustom };
    store.update((s) => ({ ...s, config: v.value, configCustom: true }));
    undoToast(
      `loaded ${f.name}${absent.length > 0 ? ` (merged: ${present.join(', ')})` : ''}` + (v.errors.length > 0 ? ` (${v.errors.length} problem(s) dropped or repaired)` : ''),
      () => store.update((s) => ({ ...s, ...before })),
    );
  });
  el('#btn-export-config').addEventListener('click', () => download('fgc-engine-config.json', JSON.stringify(store.get().config, null, 2), 'application/json'));
  el('#btn-add-row').addEventListener('click', () => openRowEditor(store, null));
  el('#btn-help').addEventListener('click', () => openHelp());
  el('#btn-reset').addEventListener('click', () => {
    if (!confirm('Forget this browser’s saved scenario, edits and loaded sheet, and go back to the built-in defaults?')) return;
    forgetPersisted();
    location.reload();
  });

  // The graph follows its container (window resizes, panels dragged, shown or hidden), once per frame.
  let resizeQueued = false;
  new ResizeObserver(() => {
    if (resizeQueued) return;
    resizeQueued = true;
    requestAnimationFrame(() => {
      resizeQueued = false;
      graph.resize();
    });
  }).observe(el('#graph'));
  // Another tab saved over this one's data: from now on this tab would overwrite it, so it stops saving and says so
  // (not when the other tab saved what this one holds, e.g. the same data in another order of keys). The message sits
  // above the header, which stays usable; it offers to reload, to export this tab's scenario, or to keep this tab's
  // version (saved over the other one's, which then stops saving in turn), and it can be closed.
  window.addEventListener('storage', (e) => {
    if (e.key !== STORAGE_KEY || !isSaving() || storedEquals(store.get(), e.newValue)) return;
    stopSaving();
    renderStatus();
    showStaleBanner();
  });
  // (also when a save of this tab finds that another tab kept its version since: see whenSavingStops)
  whenSavingStops(() => {
    renderStatus();
    showStaleBanner();
  });
  // In the one-column layout of narrow windows the inspector is below the graph and above the left panel: a selection
  // made while its top is out of view, below (e.g. from the graph's lower part) or above (from the left panel, about
  // 900 px further down), brings it into view, also when only a strip of it shows at the bottom.
  const narrow = typeof window.matchMedia === 'function' ? window.matchMedia('(max-width: 1100px)') : null;
  store.subscribe((changes) => {
    if (!changes.has('selection') || !narrow?.matches || store.get().selection.length === 0) return;
    const right = el('#right');
    const top = right.getBoundingClientRect().top;
    if (top > window.innerHeight - 120 || top < -2) right.scrollIntoView({ behavior: scrollBehavior(), block: 'start' });
  });
  // Handle for automated tests and the browser console.
  (window as unknown as { fgcExplorer: unknown }).fgcExplorer = { store, graph };
}

// (after the first paint, so that the page shows "loading…" during the first analysis, a few seconds)
requestAnimationFrame(() => setTimeout(main, 0));
