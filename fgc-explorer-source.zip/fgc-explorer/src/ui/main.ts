/**
 * Entry point of the browser app: wires the store to the views and the header actions.
 */

import builtInSheet from '../../data/FGC_Reductions_filled.csv';
import builtInConfig from '../../data/default-config.json';
import { boxOrder, canonicalProblem } from '../model/boxes';
import { checkScenarioConstants, initialScenario, Knob, validateConfig, validateScenario } from '../model/config';
import { findProblem, REQUIRED_COLUMNS } from '../model/model';
import { regimesFromSpec } from '../engine/analysis';
import { parseExpr } from '../math/parser';
import { CsvTable } from '../util/csv';
import { writeBoundsCsv } from '../model/boundsCsv';
import { openBoundsImport, openHelp, openRowEditor } from './dialogs';
import { download, h, pickFile, setChildren } from './dom';
import { FOCUS_MODES, FocusMode } from './focus';
import { formatDuration } from './format';
import { GraphView } from './graph';
import { panelHover } from './hover';
import { Inspector } from './inspector';
import { Panels } from './panels';
import { ScenarioPanel } from './scenarioPanel';
import { bestProblem, reductionOf, search } from './search';
import { clickSelect, sameItem, SelectionItem } from './selection';
import { BUILT_IN_SHEET_NAME, defaultState, forgetPersisted, initialState, jsonKind, persist, STORAGE_KEY, stopSaving } from './state';
import { Store } from './store';
import { TablesView } from './tables';
import { isDark, toggleTheme } from './theme';

/**
 * Whether the messages that only describe an upgrade of saved data (bounds a new version added or updated, IDs moved) are
 * shown when the page loads. Off while the app is being deployed: every visitor would see them once after each update.
 * Problems with saved data are always shown.
 */
const SHOW_UPGRADE_NOTES = false;

function el<T extends HTMLElement = HTMLElement>(selector: string): T {
  const e = document.querySelector<T>(selector);
  if (!e) throw new Error(`missing element ${selector}`);
  return e;
}

/** A transient message; longer ones stay longer (about 16 characters per second, at least 3.5 s, errors 8 s). */
function toast(message: string, isError = false): void {
  const t = h('div', { class: `toast ${isError ? 'error' : ''}` }, message);
  document.body.append(t);
  setTimeout(() => t.remove(), Math.max(isError ? 8000 : 3500, 60 * message.length));
}

/** A message with a button (e.g. Undo), shown for at least 12 s; the button acts once and closes it. */
function toastAction(message: string, label: string, action: () => void): void {
  const t = h('div', { class: 'toast', role: 'status' }, message, ' ');
  t.append(h('button', { class: 'link toast-action', on: { click: () => (t.remove(), action()) } }, label));
  document.body.append(t);
  setTimeout(() => t.remove(), Math.max(12000, 60 * message.length));
}

function main(): void {
  const { state, messages } = initialState(builtInSheet, builtInConfig);
  const store = new Store(state, () => defaultState(builtInSheet, builtInConfig), (m) => toast(m, true));
  messages.filter((m) => m.error || SHOW_UPGRADE_NOTES).forEach((m) => toast(m.text, m.error));
  // Save right away, so that upgraded (or replaced) saved data is stored in the current format.
  persist(store.get());

  /**
   * A click on a problem or reduction: it alone is selected, or, when `additive` (Shift, Ctrl or ⌘ held), it is added to
   * the selection or removed from it. `reveal` centers the graph on it (clicks outside the graph).
   */
  const pick = (item: SelectionItem, additive: boolean, reveal = false): void => {
    store.update((s) => ({ ...s, selection: clickSelect(s.selection, item, additive) }));
    if (reveal) graph.reveal(item);
  };
  const problem = (id: string): SelectionItem => ({ kind: 'problem', id });
  const row = (id: string): SelectionItem => ({ kind: 'row', id });
  const clearSelection = (): void => store.update((s) => (s.selection.length === 0 ? s : { ...s, selection: [] }));

  const graph = new GraphView(el('#graph'), {
    onSelectProblem: (id, additive) => pick(problem(id), additive),
    onSelectRow: (id, additive) => pick(row(id), additive),
    onClear: clearSelection,
    onOpen: () => panels.toggle('right', true),
  });
  const panels = new Panels(
    {
      main: el('main'),
      center: el('#center'),
      splitters: { left: el('#split-left'), right: el('#split-right'), bottom: el('#split-bottom') },
      toggles: { left: el('#btn-panel-left'), right: el('#btn-panel-right'), bottom: el('#btn-panel-bottom') },
      maximize: el('#btn-panel-all'),
    },
    store,
  );
  const scenario = new ScenarioPanel(el('#left'), store, {
    selectProblem: (id, additive) => pick(problem(id), additive, true),
    // (without scrolling: in a narrow window the field is far above the left panel)
    focusSearch: () => el('#search').focus({ preventScroll: true }),
    // The note is part of the inspector's view when nothing is selected.
    showInitialSettings: () => {
      panels.toggle('right', true);
      clearSelection();
      document.getElementById('initial-settings')?.scrollIntoView({ block: 'start', behavior: 'smooth' });
    },
    importBounds: async () => {
      const f = await pickFile('.csv,text/csv');
      if (f) openBoundsImport(store, f.name, f.text, (m) => toast(m));
    },
    exportBounds: () => {
      const { knobs, problems } = store.get().scenario;
      download('fgc-bounds.csv', writeBoundsCsv(knobs, store.getDerived().model, problems), 'text/csv');
    },
  });
  /** Show a bound in its problem's box in the left panel (opened if hidden). */
  const revealKnob = (id: string): void => {
    panels.toggle('left', true);
    if (!scenario.revealKnob(id)) toast(`bound ${id} is not in the left panel`, true);
  };
  new Inspector(el('#right'), store, {
    selectProblem: (id, additive) => pick(problem(id), additive, true),
    selectRow: (id, additive) => pick(row(id), additive, true),
    deselect: (item) => store.update((s) => ({ ...s, selection: s.selection.filter((x) => !sameItem(x, item)) })),
    clearSelection,
    editRow: (id) => openRowEditor(store, id),
    revealKnob,
    addKnob: (problemId, kind, spec) => {
      panels.toggle('left', true);
      scenario.prefill(problemId, kind, spec);
    },
    restoreInitialSettings: () => {
      if (!confirm('Replace the current hypotheses, algorithms, constants and engine settings by the initial ones? Sheet edits and pinned regimes are kept.')) return;
      store.update((s) => ({ ...s, scenario: initialScenario(s.config) }));
      toast('initial settings restored');
    },
  });
  new TablesView(el('#bottom-tabs'), el('#bottom-body'), store, {
    selectProblem: (id, additive) => pick(problem(id), additive, true),
    selectRow: (id, additive) => pick(row(id), additive, true),
  });
  // Pointing at a problem's name or a reduction's ID in a panel highlights it in the graph.
  for (const panel of [el('#left'), el('#right'), el('#bottom-body')]) panelHover(panel, (item) => graph.hover(item));

  const renderGraph = (): void => {
    const s = store.get();
    const d = store.getDerived();
    graph.render(d.model, d.analysis, s.prefs, s.selection);
  };
  const status = el('#status');
  const renderStatus = (): void => {
    const { model, analysis } = store.getDerived();
    const used = model.rows.filter((r) => r.status === 'ok').length;
    const lbFacts = [...analysis.lower.facts.values()].reduce((n, m) => n + m.size, 0);
    const sheetName = store.get().sheetName;
    const stats = `${used}/${model.rows.length} reductions used · ${lbFacts} lower-bound facts · ${formatDuration(analysis.elapsedMs)}`;
    // A search that reached one of its limits may have missed bounds: say so here, not only in Diagnostics.
    const limits = analysis.lower.capped.length + analysis.upper.capped.length + analysis.upperOverlay.capped.length;
    const warning =
      (analysis.complete ? '' : ' · checking the other regimes of lower bounds for upper bounds…') +
      (limits > 0 ? ' · ⚠ a search limit was reached, some bounds may be weaker (Diagnostics)' : '');
    status.textContent = store.busy ? 'computing…' : `${sheetName.replace(BUILT_IN_SHEET_NAME, 'built-in sheet')} · ${stats}${warning}`;
    status.title = store.busy ? '' : `${sheetName} · ${stats}${warning}`; // in full: the line may be cut off
    status.classList.toggle('warn', !store.busy && limits > 0);
    document.body.classList.toggle('busy', store.busy);
  };
  // The focus mode (toolbar) and the legend of its "bound derivations" mode, over the graph.
  const focus = el<HTMLSelectElement>('#opt-focus');
  setChildren(
    focus,
    FOCUS_MODES.map((m) => h('option', { value: m.mode, title: m.title }, m.label)),
  );
  const showFocus = (): void => {
    focus.value = store.get().prefs.focus;
    focus.title = `focus: ${FOCUS_MODES.find((m) => m.mode === focus.value)?.title ?? ''} (the rest is dimmed)`;
  };
  focus.addEventListener('change', () => store.update((s) => ({ ...s, prefs: { ...s.prefs, focus: focus.value as FocusMode } })));
  // Light / dark mode: the preference goes on <html> (the CSS follows it), the toggle shows it, the graph takes up the
  // colors. "system" also follows changes of the system's setting.
  const themeButton = el<HTMLButtonElement>('#btn-theme');
  const systemDark = typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  let shownDark: boolean | null = null;
  const applyTheme = (): void => {
    const theme = store.get().prefs.theme;
    if (theme === 'system') delete document.documentElement.dataset.theme;
    else document.documentElement.dataset.theme = theme;
    const dark = isDark(theme, systemDark?.matches ?? false);
    themeButton.setAttribute('aria-pressed', String(dark));
    themeButton.title = `${dark ? 'Dark' : 'Light'} mode (${theme === 'system' ? 'as set in your system' : 'your choice'}); click for ${dark ? 'light' : 'dark'} mode`;
    if (dark !== shownDark) {
      shownDark = dark;
      graph.refreshColors();
    }
  };
  themeButton.addEventListener('click', () =>
    store.update((s) => ({ ...s, prefs: { ...s.prefs, theme: toggleTheme(s.prefs.theme, systemDark?.matches ?? false) } })),
  );
  systemDark?.addEventListener('change', applyTheme);
  const legend = el('#graph-legend');
  const legendNote = el('#graph-legend-note');
  const renderLegend = (): void => {
    const s = store.get();
    legend.hidden = s.prefs.focus !== 'derivations';
    // One short line, so that it hides little of the graph (Help explains the details).
    legendNote.textContent = s.selection.some((x) => x.kind === 'problem') ? '' : '· select a problem';
  };
  store.subscribe((changes) => {
    if (changes.has('model') || changes.has('analysis') || changes.has('prefs') || changes.has('selection')) renderGraph();
    if (changes.has('busy') || changes.has('analysis') || changes.has('model')) renderStatus();
    if (changes.has('prefs') || changes.has('selection')) renderLegend();
    if (changes.has('prefs')) {
      showFocus();
      applyTheme();
    }
  });
  renderGraph();
  renderStatus();
  renderLegend();
  showFocus();
  applyTheme();

  // Toolbar. The search filters the left panel's boxes and the problems table too (it is a preference: the store keeps
  // it, and the field shows it, e.g. after the left panel's Clear).
  const searchInput = el<HTMLInputElement>('#search');
  const setSearch = (text: string): void => store.update((s) => (s.prefs.search === text ? s : { ...s, prefs: { ...s.prefs, search: text } }));
  searchInput.addEventListener('input', () => setSearch(searchInput.value));
  store.subscribe((changes) => {
    if (changes.has('prefs') && searchInput.value !== store.get().prefs.search) searchInput.value = store.get().prefs.search;
  });
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && searchInput.value !== '') {
      e.preventDefault();
      setSearch('');
    }
    if (e.key !== 'Enter') return;
    // A Bound ID: select its problem and show the bound in the left panel; a reduction's ID: select it; else select the
    // problem found that the query names best.
    const s = store.get();
    const { model } = store.getDerived();
    const result = search(s.prefs.search, model, s.scenario.knobs);
    const { exact } = result;
    const reduction = reductionOf(s.prefs.search, model);
    if (exact !== null) {
      // (the left panel first: opening it narrows the graph, which then centers the problem)
      revealKnob(exact.id);
      if (model.problems.has(exact.problem)) pick(problem(exact.problem), e.shiftKey, true);
    } else if (reduction !== null) pick(row(reduction), e.shiftKey, true);
    else {
      const id = bestProblem(result, model, boxOrder(s.scenario.problems, s.scenario.knobs, canonicalProblem(model)));
      if (id) pick(problem(id), e.shiftKey, true);
    }
  });
  const toggle = (id: string, key: 'groupFamilies' | 'showUnusedRows'): void => {
    const box = el<HTMLInputElement>(id);
    box.checked = store.get().prefs[key];
    box.addEventListener('change', () => store.update((s) => ({ ...s, prefs: { ...s.prefs, [key]: box.checked } })));
  };
  toggle('#opt-group', 'groupFamilies');
  toggle('#opt-unused', 'showUnusedRows');
  el('#btn-layout').addEventListener('click', () => graph.relayout());
  el('#btn-fit').addEventListener('click', () => graph.fit());
  el('#btn-zoom-in').addEventListener('click', () => graph.zoom(1.25));
  el('#btn-zoom-out').addEventListener('click', () => graph.zoom(0.8));
  el('#btn-zoom-100').addEventListener('click', () => graph.zoom(1, 1));

  // Header actions (one segment each for the reductions sheet, the scenario and the engine config)
  el('#btn-load-sheet').addEventListener('click', async () => {
    const f = await pickFile('.csv,text/csv');
    if (!f) return;
    const { table, warnings } = CsvTable.fromText(f.text);
    const missing = REQUIRED_COLUMNS.filter((c) => !table.hasColumn(c));
    if (missing.length > 0) return toast(`${f.name}: missing columns ${missing.join(', ')}`, true);
    store.update((s) => ({ ...s, sheetText: f.text, sheetName: f.name, sheetCustom: true, selection: [] }));
    toast(`loaded ${f.name} (${table.rowCount} rows${warnings.length ? `, ${warnings.length} CSV warnings` : ''})`);
  });
  el('#btn-export-sheet').addEventListener('click', () => {
    download('FGC_Reductions_edited.csv', store.getDerived().model.table.toText(), 'text/csv');
  });
  /** The parsed JSON of a file, or null (with a message) if it is not JSON. */
  const parseJson = (name: string, text: string): unknown => {
    try {
      return JSON.parse(text);
    } catch (e) {
      toast(`${name}: not a JSON file (${(e as Error).message}); nothing changed`, true);
      return null;
    }
  };
  el('#btn-load-scenario').addEventListener('click', async () => {
    const f = await pickFile('.json,application/json');
    if (!f) return;
    const json = parseJson(f.name, f.text);
    if (json === null) return;
    // A file of another kind would leave an empty scenario: refused, before anything changes.
    const kind = jsonKind(json);
    if (kind !== 'scenario') {
      toast(`${f.name}: ${kind === 'config' ? 'this is an engine config; load it with Config ▸ Load' : 'not a scenario (it has no "knobs" list)'}. Nothing changed.`, true);
      return;
    }
    // (new Bound IDs, e.g. for the numbered knobs of earlier versions, avoid those of the initial settings)
    const read = validateScenario(json, initialScenario(store.get().config).knobs.map((k) => k.id));
    const checked = checkScenarioConstants(read.value, store.get().config);
    const v = { value: checked.value, errors: [...read.errors, ...checked.errors] };
    if (v.errors.length > 0 && !confirm(`${f.name} has ${v.errors.length} problem(s), e.g. ${v.errors[0]}.\n\nLoad what is valid in it (${v.value.knobs.length} bound(s)) in place of the current scenario?`)) return;
    const before = { scenario: store.get().scenario, pinned: store.get().pinned };
    // Pinned regimes saved with the scenario (since November 2026) replace the current ones; a file without them keeps them.
    const pins = pinsOf((json as Record<string, unknown>)['pinned']);
    store.update((s) => ({ ...s, scenario: v.value, ...(pins !== null ? { pinned: pins.pinned } : {}) }));
    if (pins !== null) v.errors.push(...pins.errors);
    const issues = knobIssuesOf(v.value.knobs);
    toastAction(
      `loaded ${f.name}: ${v.value.knobs.length} bound(s)` +
        (v.errors.length > 0 ? `, ${v.errors.length} problem(s) dropped or repaired` : '') +
        (issues > 0 ? `, ${issues} bound(s) the engine cannot use (see their boxes and Diagnostics)` : ''),
      'Undo',
      () => store.update((s) => ({ ...s, ...before })),
    );
  });
  /** The pinned regimes of a scenario file (problem → regime specs), valid ones only; null if it has none. */
  const pinsOf = (x: unknown): { pinned: Record<string, string[]>; errors: string[] } | null => {
    if (x === undefined) return null;
    const errors: string[] = [];
    const pinned: Record<string, string[]> = {};
    if (typeof x !== 'object' || x === null || Array.isArray(x)) return { pinned, errors: ['scenario.pinned: expected an object (problem → regime specs)'] };
    const { model } = store.getDerived();
    for (const [name, specs] of Object.entries(x as Record<string, unknown>)) {
      const p = findProblem(model, name);
      if (p === undefined || !p.isStatic) {
        errors.push(`scenario.pinned: "${name}" is not a static problem of the sheet`);
        continue;
      }
      const ok = (Array.isArray(specs) ? specs : []).filter((spec): spec is string => {
        try {
          return typeof spec === 'string' && regimesFromSpec(p, spec).length > 0;
        } catch {
          errors.push(`scenario.pinned["${name}"]: ${String(spec)} is not a regime of it`);
          return false;
        }
      });
      if (ok.length > 0) pinned[p.id] = [...new Set(ok)];
    }
    return { pinned, errors };
  };
  /** How many enabled knobs name a problem the model does not have, or have a regime or formula that does not parse. */
  const knobIssuesOf = (knobs: readonly Knob[]): number => {
    const { model } = store.getDerived();
    return knobs.filter((k) => {
      if (!k.enabled) return false;
      const p = findProblem(model, k.problem);
      if (p === undefined) return true;
      try {
        if (k.regime !== undefined && k.regime.trim() !== '' && p.isStatic) regimesFromSpec(p, k.regime);
        if (k.formula !== undefined) parseExpr(k.formula);
        return false;
      } catch {
        return true;
      }
    }).length;
  };
  // (with the pinned regimes, so that a shared file shows the same picture)
  el('#btn-export-scenario').addEventListener('click', () => {
    const s = store.get();
    const pinned = Object.fromEntries(Object.entries(s.pinned).filter(([, specs]) => specs.length > 0));
    download('fgc-scenario.json', JSON.stringify({ ...s.scenario, ...(Object.keys(pinned).length > 0 ? { pinned } : {}) }, null, 2), 'application/json');
  });
  el('#btn-load-config').addEventListener('click', async () => {
    const f = await pickFile('.json,application/json');
    if (!f) return;
    const json = parseJson(f.name, f.text);
    if (json === null) return;
    const kind = jsonKind(json);
    if (kind !== 'config') {
      toast(`${f.name}: ${kind === 'scenario' ? 'this is a scenario; load it with Scenario ▸ Load' : 'not an engine config (it has no "initialKnobs", "problems" or "rows")'}. Nothing changed.`, true);
      return;
    }
    const v = validateConfig(json);
    if (v.errors.length > 0 && !confirm(`${f.name} has ${v.errors.length} problem(s), e.g. ${v.errors[0]}.\n\nUse what is valid in it in place of the current engine config?`)) return;
    const before = { config: store.get().config, configCustom: store.get().configCustom };
    store.update((s) => ({ ...s, config: v.value, configCustom: true }));
    toastAction(
      `loaded ${f.name}` + (v.errors.length > 0 ? ` (${v.errors.length} problem(s) dropped or repaired)` : ''),
      'Undo',
      () => store.update((s) => ({ ...s, ...before })),
    );
  });
  el('#btn-export-config').addEventListener('click', () => download('fgc-engine-config.json', JSON.stringify(store.get().config, null, 2), 'application/json'));
  el('#btn-add-row').addEventListener('click', () => openRowEditor(store, null));
  el('#btn-help').addEventListener('click', () => openHelp());
  el('#btn-reset').addEventListener('click', () => {
    if (!confirm('Forget this browser’s saved scenario, edits and loaded sheet, and go back to the built-in defaults?')) return;
    forgetPersisted();
    location.reload();
  });

  // The graph follows its container (window resizes, panels dragged, shown or hidden), once per frame.
  let resizeQueued = false;
  new ResizeObserver(() => {
    if (resizeQueued) return;
    resizeQueued = true;
    requestAnimationFrame(() => {
      resizeQueued = false;
      graph.resize();
    });
  }).observe(el('#graph'));
  // Another tab saved over this one's data: from now on this tab would overwrite it, so it stops saving and says so.
  window.addEventListener('storage', (e) => {
    if (e.key !== STORAGE_KEY || document.querySelector('.stale-banner') !== null) return;
    stopSaving();
    const banner = h(
      'div',
      { class: 'stale-banner', role: 'alert' },
      'This app was changed in another tab or window. Changes made here are no longer saved, so that they do not overwrite those. ',
      h('button', { on: { click: () => location.reload() } }, 'Reload with the newest data'),
    );
    document.body.prepend(banner);
  });
  // In the one-column layout of narrow windows the inspector is below the graph: a selection made while it is out of
  // view (e.g. from a table) brings it into view.
  const narrow = typeof window.matchMedia === 'function' ? window.matchMedia('(max-width: 1100px)') : null;
  store.subscribe((changes) => {
    if (!changes.has('selection') || !narrow?.matches || store.get().selection.length === 0) return;
    const right = el('#right');
    if (right.getBoundingClientRect().top > window.innerHeight - 40) right.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  // Handle for automated tests and the browser console.
  (window as unknown as { fgcExplorer: unknown }).fgcExplorer = { store, graph };
}

// (after the first paint, so that the page shows "loading…" during the first analysis, a few seconds)
requestAnimationFrame(() => setTimeout(main, 0));
