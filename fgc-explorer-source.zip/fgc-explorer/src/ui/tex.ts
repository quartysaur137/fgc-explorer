/**
 * Rendering of sheet text and formulas: KaTeX with MathML output (no fonts or stylesheet needed), and a plain-text
 * fallback for canvas labels.
 */

import katex from 'katex';
import { mathSpans } from '../math/cells';
import { escapeHtml, h } from './dom';

const cache = new Map<string, string>();

/** HTML (MathML) for a LaTeX formula; invalid LaTeX is shown in red source form. */
export function texHtml(tex: string, display = false): string {
  const key = `${display ? 'D' : 'I'}${tex}`;
  let out = cache.get(key);
  if (out === undefined) {
    out = katex.renderToString(tex, { output: 'mathml', throwOnError: false, strict: 'ignore', displayMode: display });
    if (cache.size > 5000) cache.clear();
    cache.set(key, out);
  }
  return out;
}

/** HTML for a sheet cell: prose escaped, $...$ spans rendered, line breaks kept. */
export function cellHtml(cell: string): string {
  let out = '';
  let last = 0;
  for (const s of mathSpans(cell)) {
    out += escapeHtml(cell.slice(last, s.start));
    out += texHtml(s.tex);
    last = s.end;
  }
  out += escapeHtml(cell.slice(last));
  return out.replace(/\n/g, '<br>');
}

/** Element showing a formula. */
export function texEl(tex: string, cls = 'tex'): HTMLSpanElement {
  return h('span', { class: cls, html: texHtml(tex) });
}

/** Element showing a sheet cell. */
export function cellEl(cell: string, cls = 'cell'): HTMLSpanElement {
  return h('span', { class: cls, html: cellHtml(cell) });
}

const SYMBOLS: Record<string, string> = {
  alpha: 'α', beta: 'β', gamma: 'γ', delta: 'δ', epsilon: 'ε', varepsilon: 'ε', lambda: 'λ', mu: 'μ', rho: 'ρ',
  sigma: 'σ', omega: 'ω', Delta: 'Δ', Gamma: 'Γ', Theta: 'Θ', Omega: 'Ω', ell: 'ℓ', infty: '∞', leq: '≤', le: '≤',
  geq: '≥', ge: '≥', cdot: '·', times: '×', min: 'min', max: 'max', log: 'log', sqrt: '√', ldots: '…', dots: '…',
};

/** Plain-text approximation of text with $...$ spans (for graph labels). */
export function plainText(cell: string): string {
  let out = '';
  let last = 0;
  for (const s of mathSpans(cell)) {
    out += cell.slice(last, s.start) + texToPlain(s.tex);
    last = s.end;
  }
  return (out + cell.slice(last)).replace(/\s+/g, ' ').trim();
}

/** Plain-text approximation of a LaTeX formula. */
export function texToPlain(tex: string): string {
  return tex
    .replace(/\\text\{([^}]*)\}/g, '$1')
    .replace(/\\([A-Za-z]+)/g, (_m, name: string) => SYMBOLS[name] ?? name)
    .replace(/\\([,;!: ])/g, ' ')
    .replace(/[{}]/g, '')
    .replace(/_/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}
