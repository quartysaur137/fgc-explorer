/**
 * The reductions graph (Cytoscape). Nodes are problems (optionally boxed by family), edges are rows. Positions come
 * from the compact layout of graphLayout.ts; node sizes depend only on the problem names, so analyses (which change
 * the bounds shown in the labels) never move anything.
 */

import cytoscape, { CollectionReturnValue, Core, ElementDefinition, EventObject, NodeSingular } from 'cytoscape';
import { Analysis } from '../engine/analysis';
import { Model } from '../model/model';
import { FocusLink, keptAround, Kept, selectionDerivations } from './focus';
import { boundsLine, problemLabel } from './format';
import { BoxNode, compactLayout, Link, Point, UnitBox } from './graphLayout';
import { offscreenPointer } from './hover';
import { isAdditive, itemKey, Selection, SelectionItem } from './selection';
import { UiPrefs } from './state';
import { plainText } from './tex';

export interface GraphCallbacks {
  /** A click on a problem; `additive` when Shift, Ctrl or ⌘ was held (add to / remove from the selection). */
  onSelectProblem(id: string, additive: boolean): void;
  onSelectRow(id: string, additive: boolean): void;
  onClear(): void;
  /** Double-click on a problem or reduction: it is selected, and its details should be shown. */
  onOpen(): void;
}

/** Colors of derivation paths (as the edges used by lower / upper bounds, but drawn thick). */
const PATH_COLOR = { lb: '#e65100', ub: '#1565c0', both: '#8e24aa' } as const;
const SELECTION_COLOR = '#00897b';

const STATUS_FILL: Record<string, [string, string]> = {
  conflict: ['#ef9a9a', '#c62828'],
  tight: ['#a5d6a7', '#2e7d32'],
  gap: ['#ffe082', '#c79100'],
  lb: ['#ffcc80', '#e65100'],
  ub: ['#90caf9', '#1565c0'],
  none: ['#e0e0e0', '#8a8a8a'],
};

const nodeId = (problemId: string): string => `p:${problemId}`;
const familyId = (family: string): string => `f:${family}`;
const edgeId = (rowId: string): string => `r:${rowId}`;

/*
 * Sizes in graph units (pixels at 100 % zoom). The layout packs nodes tightly (GAP), so the labels are large compared
 * with the whole graph; zoom in for comfortable reading (100 % shows labels at FONT_SIZE pixels).
 */
const FONT_FAMILY = 'system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
const FONT_SIZE = 14;
const LINE_HEIGHT = 1.2;
/** Names wrap at this width. */
const WRAP_WIDTH = 13 * FONT_SIZE;
const PAD_X = 8;
const PAD_Y = 6;
const FAMILY_FONT_SIZE = 16;
const GAP = 12;
const GROUP_PADDING = 10;
const GROUP_TITLE = Math.ceil(FAMILY_FONT_SIZE * LINE_HEIGHT) + 6;
/** Room reserved for the bounds line under a static problem's name (longer lines overflow a little). */
const BOUNDS_RESERVE = '≥ n^2.3716\u00a0\u00a0≤ n^2.3716';

/** Colors of the page that the graph follows (they change with light and dark mode). */
function pageColors(): { text: string; muted: string } {
  const style = getComputedStyle(document.body);
  return { text: style.getPropertyValue('--fg').trim() || '#222', muted: style.getPropertyValue('--muted').trim() || '#888' };
}

/** The graph's stylesheet; `text` and `muted` are the page's colors (family titles, hover highlights). */
function stylesheet({ text, muted }: { text: string; muted: string }): cytoscape.StylesheetJson {
  return [
    {
      selector: 'node.problem',
      style: {
        shape: 'round-rectangle',
        label: 'data(label)',
        'text-wrap': 'wrap',
        'text-max-width': 'data(tw)',
        'font-family': FONT_FAMILY,
        'font-size': FONT_SIZE,
        'line-height': LINE_HEIGHT,
        'text-valign': 'center',
        'text-halign': 'center',
        color: '#1a1a1a',
        width: 'data(w)',
        height: 'data(h)',
        'border-width': 1,
        'background-color': STATUS_FILL['none']![0],
        'border-color': STATUS_FILL['none']![1],
      },
    },
    ...Object.entries(STATUS_FILL).map(([status, [fill, border]]) => ({
      selector: `node.status-${status}`,
      style: { 'background-color': fill, 'border-color': border },
    })),
    {
      selector: 'node.dynamic',
      style: { 'background-color': '#fafafa', 'border-style': 'dashed', color: '#707070' },
    },
    {
      selector: 'node.family',
      style: {
        shape: 'round-rectangle',
        label: 'data(label)',
        'text-valign': 'top',
        'text-halign': 'center',
        'font-family': FONT_FAMILY,
        'font-size': FAMILY_FONT_SIZE,
        'font-weight': 'bold',
        color: text,
        'background-color': '#808080',
        'background-opacity': 0.07,
        'border-width': 1,
        'border-style': 'dashed',
        'border-color': muted,
        padding: `${GROUP_PADDING}px`,
        'text-margin-y': -2,
      },
    },
    {
      selector: 'edge',
      style: {
        width: 1,
        'curve-style': 'bezier',
        'line-color': '#9e9e9e',
        'target-arrow-color': '#9e9e9e',
        'target-arrow-shape': 'triangle',
        'arrow-scale': 0.7,
        opacity: 0.7,
      },
    },
    { selector: 'edge.unused', style: { 'line-style': 'dashed', opacity: 0.35 } },
    { selector: 'edge.lb-used', style: { 'line-color': '#e65100', 'target-arrow-color': '#e65100', width: 2, opacity: 0.9 } },
    { selector: 'edge.ub-used', style: { 'line-color': '#1565c0', 'target-arrow-color': '#1565c0', width: 2, opacity: 0.9 } },
    { selector: 'edge.lb-used.ub-used', style: { 'line-color': '#8e24aa', 'target-arrow-color': '#8e24aa' } },
    // Selected problems: a border and a halo (the halo stays when a derivation path recolors the border).
    {
      selector: 'node.selected',
      style: {
        'border-width': 3,
        'border-color': SELECTION_COLOR,
        'underlay-color': SELECTION_COLOR,
        'underlay-padding': 7,
        'underlay-opacity': 0.28,
        'underlay-shape': 'round-rectangle',
      },
    },
    { selector: 'edge.selected', style: { width: 3, 'line-color': SELECTION_COLOR, 'target-arrow-color': SELECTION_COLOR, opacity: 1 } },
    // Derivation paths ("bound derivations" focus): thick borders and edges, orange for lower and blue for upper bounds.
    { selector: 'node.path-lb', style: { 'border-width': 5, 'border-color': PATH_COLOR.lb } },
    { selector: 'node.path-ub', style: { 'border-width': 5, 'border-color': PATH_COLOR.ub } },
    { selector: 'node.path-lb.path-ub', style: { 'border-color': PATH_COLOR.both } },
    // (Arrows grow with the width: a smaller scale keeps them fitting between adjacent nodes.)
    { selector: 'edge.path-lb', style: { width: 4, 'arrow-scale': 0.5, 'line-color': PATH_COLOR.lb, 'target-arrow-color': PATH_COLOR.lb, opacity: 1, 'z-index': 10 } },
    { selector: 'edge.path-ub', style: { width: 4, 'arrow-scale': 0.5, 'line-color': PATH_COLOR.ub, 'target-arrow-color': PATH_COLOR.ub, opacity: 1, 'z-index': 10 } },
    { selector: 'edge.path-lb.path-ub', style: { 'line-color': PATH_COLOR.both, 'target-arrow-color': PATH_COLOR.both } },
    { selector: '.faded', style: { opacity: 0.12 } },
    { selector: 'node.match', style: { 'border-width': 3, 'border-color': '#d81b60' } },
    // Pointed at, in the graph or by its name or #ID in a panel: an outline (a glow for a reduction) in the text color,
    // never dimmed (nor the ends of a reduction).
    { selector: 'node.hover', style: { 'outline-width': 5, 'outline-color': text, 'outline-offset': 3, 'outline-opacity': 0.85, opacity: 1 } },
    { selector: 'node.hover-end', style: { opacity: 1 } },
    { selector: 'edge.hover', style: { 'underlay-color': text, 'underlay-padding': 6, 'underlay-opacity': 0.35, opacity: 1, 'z-index': 20 } },
  ];
}

/** Width of text in the labels' font (canvas measurement, with a rough fallback). */
class TextMeter {
  private readonly ctx: CanvasRenderingContext2D | null;

  constructor(
    private readonly fontSize: number,
    weight = 'normal',
  ) {
    this.ctx = document.createElement('canvas').getContext('2d');
    if (this.ctx) this.ctx.font = `${weight} ${fontSize}px ${FONT_FAMILY}`;
  }

  width(text: string): number {
    return this.ctx ? this.ctx.measureText(text).width : 0.6 * this.fontSize * text.length;
  }

  /** Lines of `text` wrapped at spaces to at most `max` wide (a longer word gets its own line), as Cytoscape does. */
  wrap(text: string, max: number): string[] {
    const lines: string[] = [];
    let line = '';
    for (const word of text.split(/ +/)) {
      const candidate = line === '' ? word : `${line} ${word}`;
      if (line !== '' && this.width(candidate) > max) {
        lines.push(line);
        line = word;
      } else line = candidate;
    }
    lines.push(line);
    return lines;
  }
}

/** Graph view. The model decides the elements; analyses only change labels and classes. */
export class GraphView {
  private readonly cy: Core;
  private readonly meter: TextMeter;
  private readonly titleMeter: TextMeter;
  private model: Model | null = null;
  private prefsKey = '';
  /** The layout's input (node boxes and links, rebuilt with the model) and its fingerprint. */
  private boxes: readonly (BoxNode & { readonly tw: number })[] = [];
  private links: readonly Link[] = [];
  private titleWidths: ReadonlyMap<string, number> = new Map();
  private layoutKey = '';
  /** Node positions (by problem id) and units of the current layout. */
  private positions = new Map<string, Point>();
  private units: ReadonlyMap<string, UnitBox> | undefined;
  private layoutSeed = 1;
  /** True while the view shows the whole graph as "Fit" left it (then resizing the panel fits again). */
  private fitted = false;
  /** Set while the view is changed by the program, so that only user zooming and panning clear `fitted`. */
  private programmatic = false;
  /** The item highlighted because it is pointed at (itemKey; '' for none). */
  private hoverKey = '';
  /** Shown at the edge of the graph, toward a highlighted element that is out of view (null without a parent). */
  private readonly pointer: HTMLElement | null;

  constructor(
    container: HTMLElement,
    private readonly callbacks: GraphCallbacks,
  ) {
    this.cy = cytoscape({ container, style: stylesheet(pageColors()), minZoom: 0.05, maxZoom: 4, boxSelectionEnabled: false });
    this.meter = new TextMeter(FONT_SIZE);
    this.titleMeter = new TextMeter(FAMILY_FONT_SIZE, 'bold');
    const additive = (ev: EventObject): boolean => isAdditive(ev.originalEvent as MouseEvent | undefined);
    this.cy.on('tap', 'node.problem', (ev) => this.callbacks.onSelectProblem((ev.target as NodeSingular).data('problem') as string, additive(ev)));
    this.cy.on('tap', 'edge', (ev) => this.callbacks.onSelectRow(ev.target.data('row') as string, additive(ev)));
    this.cy.on('tap', (ev) => {
      if (ev.target === this.cy && !additive(ev)) this.callbacks.onClear();
    });
    this.cy.on('dbltap', 'node.problem, edge', () => this.callbacks.onOpen());
    this.cy.on('mouseover', 'node.problem', (ev) => this.hover({ kind: 'problem', id: ev.target.data('problem') as string }));
    this.cy.on('mouseover', 'edge', (ev) => this.hover({ kind: 'row', id: ev.target.data('row') as string }));
    this.cy.on('mouseout', 'node.problem, edge', () => this.hover(null));
    this.pointer = container.parentElement ? GraphView.makePointer(container.parentElement) : null;
    this.cy.on('viewport', () => {
      if (!this.programmatic) this.fitted = false;
    });
  }

  private static makePointer(parent: HTMLElement): HTMLElement {
    const pointer = document.createElement('div');
    pointer.className = 'graph-pointer';
    pointer.hidden = true;
    pointer.setAttribute('aria-hidden', 'true');
    const arrow = document.createElement('span');
    arrow.className = 'arrow';
    arrow.textContent = '➤';
    const name = document.createElement('span');
    name.className = 'name';
    pointer.append(arrow, name);
    parent.append(pointer);
    return pointer;
  }

  /** Take up the page's colors again (after switching between light and dark mode). */
  refreshColors(): void {
    this.cy.style(stylesheet(pageColors()));
  }

  /**
   * Highlight a problem or reduction while it is pointed at (in the graph, or by its name or #ID in a panel); null:
   * nothing. An element out of view gets a pointer at the edge of the graph instead of moving the view.
   */
  hover(item: SelectionItem | null): void {
    const key = item ? itemKey(item) : '';
    if (key === this.hoverKey) return;
    this.hoverKey = key;
    const el = item ? this.elementOf(item) : this.cy.collection();
    this.cy.batch(() => {
      this.cy.elements('.hover, .hover-end').removeClass('hover hover-end');
      el.addClass('hover');
      if (item?.kind === 'row') el.connectedNodes().addClass('hover-end');
    });
    this.cy.container()?.style.setProperty('cursor', el.empty() ? '' : 'pointer');
    this.showPointer(item, el);
  }

  private showPointer(item: SelectionItem | null, el: CollectionReturnValue): void {
    const p = this.pointer;
    if (p === null) return;
    p.hidden = true;
    if (item === null || el.empty()) return;
    const problem = item.kind === 'problem' ? this.model?.problems.get(item.id) : undefined;
    p.querySelector('.name')!.textContent = problem ? problemLabel(problem) : item.kind === 'problem' ? item.id : `#${item.id}`;
    p.hidden = false; // (to measure it)
    const at = offscreenPointer(el.renderedBoundingBox(), this.cy.width(), this.cy.height(), p.offsetWidth / 2 + 6, p.offsetHeight / 2 + 6);
    if (at === null) {
      p.hidden = true;
      return;
    }
    p.style.left = `${at.x}px`;
    p.style.top = `${at.y}px`;
    p.classList.toggle('toward-right', Math.cos(at.angle) > 0);
    (p.querySelector('.arrow') as HTMLElement).style.transform = `rotate(${at.angle}rad)`;
  }

  /** Run `fn`, which changes the view, without it counting as the user's zooming or panning. */
  private moveView(fn: () => void): void {
    this.programmatic = true;
    try {
      fn();
    } finally {
      this.programmatic = false;
    }
  }

  /** Rebuild the elements if the model or the grouping preferences changed, then update labels and classes. */
  render(model: Model, analysis: Analysis, prefs: UiPrefs, selection: Selection): void {
    const key = `${prefs.groupFamilies}|${prefs.showUnusedRows}`;
    if (model !== this.model || key !== this.prefsKey) {
      this.rebuild(model, prefs);
      this.model = model;
      this.prefsKey = key;
    }
    this.update(analysis);
    this.highlight(selection, prefs, analysis);
  }

  /** Size of a problem's node: its wrapped name plus, for static problems, a line for the bounds. */
  private nodeBox(name: string, isStatic: boolean): { w: number; h: number; tw: number } {
    const lines = this.meter.wrap(name, WRAP_WIDTH);
    const textW = Math.max(...lines.map((l) => this.meter.width(l)), isStatic ? this.meter.width(BOUNDS_RESERVE) : 0);
    const rows = lines.length + (isStatic ? 1 : 0);
    const tw = Math.ceil(textW) + 2;
    return { w: tw + 2 * PAD_X, h: Math.ceil(rows * FONT_SIZE * LINE_HEIGHT) + 2 * PAD_Y, tw };
  }

  private rebuild(model: Model, prefs: UiPrefs): void {
    // Keep positions the user may have dragged nodes to.
    this.cy.nodes('.problem').forEach((n) => {
      this.positions.set(n.data('problem') as string, { ...n.position() });
    });
    const families = new Map<string, number>();
    for (const p of model.problems.values()) families.set(p.family, (families.get(p.family) ?? 0) + 1);
    // Families of one problem get no box.
    this.boxes = [...model.problems.values()].map((p) => ({
      id: p.id,
      group: (families.get(p.family) ?? 0) >= 2 ? p.family : null,
      ...this.nodeBox(problemLabel(p), p.isStatic),
    }));
    this.links = model.rows.map((r) => ({ source: r.source, target: r.target }));
    this.titleWidths = new Map([...families.keys()].map((f) => [f, Math.ceil(this.titleMeter.width(plainText(f))) + 8]));
    // The layout depends on the problems, their families and sizes, and the rows (not on what is displayed), so
    // editing a formula keeps every position, and adding a problem moves things only a little.
    const key = JSON.stringify([this.boxes.map((b) => [b.id, b.group, b.w, b.h]), this.links.map((l) => [l.source, l.target])]);
    if (key !== this.layoutKey) {
      this.computeLayout(this.units);
      this.layoutKey = key;
    }
    const boxes = new Map(this.boxes.map((b) => [b.id, b]));
    const els: ElementDefinition[] = [];
    if (prefs.groupFamilies) {
      for (const [family, count] of families) {
        if (count >= 2) els.push({ group: 'nodes', data: { id: familyId(family), label: plainText(family) }, classes: 'family' });
      }
    }
    for (const p of model.problems.values()) {
      const b = boxes.get(p.id)!;
      const parent = prefs.groupFamilies && b.group !== null ? familyId(b.group) : undefined;
      els.push({
        group: 'nodes',
        data: { id: nodeId(p.id), problem: p.id, label: problemLabel(p), w: b.w, h: b.h, tw: b.tw, ...(parent ? { parent } : {}) },
        classes: `problem${p.isStatic ? '' : ' dynamic'}`,
        position: { ...(this.positions.get(p.id) ?? { x: 0, y: 0 }) },
      });
    }
    for (const r of model.rows) {
      if (!prefs.showUnusedRows && r.status !== 'ok') continue;
      els.push({
        group: 'edges',
        data: { id: edgeId(r.id), source: nodeId(r.source), target: nodeId(r.target), row: r.id },
        classes: r.status === 'ok' ? '' : 'unused',
      });
    }
    const first = this.cy.elements().empty();
    this.cy.elements().remove();
    this.cy.add(els);
    this.hover(null);
    if (first) this.fit();
  }

  /** Compute positions with the compact layout (around the `previous` units when given). */
  private computeLayout(previous: ReadonlyMap<string, UnitBox> | undefined): void {
    // Shape the drawing like the panel (when it has a size), so that "fit" uses the space well.
    const w = this.cy.width();
    const h = this.cy.height();
    const layout = compactLayout(this.boxes, this.links, {
      gap: GAP,
      groupPadding: GROUP_PADDING,
      groupTitle: GROUP_TITLE,
      groupTitleWidth: this.titleWidths,
      aspect: 1.6,
      seed: this.layoutSeed,
      ...(w > 50 && h > 50 ? { targetAspect: Math.min(3, Math.max(0.5, w / h)) } : {}),
      ...(previous ? { previous } : {}),
    });
    this.positions = new Map(layout.positions);
    this.units = layout.units;
  }

  /** Lay the graph out again from scratch, with a new arrangement of the families. */
  relayout(): void {
    this.layoutSeed += 1;
    this.computeLayout(undefined);
    this.cy.batch(() => {
      this.cy.nodes('.problem').forEach((n) => {
        n.position({ ...(this.positions.get(n.data('problem') as string) ?? { x: 0, y: 0 }) });
      });
    });
    this.fit();
  }

  private update(analysis: Analysis): void {
    this.cy.batch(() => {
      for (const s of analysis.summaries.values()) {
        const n = this.cy.getElementById(nodeId(s.problem.id));
        if (n.empty()) continue;
        // Non-breaking spaces: the bounds line overflows a little rather than wrapping onto a line of its own.
        const line = boundsLine(s.primary).replace(/ /g, '\u00a0');
        const label = line ? `${problemLabel(s.problem)}\n${line}` : problemLabel(s.problem);
        if (n.data('label') !== label) n.data({ label });
        n.removeClass('status-conflict status-tight status-gap status-lb status-ub status-none');
        if (s.problem.isStatic) n.addClass(`status-${s.status}`);
      }
      this.cy.edges().forEach((e) => {
        const use = analysis.rowUse.get(e.data('row') as string);
        e.toggleClass('lb-used', (use?.lb ?? 0) > 0);
        e.toggleClass('ub-used', (use?.ub ?? 0) > 0);
      });
    });
  }

  /** The graph element of a selected item (empty if it is not drawn). */
  private elementOf(item: SelectionItem): CollectionReturnValue {
    return this.cy.getElementById(item.kind === 'problem' ? nodeId(item.id) : edgeId(item.id));
  }

  /** The reductions as drawn (hidden unused ones excluded), for the focus modes. */
  private drawnLinks(): FocusLink[] {
    return this.cy.edges().map((e) => ({ id: e.data('row') as string, source: e.source().data('problem') as string, target: e.target().data('problem') as string }));
  }

  /**
   * Mark the search matches and the selection, and dim what the focus mode leaves out; in the "derivations" mode,
   * draw the derivation paths of the selected problems' best bounds.
   */
  private highlight(selection: Selection, prefs: UiPrefs, analysis: Analysis): void {
    this.cy.batch(() => {
      this.cy.elements().removeClass('selected faded match path-lb path-ub');
      const q = prefs.search.trim().toLowerCase();
      if (q !== '') {
        this.cy.nodes('.problem').forEach((n) => {
          if ((n.data('problem') as string).toLowerCase().includes(q) || (n.data('label') as string).toLowerCase().includes(q)) n.addClass('match');
        });
      }
      const items = selection.filter((x) => !this.elementOf(x).empty());
      const mode = prefs.focus;
      for (const item of items) {
        const el = this.elementOf(item).addClass('selected');
        // The reductions of a selected problem stand out, except where the derivation paths are what matters.
        if (item.kind === 'problem' && mode !== 'derivations') el.connectedEdges().addClass('selected');
      }
      if (mode === 'off' || items.length === 0) return;
      let kept: Kept;
      if (mode === 'derivations') {
        const d = selectionDerivations(items, analysis);
        const mark = (path: Kept, cls: string): void => {
          path.problems.forEach((p) => this.cy.getElementById(nodeId(p)).addClass(cls));
          path.rows.forEach((r) => this.cy.getElementById(edgeId(r)).addClass(cls));
        };
        mark(d.lb, 'path-lb');
        mark(d.ub, 'path-ub');
        const own = (kind: SelectionItem['kind']): string[] => items.filter((x) => x.kind === kind).map((x) => x.id);
        kept = {
          problems: new Set([...d.lb.problems, ...d.ub.problems, ...own('problem')]),
          rows: new Set([...d.lb.rows, ...d.ub.rows, ...own('row')]),
        };
      } else kept = keptAround(mode, items, this.drawnLinks());
      let keep = this.cy.collection();
      kept.problems.forEach((p) => (keep = keep.union(this.cy.getElementById(nodeId(p)))));
      kept.rows.forEach((r) => {
        const e = this.cy.getElementById(edgeId(r));
        keep = keep.union(e).union(e.connectedNodes());
      });
      this.cy.elements().not(keep.union(keep.parents())).addClass('faded');
    });
  }

  /** Center the view on a problem or row. */
  reveal(selection: SelectionItem): void {
    const el = this.elementOf(selection);
    if (el.empty()) return;
    this.fitted = false;
    this.cy.animate({ center: { eles: el }, zoom: Math.max(this.cy.zoom(), 0.9) }, { duration: 250 });
  }

  /** First problem matching the search text, if any. */
  firstMatch(): string | null {
    const n = this.cy.nodes('.match').first();
    return n.empty() ? null : (n.data('problem') as string);
  }

  fit(): void {
    this.moveView(() => this.cy.fit(undefined, 16));
    this.fitted = true;
  }

  /** Zoom by `factor` (or to `level` when given) around the center of the view. */
  zoom(factor: number, level?: number): void {
    const z = level ?? this.cy.zoom() * factor;
    this.moveView(() =>
      this.cy.zoom({ level: Math.min(this.cy.maxZoom(), Math.max(this.cy.minZoom(), z)), renderedPosition: { x: this.cy.width() / 2, y: this.cy.height() / 2 } }),
    );
    this.fitted = false;
  }

  /**
   * Adapt to a new container size: a fitted view is fitted again, otherwise the point at the center of the view stays
   * there (at the same zoom).
   */
  resize(): void {
    const zoom = this.cy.zoom();
    const pan = this.cy.pan();
    // Cytoscape still reports the old size until resize().
    const center = { x: (this.cy.width() / 2 - pan.x) / zoom, y: (this.cy.height() / 2 - pan.y) / zoom };
    this.cy.resize();
    if (this.fitted) this.fit();
    else this.moveView(() => this.cy.pan({ x: this.cy.width() / 2 - center.x * zoom, y: this.cy.height() / 2 - center.y * zoom }));
  }

  /** On-screen size of the problem labels' font at the current zoom, in CSS pixels (used by tests). */
  get labelPixels(): number {
    return FONT_SIZE * this.cy.zoom();
  }

  /** Number of problem nodes (used by tests). */
  get problemCount(): number {
    return this.cy.nodes('.problem').length;
  }

  /** Current label of a problem node (used by tests). */
  labelOf(problemId: string): string | null {
    const n = this.cy.getElementById(nodeId(problemId));
    return n.empty() ? null : (n.data('label') as string);
  }

  /** Highlighting classes of a problem's node or a row's edge (used by tests), e.g. ["selected", "path-lb"]. */
  marksOf(item: SelectionItem): string[] | null {
    const el = this.elementOf(item);
    return el.empty() ? null : ['selected', 'faded', 'match', 'path-lb', 'path-ub', 'hover', 'hover-end'].filter((c) => el.hasClass(c));
  }

  /** The pointer's text while it is shown (used by tests), else null. */
  get pointerText(): string | null {
    return this.pointer && !this.pointer.hidden ? (this.pointer.textContent ?? '') : null;
  }

  /** Number of problems not dimmed (used by tests). */
  get undimmedProblems(): number {
    return this.cy.nodes('.problem').not('.faded').length;
  }
}
