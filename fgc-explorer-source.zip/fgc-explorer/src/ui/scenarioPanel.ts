/**
 * Left panel: knobs (hypotheses and algorithms), constants and settings.
 *
 * The panel is rebuilt only when the scenario's structure changes (knobs added/removed, model reloaded), so that
 * typing and dragging sliders never lose focus; value edits (including switching a knob on or off) update the
 * affected elements in place.
 */

import { Knob, KnobKind, Settings, validateKnobSpec } from '../model/config';
import { findProblem, Problem } from '../model/model';
import { identifierTex } from '../math/ast';
import { parseExpr } from '../math/parser';
import { h, setChildren } from './dom';
import { knobValueHtml, problemLabel } from './format';
import { AppState, newKnobId } from './state';
import { Change, Store } from './store';
import { plainText, texHtml } from './tex';

/** " · Family" after a problem's label, or nothing when the label already is the family. */
function familySuffix(p: Problem): HTMLElement | null {
  const family = plainText(p.family);
  return problemLabel(p) === family ? null : h('span', { class: 'knob-family' }, ` · ${family}`);
}

export interface ScenarioPanelCallbacks {
  selectProblem(id: string): void;
  /** Show the note listing the initial knobs (it lives in the inspector). */
  showInitialSettings(): void;
  /** Read hypotheses and algorithms from a bounds CSV chosen by the user. */
  importBounds(): void;
  /** Save the current hypotheses and algorithms as a bounds CSV. */
  exportBounds(): void;
}

const SECTION_TITLE: Readonly<Record<KnobKind, string>> = { LB: 'Hypotheses (lower bounds)', UB: 'Algorithms (upper bounds)' };

/** Sections whose number of switched-on knobs is at most this start open. */
const OPEN_SECTION_MAX_ON = 8;

export class ScenarioPanel {
  private readonly issueEls = new Map<string, HTMLElement>();
  /** Per knob: its card (class "disabled" when off) and the one-line summary shown while it is off. */
  private readonly cardEls = new Map<string, { readonly card: HTMLElement; readonly summary: HTMLElement }>();
  private readonly sectionSummaryEls = new Map<KnobKind, HTMLElement>();
  /** Open/closed state of the knob sections, kept across re-renders. */
  private readonly sectionOpen: Record<KnobKind, boolean | null> = { LB: null, UB: null };
  /** The scenario after this panel's own last edit: any other scenario came from outside (e.g. an import). */
  private ownScenario: unknown = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly store: Store,
    private readonly cb: ScenarioPanelCallbacks,
  ) {
    this.render();
    store.subscribe((changes) => this.onChange(changes));
  }

  private onChange(changes: ReadonlySet<Change>): void {
    const external = changes.has('scenario') && this.store.get().scenario !== this.ownScenario;
    if (changes.has('scenario-structure') || changes.has('model') || external) this.render();
    else if (changes.has('analysis') || changes.has('scenario')) this.refreshDynamicBits();
  }

  /** Apply an edit made in this panel (the panel keeps its inputs instead of re-rendering). */
  private edit(fn: (s: AppState) => AppState, debounce = false): void {
    this.store.update((s) => {
      const next = fn(s);
      this.ownScenario = next.scenario;
      return next;
    }, debounce);
  }

  /** Update issue messages, on/off states and section counts without rebuilding inputs. */
  private refreshDynamicBits(): void {
    const { analysis } = this.store.getDerived();
    const knobs = this.store.get().scenario.knobs;
    for (const [id, el] of this.issueEls) {
      const msg = analysis.knobIssues.get(id);
      el.textContent = msg ?? '';
      el.hidden = msg === undefined;
    }
    for (const k of knobs) {
      const els = this.cardEls.get(k.id);
      if (!els) continue;
      els.card.classList.toggle('disabled', !k.enabled);
      els.summary.innerHTML = knobValueHtml(k);
    }
    for (const [kind, el] of this.sectionSummaryEls) {
      const ofKind = knobs.filter((k) => k.kind === kind);
      el.textContent = `${SECTION_TITLE[kind]} · ${ofKind.filter((k) => k.enabled).length}/${ofKind.length} on`;
    }
  }

  private setKnob(id: string, patch: Partial<Knob>, debounce = false): void {
    this.edit(
      (s) => ({ ...s, scenario: { ...s.scenario, knobs: s.scenario.knobs.map((k) => (k.id === id ? ({ ...k, ...patch } as Knob) : k)) } }),
      debounce,
    );
  }

  private removeKnob(id: string): void {
    this.edit((s) => ({ ...s, scenario: { ...s.scenario, knobs: s.scenario.knobs.filter((k) => k.id !== id) } }));
  }

  private setSettings(patch: Partial<Settings>): void {
    this.edit((s) => ({ ...s, scenario: { ...s.scenario, settings: { ...s.scenario.settings, ...patch } } }));
  }

  render(): void {
    const s = this.store.get();
    this.ownScenario = s.scenario;
    this.issueEls.clear();
    this.cardEls.clear();
    this.sectionSummaryEls.clear();
    const initialLink = (text: string): HTMLElement =>
      h('button', { class: 'link', title: 'list the knobs this panel starts with', on: { click: () => this.cb.showInitialSettings() } }, text);
    setChildren(
      this.root,
      h('h2', {}, 'Hypotheses & algorithms'),
      h(
        'p',
        { class: 'hint' },
        'Lower bounds (LB) propagate forward along reductions, upper bounds (UB) backward. Exponents are with respect to the regime’s main parameter. Unchecked knobs are ignored. ',
        initialLink('Initial settings'),
      ),
      h(
        'div',
        { class: 'panel-actions' },
        h(
          'span',
          { class: 'seg', role: 'group', 'aria-label': 'bounds CSV' },
          h('span', { class: 'seg-label', title: 'the hypotheses and algorithms as a CSV sheet (one row per bound)' }, 'Bounds CSV'),
          h(
            'button',
            {
              'aria-label': 'Import bounds CSV',
              title: 'read hypotheses and algorithms from a CSV file (Problem, Variation, Bound ID, Upper or Lower, Runtime, …), replacing the current ones or adding to them',
              on: { click: () => this.cb.importBounds() },
            },
            'Import…',
          ),
          h('button', { 'aria-label': 'Export bounds CSV', title: 'save the hypotheses and algorithms below as a CSV file', on: { click: () => this.cb.exportBounds() } }, 'Export'),
        ),
      ),
      s.scenario.knobs.length === 0 ? h('p', { class: 'hint' }, 'No knobs: add one below, or restore the ', initialLink('initial settings'), '.') : null,
      this.knobSection('LB'),
      this.knobSection('UB'),
      this.addForm(),
      this.constants(),
      this.settings(),
    );
    this.refreshDynamicBits();
  }

  private knobSection(kind: KnobKind): HTMLElement | null {
    const knobs = this.store.get().scenario.knobs.filter((k) => k.kind === kind);
    if (knobs.length === 0) return null;
    const open = this.sectionOpen[kind] ?? knobs.filter((k) => k.enabled).length <= OPEN_SECTION_MAX_ON;
    const summary = h('summary', {}, SECTION_TITLE[kind]);
    this.sectionSummaryEls.set(kind, summary);
    const details = h('details', { class: 'knob-section', open }, summary, h('div', { class: 'knobs' }, knobs.map((k) => this.knobCard(k))));
    details.addEventListener('toggle', () => {
      this.sectionOpen[kind] = details.open;
    });
    return details;
  }

  /** A knob's card; while the knob is off, its inputs are hidden and a one-line summary is shown instead (CSS). */
  private knobCard(k: Knob): HTMLElement {
    const { model } = this.store.getDerived();
    const problem = findProblem(model, k.problem);
    const issue = h('div', { class: 'issue', hidden: true });
    this.issueEls.set(k.id, issue);
    const summary = h('div', { class: 'knob-summary' });
    const valueRow =
      k.exponent !== undefined ? this.exponentInput(k) : this.formulaInput(k);
    const card = h(
      'div',
      { class: `knob ${k.enabled ? '' : 'disabled'}` },
      h(
        'div',
        { class: 'knob-head' },
        h('input', {
          type: 'checkbox',
          checked: k.enabled,
          title: 'switch this knob on or off',
          on: { change: (e) => this.setKnob(k.id, { enabled: (e.target as HTMLInputElement).checked }) },
        }),
        h('span', { class: `kind kind-${k.kind}`, title: k.kind === 'LB' ? 'lower bound (hypothesis)' : 'upper bound (algorithm)' }, k.kind),
        h('span', { class: 'knob-id', title: `Bound ID ${k.id} (the bounds CSV matches rows to knobs by it)` }, `#${k.id}`),
        h(
          'a',
          {
            class: 'knob-problem',
            href: '#',
            title: problem ? problem.id : `unknown problem: ${k.problem}`,
            on: {
              click: (e) => {
                e.preventDefault();
                if (problem) this.cb.selectProblem(problem.id);
              },
            },
          },
          // The variation first (it tells e.g. directed from undirected APSP), then the family if it adds anything.
          problem ? [problemLabel(problem), familySuffix(problem)] : k.problem,
        ),
        h('button', { class: 'icon', title: 'remove', on: { click: () => this.removeKnob(k.id) } }, '×'),
      ),
      summary,
      h(
        'label',
        { class: 'field' },
        h('span', {}, 'regime'),
        h('input', {
          type: 'text',
          class: 'mono',
          value: k.regime ?? '',
          placeholder: k.kind === 'UB' ? 'all regimes' : 'n=1, m=2, M=poly',
          title: 'param=growth, … with growth: number (exponent), log, polylog, const[:v|[v1,v2]], poly (log-dependent)',
          on: { change: (e) => this.setKnob(k.id, { regime: (e.target as HTMLInputElement).value.trim() || undefined }) },
        }),
      ),
      valueRow,
      k.note ? h('div', { class: 'note' }, k.note) : null,
      issue,
    );
    this.cardEls.set(k.id, { card, summary });
    return card;
  }

  private exponentInput(k: Knob): HTMLElement {
    const x = k.exponent ?? 0;
    const max = Math.max(4, Math.ceil(x * 2));
    const num = h('input', { type: 'number', class: 'num', step: 'any', min: '0', value: String(x), title: 'exponent (any number of decimals)' });
    const slider = h('input', { type: 'range', min: '0', max: String(max), step: '0.01', value: String(x) });
    slider.addEventListener('input', () => {
      num.value = slider.value;
      this.setKnob(k.id, { exponent: Number(slider.value) }, true);
    });
    num.addEventListener('change', () => {
      const v = Number(num.value);
      if (!Number.isFinite(v) || v < 0) return;
      slider.max = String(Math.max(Number(slider.max), Math.ceil(v)));
      slider.value = String(v);
      this.setKnob(k.id, { exponent: v });
    });
    return h(
      'div',
      { class: 'field' },
      h('span', {}, 'exponent'),
      slider,
      num,
      h('button', { class: 'link', title: 'switch to a runtime formula', on: { click: () => this.setKnob(k.id, { exponent: undefined, formula: `n^{${x}}` }) } }, 'ƒ'),
    );
  }

  private formulaInput(k: Knob): HTMLElement {
    // The rendered preview is shown while editing and when the formula does not parse.
    const preview = h('span', { class: 'preview' });
    let focused = false;
    const showPreview = (tex: string): void => {
      try {
        parseExpr(tex);
        preview.innerHTML = texHtml(tex);
        preview.classList.remove('bad');
        preview.hidden = !focused;
      } catch (e) {
        preview.textContent = (e as Error).message;
        preview.classList.add('bad');
        preview.hidden = false;
      }
    };
    showPreview(k.formula ?? '');
    const input = h('input', {
      type: 'text',
      class: 'mono',
      value: k.formula ?? '',
      title: 'running time in the problem’s parameters, e.g. n^2 d, \\min(n^{\\omega}, m^{2\\omega/(\\omega+1)})',
    });
    input.addEventListener('input', () => showPreview(input.value));
    input.addEventListener('focus', () => ((focused = true), showPreview(input.value)));
    input.addEventListener('blur', () => ((focused = false), showPreview(input.value)));
    input.addEventListener('change', () => this.setKnob(k.id, { formula: input.value }));
    return h(
      'div',
      { class: 'field formula' },
      h('span', {}, 'time'),
      input,
      h('button', { class: 'link', title: 'switch to a plain exponent', on: { click: () => this.setKnob(k.id, { formula: undefined, exponent: 2 }) } }, 'x'),
      preview,
    );
  }

  private addForm(): HTMLElement {
    const { model } = this.store.getDerived();
    const listId = 'problem-list';
    const datalist = h(
      'datalist',
      { id: listId },
      [...model.problems.values()].filter((p) => p.isStatic).map((p) => h('option', { value: p.id })),
    );
    const problem = h('input', { type: 'text', list: listId, placeholder: 'problem (Family / Variation)' });
    const kind = h('select', {}, h('option', { value: 'LB' }, 'LB (hypothesis)'), h('option', { value: 'UB' }, 'UB (algorithm)'));
    const regime = h('input', { type: 'text', class: 'mono', placeholder: 'regime (empty: the problem’s main regime; all regimes for UB formulas)' });
    const value = h('input', { type: 'text', class: 'mono', placeholder: 'exponent (e.g. 2) or formula (e.g. n^2 d)' });
    const msg = h('div', { class: 'issue', hidden: true });
    problem.addEventListener('change', () => {
      const p = findProblem(this.store.getDerived().model, problem.value);
      if (p) regime.placeholder = `${p.regimeSpecs[0] ?? ''} (empty: this; all regimes for UB formulas)`;
    });
    const add = (): void => {
      const p = findProblem(this.store.getDerived().model, problem.value);
      const fail = (m: string): void => {
        msg.textContent = m;
        msg.hidden = false;
      };
      if (!p) return fail('unknown problem');
      const v = value.value.trim();
      const isNumber = /^[+-]?(\d+(\.\d*)?|\.\d+)$/.test(v);
      if (isNumber && Number(v) < 0) return fail('exponents must be nonnegative');
      // An empty regime means the problem's main regime, except for UB formulas, which then apply everywhere.
      const regimeText = regime.value.trim() || (kind.value === 'UB' && !isNumber ? '' : (p.regimeSpecs[0] ?? ''));
      const errors: string[] = [];
      const spec = validateKnobSpec(
        {
          problem: p.id,
          kind: kind.value as KnobKind,
          ...(regimeText ? { regime: regimeText } : {}),
          ...(isNumber ? { exponent: Number(v) } : { formula: v }),
        },
        'knob',
        errors,
      );
      if (!spec) return fail(errors.join('; '));
      if (!isNumber) {
        try {
          parseExpr(v);
        } catch (e) {
          return fail(`formula: ${(e as Error).message}`);
        }
      }
      msg.hidden = true;
      this.edit((s) => ({ ...s, scenario: { ...s.scenario, knobs: [...s.scenario.knobs, { ...spec, id: newKnobId(s.scenario.knobs), enabled: true }] } }));
    };
    return h(
      'details',
      { class: 'add-knob', id: 'add-knob' },
      h('summary', {}, '＋ Add a hypothesis or algorithm'),
      datalist,
      h('label', { class: 'field' }, h('span', {}, 'problem'), problem),
      h('label', { class: 'field' }, h('span', {}, 'kind'), kind),
      h('label', { class: 'field' }, h('span', {}, 'regime'), regime),
      h('label', { class: 'field' }, h('span', {}, 'value'), value),
      h('button', { class: 'primary', on: { click: add } }, 'Add'),
      msg,
    );
  }

  /** Prefill the add form (used by the inspector's "add knob here" buttons). */
  prefill(problemId: string, kind: KnobKind, regimeSpec: string): void {
    const form = this.root.querySelector<HTMLDetailsElement>('#add-knob');
    if (!form) return;
    form.open = true;
    const inputs = form.querySelectorAll('input');
    const select = form.querySelector('select');
    if (inputs[0]) inputs[0].value = problemId;
    if (select) select.value = kind;
    if (inputs[1]) inputs[1].value = regimeSpec;
    inputs[2]?.focus();
    form.scrollIntoView({ block: 'nearest' });
  }

  private constants(): HTMLElement {
    const s = this.store.get();
    const entries = Object.entries(s.config.constants);
    if (entries.length === 0) return h('div');
    return h(
      'div',
      { class: 'constants' },
      h('h3', {}, 'Constants'),
      entries.map(([name, def]) => {
        const value = s.scenario.constants[name] ?? def.value;
        const num = h('input', { type: 'number', class: 'num', step: 'any', value: String(value) });
        const slider = h('input', { type: 'range', min: String(def.min), max: String(def.max), step: '0.001', value: String(value) });
        const set = (v: number, debounce: boolean): void =>
          this.edit((st) => ({ ...st, scenario: { ...st.scenario, constants: { ...st.scenario.constants, [name]: v } } }), debounce);
        slider.addEventListener('input', () => {
          num.value = slider.value;
          set(Number(slider.value), true);
        });
        num.addEventListener('change', () => {
          const v = Number(num.value);
          if (Number.isFinite(v)) {
            slider.value = String(v);
            set(v, false);
          }
        });
        return h('label', { class: 'field', title: def.label }, h('span', { html: texHtml(identifierTex(name)) }), slider, num);
      }),
    );
  }

  private settings(): HTMLElement {
    const st = this.store.get().scenario.settings;
    const intField = (label: string, key: 'maxHopsLB' | 'maxDepthUB' | 'gridPoints' | 'refineRounds', min: number, max: number, title: string): HTMLElement =>
      h(
        'label',
        { class: 'field', title },
        h('span', {}, label),
        h('input', {
          type: 'number',
          class: 'num',
          min: String(min),
          max: String(max),
          value: String(st[key]),
          on: {
            change: (e) => {
              const v = Math.round(Number((e.target as HTMLInputElement).value));
              if (v >= min && v <= max) this.setSettings({ [key]: v } as Partial<Settings>);
            },
          },
        }),
      );
    return h(
      'details',
      { class: 'settings' },
      h('summary', {}, 'Settings'),
      intField('LB hops', 'maxHopsLB', 0, 50, 'maximum number of reductions in a lower-bound derivation'),
      intField('UB depth', 'maxDepthUB', 0, 12, 'maximum number of reductions in an upper-bound derivation'),
      intField('grid points', 'gridPoints', 2, 41, 'grid points per continuous free parameter'),
      intField('refinement', 'refineRounds', 0, 40, 'rounds of local refinement after the grid search (each halves the step)'),
      h(
        'label',
        { class: 'field', title: 'rows whose Reduction Runtime has no formula' },
        h('span', {}, 'unknown RT'),
        h(
          'select',
          { on: { change: (e) => this.setSettings({ unknownRT: (e.target as HTMLSelectElement).value as Settings['unknownRT'] }) } },
          h('option', { value: 'assume-negligible', selected: st.unknownRT === 'assume-negligible' }, 'assume negligible'),
          h('option', { value: 'block', selected: st.unknownRT === 'block' }, 'block the row'),
        ),
      ),
      h(
        'label',
        { class: 'field check' },
        h('input', {
          type: 'checkbox',
          checked: st.useRandomized,
          on: { change: (e) => this.setSettings({ useRandomized: (e.target as HTMLInputElement).checked }) },
        }),
        h('span', {}, 'use randomized reductions'),
      ),
      st.disabledRows.length > 0
        ? h(
            'div',
            { class: 'field' },
            h('span', {}, `disabled rows: ${st.disabledRows.join(', ')}`),
            h('button', { class: 'link', on: { click: () => this.setSettings({ disabledRows: [] }) } }, 'enable all'),
          )
        : null,
    );
  }
}
