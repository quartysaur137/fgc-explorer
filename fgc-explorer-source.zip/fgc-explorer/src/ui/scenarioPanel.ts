/**
 * Left panel: one box per problem with its lower bounds (hypotheses) and algorithms (upper bounds), then constants
 * and settings (SPEC §7).
 *
 * The panel is rebuilt only when the scenario's structure changes (knobs or boxes added/removed, model reloaded), so
 * that typing and dragging sliders never lose focus; value edits (including switching a knob on or off) and new
 * analyses update the affected elements in place.
 */

import { STATUS_TEXT } from '../engine/analysis';
import { identifierTex } from '../math/ast';
import { parseExpr } from '../math/parser';
import { boxOrder, canonicalProblem, ProblemBox, problemBoxes } from '../model/boxes';
import { Knob, KnobKind, Settings, validateKnobSpec } from '../model/config';
import { findProblem, Model, Problem } from '../model/model';
import { h, setChildren } from './dom';
import { boundsLine, knobValueHtml, problemLabel } from './format';
import { refAttrs } from './hover';
import { isAdditive } from './selection';
import { AppState, newKnobId } from './state';
import { Change, Store } from './store';
import { plainText, texHtml } from './tex';

export interface ScenarioPanelCallbacks {
  /** A click on a problem's name; `additive` when Shift, Ctrl or ⌘ was held. */
  selectProblem(id: string, additive: boolean): void;
  /** Show the note listing the initial knobs (it lives in the inspector). */
  showInitialSettings(): void;
  /** Read hypotheses and algorithms from a bounds CSV chosen by the user. */
  importBounds(): void;
  /** Save the current hypotheses and algorithms as a bounds CSV. */
  exportBounds(): void;
}

/** The elements of a problem's box that change without a rebuild. */
interface BoxEls {
  readonly root: HTMLElement;
  readonly toggle: HTMLButtonElement;
  /** The problem's bounds at its primary regime, colored by status. */
  readonly bounds: HTMLElement;
  /** "2/3 on", shown while the box is collapsed. */
  readonly count: HTMLElement;
  /** Open the form for a new bound (kind and regime prefilled when given). */
  openForm(kind?: KnobKind, regime?: string): void;
}

const NUMBER = /^[+-]?(\d+(\.\d*)?|\.\d+)$/;

export class ScenarioPanel {
  private readonly issueEls = new Map<string, HTMLElement>();
  /** Per knob: its row (class "disabled" when off) and the one-line summary shown while it is off. */
  private readonly knobEls = new Map<string, { readonly row: HTMLElement; readonly summary: HTMLElement }>();
  /** Per box (problem id): its elements. */
  private readonly boxEls = new Map<string, BoxEls>();
  /** Collapsed boxes, kept across re-renders. */
  private readonly collapsed = new Set<string>();
  private totalsEl: HTMLElement | null = null;
  /** The scenario after this panel's own last edit: any other scenario came from outside (e.g. an import). */
  private ownScenario: unknown = null;

  constructor(
    private readonly root: HTMLElement,
    private readonly store: Store,
    private readonly cb: ScenarioPanelCallbacks,
  ) {
    this.render();
    store.subscribe((changes) => this.onChange(changes));
  }

  private onChange(changes: ReadonlySet<Change>): void {
    const external = changes.has('scenario') && this.store.get().scenario !== this.ownScenario;
    if (changes.has('scenario-structure') || changes.has('model') || external) this.render();
    else if (changes.has('analysis') || changes.has('scenario')) this.refreshDynamicBits();
    if (changes.has('selection')) this.refreshSelection();
  }

  /** Apply an edit made in this panel (the panel keeps its inputs instead of re-rendering). */
  private edit(fn: (s: AppState) => AppState, debounce = false): void {
    this.store.update((s) => {
      const next = fn(s);
      this.ownScenario = next.scenario;
      return next;
    }, debounce);
  }

  /** The box key of a problem name (see canonicalProblem). */
  private canonical(): (name: string) => string {
    return canonicalProblem(this.store.getDerived().model);
  }

  /** The current box order, complete (so that boxes stay when their knobs change). */
  private order(s: AppState): string[] {
    return boxOrder(s.scenario.problems, s.scenario.knobs, this.canonical());
  }

  /** Update issue messages, on/off states, bounds and counts without rebuilding inputs. */
  private refreshDynamicBits(): void {
    const { analysis } = this.store.getDerived();
    const s = this.store.get();
    for (const [id, el] of this.issueEls) {
      const msg = analysis.knobIssues.get(id);
      el.textContent = msg ?? '';
      el.hidden = msg === undefined;
    }
    for (const k of s.scenario.knobs) {
      const els = this.knobEls.get(k.id);
      if (!els) continue;
      els.row.classList.toggle('disabled', !k.enabled);
      els.summary.innerHTML = knobValueHtml(k);
    }
    const boxes = problemBoxes(s.scenario.problems, s.scenario.knobs, this.canonical());
    for (const b of boxes) {
      const els = this.boxEls.get(b.problem);
      if (!els) continue;
      const summary = analysis.summaries.get(b.problem);
      const status = summary && summary.problem.isStatic ? summary.status : null;
      els.bounds.textContent = !summary ? 'not in the sheet' : !summary.problem.isStatic ? 'not propagated' : boundsLine(summary.primary) || 'no bound';
      els.bounds.className = `box-bounds${status ? ` status-${status}` : ''}`;
      els.bounds.title = status
        ? `${STATUS_TEXT[status]}${summary?.primary ? ` (at the primary regime ${summary.primary.regime.key})` : ''}`
        : summary
          ? 'a dynamic / multi-function problem: shown, not propagated'
          : 'not a problem of the current sheet: its bounds are ignored';
      els.count.textContent = `${b.knobs.filter((k) => k.enabled).length}/${b.knobs.length} on`;
    }
    if (this.totalsEl) {
      const knobs = s.scenario.knobs;
      this.totalsEl.textContent = `${boxes.length} problem${boxes.length === 1 ? '' : 's'} · ${knobs.length} bound${knobs.length === 1 ? '' : 's'}, ${knobs.filter((k) => k.enabled).length} on`;
    }
  }

  /** Mark the boxes of the selected problems. */
  private refreshSelection(): void {
    const selected = new Set(this.store.get().selection.flatMap((x) => (x.kind === 'problem' ? [x.id] : [])));
    for (const [key, els] of this.boxEls) els.root.classList.toggle('selected', selected.has(key));
  }

  private setKnob(id: string, patch: Partial<Knob>, debounce = false): void {
    this.edit(
      (s) => ({ ...s, scenario: { ...s.scenario, knobs: s.scenario.knobs.map((k) => (k.id === id ? ({ ...k, ...patch } as Knob) : k)) } }),
      debounce,
    );
  }

  /** Remove a knob; its box stays (possibly empty). */
  private removeKnob(id: string): void {
    this.edit((s) => ({ ...s, scenario: { ...s.scenario, problems: this.order(s), knobs: s.scenario.knobs.filter((k) => k.id !== id) } }));
  }

  /** Remove a box and its knobs (after asking, if it has any). */
  private removeBox(key: string, name: string, knobCount: number): void {
    if (knobCount > 0 && !confirm(`Remove ${name} and its ${knobCount} bound${knobCount === 1 ? '' : 's'}?`)) return;
    const canonical = this.canonical();
    this.edit((s) => ({
      ...s,
      scenario: { ...s.scenario, problems: this.order(s).filter((p) => p !== key), knobs: s.scenario.knobs.filter((k) => canonical(k.problem) !== key) },
    }));
  }

  /** Add an (empty) box for a problem at the end, unless it has one; returns its elements. */
  private ensureBox(key: string): BoxEls | undefined {
    if (!this.boxEls.has(key)) this.edit((s) => ({ ...s, scenario: { ...s.scenario, problems: [...this.order(s), key] } }));
    return this.boxEls.get(key);
  }

  private setSettings(patch: Partial<Settings>): void {
    this.edit((s) => ({ ...s, scenario: { ...s.scenario, settings: { ...s.scenario.settings, ...patch } } }));
  }

  private setCollapsed(key: string, collapsed: boolean): void {
    if (collapsed) this.collapsed.add(key);
    else this.collapsed.delete(key);
    const els = this.boxEls.get(key);
    if (!els) return;
    els.root.classList.toggle('collapsed', collapsed);
    els.toggle.setAttribute('aria-expanded', String(!collapsed));
    els.toggle.textContent = collapsed ? '▸' : '▾';
  }

  render(): void {
    const s = this.store.get();
    const { model } = this.store.getDerived();
    this.ownScenario = s.scenario;
    this.issueEls.clear();
    this.knobEls.clear();
    this.boxEls.clear();
    const boxes = problemBoxes(s.scenario.problems, s.scenario.knobs, this.canonical());
    const initialLink = (text: string): HTMLElement =>
      h('button', { class: 'link', title: 'list the knobs this panel starts with', on: { click: () => this.cb.showInitialSettings() } }, text);
    this.totalsEl = h('span', { class: 'hint' });
    setChildren(
      this.root,
      h('h2', {}, 'Hypotheses & algorithms'),
      h(
        'p',
        { class: 'hint' },
        'One box per problem with its lower bounds (LB, hypotheses) and algorithms (UB). Lower bounds propagate forward along reductions, upper bounds backward; exponents are with respect to the regime’s main parameter; unchecked bounds are ignored. ',
        initialLink('Initial settings'),
      ),
      h(
        'div',
        { class: 'panel-actions' },
        h(
          'span',
          { class: 'seg', role: 'group', 'aria-label': 'bounds CSV' },
          h('span', { class: 'seg-label', title: 'the problems and their bounds as a CSV sheet (one row per bound)' }, 'Bounds CSV'),
          h(
            'button',
            {
              'aria-label': 'Import bounds CSV',
              title: 'read problems and their bounds from a CSV file (Problem, Variation, Bound ID, Upper or Lower, Runtime, …), replacing the current ones or adding to them',
              on: { click: () => this.cb.importBounds() },
            },
            'Import…',
          ),
          h('button', { 'aria-label': 'Export bounds CSV', title: 'save the problems below and their bounds as a CSV file', on: { click: () => this.cb.exportBounds() } }, 'Export'),
        ),
      ),
      h(
        'div',
        { class: 'boxes-head' },
        this.totalsEl,
        boxes.length > 1
          ? h(
              'span',
              { class: 'boxes-actions' },
              h('button', { class: 'link', on: { click: () => boxes.forEach((b) => this.setCollapsed(b.problem, false)) } }, 'Expand all'),
              h('button', { class: 'link', on: { click: () => boxes.forEach((b) => this.setCollapsed(b.problem, true)) } }, 'Collapse all'),
            )
          : null,
      ),
      boxes.length === 0 ? h('p', { class: 'hint' }, 'No problems: add one below, or restore the ', initialLink('initial settings'), '.') : null,
      h(
        'div',
        { class: 'boxes' },
        boxes.map((b) => this.box(b, model)),
      ),
      this.addProblem(model),
      this.constants(),
      this.settings(),
    );
    this.refreshDynamicBits();
    this.refreshSelection();
  }

  /** A problem's box: its name and bounds, its knobs, and a form for a new one. */
  private box(b: ProblemBox<Knob>, model: Model): HTMLElement {
    const key = b.problem;
    const p = model.problems.get(key);
    const name = p ? problemLabel(p) : key;
    const collapsed = this.collapsed.has(key);
    const toggle = h(
      'button',
      { class: 'icon box-toggle', title: 'collapse or expand', 'aria-expanded': String(!collapsed), on: { click: () => this.setCollapsed(key, !this.collapsed.has(key)) } },
      collapsed ? '▸' : '▾',
    );
    const title = p
      ? h(
          'a',
          {
            class: 'box-name',
            href: '#',
            ...refAttrs({ kind: 'problem', id: p.id }),
            title: `${plainText(p.family)} / ${problemLabel(p)} (click: select in the graph; Shift-click: add to the selection)`,
            on: {
              click: (e) => {
                e.preventDefault();
                this.cb.selectProblem(p.id, isAdditive(e));
              },
            },
          },
          h('b', {}, name),
        )
      : h('span', { class: 'box-name unknown', title: 'not a problem of the current sheet: its bounds are ignored' }, key);
    const bounds = h('span', { class: 'box-bounds' });
    const count = h('span', { class: 'box-count' });
    const form = this.boundForm(key, p);
    const els: BoxEls = {
      root: h('section', { class: `box ${collapsed ? 'collapsed' : ''}`, 'data-problem': key, 'aria-label': name }),
      toggle,
      bounds,
      count,
      openForm: (kind, regime) => {
        this.setCollapsed(key, false);
        form.open(kind, regime);
      },
    };
    this.boxEls.set(key, els);
    setChildren(
      els.root,
      h(
        'div',
        { class: 'box-head' },
        toggle,
        title,
        count,
        bounds,
        h('button', { class: 'icon', title: 'add a lower bound or an algorithm for this problem', 'aria-label': `add a bound for ${name}`, on: { click: () => els.openForm() } }, '＋'),
        h('button', { class: 'icon', title: 'remove this problem and its bounds', 'aria-label': `remove ${name}`, on: { click: () => this.removeBox(key, name, b.knobs.length) } }, '×'),
      ),
      h(
        'div',
        { class: 'box-body' },
        b.knobs.length === 0 ? h('div', { class: 'hint empty' }, 'No bounds yet: ＋ adds one.') : null,
        b.knobs.map((k) => this.knobRow(k)),
        form.root,
      ),
    );
    return els.root;
  }

  /**
   * A knob in its box. While on: value (slider and number, or formula) on the first line, regime and note on the
   * second; while off, a one-line summary instead of the inputs (CSS).
   */
  private knobRow(k: Knob): HTMLElement {
    const issue = h('div', { class: 'issue', hidden: true });
    this.issueEls.set(k.id, issue);
    const summary = h('span', { class: 'knob-summary' });
    const editor = k.exponent !== undefined ? this.exponentEditor(k) : this.formulaEditor(k);
    const row = h(
      'div',
      { class: `knob ${k.enabled ? '' : 'disabled'}`, 'data-knob': k.id },
      h(
        'div',
        { class: 'knob-head' },
        h('input', {
          type: 'checkbox',
          checked: k.enabled,
          title: 'switch this bound on or off',
          'aria-label': `bound ${k.id} on`,
          on: { change: (e) => this.setKnob(k.id, { enabled: (e.target as HTMLInputElement).checked }) },
        }),
        h('span', { class: `kind kind-${k.kind}`, title: k.kind === 'LB' ? 'lower bound (hypothesis)' : 'upper bound (algorithm)' }, k.kind),
        h('span', { class: 'knob-id', title: `Bound ID ${k.id} (the bounds CSV matches rows to bounds by it)` }, `#${k.id}`),
        editor.main,
        summary,
        h('button', { class: 'icon', title: 'remove this bound', 'aria-label': `remove bound ${k.id}`, on: { click: () => this.removeKnob(k.id) } }, '×'),
      ),
      h(
        'div',
        { class: 'knob-sub' },
        h('input', {
          type: 'text',
          class: 'mono regime',
          value: k.regime ?? '',
          placeholder: k.kind === 'UB' && k.formula !== undefined ? 'all regimes' : 'regime, e.g. n=1, m=2, M=poly',
          title: 'regime: param=growth, … with growth: number (exponent), log, polylog, const[:v|[v1,v2]], poly (log-dependent)',
          'aria-label': `regime of bound ${k.id}`,
          on: { change: (e) => this.setKnob(k.id, { regime: (e.target as HTMLInputElement).value.trim() || undefined }) },
        }),
        k.note ? h('span', { class: 'note', title: k.note }, k.note) : null,
      ),
      editor.preview,
      issue,
    );
    this.knobEls.set(k.id, { row, summary });
    return row;
  }

  private exponentEditor(k: Knob): { main: HTMLElement; preview: null } {
    const x = k.exponent ?? 0;
    const max = Math.max(4, Math.ceil(x * 2));
    const num = h('input', { type: 'number', class: 'num', step: 'any', min: '0', value: String(x), title: 'exponent (any number of decimals)', 'aria-label': `exponent of bound ${k.id}` });
    const slider = h('input', { type: 'range', min: '0', max: String(max), step: '0.01', value: String(x), 'aria-label': `exponent of bound ${k.id} (slider)` });
    slider.addEventListener('input', () => {
      num.value = slider.value;
      this.setKnob(k.id, { exponent: Number(slider.value) }, true);
    });
    num.addEventListener('change', () => {
      const v = Number(num.value);
      if (!Number.isFinite(v) || v < 0) return;
      slider.max = String(Math.max(Number(slider.max), Math.ceil(v)));
      slider.value = String(v);
      this.setKnob(k.id, { exponent: v });
    });
    const toFormula = h('button', { class: 'link', title: 'switch to a runtime formula', on: { click: () => this.setKnob(k.id, { exponent: undefined, formula: `n^{${x}}` }) } }, 'ƒ');
    return { main: h('span', { class: 'knob-editor' }, slider, num, toFormula), preview: null };
  }

  private formulaEditor(k: Knob): { main: HTMLElement; preview: HTMLElement } {
    // The rendered preview is shown while editing and when the formula does not parse.
    const preview = h('div', { class: 'preview' });
    let focused = false;
    const showPreview = (tex: string): void => {
      try {
        parseExpr(tex);
        preview.innerHTML = texHtml(tex);
        preview.classList.remove('bad');
        preview.hidden = !focused;
      } catch (e) {
        preview.textContent = (e as Error).message;
        preview.classList.add('bad');
        preview.hidden = false;
      }
    };
    showPreview(k.formula ?? '');
    const input = h('input', {
      type: 'text',
      class: 'mono',
      value: k.formula ?? '',
      title: 'running time in the problem’s parameters, e.g. n^2 d, \\min(n^{\\omega}, m^{2\\omega/(\\omega+1)})',
      'aria-label': `running time of bound ${k.id}`,
    });
    input.addEventListener('input', () => showPreview(input.value));
    input.addEventListener('focus', () => ((focused = true), showPreview(input.value)));
    input.addEventListener('blur', () => ((focused = false), showPreview(input.value)));
    input.addEventListener('change', () => this.setKnob(k.id, { formula: input.value }));
    const toExponent = h('button', { class: 'link', title: 'switch to a plain exponent', on: { click: () => this.setKnob(k.id, { formula: undefined, exponent: 2 }) } }, 'x');
    return { main: h('span', { class: 'knob-editor formula' }, input, toExponent), preview };
  }

  /** The form for a new bound of a box's problem (hidden until opened). */
  private boundForm(key: string, problem: Problem | undefined): { root: HTMLElement; open(kind?: KnobKind, regime?: string): void } {
    const group = `kind-${key}`;
    const lb = h('input', { type: 'radio', name: group, value: 'LB', checked: true });
    const ub = h('input', { type: 'radio', name: group, value: 'UB' });
    const main = problem?.regimeSpecs[0];
    const regime = h('input', { type: 'text', class: 'mono', 'aria-label': 'regime of the new bound' });
    const value = h('input', { type: 'text', class: 'mono', placeholder: 'exponent (e.g. 2) or formula (e.g. n^2 d)', 'aria-label': 'exponent or running time of the new bound' });
    const msg = h('div', { class: 'issue', hidden: true });
    const placeholders = (): void => {
      regime.placeholder = lb.checked ? `empty: ${main ?? 'the main regime'}` : `empty: ${main ?? 'the main regime'} (exponent) / all (formula)`;
    };
    lb.addEventListener('change', placeholders);
    ub.addEventListener('change', placeholders);
    placeholders();
    const fail = (m: string): void => {
      msg.textContent = m;
      msg.hidden = false;
    };
    const add = (): void => {
      const kind: KnobKind = ub.checked ? 'UB' : 'LB';
      const v = value.value.trim();
      if (v === '') return fail('give an exponent or a running time');
      const isNumber = NUMBER.test(v);
      if (isNumber && Number(v) < 0) return fail('exponents must be nonnegative');
      // An empty regime means the problem's main regime, except for UB formulas, which then apply everywhere.
      const regimeText = regime.value.trim() || (kind === 'UB' && !isNumber ? '' : (main ?? ''));
      const errors: string[] = [];
      const spec = validateKnobSpec(
        { problem: problem?.id ?? key, kind, ...(regimeText ? { regime: regimeText } : {}), ...(isNumber ? { exponent: Number(v) } : { formula: v }) },
        'bound',
        errors,
      );
      if (!spec) return fail(errors.join('; '));
      if (!isNumber) {
        try {
          parseExpr(v);
        } catch (e) {
          return fail(`formula: ${(e as Error).message}`);
        }
      }
      msg.hidden = true;
      this.edit((s) => ({
        ...s,
        scenario: { ...s.scenario, problems: this.order(s), knobs: [...s.scenario.knobs, { ...spec, id: newKnobId(s.scenario.knobs), enabled: true }] },
      }));
    };
    const root = h(
      'div',
      { class: 'add-bound', hidden: true },
      h('div', { class: 'kind-choice' }, h('label', {}, lb, ' lower bound (LB)'), h('label', {}, ub, ' algorithm (UB)')),
      h('label', { class: 'field' }, h('span', {}, 'regime'), regime),
      h('label', { class: 'field' }, h('span', {}, 'value'), value),
      h(
        'div',
        { class: 'buttons' },
        h('button', { class: 'primary', on: { click: add } }, 'Add'),
        h('button', { on: { click: () => (root.hidden = true) } }, 'Cancel'),
      ),
      msg,
    );
    for (const input of [regime, value]) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') add();
        else if (e.key === 'Escape') root.hidden = true;
      });
    }
    return {
      root,
      open: (kind, regimeSpec) => {
        root.hidden = false;
        if (kind) (kind === 'UB' ? ub : lb).checked = true;
        placeholders();
        regime.value = regimeSpec ?? '';
        msg.hidden = true;
        root.scrollIntoView({ block: 'nearest' });
        value.focus();
      },
    };
  }

  /** "＋ Problem": a new box at the end (or the problem's existing box, shown). */
  private addProblem(model: Model): HTMLElement {
    const listId = 'problem-list';
    const datalist = h(
      'datalist',
      { id: listId },
      [...model.problems.values()].filter((p) => p.isStatic).map((p) => h('option', { value: p.id })),
    );
    const input = h('input', { type: 'text', list: listId, placeholder: 'Family / Variation', 'aria-label': 'problem to add' });
    const msg = h('div', { class: 'issue', hidden: true });
    const add = (): void => {
      const p = findProblem(this.store.getDerived().model, input.value);
      if (!p) {
        msg.textContent = 'not a problem of the sheet: pick one from the list';
        msg.hidden = false;
        return;
      }
      msg.hidden = true;
      const box = this.ensureBox(this.canonical()(p.id));
      if (!box) return;
      box.root.scrollIntoView({ block: 'nearest' });
      box.root.classList.add('flash');
      setTimeout(() => box.root.classList.remove('flash'), 1200);
      if (box.root.querySelector('.knob') === null) box.openForm();
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') add();
    });
    return h(
      'div',
      { class: 'add-problem' },
      h('label', { class: 'field' }, h('span', {}, '＋ Problem'), input, h('button', { on: { click: add } }, 'Add')),
      msg,
      datalist,
    );
  }

  /** Open the new-bound form of a problem's box, prefilled (the inspector's "add knob here"); adds the box if needed. */
  prefill(problemId: string, kind: KnobKind, regimeSpec: string): void {
    this.ensureBox(this.canonical()(problemId))?.openForm(kind, regimeSpec);
  }

  private constants(): HTMLElement {
    const s = this.store.get();
    const entries = Object.entries(s.config.constants);
    if (entries.length === 0) return h('div');
    return h(
      'div',
      { class: 'constants' },
      h('h3', {}, 'Constants'),
      entries.map(([name, def]) => {
        const value = s.scenario.constants[name] ?? def.value;
        const num = h('input', { type: 'number', class: 'num', step: 'any', value: String(value) });
        const slider = h('input', { type: 'range', min: String(def.min), max: String(def.max), step: '0.001', value: String(value) });
        const set = (v: number, debounce: boolean): void =>
          this.edit((st) => ({ ...st, scenario: { ...st.scenario, constants: { ...st.scenario.constants, [name]: v } } }), debounce);
        slider.addEventListener('input', () => {
          num.value = slider.value;
          set(Number(slider.value), true);
        });
        num.addEventListener('change', () => {
          const v = Number(num.value);
          if (Number.isFinite(v)) {
            slider.value = String(v);
            set(v, false);
          }
        });
        return h('label', { class: 'field', title: def.label }, h('span', { html: texHtml(identifierTex(name)) }), slider, num);
      }),
    );
  }

  private settings(): HTMLElement {
    const st = this.store.get().scenario.settings;
    const intField = (label: string, key: 'maxHopsLB' | 'maxDepthUB' | 'gridPoints' | 'refineRounds', min: number, max: number, title: string): HTMLElement =>
      h(
        'label',
        { class: 'field', title },
        h('span', {}, label),
        h('input', {
          type: 'number',
          class: 'num',
          min: String(min),
          max: String(max),
          value: String(st[key]),
          on: {
            change: (e) => {
              const v = Math.round(Number((e.target as HTMLInputElement).value));
              if (v >= min && v <= max) this.setSettings({ [key]: v } as Partial<Settings>);
            },
          },
        }),
      );
    return h(
      'details',
      { class: 'settings' },
      h('summary', {}, 'Settings'),
      intField('LB hops', 'maxHopsLB', 0, 50, 'maximum number of reductions in a lower-bound derivation'),
      intField('UB depth', 'maxDepthUB', 0, 12, 'maximum number of reductions in an upper-bound derivation'),
      intField('grid points', 'gridPoints', 2, 41, 'grid points per continuous free parameter'),
      intField('refinement', 'refineRounds', 0, 40, 'rounds of local refinement after the grid search (each halves the step)'),
      h(
        'label',
        { class: 'field', title: 'rows whose Reduction Runtime has no formula' },
        h('span', {}, 'unknown RT'),
        h(
          'select',
          { on: { change: (e) => this.setSettings({ unknownRT: (e.target as HTMLSelectElement).value as Settings['unknownRT'] }) } },
          h('option', { value: 'assume-negligible', selected: st.unknownRT === 'assume-negligible' }, 'assume negligible'),
          h('option', { value: 'block', selected: st.unknownRT === 'block' }, 'block the row'),
        ),
      ),
      h(
        'label',
        { class: 'field check' },
        h('input', {
          type: 'checkbox',
          checked: st.useRandomized,
          on: { change: (e) => this.setSettings({ useRandomized: (e.target as HTMLInputElement).checked }) },
        }),
        h('span', {}, 'use randomized reductions'),
      ),
      st.disabledRows.length > 0
        ? h(
            'div',
            { class: 'field' },
            h('span', {}, `disabled rows: ${st.disabledRows.join(', ')}`),
            h('button', { class: 'link', on: { click: () => this.setSettings({ disabledRows: [] }) } }, 'enable all'),
          )
        : null,
    );
  }
}
