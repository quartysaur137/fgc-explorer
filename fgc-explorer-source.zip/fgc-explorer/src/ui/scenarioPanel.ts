/**
 * Left panel: one box per problem with its lower bounds (hypotheses) and algorithms (upper bounds), then constants
 * and settings (SPEC §7).
 *
 * The boxes are rebuilt only when the scenario's structure changes (knobs or boxes added/removed, model reloaded), so
 * that typing and dragging sliders never lose focus; value edits (including switching a knob on or off) and new
 * analyses update the affected elements in place. The bar above the boxes stays put (and at the top of the panel while
 * it scrolls); the search (above the graph) hides the boxes it does not find, without rebuilding anything.
 */

import { clippedRegimes, formulaRate, knobPower, regimesFromSpec, STATUS_TEXT } from '../engine/analysis';
import { constantEnv } from '../engine/rowEval';
import { finiteRate, plainNumber } from '../growth/growth';
import { identifierTex } from '../math/ast';
import { parseExpr } from '../math/parser';
import { boxOrder, canonicalProblem, ProblemBox, problemBoxes } from '../model/boxes';
import { initialScenario, Knob, KnobKind, MAX_DEPTH_UB, Settings, validateKnobSpec } from '../model/config';
import { findProblem, Model, Problem } from '../model/model';
import { Regime } from '../model/regime';
import { flash, h, markedText, rebuildInPlace, scrollBehavior, scrollParent, setChildren } from './dom';
import { knobRate, knobRegime, knobValueHtml, parseDecimal, problemLabel, regimeToSpec } from './format';
import { paramFamily, problemBoundsLine } from './paramFamily';
import { refAttrs } from './hover';
import { matchRanges, NO_SEARCH, reductionOf, search, SearchResult, searchQuery } from './search';
import { isAdditive } from './selection';
import { AppState, newKnobId } from './state';
import { Change, Store } from './store';
import { plainText, texHtml } from './tex';

export interface ScenarioPanelCallbacks {
  /** A click on a problem's name; `additive` when Shift, Ctrl or ⌘ was held. */
  selectProblem(id: string, additive: boolean): void;
  /** Put the keyboard focus in the search field (above the graph), e.g. after Clear. */
  focusSearch(): void;
  /** Show the note listing the initial knobs (it lives in the inspector). */
  showInitialSettings(): void;
  /** Read hypotheses and algorithms from a bounds CSV chosen by the user. */
  importBounds(): void;
  /** Save the current hypotheses and algorithms as a bounds CSV. */
  exportBounds(): void;
  /** Say that × removed something, offering `undo` (which puts it back). */
  removed(message: string, undo: () => void): void;
}

/** The elements of a problem's box that change without a rebuild. */
interface BoxEls {
  readonly root: HTMLElement;
  readonly toggle: HTMLButtonElement;
  /** The problem's name as shown (the search marks what it found in it). */
  readonly name: HTMLElement;
  readonly nameText: string;
  /** The problem's bounds at its primary regime, colored by status. */
  readonly bounds: HTMLElement;
  /** "2/3 on", shown while the box is collapsed. */
  readonly count: HTMLElement;
  /** The Bound IDs of its knobs. */
  readonly knobIds: readonly string[];
  /** Open the form for a new bound (kind and regime prefilled when given). */
  openForm(kind?: KnobKind, regime?: string): void;
}

/** The elements of a knob's row that change without a rebuild. */
interface KnobEls {
  /** The row (class "disabled" when off, "match" when the search found it). */
  readonly row: HTMLElement;
  /** The box key of its problem. */
  readonly box: string;
  /** The one-line summary shown while it is off. */
  readonly summary: HTMLElement;
  readonly id: HTMLElement;
  /** Its note, if it has one (the search marks what it found in it). */
  readonly note: HTMLElement | null;
  readonly noteText: string;
}


/** "1 problem", "3 problems". */
function plural(n: number, noun: string): string {
  return `${n} ${noun}${n === 1 ? '' : 's'}`;
}

export class ScenarioPanel {
  private readonly issueEls = new Map<string, HTMLElement>();
  /** Per knob: where its regime is clipped to its problem's limits (SPEC §2.3), the regime it stands for. */
  private readonly clipEls = new Map<string, HTMLElement>();
  /** Per exponent knob with a power control: re-renders its running time (after an edit of its exponent). */
  private readonly timeEls = new Map<string, () => void>();
  /** Per knob (Bound ID): its elements. */
  private readonly knobEls = new Map<string, KnobEls>();
  /** Per box (problem id): its elements, in the order shown. */
  private readonly boxEls = new Map<string, BoxEls>();
  /** Collapsed boxes, kept across re-renders. */
  private readonly collapsed = new Set<string>();
  /** Collapsed boxes shown open because the search found bounds in them (until the search changes or they are closed). */
  private readonly searchOpened = new Set<string>();
  /** The search applied to the boxes (see applySearch). */
  private result: SearchResult = NO_SEARCH;
  /** Names and notes with the query marked in them, and that query. */
  private readonly marks = new Map<HTMLElement, string>();
  /**
   * The bar above the boxes (it stays at the top while the panel scrolls): the totals, or what the search above the
   * graph found and Clear; "Collapse all" (or, when all boxes shown are collapsed, "Expand all").
   */
  private readonly bar: HTMLElement;
  private readonly totalsEl: HTMLElement;
  private readonly clearLink: HTMLElement;
  private readonly allToggle: HTMLButtonElement;
  /** What render() rebuilds: the boxes, the new-problem field, the constants and the settings. */
  private readonly content: HTMLElement;
  private boxesEl: HTMLElement | null = null;
  /** The scenario after this panel's own last edit: any other scenario came from outside (e.g. an import). */
  private ownScenario: unknown = null;

  /**
   * The formula a knob had before "n^c" made it an exponent, with that exponent and power (ƒ(n) restores the formula
   * while they are unchanged).
   */
  private readonly formulasBefore = new Map<string, { formula: string; regime: string | undefined; exponent: number | undefined; power: number | undefined }>();

  /** The settings section (re-rendered alone when the settings change), the settings it shows, and whether it is open. */
  private settingsEl: HTMLElement | null = null;
  private settingsShown: Settings | null = null;
  private settingsOpen = false;

  constructor(
    private readonly root: HTMLElement,
    private readonly store: Store,
    private readonly cb: ScenarioPanelCallbacks,
  ) {
    const initialLink = (text: string): HTMLElement =>
      h('button', { class: 'link', title: 'list the knobs this panel starts with', on: { click: () => this.cb.showInitialSettings() } }, text);
    this.totalsEl = h('span', { class: 'hint boxes-totals', 'aria-live': 'polite' });
    this.clearLink = h(
      'button',
      {
        class: 'link',
        title: 'end the search (above the graph): show all boxes again',
        hidden: true,
        on: {
          click: () => {
            this.setSearch('');
            // (this link is hidden now: the focus goes to the search field)
            this.cb.focusSearch();
          },
        },
      },
      'Clear',
    );
    this.allToggle = h('button', {
      class: 'link boxes-toggle',
      on: {
        click: () => {
          // (during a search: the boxes shown)
          const collapse = this.allToggle.dataset.collapse === 'true';
          for (const [key, els] of this.boxEls) if (!els.root.hidden) this.setCollapsed(key, collapse);
        },
      },
    });
    this.bar = h('div', { class: 'boxes-bar' }, h('div', { class: 'boxes-head' }, h('span', {}, this.totalsEl, this.clearLink), this.allToggle));
    // Scrolling to a box, a bound or a form leaves room for the bar (its height changes when its text wraps).
    if (typeof ResizeObserver === 'function') {
      new ResizeObserver(() => this.root.style.setProperty('--bar-height', `${this.bar.offsetHeight}px`)).observe(this.bar);
    }
    this.content = h('div', { class: 'left-content' });
    setChildren(
      this.root,
      h('h2', {}, 'Hypotheses & algorithms'),
      h(
        'p',
        { class: 'hint' },
        'One box per problem with its lower bounds (LB, hypotheses) and algorithms (UB). Lower bounds propagate forward along reductions, upper bounds backward; exponents are with respect to the regime’s main parameter; unchecked bounds are ignored. ',
        initialLink('Initial settings'),
      ),
      h(
        'div',
        { class: 'panel-actions' },
        h(
          'span',
          { class: 'seg', role: 'group', 'aria-label': 'bounds CSV' },
          h('span', { class: 'seg-label', title: 'the problems and their bounds as a CSV sheet (one row per bound)' }, 'Bounds CSV'),
          h(
            'button',
            {
              'aria-label': 'Import bounds CSV',
              title: 'read problems and their bounds from a CSV file (Problem, Variation, Bound ID, Upper or Lower, Runtime, …), replacing the current ones or adding to them',
              on: { click: () => this.cb.importBounds() },
            },
            'Import…',
          ),
          h('button', { 'aria-label': 'Export bounds CSV', title: 'save the problems below and their bounds as a CSV file', on: { click: () => this.cb.exportBounds() } }, 'Export'),
        ),
      ),
      this.bar,
      this.content,
    );
    this.render();
    store.subscribe((changes) => this.onChange(changes));
  }

  private onChange(changes: ReadonlySet<Change>): void {
    const external = changes.has('scenario') && this.store.get().scenario !== this.ownScenario;
    const rebuild = changes.has('scenario-structure') || changes.has('model') || external;
    if (rebuild) this.render();
    else if (changes.has('analysis') || changes.has('scenario')) this.refreshDynamicBits();
    // (the settings section alone, in place: the panel keeps its scroll position, the section stays open, and the
    // field that was changed keeps the keyboard focus)
    if (!rebuild && changes.has('scenario') && this.settingsEl !== null && this.store.get().scenario.settings !== this.settingsShown) {
      const old = this.settingsEl;
      const parent = old.parentElement;
      if (parent === null) old.replaceWith(this.settings());
      else rebuildInPlace(parent, () => old.replaceWith(this.settings()));
    }
    if (changes.has('selection')) this.refreshSelection();
    // (render() applies the search itself; an edit, e.g. of a formula, may change what it finds)
    const newSearch = changes.has('prefs') && searchQuery(this.store.get().prefs.search) !== this.result.query;
    if (!rebuild && (newSearch || (changes.has('scenario') && this.result.query !== ''))) this.applySearch();
  }

  /** Set the search text (the field above the graph shows it). */
  private setSearch(text: string): void {
    this.store.update((s) => (s.prefs.search === text ? s : { ...s, prefs: { ...s.prefs, search: text } }));
  }

  /** Apply an edit made in this panel (the panel keeps its inputs instead of re-rendering). */
  private edit(fn: (s: AppState) => AppState, debounce = false): void {
    this.store.update((s) => {
      const next = fn(s);
      this.ownScenario = next.scenario;
      return next;
    }, debounce);
  }

  /** The box key of a problem name (see canonicalProblem). */
  private canonical(): (name: string) => string {
    return canonicalProblem(this.store.getDerived().model);
  }

  /** The current box order, complete (so that boxes stay when their knobs change). */
  private order(s: AppState): string[] {
    return boxOrder(s.scenario.problems, s.scenario.knobs, this.canonical());
  }

  /** Update issue messages, on/off states, bounds and counts without rebuilding inputs. */
  private refreshDynamicBits(): void {
    const { analysis } = this.store.getDerived();
    const s = this.store.get();
    const formulas = new Map(s.scenario.knobs.map((k) => [k.id, k.formula]));
    for (const [id, el] of this.issueEls) {
      // (a formula that does not parse shows the error in its preview already: a second line, appearing when the field
      // loses the focus, would move what follows, and a click there would miss)
      const formula = formulas.get(id);
      const msg = formula !== undefined && !parses(formula) ? undefined : analysis.knobIssues.get(id);
      el.textContent = msg ?? '';
      el.hidden = msg === undefined;
    }
    const { model } = this.store.getDerived();
    for (const show of this.timeEls.values()) show();
    for (const k of s.scenario.knobs) {
      const els = this.knobEls.get(k.id);
      if (!els) continue;
      const clip = this.clipEls.get(k.id);
      if (clip) {
        const p = k.regime === undefined ? undefined : findProblem(model, k.problem);
        const clipped = p === undefined || !p.isStatic ? [] : clippedRegimes(p, k.regime!);
        const specs = clipped.map(regimeToSpec).join('; ');
        // (a formula knob's regime is a filter: it applies wherever the limits clip the sizes it names to the regime's)
        clip.textContent =
          clipped.length === 0 ? '' : k.formula !== undefined ? `beyond the limits of its parameters: it applies where they clip it, e.g. ${specs}` : `at the limits of its parameters: ${specs}`;
        clip.hidden = clipped.length === 0;
      }
      els.row.classList.toggle('disabled', !k.enabled);
      els.summary.innerHTML = knobValueHtml(k, k.exponent !== undefined ? knobRegime(model, k) : null);
    }
    const boxes = problemBoxes(s.scenario.problems, s.scenario.knobs, this.canonical());
    for (const b of boxes) {
      const els = this.boxEls.get(b.problem);
      if (!els) continue;
      const summary = analysis.summaries.get(b.problem);
      const status = summary && summary.problem.isStatic ? summary.status : null;
      els.bounds.textContent = !summary ? 'not in the sheet' : !summary.problem.isStatic ? 'not propagated' : problemBoundsLine(analysis, summary) || 'no bound';
      els.bounds.className = `box-bounds${status ? ` status-${status}` : ''}`;
      const family = summary && status ? paramFamily(analysis, summary) : null;
      els.bounds.title = status
        ? `${STATUS_TEXT[status]}${summary?.primary ? ` (at the primary regime ${summary.primary.regime.key})` : ''}${family ? `; the line gives the bounds for every listed value of ${family.param}, or only the status at each` : ''}`
        : summary
          ? 'a dynamic / multi-function problem: shown, not propagated'
          : 'not a problem of the current sheet: its bounds are ignored';
      els.count.textContent = `${b.knobs.filter((k) => k.enabled).length}/${b.knobs.length} on`;
    }
    this.refreshHead();
  }

  /** The line under the search: the totals, or what the search found; and the actions on all boxes shown. */
  private refreshHead(): void {
    const knobs = this.store.get().scenario.knobs;
    const total = this.boxEls.size;
    let shown = total;
    let text: string;
    if (this.result.query === '') {
      text = `${plural(total, 'problem')} · ${plural(knobs.length, 'bound')}, ${knobs.filter((k) => k.enabled).length} on`;
    } else {
      shown = [...this.boxEls.values()].filter((els) => !els.root.hidden).length;
      const found = [...this.knobEls.keys()].filter((id) => this.result.knobs.has(id)).length;
      const row = reductionOf(this.result.query, this.store.getDerived().model);
      text =
        shown > 0
          ? `${shown} of ${plural(total, 'problem')}${found > 0 ? ` · ${plural(found, 'bound')} found` : ''}`
          : row !== null
            ? `no problem or bound here: Enter selects reduction ${row}`
            : `nothing found among ${plural(total, 'problem')} and ${plural(knobs.length, 'bound')}`;
    }
    // (only changes are announced to screen readers)
    if (this.totalsEl.textContent !== text) this.totalsEl.textContent = text;
    this.clearLink.hidden = this.result.query === '';
    this.refreshAllToggle();
    this.allToggle.hidden = shown < 2;
  }

  /** "Collapse all" while a box shown is open, else "Expand all". */
  private refreshAllToggle(): void {
    const collapse = [...this.boxEls].some(([key, els]) => !els.root.hidden && this.isOpen(key));
    if (this.allToggle.dataset.collapse === String(collapse)) return;
    this.allToggle.dataset.collapse = String(collapse);
    this.allToggle.textContent = collapse ? 'Collapse all' : 'Expand all';
    this.allToggle.title = collapse ? 'collapse all boxes shown' : 'expand all boxes shown';
  }

  /** Mark the boxes of the selected problems. */
  private refreshSelection(): void {
    const selected = new Set(this.store.get().selection.flatMap((x) => (x.kind === 'problem' ? [x.id] : [])));
    for (const [key, els] of this.boxEls) els.root.classList.toggle('selected', selected.has(key));
  }

  private setKnob(id: string, patch: Partial<Knob>, debounce = false): void {
    this.edit(
      (s) => ({ ...s, scenario: { ...s.scenario, knobs: s.scenario.knobs.map((k) => (k.id === id ? ({ ...k, ...patch } as Knob) : k)) } }),
      debounce,
    );
  }

  /** Remove a knob, with Undo; its box stays (possibly empty). */
  private removeKnob(id: string): void {
    const before = this.store.get().scenario.knobs;
    const removed = before.flatMap((k, i) => (k.id === id ? [{ knob: k, at: i }] : []));
    this.edit((s) => ({ ...s, scenario: { ...s.scenario, problems: this.order(s), knobs: s.scenario.knobs.filter((k) => k.id !== id) } }));
    if (removed.length > 0) this.cb.removed(`Bound ${id} removed.`, () => this.putBack(removed, null));
  }

  /** Remove a box and its knobs (after asking, if it has any), with Undo. */
  private removeBox(key: string, name: string, knobCount: number): void {
    if (knobCount > 0 && !confirm(`Remove ${name} and its ${knobCount} bound${knobCount === 1 ? '' : 's'}?`)) return;
    const canonical = this.canonical();
    const s0 = this.store.get();
    const removed = s0.scenario.knobs.flatMap((k, i) => (canonical(k.problem) === key ? [{ knob: k, at: i }] : []));
    const box = { key, at: this.order(s0).indexOf(key) };
    this.edit((s) => ({
      ...s,
      scenario: { ...s.scenario, problems: this.order(s).filter((p) => p !== key), knobs: s.scenario.knobs.filter((k) => canonical(k.problem) !== key) },
    }));
    this.cb.removed(`${name} removed${removed.length > 0 ? ` with its ${removed.length} bound${removed.length === 1 ? '' : 's'}` : ''}.`, () => this.putBack(removed, box));
  }

  /**
   * Undo of a removal: the knobs back where they were (those that are not there again, by Bound ID), and the box at its
   * place; what changed since stays.
   */
  private putBack(knobs: ReadonlyArray<{ knob: Knob; at: number }>, box: { key: string; at: number } | null): void {
    this.edit((s) => {
      const order = this.order(s);
      const problems = box === null || box.at < 0 || order.includes(box.key) ? order : [...order.slice(0, box.at), box.key, ...order.slice(box.at)];
      const list = [...s.scenario.knobs];
      for (const { knob, at } of knobs) if (!list.some((k) => k.id === knob.id)) list.splice(Math.min(at, list.length), 0, knob);
      return { ...s, scenario: { ...s.scenario, problems, knobs: list } };
    });
  }

  /**
   * Add an (empty) box for a problem at the end, unless it has one; returns its elements. The box is shown: the search
   * is cleared if it hides the box.
   */
  private ensureBox(key: string): BoxEls | undefined {
    if (!this.boxEls.has(key)) this.edit((s) => ({ ...s, scenario: { ...s.scenario, problems: [...this.order(s), key] } }));
    if (this.boxEls.get(key)?.root.hidden) this.setSearch('');
    return this.boxEls.get(key);
  }

  /**
   * Change settings from the section's own fields, which show the new values already: the section is not rebuilt (it
   * was, inside the change event, so that Tab or Shift+Tab after a change sent the focus to the page).
   */
  private setSettings(patch: Partial<Settings>): void {
    this.edit((s) => {
      const settings = { ...s.scenario.settings, ...patch };
      this.settingsShown = settings;
      return { ...s, scenario: { ...s.scenario, settings } };
    });
  }

  /** Whether a box is shown open: not collapsed, or opened by the search. */
  private isOpen(key: string): boolean {
    return !this.collapsed.has(key) || this.searchOpened.has(key);
  }

  /** Collapse or expand a box (one opened by the search is closed for the rest of that search). */
  private setCollapsed(key: string, collapsed: boolean): void {
    if (collapsed) {
      this.collapsed.add(key);
      this.searchOpened.delete(key);
    } else this.collapsed.delete(key);
    this.showOpen(key);
    this.refreshAllToggle();
  }

  private showOpen(key: string): void {
    const els = this.boxEls.get(key);
    if (!els) return;
    const open = this.isOpen(key);
    if (els.root.classList.contains('collapsed') === open) {
      els.root.classList.toggle('collapsed', !open);
      els.toggle.setAttribute('aria-expanded', String(open));
      els.toggle.textContent = open ? '▾' : '▸';
    }
  }

  render(): void {
    const s = this.store.get();
    const { model } = this.store.getDerived();
    // (rebuilt in place: the panel keeps its scroll position)
    const scrolled = this.root.scrollTop;
    this.ownScenario = s.scenario;
    this.issueEls.clear();
    this.clipEls.clear();
    this.timeEls.clear();
    this.knobEls.clear();
    this.boxEls.clear();
    this.marks.clear();
    const boxes = problemBoxes(s.scenario.problems, s.scenario.knobs, this.canonical());
    this.boxesEl = h(
      'div',
      { class: 'boxes' },
      boxes.map((b) => this.box(b, model)),
    );
    setChildren(
      this.content,
      boxes.length === 0
        ? h(
            'p',
            { class: 'hint' },
            'No problems: add one below, or restore the ',
            h('button', { class: 'link', on: { click: () => this.cb.showInitialSettings() } }, 'initial settings'),
            '.',
          )
        : null,
      this.boxesEl,
      this.addProblem(model),
      this.constants(),
      this.settings(),
    );
    this.root.scrollTop = scrolled;
    this.refreshDynamicBits();
    this.refreshSelection();
    this.applySearch();
  }

  /**
   * Apply the search to the boxes: show only those of the problems found, mark what was found (bounds, and the text in
   * names and notes), and show open the collapsed boxes that hold bounds found (for a new search all of them, else
   * those with bounds found only now, e.g. after an import or a formula edit). A new search, typed while the bar above
   * the boxes is in view, shows its first boxes right below the bar; clearing the search keeps the box at the top of the
   * view in place. Only what changes is touched, and layout is read only for scrolling.
   */
  private applySearch(): void {
    const s = this.store.get();
    const before = this.result;
    const r = search(s.prefs.search, this.store.getDerived().model, s.scenario.knobs, s.scenario.problems);
    const changed = r.query !== before.query;
    // Before the boxes change: what scrolling needs.
    const scroller = changed ? scrollParent(this.root) : null;
    const anchor = scroller !== null && r.query === '' ? this.topBox(scroller) : null;
    const start = scroller !== null && r.query !== '' ? this.boxesStart(scroller) : null;
    this.result = r;
    if (changed) this.searchOpened.clear();
    for (const [key, els] of this.boxEls) {
      if (this.collapsed.has(key) && els.knobIds.some((id) => r.knobs.has(id) && (changed || !before.knobs.has(id)))) this.searchOpened.add(key);
      const hide = r.query !== '' && !r.problems.has(key);
      if (els.root.hidden !== hide) els.root.hidden = hide;
      this.mark(els.name, els.nameText, r.query);
      this.showOpen(key);
    }
    for (const [id, els] of this.knobEls) {
      els.row.classList.toggle('match', r.knobs.has(id));
      els.id.classList.toggle('hit', r.query !== '' && id.toLowerCase() === r.query);
      if (els.note) this.mark(els.note, els.noteText, r.query);
    }
    this.refreshHead();
    if (scroller === null) return;
    if (anchor !== null) {
      // (the box stays where it was)
      if (!anchor.el.hidden) scroller.scrollTop += anchor.el.getBoundingClientRect().top - anchor.top;
    } else if (start !== null && start.scrollTop > start.offset - start.bar - 6) {
      // (from offsets measured before: hiding boxes may have scrolled the scroller back already)
      scroller.scrollTop = start.offset - this.bar.offsetHeight - 6;
    }
  }

  /**
   * With the bar above the boxes in view: where the boxes start in the scroller's content, how far it is scrolled, and
   * the bar's height (null when the bar is not in view, e.g. in a narrow window showing the graph, or the panel is
   * hidden).
   */
  private boxesStart(scroller: HTMLElement): { offset: number; scrollTop: number; bar: number } | null {
    const bar = this.bar.getBoundingClientRect();
    const view = this.view(scroller);
    if (this.boxesEl === null || bar.height === 0 || bar.top < view.top - 1 || bar.bottom > view.bottom + 1) return null;
    const top = scroller.getBoundingClientRect().top + scroller.clientTop;
    return { offset: this.boxesEl.getBoundingClientRect().top - top + scroller.scrollTop, scrollTop: scroller.scrollTop, bar: bar.height };
  }

  /** Mark the query in an element's text, rewriting only elements whose marks change. */
  private mark(el: HTMLElement, text: string, query: string): void {
    const want = query !== '' && text.toLowerCase().includes(query) ? query : '';
    if ((this.marks.get(el) ?? '') === want) return;
    setChildren(el, want === '' ? text : markedText(text, matchRanges(text, want)));
    if (want === '') this.marks.delete(el);
    else this.marks.set(el, want);
  }

  /** The part of the window where the scroller shows the panel (viewport coordinates). */
  private view(scroller: HTMLElement): { top: number; bottom: number } {
    const r = scroller.getBoundingClientRect();
    return { top: Math.max(r.top, 0), bottom: Math.min(r.bottom, window.innerHeight) };
  }

  /** The first box shown in view below the bar, and its position (null if there is none). */
  private topBox(scroller: HTMLElement): { el: HTMLElement; top: number } | null {
    const view = this.view(scroller);
    const below = Math.max(this.bar.getBoundingClientRect().bottom, view.top);
    for (const els of this.boxEls.values()) {
      if (els.root.hidden) continue;
      const box = els.root.getBoundingClientRect();
      if (box.bottom <= below) continue;
      return box.top < view.bottom ? { el: els.root, top: box.top } : null;
    }
    return null;
  }

  /**
   * Show a bound in its box (the inspector's links to bounds): the box shown (the search cleared if it hides it) and
   * open, the bound scrolled into view and highlighted for a moment. False if the scenario has no such bound.
   */
  revealKnob(id: string): boolean {
    const els = this.knobEls.get(id);
    if (!els) return false;
    if (this.boxEls.get(els.box)?.root.hidden) this.setSearch('');
    this.setCollapsed(els.box, false);
    els.row.scrollIntoView({ block: 'center', behavior: scrollBehavior() });
    flash(els.row, 'flash', 2000);
    return true;
  }

  /** A problem's box: its name and bounds, its knobs, and a form for a new one. */
  private box(b: ProblemBox<Knob>, model: Model): HTMLElement {
    const key = b.problem;
    const p = model.problems.get(key);
    const name = p ? problemLabel(p) : key;
    const open = this.isOpen(key);
    const toggle = h(
      'button',
      { class: 'icon box-toggle', title: 'collapse or expand', 'aria-label': `bounds of ${name}`, 'aria-expanded': String(open), on: { click: () => this.setCollapsed(key, this.isOpen(key)) } },
      open ? '▾' : '▸',
    );
    const nameEl = p ? h('b', {}, name) : h('span', { class: 'box-name unknown', title: 'not a problem of the current sheet: its bounds are ignored' }, key);
    const title = p
      ? h(
          'a',
          {
            class: 'box-name',
            href: '#',
            ...refAttrs({ kind: 'problem', id: p.id }),
            title: `${p.family === '' ? '' : `${plainText(p.family)} / `}${problemLabel(p)} (click: select in the graph; Shift-click: add to the selection)`,
            on: {
              click: (e) => {
                e.preventDefault();
                this.cb.selectProblem(p.id, isAdditive(e));
              },
            },
          },
          nameEl,
        )
      : nameEl;
    const bounds = h('span', { class: 'box-bounds' });
    const count = h('span', { class: 'box-count' });
    const form = this.boundForm(key, p);
    const els: BoxEls = {
      root: h('section', { class: `box ${open ? '' : 'collapsed'}`, 'data-problem': key, 'aria-label': name }),
      toggle,
      name: nameEl,
      nameText: name,
      bounds,
      count,
      knobIds: b.knobs.map((k) => k.id),
      openForm: (kind, regime) => {
        this.setCollapsed(key, false);
        form.open(kind, regime);
      },
    };
    this.boxEls.set(key, els);
    setChildren(
      els.root,
      h(
        'div',
        { class: 'box-head' },
        toggle,
        title,
        count,
        bounds,
        h('button', { class: 'icon', title: 'add a lower bound or an algorithm for this problem', 'aria-label': `add a bound for ${name}`, on: { click: () => els.openForm() } }, '＋'),
        h('button', { class: 'icon', title: 'remove this problem and its bounds', 'aria-label': `remove ${name}`, on: { click: () => this.removeBox(key, name, b.knobs.length) } }, '×'),
      ),
      h(
        'div',
        { class: 'box-body' },
        b.knobs.length === 0 ? h('div', { class: 'hint empty' }, 'No bounds yet: ＋ adds one.') : null,
        b.knobs.map((k) => this.knobRow(k, key)),
        form.root,
      ),
    );
    return els.root;
  }

  /**
   * A knob in its box. While on: value (slider and number, or formula) on the first line, regime and note on the
   * second; while off, a one-line summary instead of the inputs (CSS).
   */
  private knobRow(k: Knob, box: string): HTMLElement {
    const issue = h('div', { class: 'issue', hidden: true });
    this.issueEls.set(k.id, issue);
    const clip = h('div', { class: 'hint clip', hidden: true, title: 'the regime is clipped to the problem’s limits (they name the same instances: see the inspector)' });
    this.clipEls.set(k.id, clip);
    const summary = h('span', { class: 'knob-summary' });
    const editor = k.exponent !== undefined ? this.exponentEditor(k) : this.formulaEditor(k);
    const power = k.exponent !== undefined ? this.powerEditor(k) : null;
    const id = h('span', { class: 'knob-id', title: `Bound ID ${k.id} (the bounds CSV matches rows to bounds by it)` }, k.id);
    const note = k.note ? h('span', { class: 'note', title: k.note }, k.note) : null;
    const row = h(
      'div',
      { class: `knob ${k.enabled ? '' : 'disabled'}`, 'data-knob': k.id },
      h(
        'div',
        { class: 'knob-head' },
        h('input', {
          type: 'checkbox',
          checked: k.enabled,
          title: 'switch this bound on or off',
          'aria-label': `bound ${k.id} on`,
          on: { change: (e) => this.setKnob(k.id, { enabled: (e.target as HTMLInputElement).checked }) },
        }),
        h('span', { class: `kind kind-${k.kind}`, title: k.kind === 'LB' ? 'lower bound (hypothesis)' : 'upper bound (algorithm)' }, k.kind),
        id,
        editor.main,
        summary,
        h('button', { class: 'icon', title: 'remove this bound', 'aria-label': `remove bound ${k.id}`, on: { click: () => this.removeKnob(k.id) } }, '×'),
      ),
      h(
        'div',
        { class: 'knob-sub' },
        h('input', {
          type: 'text',
          class: 'mono regime',
          value: k.regime ?? '',
          placeholder: k.kind === 'UB' && k.formula !== undefined ? 'all regimes' : 'regime, e.g. n=1, m=2, M=poly',
          title: 'regime: param=growth, … with growth: number (exponent), log, polylog, const[:v|[v1,v2]], poly (log-dependent)',
          'aria-label': `regime of bound ${k.id}`,
          on: { change: (e) => this.setKnob(k.id, { regime: (e.target as HTMLInputElement).value.trim() || undefined }) },
        }),
        note,
      ),
      power,
      editor.preview,
      issue,
      clip,
    );
    this.knobEls.set(k.id, { row, box, summary, id, note, noteText: k.note ?? '' });
    return row;
  }

  private exponentEditor(k: Knob): { main: HTMLElement; preview: null } {
    const x = k.exponent ?? 0;
    const max = Math.max(4, Math.ceil(x * 2));
    const what = this.hasPower(k) ? 'exponent c of the running time 2^{c·n^a}' : 'exponent';
    const current = (): Knob => this.store.get().scenario.knobs.find((y) => y.id === k.id) ?? k;
    const slider = h('input', { type: 'range', min: '0', max: String(max), step: '0.01', value: String(x), title: what, 'aria-label': `exponent of bound ${k.id} (slider)` });
    const num = this.numberInput({
      value: x,
      title: `${what} (any number of decimals; a decimal comma is read as a point)`,
      label: `exponent of bound ${k.id}`,
      current: () => current().exponent ?? 0,
      check: (v) => (v >= 0 ? (k.kind === 'LB' && v === 0 ? 'a lower bound needs an exponent above 0' : null) : 'the exponent must be 0 or more'),
      set: (v) => {
        slider.max = String(Math.max(Number(slider.max), Math.ceil(v)));
        slider.value = String(v);
        this.setKnob(k.id, { exponent: v });
      },
    });
    onSlider(slider, (v) => (num.input.value = String(v)), (v) => this.setKnob(k.id, { exponent: v }, true));
    const toFormula = h(
      'button',
      {
        class: 'link mode',
        title: 'edit as a runtime formula (a formula this bound had is restored)',
        'aria-label': `edit bound ${k.id} as a runtime formula`,
        on: {
          click: () => {
            // The formula it had before "n^c" (unless its exponent changed since), else the knob as a formula at its
            // regime (n^{c}, 2^{c n^{a}}, …), with the numbers as stored.
            const knob = current();
            const before = this.formulasBefore.get(k.id);
            this.formulasBefore.delete(k.id);
            if (before !== undefined && before.exponent === knob.exponent && before.power === knob.power) {
              this.setKnob(k.id, { exponent: undefined, power: undefined, formula: before.formula, regime: before.regime });
              return;
            }
            const regime = knobRegime(this.store.getDerived().model, knob);
            const formula = regime?.timeFormula(knobRate(knob)) ?? `n^{${plainNumber(knob.exponent ?? x)}}`;
            this.setKnob(k.id, { exponent: undefined, power: undefined, formula });
          },
        },
      },
      'ƒ(n)',
    );
    return { main: h('span', { class: 'knob-editor' }, slider, num.input, num.error, toFormula), preview: null };
  }

  /**
   * A number field that checks what is typed (a decimal comma reads as a point): a value that is not a number or that
   * `check` refuses is not applied, the message shows beside the field, and the field shows the current value again.
   */
  private numberInput(o: {
    value: number;
    title: string;
    label: string;
    current: () => number;
    check: (v: number) => string | null;
    set: (v: number) => void;
  }): { input: HTMLInputElement; error: HTMLElement } {
    const error = h('span', { class: 'field-error', hidden: true, role: 'alert' });
    const input = h('input', { type: 'text', inputmode: 'decimal', class: 'num', value: String(o.value), title: o.title, 'aria-label': o.label });
    // (typing again clears the message about the last entry: retyping the kept value gives no change event, and the
    // message stayed)
    input.addEventListener('input', () => {
      if (error.hidden) return;
      error.hidden = true;
      error.textContent = '';
      input.setAttribute('aria-invalid', 'false');
    });
    input.addEventListener('change', () => {
      const v = parseDecimal(input.value);
      const problem = v === null ? `"${input.value.trim()}" is not a number` : o.check(v);
      input.setAttribute('aria-invalid', String(problem !== null));
      error.textContent = problem === null ? '' : `${problem} (kept ${plainNumber(o.current())})`;
      error.hidden = problem === null;
      if (problem !== null || v === null) {
        input.value = String(o.current());
        return;
      }
      input.value = String(v);
      o.set(v);
    });
    return { input, error };
  }

  /**
   * Whether an exponent knob gets a power control: on problems of exponential time (2^{c·n^a}), or when it has a
   * power other than 1 (2^{c·log^a n} at a polynomial regime, e.g. from a bounds CSV).
   */
  private hasPower(k: Knob): boolean {
    const p = findProblem(this.store.getDerived().model, k.problem);
    return p?.timeType === 'exp' || (k.power !== undefined && k.power !== 1);
  }

  /**
   * The power a of an exponent knob's running time 2^{c·n^a} (slider and number), and the running time rendered; null
   * for knobs without power control (see hasPower).
   */
  private powerEditor(k: Knob): HTMLElement | null {
    if (!this.hasPower(k)) return null;
    const a = k.power ?? 1;
    const time = h('span', { class: 'knob-time' });
    const regimeOf = (): ReturnType<typeof knobRegime> => knobRegime(this.store.getDerived().model, this.store.get().scenario.knobs.find((y) => y.id === k.id) ?? k);
    const ref = regimeOf();
    const n = ref !== null && ref.expScale ? ref.normalizerName : 'n';
    const shape = ref === null || ref.expScale ? `2^{c·${n}^a}` : `2^{c·log^a ${ref.normalizerName}}`;
    const show = (power: number): void => {
      const knob = this.store.get().scenario.knobs.find((y) => y.id === k.id) ?? k;
      const regime = regimeOf();
      time.innerHTML = regime === null ? '' : `= ${texHtml(regime.timeTex({ power, exponent: knob.exponent ?? 0 }))}`;
    };
    const title = `power a of the running time ${shape} (1: ${ref === null || ref.expScale ? `2^{c·${n}}` : `${ref.normalizerName}^c`}; below 1 subexponential, e.g. 2^{${n}^0.99})`;
    const slider = h('input', { type: 'range', min: '0.05', max: String(Math.max(2, Math.ceil(a))), step: '0.01', value: String(a), title, 'aria-label': `power of bound ${k.id} (slider)` });
    const set = (v: number, debounce: boolean): void => {
      this.setKnob(k.id, { power: v }, debounce);
      show(v);
    };
    const num = this.numberInput({
      value: a,
      title,
      label: `power of bound ${k.id}`,
      current: () => this.store.get().scenario.knobs.find((y) => y.id === k.id)?.power ?? 1,
      check: (v) => (v > 0 ? null : 'the power must be above 0'),
      set: (v) => {
        slider.max = String(Math.max(Number(slider.max), Math.ceil(v)));
        slider.value = String(v);
        set(v, false);
      },
    });
    onSlider(
      slider,
      (v) => {
        num.input.value = String(v);
        show(v);
      },
      (v) => set(v, true),
    );
    this.timeEls.set(k.id, () => show(this.store.get().scenario.knobs.find((y) => y.id === k.id)?.power ?? 1));
    show(a);
    return h('div', { class: 'knob-power' }, h('span', { class: 'knob-power-label', title }, 'power a'), slider, num.input, num.error, time);
  }

  private formulaEditor(k: Knob): { main: HTMLElement; preview: HTMLElement } {
    // The rendered preview is shown while editing and when the formula does not parse.
    const preview = h('div', { class: 'preview' });
    let focused = false;
    const showPreview = (tex: string): void => {
      try {
        parseExpr(tex);
        preview.innerHTML = texHtml(tex);
        preview.classList.remove('bad');
        preview.hidden = !focused;
      } catch (e) {
        preview.textContent = (e as Error).message;
        preview.classList.add('bad');
        preview.hidden = false;
      }
    };
    showPreview(k.formula ?? '');
    const input = h('input', {
      type: 'text',
      class: 'mono',
      value: k.formula ?? '',
      title: 'running time in the problem’s parameters, e.g. n^2 d, \\min(n^{\\omega}, m^{2\\omega/(\\omega+1)})',
      'aria-label': `running time of bound ${k.id}`,
    });
    input.addEventListener('input', () => showPreview(input.value));
    input.addEventListener('focus', () => ((focused = true), showPreview(input.value)));
    input.addEventListener('blur', () => ((focused = false), showPreview(input.value)));
    input.addEventListener('change', () => this.setKnob(k.id, { formula: input.value }));
    const toExponent = h(
      'button',
      {
        class: 'link mode',
        title: 'edit as a plain exponent n^c at a regime (ƒ(n) brings the formula back)',
        'aria-label': `edit bound ${k.id} as a plain exponent`,
        on: {
          click: () => {
            const knob = this.store.get().scenario.knobs.find((y) => y.id === k.id);
            const change = this.formulaAsExponent(k.id);
            if (knob?.formula !== undefined) this.formulasBefore.set(k.id, { formula: knob.formula, regime: knob.regime, exponent: change.exponent, power: change.power });
            this.setKnob(k.id, change);
          },
        },
      },
      'n^c',
    );
    return { main: h('span', { class: 'knob-editor formula' }, input, toExponent), preview };
  }

  /**
   * The change that turns a formula knob into an exponent knob: its running time as an exponent and a power at the
   * knob's regime (exponent 2 if it does not evaluate there to a finite rate). A knob without a regime (an algorithm
   * for every regime) gets its problem's main regime, which an exponent needs.
   */
  private formulaAsExponent(id: string): Partial<Knob> {
    const k = this.store.get().scenario.knobs.find((y) => y.id === id);
    const { model } = this.store.getDerived();
    const main = k === undefined ? undefined : findProblem(model, k.problem)?.regimeSpecs[0];
    const base: Partial<Knob> = { formula: undefined, exponent: 2, ...(k?.regime === undefined && main !== undefined ? { regime: main } : {}) };
    const regime = k === undefined ? null : knobRegime(model, k);
    if (k === undefined || regime === null || k.formula === undefined) return base;
    try {
      const r = formulaRate(parseExpr(k.formula), regime, constantEnv(model, this.store.get().scenario.constants));
      if (!finiteRate(r) || r.power === 0) return base;
      // (rounded only to 12 decimals, far below every tolerance, to drop floating-point noise such as 0.30000000000000004)
      const exponent = Math.round(r.exponent * 1e12) / 1e12;
      const power = knobPower({ power: r.power });
      return { ...base, exponent, ...(power !== 1 ? { power } : {}) };
    } catch {
      return base;
    }
  }

  /** The form for a new bound of a box's problem (hidden until opened). */
  private boundForm(key: string, problem: Problem | undefined): { root: HTMLElement; open(kind?: KnobKind, regime?: string): void } {
    const group = `kind-${key}`;
    const lb = h('input', { type: 'radio', name: group, value: 'LB', checked: true });
    const ub = h('input', { type: 'radio', name: group, value: 'UB' });
    const main = problem?.regimeSpecs[0];
    const regime = h('input', { type: 'text', class: 'mono', 'aria-label': 'regime of the new bound' });
    const value = h('input', {
      type: 'text',
      class: 'mono',
      placeholder: problem?.timeType === 'exp' ? 'exponent (e.g. 1) or formula (e.g. 2^{n^{0.99}})' : 'exponent (e.g. 2) or formula (e.g. n^2 d)',
      'aria-label': 'exponent or running time of the new bound',
    });
    const msg = h('div', { class: 'issue', hidden: true });
    const placeholders = (): void => {
      regime.placeholder = lb.checked ? `empty: ${main ?? 'the main regime'}` : `empty: ${main ?? 'the main regime'} (exponent) / all (formula)`;
    };
    lb.addEventListener('change', placeholders);
    ub.addEventListener('change', placeholders);
    placeholders();
    const fail = (m: string): void => {
      msg.textContent = m;
      msg.hidden = false;
    };
    const add = (): void => {
      const kind: KnobKind = ub.checked ? 'UB' : 'LB';
      const v = value.value.trim();
      if (v === '') return fail('give an exponent or a running time');
      // (a plain number, also with a decimal comma, is an exponent; anything else a formula)
      const number = parseDecimal(v);
      const isNumber = number !== null;
      if (isNumber && number < 0) return fail('exponents must be nonnegative');
      if (isNumber && kind === 'LB' && number === 0) return fail('a lower bound needs an exponent above 0');
      // An empty regime means the problem's main regime, except for UB formulas, which then apply everywhere.
      const regimeText = regime.value.trim() || (kind === 'UB' && !isNumber ? '' : (main ?? ''));
      const errors: string[] = [];
      const spec = validateKnobSpec(
        { problem: problem?.id ?? key, kind, ...(regimeText ? { regime: regimeText } : {}), ...(isNumber ? { exponent: number } : { formula: v }) },
        'bound',
        errors,
      );
      if (!spec) return fail(errors.join('; '));
      // The regime and the formula as the engine reads them: an error here would leave a bound that does nothing.
      let probes: Regime[] = [];
      if (problem !== undefined && problem.isStatic) {
        try {
          probes = regimesFromSpec(problem, regimeText || (main ?? ''));
        } catch (e) {
          return fail(`regime: ${(e as Error).message}`);
        }
      }
      if (!isNumber) {
        let expr;
        try {
          expr = parseExpr(v);
        } catch (e) {
          return fail(`formula: ${(e as Error).message}`);
        }
        const env = constantEnv(this.store.getDerived().model, this.store.get().scenario.constants);
        let why = '';
        const ok =
          probes.length === 0 ||
          probes.some((r) => {
            try {
              if (finiteRate(formulaRate(expr, r, env))) return true;
              why = 'it gives no finite running time';
            } catch (e) {
              why = (e as Error).message;
            }
            return false;
          });
        if (!ok) return fail(`formula: ${why} (parameters: ${problem!.params.join(', ')})`);
      }
      msg.hidden = true;
      this.edit((s) => ({
        ...s,
        scenario: { ...s.scenario, problems: this.order(s), knobs: [...s.scenario.knobs, { ...spec, id: newKnobId([...s.scenario.knobs, ...initialScenario(s.config).knobs], spec.kind), enabled: true }] },
      }));
    };
    const root = h(
      'div',
      { class: 'add-bound', hidden: true },
      h('div', { class: 'kind-choice' }, h('label', {}, lb, ' lower bound (LB)'), h('label', {}, ub, ' algorithm (UB)')),
      h('label', { class: 'field' }, h('span', {}, 'regime'), regime),
      h('label', { class: 'field' }, h('span', {}, 'value'), value),
      h(
        'div',
        { class: 'buttons' },
        h('button', { class: 'primary', on: { click: add } }, 'Add'),
        h('button', { on: { click: () => (root.hidden = true) } }, 'Cancel'),
      ),
      msg,
    );
    for (const input of [regime, value]) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') add();
        else if (e.key === 'Escape') root.hidden = true;
      });
    }
    return {
      root,
      open: (kind, regimeSpec) => {
        root.hidden = false;
        if (kind) (kind === 'UB' ? ub : lb).checked = true;
        placeholders();
        regime.value = regimeSpec ?? '';
        msg.hidden = true;
        root.scrollIntoView({ block: 'nearest' });
        value.focus();
      },
    };
  }

  /** "＋ Problem": a new box at the end (or the problem's existing box, shown). */
  private addProblem(model: Model): HTMLElement {
    const listId = 'problem-list';
    const datalist = h(
      'datalist',
      { id: listId },
      [...model.problems.values()].filter((p) => p.isStatic).map((p) => h('option', { value: p.id })),
    );
    const input = h('input', { type: 'text', list: listId, placeholder: 'Family / Variation', 'aria-label': 'problem to add' });
    const msg = h('div', { class: 'issue', hidden: true });
    const add = (): void => {
      const p = findProblem(this.store.getDerived().model, input.value);
      if (!p) {
        msg.textContent = 'not a problem of the sheet: pick one from the list';
        msg.hidden = false;
        return;
      }
      msg.hidden = true;
      const box = this.ensureBox(this.canonical()(p.id));
      if (!box) return;
      box.root.scrollIntoView({ block: 'nearest' });
      flash(box.root);
      if (box.root.querySelector('.knob') === null) box.openForm();
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') add();
    });
    return h(
      'div',
      { class: 'add-problem' },
      h('label', { class: 'field' }, h('span', {}, '＋ Problem'), input, h('button', { on: { click: add } }, 'Add')),
      msg,
      datalist,
    );
  }

  /** Open the new-bound form of a problem's box, prefilled (the inspector's "add knob here"); adds the box if needed. */
  prefill(problemId: string, kind: KnobKind, regimeSpec: string): void {
    this.ensureBox(this.canonical()(problemId))?.openForm(kind, regimeSpec);
  }

  private constants(): HTMLElement {
    const s = this.store.get();
    const entries = Object.entries(s.config.constants);
    if (entries.length === 0) return h('div');
    return h(
      'div',
      { class: 'constants' },
      h('h3', {}, 'Constants'),
      entries.flatMap(([name, def]) => {
        const value = s.scenario.constants[name] ?? def.value;
        const slider = h('input', { type: 'range', min: String(def.min), max: String(def.max), step: '0.001', value: String(value), 'aria-label': `${def.label} (slider)` });
        // (values from papers, e.g. one not yet refereed, a click away; the current one is marked, and the mark follows
        // the value: it stayed on the refereed default while another value was set)
        const presetButtons = (def.presets ?? []).map((p) =>
          h(
            'button',
            {
              class: 'link preset',
              title: `${p.title ?? p.label}: set ${def.label} to ${p.value}`,
              on: {
                click: () => {
                  slider.value = String(p.value);
                  num.input.value = String(p.value);
                  set(p.value, false);
                },
              },
            },
            p.label,
          ),
        );
        const markPresets = (v: number): void =>
          presetButtons.forEach((b, i) => {
            const current = Math.abs(def.presets![i]!.value - v) < 1e-12;
            b.classList.toggle('current', current);
            b.setAttribute('aria-pressed', String(current));
          });
        const set = (v: number, debounce: boolean): void => {
          markPresets(v);
          this.edit((st) => ({ ...st, scenario: { ...st.scenario, constants: { ...st.scenario.constants, [name]: v } } }), debounce);
        };
        const num = this.numberInput({
          value,
          title: `${def.label}: from ${def.min} to ${def.max}`,
          label: def.label,
          current: () => this.store.get().scenario.constants[name] ?? def.value,
          check: (v) => (v >= def.min && v <= def.max ? null : `from ${def.min} to ${def.max}`),
          set: (v) => {
            slider.value = String(v);
            set(v, false);
          },
        });
        onSlider(
          slider,
          (v) => {
            num.input.value = String(v);
            markPresets(v);
          },
          (v) => set(v, true),
        );
        markPresets(value);
        const field = h('label', { class: 'field', title: def.label }, h('span', { html: texHtml(identifierTex(name)) }), slider, num.input, num.error);
        const presets = presetButtons.length === 0 ? null : h('div', { class: 'constant-presets' }, presetButtons);
        const shown: Array<HTMLElement | null> = [field, presets, def.note ? h('div', { class: 'note constant-note' }, def.note) : null];
        return shown.filter((x): x is HTMLElement => x !== null);
      }),
    );
  }

  private settings(): HTMLElement {
    const st = this.store.get().scenario.settings;
    this.settingsShown = st;
    const intField = (label: string, key: 'maxDepthUB' | 'gridPoints' | 'refineRounds', min: number, max: number, title: string): HTMLElement => {
      const num = this.numberInput({
        value: st[key],
        title,
        label,
        current: () => this.store.get().scenario.settings[key],
        check: (v) => (Number.isInteger(v) && v >= min && v <= max ? null : `a whole number from ${min} to ${max}`),
        set: (v) => this.setSettings({ [key]: v } as Partial<Settings>),
      });
      return h('label', { class: 'field', title }, h('span', {}, label), num.input, num.error);
    };
    const el = h(
      'details',
      { class: 'settings', open: this.settingsOpen, on: { toggle: () => (this.settingsOpen = (el as HTMLDetailsElement).open) } },
      h('summary', {}, 'Settings'),
      intField(
        'UB detours',
        'maxDepthUB',
        0,
        MAX_DEPTH_UB,
        `upper bounds: how many reductions in a row a derivation may take through regimes besides those the search starts from (configured, of algorithms, or pinned; between those, derivations have no length limit; neither do lower bounds). At most ${MAX_DEPTH_UB}: on the built-in sheet ${MAX_DEPTH_UB} finds every bound that 4 to 6 find, and more detours only add time`,
      ),
      intField('grid points', 'gridPoints', 2, 41, 'grid points per continuous free parameter'),
      intField('refinement', 'refineRounds', 0, 40, 'rounds of local refinement after the grid search (each halves the step)'),
      h(
        'label',
        { class: 'field', title: 'rows whose Reduction Runtime has no formula' },
        h('span', {}, 'unknown RT'),
        h(
          'select',
          { on: { change: (e) => this.setSettings({ unknownRT: (e.target as HTMLSelectElement).value as Settings['unknownRT'] }) } },
          h('option', { value: 'assume-negligible', selected: st.unknownRT === 'assume-negligible' }, 'assume negligible'),
          h('option', { value: 'block', selected: st.unknownRT === 'block' }, 'block the row'),
        ),
      ),
      h(
        'label',
        { class: 'field check' },
        h('input', {
          type: 'checkbox',
          checked: st.useRandomized,
          on: { change: (e) => this.setSettings({ useRandomized: (e.target as HTMLInputElement).checked }) },
        }),
        h('span', {}, 'use randomized reductions'),
      ),
      st.disabledRows.length > 0
        ? h(
            'div',
            { class: 'field' },
            h('span', {}, `disabled rows: ${st.disabledRows.join(', ')}`),
            h('button', { class: 'link', on: { click: () => this.setSettings({ disabledRows: [] }) } }, 'enable all'),
          )
        : null,
    );
    this.settingsEl = el;
    return el;
  }
}

/** Whether a formula parses (its preview shows the error if not). */
function parses(tex: string): boolean {
  try {
    parseExpr(tex);
    return true;
  } catch {
    return false;
  }
}

/**
 * The events of a slider: `preview` shows each value it passes (the number beside it), `commit` sets one. While the
 * pointer drags it, only the value where it is let go is set (the change event), as each value set starts an analysis
 * that holds the page for about a second: dragging used to stall (25 moves took 12 s). Keyboard steps are set as they
 * come (the store waits for a pause before analysing).
 */
function onSlider(slider: HTMLInputElement, preview: (v: number) => void, commit: (v: number) => void): void {
  let dragging = false;
  let committed = Number(slider.value);
  const set = (): void => {
    const v = Number(slider.value);
    if (v === committed) return;
    committed = v;
    commit(v);
  };
  slider.addEventListener('pointerdown', () => {
    dragging = true;
    committed = Number(slider.value);
  });
  slider.addEventListener('input', () => {
    preview(Number(slider.value));
    if (!dragging) set();
  });
  slider.addEventListener('change', () => {
    dragging = false;
    set();
  });
  // (a drag that ends without a change event, e.g. cancelled by the system)
  for (const type of ['pointerup', 'pointercancel', 'blur'] as const) {
    slider.addEventListener(type, () => {
      if (!dragging) return;
      dragging = false;
      set();
    });
  }
}
