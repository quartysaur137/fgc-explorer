/**
 * Resizable and hideable side and bottom panels (SPEC §7).
 *
 * Sizes and visibility are UI preferences (persisted with the others). While a splitter is dragged only CSS variables
 * change; the final size is committed to the store when the pointer is released, so dragging never re-renders views.
 */

import type { Store } from './store';

export type PanelName = 'left' | 'right' | 'bottom';

export interface PanelPref {
  /** Visible? */
  readonly open: boolean;
  /** Width (left, right) or height (bottom) in CSS pixels. */
  readonly size: number;
}

export type PanelPrefs = Readonly<Record<PanelName, PanelPref>>;

export const PANEL_NAMES: readonly PanelName[] = ['left', 'right', 'bottom'];

/** Panel sizes for a 1600 × 1000 window (see defaultPanels). */
export const DEFAULT_PANELS: PanelPrefs = {
  left: { open: true, size: 336 },
  right: { open: true, size: 416 },
  bottom: { open: true, size: 300 },
};

/** Default panels for a window of this size: smaller windows get narrower panels, so the graph keeps room. */
export function defaultPanels(windowWidth: number, windowHeight: number): PanelPrefs {
  const within = (x: number, lo: number, hi: number): number => Math.round(Math.min(hi, Math.max(lo, x)));
  return {
    left: { open: true, size: within(0.21 * windowWidth, 260, 340) },
    right: { open: true, size: within(0.26 * windowWidth, 300, 420) },
    bottom: { open: true, size: within(0.3 * windowHeight, 160, 300) },
  };
}

/** Smallest size of each panel, and the space the graph keeps at least (CSS pixels). */
const MIN_SIZE: Readonly<Record<PanelName, number>> = { left: 220, right: 260, bottom: 100 };
const MIN_GRAPH_WIDTH = 320;
const MIN_GRAPH_HEIGHT = 160;

/** Size kept within [the panel's minimum, what leaves the graph its minimum] (`room`: space shared with the graph). */
export function clampPanelSize(name: PanelName, size: number, room: number): number {
  const max = Math.max(MIN_SIZE[name], room - (name === 'bottom' ? MIN_GRAPH_HEIGHT : MIN_GRAPH_WIDTH));
  return Math.round(Math.min(max, Math.max(MIN_SIZE[name], size)));
}

/**
 * The sizes to show the panels at in a main area of `width` × `height` CSS pixels (`height`: the center column without
 * its toolbar): the preferred ones where they leave the graph its minimum, else the open side panels shrunk in proportion
 * to their room above their minimum (down to it), and the bottom panel to what leaves the graph its minimum height. The
 * preferences stay as they are, so a larger window shows them again.
 */
export function fitPanelSizes(prefs: PanelPrefs, width: number, height: number): Record<PanelName, number> {
  const out: Record<PanelName, number> = { left: prefs.left.size, right: prefs.right.size, bottom: prefs.bottom.size };
  const sides = (['left', 'right'] as const).filter((n) => prefs[n].open);
  const total = sides.reduce((sum, n) => sum + out[n], 0);
  const room = width - MIN_GRAPH_WIDTH;
  if (sides.length > 0 && total > room) {
    const mins = sides.reduce((sum, n) => sum + MIN_SIZE[n], 0);
    const above = total - mins;
    const left = Math.max(0, room - mins);
    for (const n of sides) out[n] = Math.round(MIN_SIZE[n] + (above > 0 ? (Math.max(0, out[n] - MIN_SIZE[n]) * left) / above : 0));
  }
  if (prefs.bottom.open && height > 0) out.bottom = Math.round(Math.max(MIN_SIZE.bottom, Math.min(out.bottom, height - MIN_GRAPH_HEIGHT)));
  return out;
}

/** Panel preferences from saved data; anything missing or invalid takes the default. Never throws. */
export function validatePanelPrefs(x: unknown, defaults: PanelPrefs = DEFAULT_PANELS): PanelPrefs {
  const out: Record<PanelName, PanelPref> = { ...defaults };
  if (typeof x !== 'object' || x === null) return out;
  for (const name of PANEL_NAMES) {
    const p = (x as Record<string, unknown>)[name];
    if (typeof p !== 'object' || p === null) continue;
    const { open, size } = p as Record<string, unknown>;
    out[name] = {
      open: typeof open === 'boolean' ? open : defaults[name].open,
      size: typeof size === 'number' && Number.isFinite(size) && size > 0 ? Math.round(size) : defaults[name].size,
    };
  }
  return out;
}

export interface PanelElements {
  /** The grid holding left panel, splitter, center, splitter, right panel. */
  readonly main: HTMLElement;
  /** The column holding toolbar, graph, splitter and bottom panel. */
  readonly center: HTMLElement;
  readonly splitters: Readonly<Record<PanelName, HTMLElement>>;
  /** Show/hide buttons (aria-pressed reflects visibility). */
  readonly toggles: Readonly<Record<PanelName, HTMLElement>>;
  /** Hides all panels, or shows them all when all are hidden. */
  readonly maximize: HTMLElement;
}

export class Panels {
  constructor(
    private readonly els: PanelElements,
    private readonly store: Store,
  ) {
    for (const name of PANEL_NAMES) {
      this.wireSplitter(name);
      els.toggles[name].addEventListener('click', () => this.toggle(name));
    }
    els.maximize.addEventListener('click', () => this.toggleAll());
    this.apply();
    store.subscribe((changes) => {
      if (changes.has('prefs')) this.apply();
    });
    // (sizes saved in a larger window are shown smaller in a smaller one, so that the graph keeps its room)
    let queued = false;
    window.addEventListener('resize', () => {
      if (queued) return;
      queued = true;
      requestAnimationFrame(() => {
        queued = false;
        this.apply();
      });
    });
  }

  private get prefs(): PanelPrefs {
    return this.store.get().prefs.panels;
  }

  private set(name: PanelName, patch: Partial<PanelPref>): void {
    this.store.update((s) => ({
      ...s,
      prefs: { ...s.prefs, panels: { ...s.prefs.panels, [name]: { ...s.prefs.panels[name], ...patch } } },
    }));
  }

  toggle(name: PanelName, open = !this.prefs[name].open): void {
    if (open !== this.prefs[name].open) this.set(name, { open });
  }

  /** The panels that were open when toggleAll hid them all (shown again by the next toggleAll). */
  private hiddenByToggleAll: PanelName[] | null = null;

  /** Hide every panel, or, if all are hidden, show again those that were open (all, if none was or it is unknown). */
  toggleAll(): void {
    const allHidden = PANEL_NAMES.every((n) => !this.prefs[n].open);
    let show: readonly PanelName[] = [];
    if (allHidden) {
      show = this.hiddenByToggleAll !== null && this.hiddenByToggleAll.length > 0 ? this.hiddenByToggleAll : PANEL_NAMES;
      this.hiddenByToggleAll = null;
    } else this.hiddenByToggleAll = PANEL_NAMES.filter((n) => this.prefs[n].open);
    this.store.update((s) => {
      const panels = { ...s.prefs.panels };
      for (const n of PANEL_NAMES) panels[n] = { ...panels[n], open: allHidden && show.includes(n) };
      return { ...s, prefs: { ...s.prefs, panels } };
    });
  }

  /** Space a panel shares with the graph (CSS pixels). */
  private room(name: PanelName): number {
    if (name === 'bottom') {
      const toolbar = this.els.center.querySelector<HTMLElement>('.toolbar')?.offsetHeight ?? 0;
      return this.els.center.clientHeight - toolbar;
    }
    const other: PanelName = name === 'left' ? 'right' : 'left';
    const otherW = this.prefs[other].open ? this.prefs[other].size : 0;
    return this.els.main.clientWidth - otherW;
  }

  /** Reflect the preferences in CSS variables, classes and button states. */
  private apply(): void {
    const { main } = this.els;
    const toolbar = this.els.center.querySelector<HTMLElement>('.toolbar')?.offsetHeight ?? 0;
    const fit = fitPanelSizes(this.prefs, main.clientWidth, this.els.center.clientHeight - toolbar);
    for (const name of PANEL_NAMES) {
      const p = this.prefs[name];
      this.setSize(name, fit[name]);
      main.classList.toggle(`hide-${name}`, !p.open);
      this.els.toggles[name].setAttribute('aria-pressed', String(p.open));
      this.els.splitters[name].setAttribute('aria-valuenow', String(p.size));
    }
    this.els.maximize.setAttribute('aria-pressed', String(PANEL_NAMES.every((n) => !this.prefs[n].open)));
  }

  private setSize(name: PanelName, size: number): void {
    this.els.main.style.setProperty(`--${name}-size`, `${size}px`);
  }

  private wireSplitter(name: PanelName): void {
    const splitter = this.els.splitters[name];
    const vertical = name !== 'bottom';
    // Dragging the left splitter right, the right splitter left, or the bottom splitter up enlarges the panel.
    const sign = name === 'left' ? 1 : -1;
    splitter.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      e.preventDefault();
      splitter.setPointerCapture(e.pointerId);
      const start = vertical ? e.clientX : e.clientY;
      const startSize = this.prefs[name].size;
      const room = this.room(name);
      let size = startSize;
      document.body.classList.add('resizing', vertical ? 'resizing-x' : 'resizing-y');
      splitter.classList.add('active');
      const move = (ev: PointerEvent): void => {
        size = clampPanelSize(name, startSize + sign * ((vertical ? ev.clientX : ev.clientY) - start), room);
        this.setSize(name, size);
      };
      const end = (): void => {
        splitter.removeEventListener('pointermove', move);
        splitter.removeEventListener('pointerup', end);
        splitter.removeEventListener('pointercancel', end);
        document.body.classList.remove('resizing', 'resizing-x', 'resizing-y');
        splitter.classList.remove('active');
        if (size !== startSize) this.set(name, { size });
      };
      splitter.addEventListener('pointermove', move);
      splitter.addEventListener('pointerup', end);
      splitter.addEventListener('pointercancel', end);
    });
    // Double-click: back to the default size for this window.
    splitter.addEventListener('dblclick', () => {
      const size = defaultPanels(window.innerWidth, window.innerHeight)[name].size;
      this.set(name, { size: clampPanelSize(name, size, this.room(name)) });
    });
    // Keyboard: arrow keys resize (Shift: faster).
    splitter.addEventListener('keydown', (e) => {
      const keys: Readonly<Record<string, number>> = vertical ? { ArrowLeft: -1, ArrowRight: 1 } : { ArrowUp: 1, ArrowDown: -1 };
      const dir = keys[e.key];
      if (dir === undefined) return;
      e.preventDefault();
      const step = (e.shiftKey ? 60 : 20) * dir * (vertical ? sign : 1);
      this.set(name, { size: clampPanelSize(name, this.prefs[name].size + step, this.room(name)) });
    });
  }
}
