/**
 * Bottom panel: sortable problems table, reductions table, diagnostics.
 */

import { STATUS_ORDER } from '../engine/analysis';
import { ROW_STATUS_TEXT } from '../model/model';
import { h, setChildren } from './dom';
import { boundsLine, formatDuration, problemLabel, statusBadge } from './format';
import { refAttrs } from './hover';
import { isAdditive } from './selection';
import { BottomTab } from './state';
import { Store } from './store';
import { plainText, texEl } from './tex';

/** Handlers of a clickable table row: a click selects (Shift / Ctrl / ⌘: adds or removes) without selecting text. */
function rowClick(select: (additive: boolean) => void): Record<string, (e: Event) => void> {
  return {
    click: (e) => select(isAdditive(e as MouseEvent)),
    mousedown: (e) => {
      if ((e as MouseEvent).shiftKey) e.preventDefault();
    },
  };
}

type SortKey = 'problem' | 'family' | 'status' | 'lb' | 'ub' | 'regimes';

export class TablesView {
  private sortKey: SortKey = 'status';
  private sortAsc = true;
  private onlyUnused = false;

  constructor(
    private readonly tabsEl: HTMLElement,
    private readonly bodyEl: HTMLElement,
    private readonly store: Store,
    private readonly cb: { selectProblem(id: string, additive: boolean): void; selectRow(id: string, additive: boolean): void },
  ) {
    store.subscribe((changes) => {
      if (changes.has('analysis') || changes.has('model') || changes.has('prefs') || changes.has('selection')) this.render();
    });
    this.render();
  }

  private setTab(tab: BottomTab): void {
    this.store.update((s) => ({ ...s, prefs: { ...s.prefs, bottomTab: tab } }));
  }

  render(): void {
    const tab = this.store.get().prefs.bottomTab;
    const { model } = this.store.getDerived();
    const notOk = model.rows.filter((r) => r.status !== 'ok').length;
    setChildren(
      this.tabsEl,
      (
        [
          ['problems', `Problems (${model.problems.size})`],
          ['rows', `Reductions (${model.rows.length}, ${notOk} not used)`],
          ['diagnostics', 'Diagnostics'],
        ] as const
      ).map(([id, label]) => h('button', { class: `tab ${tab === id ? 'active' : ''}`, on: { click: () => this.setTab(id) } }, label)),
    );
    if (tab === 'problems') this.problems();
    else if (tab === 'rows') this.rows();
    else this.diagnostics();
  }

  private header(label: string, key: SortKey): HTMLElement {
    const active = this.sortKey === key;
    return h(
      'th',
      {
        class: `sortable ${active ? 'active' : ''}`,
        on: {
          click: () => {
            if (this.sortKey === key) this.sortAsc = !this.sortAsc;
            else {
              this.sortKey = key;
              this.sortAsc = true;
            }
            this.render();
          },
        },
      },
      label,
      active ? (this.sortAsc ? ' ▲' : ' ▼') : '',
    );
  }

  private problems(): void {
    const { analysis } = this.store.getDerived();
    const q = this.store.get().prefs.search.trim().toLowerCase();
    const selected = new Set(this.store.get().selection.flatMap((x) => (x.kind === 'problem' ? [x.id] : [])));
    const items = [...analysis.summaries.values()].filter((s) => q === '' || s.problem.id.toLowerCase().includes(q) || problemLabel(s.problem).toLowerCase().includes(q));
    const key = (s: (typeof items)[number]): string | number => {
      switch (this.sortKey) {
        case 'problem':
          return problemLabel(s.problem).toLowerCase();
        case 'family':
          return s.problem.family.toLowerCase();
        case 'status':
          return STATUS_ORDER.indexOf(s.status) * 1000 + (s.problem.isStatic ? 0 : 500);
        case 'lb':
          return s.primary?.lb?.exponent ?? -1;
        case 'ub':
          return s.primary?.ub?.exponent ?? Infinity;
        case 'regimes':
          return s.regimes.length;
      }
    };
    items.sort((a, b) => {
      const ka = key(a);
      const kb = key(b);
      const c = ka < kb ? -1 : ka > kb ? 1 : problemLabel(a.problem).localeCompare(problemLabel(b.problem));
      return this.sortAsc ? c : -c;
    });
    setChildren(
      this.bodyEl,
      h(
        'table',
        { class: 'grid data' },
        h(
          'thead',
          {},
          h('tr', {}, this.header('Problem', 'problem'), this.header('Family', 'family'), this.header('Status', 'status'), h('th', {}, 'Primary regime'), this.header('Bounds', 'lb'), this.header('#Regimes', 'regimes')),
        ),
        h(
          'tbody',
          {},
          items.map((s) =>
            h(
              'tr',
              {
                class: `clickable ${selected.has(s.problem.id) ? 'selected' : ''}`,
                ...refAttrs({ kind: 'problem', id: s.problem.id }),
                on: rowClick((add) => this.cb.selectProblem(s.problem.id, add)),
              },
              h('td', {}, problemLabel(s.problem)),
              h('td', { class: 'muted' }, plainText(s.problem.family)),
              h('td', {}, s.problem.isStatic ? statusBadge(s.status) : h('span', { class: 'hint' }, 'dynamic')),
              h('td', { class: 'small' }, s.primary ? texEl(s.primary.regime.describeTex()) : ''),
              h('td', { class: 'mono nowrap' }, boundsLine(s.primary)),
              h('td', { class: 'num' }, String(s.regimes.length)),
            ),
          ),
        ),
      ),
    );
  }

  private rows(): void {
    const { model, analysis } = this.store.getDerived();
    const q = this.store.get().prefs.search.trim().toLowerCase();
    const selected = new Set(this.store.get().selection.flatMap((x) => (x.kind === 'row' ? [x.id] : [])));
    const items = model.rows.filter(
      (r) => (!this.onlyUnused || r.status !== 'ok') && (q === '' || r.id === q || r.source.toLowerCase().includes(q) || r.target.toLowerCase().includes(q)),
    );
    setChildren(
      this.bodyEl,
      h(
        'label',
        { class: 'check' },
        h('input', { type: 'checkbox', checked: this.onlyUnused, on: { change: (e) => ((this.onlyUnused = (e.target as HTMLInputElement).checked), this.render()) } }),
        ' only reductions the engine does not use',
      ),
      h(
        'table',
        { class: 'grid data' },
        h('thead', {}, h('tr', {}, h('th', {}, 'ID'), h('th', {}, 'From'), h('th', {}, 'To'), h('th', {}, 'Status'), h('th', {}, 'Used'), h('th', {}, 'Message'))),
        h(
          'tbody',
          {},
          items.map((r) => {
            const use = analysis.rowUse.get(r.id);
            return h(
              'tr',
              { class: `clickable ${selected.has(r.id) ? 'selected' : ''}`, ...refAttrs({ kind: 'row', id: r.id }), on: rowClick((add) => this.cb.selectRow(r.id, add)) },
              h('td', { class: 'num' }, r.id),
              h('td', {}, plainText(r.source)),
              h('td', {}, plainText(r.target)),
              h('td', {}, h('span', { class: `badge row-${r.status}` }, ROW_STATUS_TEXT[r.status])),
              h('td', { class: 'num' }, use ? `${use.lb} LB / ${use.ub} UB` : ''),
              h('td', { class: 'small' }, r.messages[0] ?? ''),
            );
          }),
        ),
      ),
    );
  }

  private diagnostics(): void {
    const { model, analysis, sheetWarnings } = this.store.getDerived();
    const lbCount = [...analysis.lower.facts.values()].reduce((n, m) => n + m.size, 0);
    const items: HTMLElement[] = [
      h(
        'p',
        {},
        `Analysis: ${lbCount} lower-bound facts (${analysis.lower.pops} propagation steps), ${analysis.upper.queryCount} upper-bound queries, ${formatDuration(analysis.elapsedMs)}.`,
      ),
    ];
    const section = (title: string, lines: string[]): void => {
      if (lines.length === 0) return;
      items.push(h('h4', {}, title), h('ul', {}, lines.map((l) => h('li', {}, l))));
    };
    section('Knob problems', [...analysis.knobIssues].map(([id, m]) => `${analysis.scenario.knobs.find((k) => k.id === id)?.problem ?? id}: ${m}`));
    section(
      'Inconsistencies (a reduction beats a lower bound without using its target)',
      analysis.lower.inconsistencies.map((i) => `row ${i.rowId} from ${i.parent.problem}: ${i.message}`),
    );
    section('Limits reached', [...analysis.lower.capped]);
    section('Sheet', [...sheetWarnings]);
    section(
      'Model',
      model.diagnostics.map((d) => `${d.level}: ${d.message}`),
    );
    if (items.length === 1) items.push(h('p', { class: 'hint' }, 'No problems found.'));
    setChildren(this.bodyEl, h('div', { class: 'diagnostics' }, items));
  }
}
