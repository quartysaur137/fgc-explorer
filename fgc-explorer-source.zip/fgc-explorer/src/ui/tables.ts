/**
 * Bottom panel: sortable problems table, reductions table, diagnostics.
 */

import { STATUS_ORDER } from '../engine/analysis';
import { Rate } from '../growth/growth';
import { canonicalRowId } from '../model/config';
import { ROW_STATUS_TEXT } from '../model/model';
import { h, setChildren } from './dom';
import { formatDuration, problemLabel, statusBadge, timePlain } from './format';
import { problemBoundsLine } from './paramFamily';
import { refAttrs } from './hover';
import { search } from './search';
import { isAdditive } from './selection';
import { BottomTab } from './state';
import { Store } from './store';
import { plainText, texEl } from './tex';

/** Handlers of a clickable table row: a click selects (Shift / Ctrl / ⌘: adds or removes) without selecting text. */
function rowClick(select: (additive: boolean) => void): Record<string, (e: Event) => void> {
  return {
    click: (e) => select(isAdditive(e as MouseEvent)),
    mousedown: (e) => {
      if ((e as MouseEvent).shiftKey) e.preventDefault();
    },
  };
}

type SortKey = 'problem' | 'family' | 'status' | 'lb' | 'ub' | 'regimes';

/** A sort key of a rate: power first, then exponent (as compareRates). */
function rateSortKey(r: Rate): readonly number[] {
  return [r.power, r.exponent];
}

type SortValue = string | number | readonly number[];

/** Order of sort values: strings and numbers as usual, arrays lexicographically. */
function compareValues(a: SortValue, b: SortValue): number {
  if (Array.isArray(a) && Array.isArray(b)) {
    for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i]! < b[i]! ? -1 : 1;
    return a.length - b.length;
  }
  return a < b ? -1 : a > b ? 1 : 0;
}

export class TablesView {
  private sortKey: SortKey = 'status';
  private sortAsc = true;
  private onlyUnused = false;

  constructor(
    private readonly tabsEl: HTMLElement,
    private readonly bodyEl: HTMLElement,
    private readonly store: Store,
    private readonly cb: { selectProblem(id: string, additive: boolean): void; selectRow(id: string, additive: boolean): void },
  ) {
    store.subscribe((changes) => {
      if (changes.has('analysis') || changes.has('model') || changes.has('prefs') || changes.has('selection')) this.render();
    });
    this.render();
  }

  private setTab(tab: BottomTab): void {
    this.store.update((s) => ({ ...s, prefs: { ...s.prefs, bottomTab: tab } }));
  }

  render(): void {
    const tab = this.store.get().prefs.bottomTab;
    const { model } = this.store.getDerived();
    const notOk = model.rows.filter((r) => r.status !== 'ok').length;
    // (during a search: how many of them it finds, as the table shows only those)
    const found = search(this.store.get().prefs.search, model, this.store.get().scenario.knobs);
    const problems = found.query === '' ? `${model.problems.size}` : `${[...model.problems.keys()].filter((p) => found.problems.has(p)).length} of ${model.problems.size}`;
    setChildren(
      this.tabsEl,
      (
        [
          ['problems', `Problems (${problems})`],
          ['rows', `Reductions (${model.rows.length}, ${notOk} not used)`],
          ['diagnostics', 'Diagnostics'],
        ] as const
      ).map(([id, label]) => h('button', { class: `tab ${tab === id ? 'active' : ''}`, on: { click: () => this.setTab(id) } }, label)),
    );
    if (tab === 'problems') this.problems();
    else if (tab === 'rows') this.rows();
    else this.diagnostics();
  }

  private toggleSort(key: SortKey): void {
    if (this.sortKey === key) this.sortAsc = !this.sortAsc;
    else {
      this.sortKey = key;
      this.sortAsc = true;
    }
    this.render();
  }

  private header(label: string, key: SortKey): HTMLElement {
    const active = this.sortKey === key;
    return h('th', { class: `sortable ${active ? 'active' : ''}`, on: { click: () => this.toggleSort(key) } }, label, active ? (this.sortAsc ? ' ▲' : ' ▼') : '');
  }

  /** The Bounds column's header: sort by the lower bound (≥) or by the upper bound (≤). */
  private boundsHeader(): HTMLElement {
    const part = (label: string, key: SortKey, title: string): HTMLElement => {
      const active = this.sortKey === key;
      return h('button', { class: `link sort ${active ? 'active' : ''}`, title, 'aria-label': title, on: { click: () => this.toggleSort(key) } }, label, active ? (this.sortAsc ? ' ▲' : ' ▼') : '');
    };
    return h(
      'th',
      { class: `sortable-split ${this.sortKey === 'lb' || this.sortKey === 'ub' ? 'active' : ''}` },
      'Bounds ',
      part('≥', 'lb', 'sort by the lower bound (then the upper bound)'),
      ' ',
      part('≤', 'ub', 'sort by the upper bound (then the lower bound)'),
    );
  }

  private problems(): void {
    const { model, analysis } = this.store.getDerived();
    // The problems found by name or through one of their bounds (search.ts).
    const found = search(this.store.get().prefs.search, model, this.store.get().scenario.knobs);
    const selected = new Set(this.store.get().selection.flatMap((x) => (x.kind === 'problem' ? [x.id] : [])));
    const items = [...analysis.summaries.values()].filter((s) => found.query === '' || found.problems.has(s.problem.id));
    const key = (s: (typeof items)[number]): SortValue => {
      switch (this.sortKey) {
        case 'problem':
          return problemLabel(s.problem).toLowerCase();
        case 'family':
          return s.problem.family.toLowerCase();
        case 'status':
          return STATUS_ORDER.indexOf(s.status) * 1000 + (s.problem.isStatic ? 0 : 500);
        case 'lb':
          // (lower bound, then upper bound)
          return [...(s.primary?.lb ? rateSortKey(s.primary.lb) : [-1, -1]), ...(s.primary?.ub ? rateSortKey(s.primary.ub) : [Infinity, Infinity])];
        case 'ub':
          // (upper bound, then lower bound)
          return [...(s.primary?.ub ? rateSortKey(s.primary.ub) : [Infinity, Infinity]), ...(s.primary?.lb ? rateSortKey(s.primary.lb) : [-1, -1])];
        case 'regimes':
          return s.regimes.length;
      }
    };
    items.sort((a, b) => {
      const c = compareValues(key(a), key(b)) || problemLabel(a.problem).localeCompare(problemLabel(b.problem));
      return this.sortAsc ? c : -c;
    });
    setChildren(
      this.bodyEl,
      h(
        'table',
        { class: 'grid data' },
        h(
          'thead',
          {},
          h('tr', {}, this.header('Problem', 'problem'), this.header('Family', 'family'), this.header('Status', 'status'), h('th', {}, 'Primary regime'), this.boundsHeader(), this.header('#Regimes', 'regimes')),
        ),
        h(
          'tbody',
          {},
          items.map((s) =>
            h(
              'tr',
              {
                class: `clickable ${selected.has(s.problem.id) ? 'selected' : ''}`,
                ...refAttrs({ kind: 'problem', id: s.problem.id }),
                on: rowClick((add) => this.cb.selectProblem(s.problem.id, add)),
              },
              h('td', {}, problemLabel(s.problem)),
              h('td', { class: 'muted' }, plainText(s.problem.family)),
              h('td', {}, s.problem.isStatic ? statusBadge(s.status) : h('span', { class: 'hint' }, 'dynamic')),
              h('td', { class: 'small' }, s.primary ? texEl(s.primary.regime.describeTex()) : ''),
              h('td', { class: 'mono nowrap' }, problemBoundsLine(analysis, s)),
              h('td', { class: 'num' }, String(s.regimes.length)),
            ),
          ),
        ),
      ),
    );
  }

  private rows(): void {
    const { model, analysis } = this.store.getDerived();
    const q = this.store.get().prefs.search.trim().toLowerCase();
    const selected = new Set(this.store.get().selection.flatMap((x) => (x.kind === 'row' ? [x.id] : [])));
    // (a search for "12" or "r12" finds reduction R12)
    const id = canonicalRowId(q);
    const items = model.rows.filter(
      (r) => (!this.onlyUnused || r.status !== 'ok') && (q === '' || r.id === id || r.id.toLowerCase() === q || r.source.toLowerCase().includes(q) || r.target.toLowerCase().includes(q)),
    );
    setChildren(
      this.bodyEl,
      h(
        'label',
        { class: 'check' },
        h('input', { type: 'checkbox', checked: this.onlyUnused, on: { change: (e) => ((this.onlyUnused = (e.target as HTMLInputElement).checked), this.render()) } }),
        ' only reductions the engine does not use',
      ),
      h(
        'table',
        { class: 'grid data' },
        h('thead', {}, h('tr', {}, h('th', {}, 'ID'), h('th', {}, 'From'), h('th', {}, 'To'), h('th', {}, 'Status'), h('th', {}, 'Used'), h('th', {}, 'Message'))),
        h(
          'tbody',
          {},
          items.map((r) => {
            const use = analysis.rowUse.get(r.id);
            return h(
              'tr',
              { class: `clickable ${selected.has(r.id) ? 'selected' : ''}`, ...refAttrs({ kind: 'row', id: r.id }), on: rowClick((add) => this.cb.selectRow(r.id, add)) },
              h('td', { class: 'num' }, r.id),
              h('td', {}, plainText(r.source)),
              h('td', {}, plainText(r.target)),
              h(
                'td',
                {},
                h('span', { class: `badge row-${r.status}` }, ROW_STATUS_TEXT[r.status]),
                r.lowerOnly && r.status === 'ok'
                  ? h('span', { class: 'badge row-lower-only', title: 'holds only on special instances of its target: used for lower bounds only, never for algorithms' }, 'LB only')
                  : null,
              ),
              h('td', { class: 'num' }, use ? `${use.lb} LB / ${use.ub} UB` : ''),
              h('td', { class: 'small' }, r.messages[0] ?? ''),
            );
          }),
        ),
      ),
    );
  }

  private diagnostics(): void {
    const { model, analysis, sheetWarnings } = this.store.getDerived();
    const lbCount = [...analysis.lower.facts.values()].reduce((n, m) => n + m.size, 0);
    const { upper, upperOverlay } = analysis;
    const items: HTMLElement[] = [
      h(
        'p',
        {},
        `Analysis: ${lbCount} lower-bound facts (${analysis.lower.pops} propagation steps); upper bounds searched at ${upper.nodeCount + upperOverlay.nodeCount} problem regimes (${upper.evaluationCount + upperOverlay.evaluationCount} evaluations); ${formatDuration(analysis.elapsedMs)}.`,
      ),
    ];
    const section = (title: string, lines: string[]): void => {
      if (lines.length === 0) return;
      items.push(h('h4', {}, title), h('ul', {}, lines.map((l) => h('li', {}, l))));
    };
    section('Knob problems', [...analysis.knobIssues].map(([id, m]) => `${analysis.scenario.knobs.find((k) => k.id === id)?.problem ?? id}: ${m}`));
    const name = (id: string): string => {
      const p = model.problems.get(id);
      return p ? problemLabel(p) : id;
    };
    section('Cycles that improve a bound each time around (the bound is their limit)', [
      ...analysis.lower.cycles.map(
        (f) =>
          `lower bound of ${name(f.problem)} at ${f.regime.key}: ${f.exponent !== Infinity ? `→ ${timePlain(f.regime, f, 6)}` : f.power === 1 ? 'grows without limit (∞: no polynomial-time algorithm)' : 'grows without limit'}`,
      ),
      ...[...upper.cycles, ...upperOverlay.cycles].map((f) => `upper bound of ${name(f.problem)} at ${f.regime.key}: → ${timePlain(f.regime, f, 6)}`),
    ]);
    // One line per reduction, source and message (a source may have lower bounds at many regimes).
    const inconsistencies = new Map<string, { text: string; regimes: Set<string> }>();
    for (const i of analysis.lower.inconsistencies) {
      const text = `row ${i.rowId} from ${name(i.parent.problem)}: ${i.message}`;
      const e = inconsistencies.get(text) ?? { text, regimes: new Set<string>() };
      e.regimes.add(i.parent.regime.key);
      inconsistencies.set(text, e);
    }
    section(
      'Inconsistencies (a reduction beats a lower bound without using its target)',
      [...inconsistencies.values()].map((e) => (e.regimes.size > 1 ? `${e.text} (at ${e.regimes.size} regimes)` : e.text)),
    );
    section('Limits reached', [...analysis.lower.capped, ...upper.capped, ...upperOverlay.capped]);
    section('Sheet', [...sheetWarnings]);
    section(
      'Model',
      model.diagnostics.map((d) => `${d.level}: ${d.message}`),
    );
    if (items.length === 1) items.push(h('p', { class: 'hint' }, 'No problems found.'));
    setChildren(this.bodyEl, h('div', { class: 'diagnostics' }, items));
  }
}
