/**
 * The selection (SPEC §7): problems and reductions picked in the graph, the tables, the inspector or the left panel.
 * A click selects one item; with Shift (or Ctrl / ⌘) held, it adds the item, or removes it when it is selected already.
 */

export type SelectionItem =
  | {
      readonly kind: 'problem';
      readonly id: string;
      /** Key of the regime whose derivations are shown (inspector and graph); default: the problem's primary regime. */
      readonly regime?: string;
    }
  | { readonly kind: 'row'; readonly id: string };

/** Selected items in the order they were picked; empty when nothing is selected. */
export type Selection = readonly SelectionItem[];

export const sameItem = (a: SelectionItem, b: SelectionItem): boolean => a.kind === b.kind && a.id === b.id;

/** Whether an event asks to add to the selection rather than replace it (Shift, Ctrl or ⌘ held). */
export function isAdditive(e: { readonly shiftKey?: boolean; readonly ctrlKey?: boolean; readonly metaKey?: boolean } | null | undefined): boolean {
  return !!e && (e.shiftKey === true || e.ctrlKey === true || e.metaKey === true);
}

/**
 * The selection after a click on `item`: the item alone (as selected before, if it was), or, when `additive`, the
 * selection with the item added at the end or removed.
 */
export function clickSelect(selection: Selection, item: SelectionItem, additive: boolean): Selection {
  const existing = selection.find((x) => sameItem(x, item));
  if (!additive) return selection.length === 1 && existing ? selection : [existing ?? item];
  return existing ? selection.filter((x) => x !== existing) : [...selection, item];
}

/** The selection with the regime of problem `problemId` set (undefined: back to the primary regime). */
export function withRegime(selection: Selection, problemId: string, regime: string | undefined): Selection {
  return selection.map((x) => {
    if (x.kind !== 'problem' || x.id !== problemId) return x;
    const { regime: _old, ...rest } = x;
    return regime === undefined ? rest : { ...rest, regime };
  });
}

/** Stable key of an item (for remembering per-item view state). */
export const itemKey = (x: SelectionItem): string => `${x.kind}:${x.id}`;
