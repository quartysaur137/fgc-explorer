/**
 * Hover highlighting (SPEC §7): pointing at a problem or reduction, in the graph or at its name or ID in a panel,
 * highlights it in the graph. Views mark such references with data attributes (refAttrs); one listener per panel
 * (panelHover) reports the reference under the pointer or keyboard focus.
 */

import { SelectionItem } from './selection';

const REF_PROBLEM = 'data-ref-problem';
const REF_ROW = 'data-ref-row';

/** Attributes marking an element as a reference to a problem or reduction (spread them into h(…)'s attributes). */
export function refAttrs(item: SelectionItem): Record<string, string> {
  return item.kind === 'problem' ? { [REF_PROBLEM]: item.id } : { [REF_ROW]: item.id };
}

/** The problem or reduction an event target refers to (itself or its closest marked ancestor), or null. */
export function refOf(target: EventTarget | null): SelectionItem | null {
  const el = target instanceof Element ? target.closest(`[${REF_PROBLEM}], [${REF_ROW}]`) : null;
  if (el === null) return null;
  const problem = el.getAttribute(REF_PROBLEM);
  return problem !== null ? { kind: 'problem', id: problem } : { kind: 'row', id: el.getAttribute(REF_ROW)! };
}

/** Report the reference under the pointer or with the keyboard focus inside `root` (null when there is none). */
export function panelHover(root: HTMLElement, onHover: (item: SelectionItem | null) => void): void {
  root.addEventListener('mouseover', (e) => onHover(refOf(e.target)));
  root.addEventListener('mouseleave', () => onHover(null));
  root.addEventListener('focusin', (e) => onHover(refOf(e.target)));
  root.addEventListener('focusout', () => onHover(null));
}

/** A box in view coordinates. */
export interface Box {
  readonly x1: number;
  readonly y1: number;
  readonly x2: number;
  readonly y2: number;
}

/**
 * Where to point at an element outside the view: the element's center clamped to the view shrunk by (mx, my) on each
 * side (room for the pointer itself), and the direction from there to the element (radians, 0 = right, clockwise
 * since y grows downward).
 * @returns null when the element is (partly) inside the view, which is [0, width] × [0, height]
 */
export function offscreenPointer(box: Box, width: number, height: number, mx: number, my: number): { x: number; y: number; angle: number } | null {
  if (box.x2 >= 0 && box.x1 <= width && box.y2 >= 0 && box.y1 <= height) return null;
  const cx = (box.x1 + box.x2) / 2;
  const cy = (box.y1 + box.y2) / 2;
  const clamp = (v: number, lo: number, hi: number): number => (lo > hi ? (lo + hi) / 2 : Math.min(hi, Math.max(lo, v)));
  const x = clamp(cx, mx, width - mx);
  const y = clamp(cy, my, height - my);
  return { x, y, angle: Math.atan2(cy - y, cx - x) };
}
