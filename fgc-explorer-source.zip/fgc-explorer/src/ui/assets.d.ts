/** Module declarations for assets bundled by esbuild (see build.mjs). */

declare module '*.csv' {
  const text: string;
  export default text;
}

declare module 'cytoscape-fcose' {
  import type { Ext } from 'cytoscape';
  const fcose: Ext;
  export default fcose;
}
