/**
 * Display helpers shared by the views.
 */

import { Analysis, CONFLICT_TOL, ProblemSummary, RegimeSummary, Status, STATUS_TEXT, TIGHT_TOL } from '../engine/analysis';
import { formatNumber } from '../growth/growth';
import { identifierTex } from '../math/ast';
import { KnobSpec } from '../model/config';
import { Problem } from '../model/model';
import { Regime } from '../model/regime';
import { escapeHtml, h } from './dom';
import { plainText, texHtml, texToPlain } from './tex';

/** HTML for a knob's value and where it applies, e.g. "exponent 2 at n=1, M=poly", or a rendered formula. */
export function knobValueHtml(k: KnobSpec): string {
  const value = k.exponent !== undefined ? `exponent ${formatNumber(k.exponent, 4)}` : texHtml(k.formula ?? '');
  if (k.regime !== undefined && k.regime.trim() !== '') return `${value} <span class="muted">at</span> <span class="mono">${escapeHtml(k.regime)}</span>`;
  return k.formula !== undefined ? `${value} <span class="muted">(all regimes)</span>` : value;
}

/** Short plain-text name of a problem (its variation, or family / variation when the variation is generic). */
export function problemLabel(p: Problem): string {
  const v = plainText(p.variation);
  return v === '' ? plainText(p.family) : v;
}

/** A displayed bound may overstate the computed one by at most this much (rounding, search precision). */
const DISPLAY_SLACK = 1e-6;

/**
 * Decimals for showing a lower bound, an upper bound, or both side by side: the fewest from 4 to 8 such that rounding
 * never overstates a bound by more than DISPLAY_SLACK (a lower bound is not shown larger, an upper bound not smaller:
 * 3SUM in n^{1.99915} shows as 1.99915, not 1.9991), and a conflict or gap does not look like equality (2 vs 1.99995).
 * Integers and short decimals keep their short form.
 */
export function boundDecimals(lb: number | undefined, ub: number | undefined): number {
  const finite = (x: number | undefined): x is number => x !== undefined && Number.isFinite(x);
  const fits = (d: number): boolean => {
    if (finite(lb) && Number(formatNumber(lb, d)) > lb + DISPLAY_SLACK) return false;
    if (finite(ub) && Number(formatNumber(ub, d)) < ub - DISPLAY_SLACK) return false;
    const distinct = finite(lb) && finite(ub) && (ub < lb - CONFLICT_TOL || ub > lb + TIGHT_TOL);
    return !(distinct && formatNumber(lb, d) === formatNumber(ub, d));
  };
  let d = 4;
  while (d < 8 && !fits(d)) d++;
  return d;
}

/** Exponent as text, e.g. "n^2.3716", "2^n" or "2^(0.5n)". */
export function timePlain(regime: Regime, x: number, decimals = 4): string {
  const n = texToPlain(identifierTex(regime.normalizerName));
  const e = formatNumber(x, decimals);
  if (!Number.isFinite(x)) return '∞';
  if (!regime.expScale) return `${n}^${e}`;
  return e === '1' ? `2^${n}` : `2^(${e}${n})`;
}

/** "≥ n^3 · ≤ n^3" line for a regime summary (empty when it has no bound). */
export function boundsLine(s: RegimeSummary | null): string {
  if (s === null) return '';
  const parts: string[] = [];
  const d = boundDecimals(s.lb?.exponent, s.ub?.exponent);
  if (s.lb) parts.push(`≥ ${timePlain(s.regime, s.lb.exponent, d)}`);
  if (s.ub) parts.push(`≤ ${timePlain(s.regime, s.ub.exponent, d)}`);
  return parts.join('  ');
}

export const STATUS_LABEL: Readonly<Record<Status, string>> = {
  conflict: 'conflict',
  tight: 'tight',
  gap: 'gap',
  lb: 'lower bound',
  ub: 'upper bound',
  none: 'no bound',
};

/** A colored status badge. */
export function statusBadge(status: Status): HTMLSpanElement {
  return h('span', { class: `badge status-${status}`, title: STATUS_TEXT[status] }, STATUS_LABEL[status]);
}

/** Summary of a problem, or null for problems without one. */
export function summaryOf(analysis: Analysis, problemId: string): ProblemSummary | null {
  return analysis.summaries.get(problemId) ?? null;
}

/** "1.23 s" / "450 ms" */
export function formatDuration(ms: number): string {
  return ms >= 1000 ? `${(ms / 1000).toFixed(2)} s` : `${Math.round(ms)} ms`;
}
