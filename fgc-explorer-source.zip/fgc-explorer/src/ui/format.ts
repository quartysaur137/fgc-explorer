/**
 * Display helpers shared by the views.
 */

import { Analysis, CONFLICT_TOL, ProblemSummary, RegimeSummary, regimesFromSpec, Status, STATUS_TEXT, TIGHT_TOL } from '../engine/analysis';
import { formatNumber, formatPower, Rate, samePower } from '../growth/growth';
import { identifierTex } from '../math/ast';
import { KnobSpec } from '../model/config';
import { findProblem, Model, Problem } from '../model/model';
import { Regime, regimeNumberText } from '../model/regime';
import { escapeHtml, h } from './dom';
import { plainText, texHtml, texToPlain } from './tex';

/** The (first) regime a knob's spec stands for, completed by its problem's main regime; null if there is none. */
/**
 * The number typed in a field, or null: digits with a decimal point or a decimal comma ("1,5" is 1.5), an optional sign
 * and exponent; empty text, other text and infinite values are not numbers.
 */
export function parseDecimal(text: string): number | null {
  const t = text.trim();
  if (!/^[+-]?(\d+([.,]\d*)?|[.,]\d+)([eE][+-]?\d+)?$/.test(t)) return null;
  const v = Number(t.replace(',', '.'));
  return Number.isFinite(v) ? v : null;
}

export function knobRegime(model: Model, k: KnobSpec): Regime | null {
  const p = findProblem(model, k.problem);
  if (p === undefined || !p.isStatic) return null;
  try {
    return regimesFromSpec(p, k.regime ?? '')[0] ?? null;
  } catch {
    return null;
  }
}

/** The rate of an exponent knob (power 1 when not given). */
export function knobRate(k: KnobSpec): Rate {
  return { power: k.power ?? 1, exponent: k.exponent ?? 0 };
}

/**
 * HTML for a knob's value and where it applies, e.g. "n^{2} at n=1, M=poly" (an exponent knob at its regime `regime`,
 * else "exponent 2", with its power if not 1), or a rendered formula.
 */
export function knobValueHtml(k: KnobSpec, regime: Regime | null = null): string {
  const exponentText = (): string =>
    regime !== null ? texHtml(regime.timeTex(knobRate(k))) : `exponent ${formatNumber(k.exponent!, 4)}${k.power !== undefined && k.power !== 1 ? `, power ${formatPower(k.power, 4)}` : ''}`;
  const value = k.exponent !== undefined ? exponentText() : texHtml(k.formula ?? '');
  if (k.regime !== undefined && k.regime.trim() !== '') return `${value} <span class="muted">at</span> <span class="mono">${escapeHtml(k.regime)}</span>`;
  return k.formula !== undefined ? `${value} <span class="muted">(all regimes)</span>` : value;
}

/** Short plain-text name of a problem (its variation, or family / variation when the variation is generic). */
export function problemLabel(p: Problem): string {
  const v = plainText(p.variation);
  return v === '' ? plainText(p.family) : v;
}

/** A displayed bound may overstate the computed one by at most this much (rounding, search precision). */
const DISPLAY_SLACK = 1e-6;

/**
 * Decimals for showing a lower bound, an upper bound, or both side by side: the fewest from 4 to 8 such that rounding
 * never overstates a bound's exponent by more than DISPLAY_SLACK (a lower bound is not shown larger, an upper bound not
 * smaller: 3SUM in n^{1.99915} shows as 1.99915, not 1.9991), and a conflict or gap does not look like equality (2 vs
 * 1.99995; only bounds of the same power are compared). Integers and short decimals keep their short form.
 */
export function boundDecimals(lbRate: Rate | undefined, ubRate: Rate | undefined): number {
  const finite = (x: number | undefined): x is number => x !== undefined && Number.isFinite(x);
  const lb = lbRate?.exponent;
  const ub = ubRate?.exponent;
  const comparable = lbRate !== undefined && ubRate !== undefined && samePower(lbRate.power, ubRate.power);
  const fits = (d: number): boolean => {
    if (finite(lb) && Number(formatNumber(lb, d)) > lb + DISPLAY_SLACK) return false;
    if (finite(ub) && Number(formatNumber(ub, d)) < ub - DISPLAY_SLACK) return false;
    const distinct = comparable && finite(lb) && finite(ub) && (ub < lb - CONFLICT_TOL || ub > lb + TIGHT_TOL);
    return !(distinct && formatNumber(lb!, d) === formatNumber(ub!, d));
  };
  let d = 4;
  while (d < 8 && !fits(d)) d++;
  return d;
}

/**
 * A running time of rate `r` at a regime as text (see Regime.timeTex), e.g. "n^2.3716", "2^n", "2^(0.5n)",
 * "2^(0.5n^0.75)", "2^(log^2 n)", "n^o(1)", "polylog(n)".
 */
export function timePlain(regime: Regime, r: Rate, decimals = 4): string {
  return regime.timeText(r, decimals, texToPlain(identifierTex(regime.normalizerName)));
}

/**
 * The upper bound as shown beside a lower bound: the lower bound's value when the two are tight (of the same power, the
 * upper bound at most TIGHT_TOL above the lower one and not a conflict below it), so that tight bounds read the same:
 * n^{4/3} computed as 1.3333333 and 1.3333337 is not shown as 1.333333 ≤ 1.333334, nor Triangle Listing's tight
 * 1.6666667 and 1.6666680 as 1.666667 ≤ 1.666668 (the free-parameter search leaves such differences, which TIGHT_TOL
 * absorbs).
 */
export function shownUb<R extends Rate>(lb: Rate | null | undefined, ub: R): R {
  const tight = lb && samePower(lb.power, ub.power) && Number.isFinite(lb.exponent) && ub.exponent >= lb.exponent - CONFLICT_TOL && ub.exponent <= lb.exponent + TIGHT_TOL;
  return tight ? { ...ub, exponent: lb.exponent } : ub;
}

/** "≥ n^3 · ≤ n^3" line for a regime summary (empty when it has no bound). */
export function boundsLine(s: RegimeSummary | null): string {
  if (s === null) return '';
  const parts: string[] = [];
  const ub = s.ub ? shownUb(s.lb, s.ub) : undefined;
  const d = boundDecimals(s.lb ?? undefined, ub);
  if (s.lb) parts.push(`≥ ${timePlain(s.regime, s.lb, d)}`);
  if (ub) parts.push(`≤ ${timePlain(s.regime, ub, d)}`);
  return parts.join('  ');
}

export const STATUS_LABEL: Readonly<Record<Status, string>> = {
  conflict: 'conflict',
  tight: 'tight',
  gap: 'gap',
  lb: 'lower bound',
  ub: 'upper bound',
  none: 'no bound',
};

/** A colored status badge. */
export function statusBadge(status: Status): HTMLSpanElement {
  return h('span', { class: `badge status-${status}`, title: STATUS_TEXT[status] }, STATUS_LABEL[status]);
}

/** Summary of a problem, or null for problems without one. */
export function summaryOf(analysis: Analysis, problemId: string): ProblemSummary | null {
  return analysis.summaries.get(problemId) ?? null;
}

/** "1.23 s" / "450 ms" */
export function formatDuration(ms: number): string {
  return ms >= 1000 ? `${(ms / 1000).toFixed(2)} s` : `${Math.round(ms)} ms`;
}

/** Regime spec text that reproduces a normalized regime (for knobs and pins). */
export function regimeToSpec(r: Regime): string {
  return r.params
    .map((p, i) => {
      const g = r.growths[i]!;
      if (r.logDep.has(p)) return `${p}=${g.kind === 'const' ? 'const' : g.kind === 'log' ? 'polylog' : 'poly'}`;
      if (i === r.normalizer) return `${p}=${r.expScale ? 'log' : '1'}`;
      switch (g.kind) {
        case 'poly':
          return `${p}=${regimeNumberText(g.exp)}`;
        case 'log':
          return `${p}=polylog`;
        case 'qpoly':
          return `${p}=subpoly`;
        case 'const':
          return `${p}=const${g.value === null ? '' : `:${regimeNumberText(g.value)}`}`;
        default:
          return `${p}=1`;
      }
    })
    .join(', ');
}
