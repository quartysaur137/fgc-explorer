/**
 * Growth algebra (SPEC §5): asymptotic classes of positive quantities f(N) as N → ∞, modulo constant factors and, for
 * the classes 2^{(c ± o(1))·L^a} (L = log2 N; the polynomial ones N^{c ± o(1)} are those with a = 1), the o(1) in the
 * coefficient of the exponent.
 *
 * Every operation returns a class that contains all possible results of the operation on members of its argument
 * classes ("upper-bound semantics"), or throws EvalError when no useful class exists. Nothing is silently mapped to 0.
 */

import { assert } from '../util/assert';

/** Failure to evaluate a quantity (unsupported or meaningless operation). Caught by the engine, never fatal. */
export class EvalError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'EvalError';
  }
}

/**
 * A growth class. L stands for log2 N.
 *
 * AF:
 *   const(v)      = Θ(1); v is the exact value when known (v may be ≤ 0 only when used as an exponent).
 *   log(p, c)     = Θ(L^p) and ω(1), of rate zero (2^{o(L^a)} for every a > 0); p ∈ [0, ∞]: p = 0 means L^{o(1)}
 *                   (e.g. log log N), p = ∞ a quantity of rate zero of unknown, at least polylogarithmic, order (e.g.
 *                   (log N)^{O(1)}); for 0 < p < ∞ and c ≠ null the value is c·L^p·(1 ± o(1)) (c < 0 only for
 *                   quantities used as exponents of 2).
 *   qpoly(a, c)   = 2^{(c ± o(1))·L^a}: for a < 1 sub-polynomial (e.g. 2^{√log N}), for a > 1 super-polynomial (e.g.
 *                   quasi-polynomial 2^{log² N}); c = 0 means 2^{o(L^a)}, and qpoly(1, 0) is N^{o(1)}.
 *   poly(e)       = N^{e ± o(1)}, e ≠ 0.
 *   polyUnknown   = N^{Θ(1)} with an unknown (nonnegative) exponent.
 *   super         = N^{ω(1)}, without any useful upper bound (e.g. 2^N).
 * RI: poly.exp finite and ≠ 0; log.pow ∈ [0, ∞]; log.coef === null unless 0 < pow < ∞, finite and ≠ 0 otherwise;
 *     qpoly.pow finite and > 0, qpoly.coef finite and ≥ 0, and qpoly.coef === 0 if qpoly.pow === 1; const.value finite
 *     or null.
 * SRE: all fields are readonly primitives (enforced by the type); no operation mutates a growth after creation.
 */
export type Growth =
  | { readonly kind: 'const'; readonly value: number | null }
  | { readonly kind: 'log'; readonly pow: number; readonly coef: number | null }
  | { readonly kind: 'qpoly'; readonly pow: number; readonly coef: number }
  | { readonly kind: 'poly'; readonly exp: number }
  | { readonly kind: 'polyUnknown' }
  | { readonly kind: 'super' };

/**
 * Exponent used for Ω(1) in exponents such as n^{2-Ω(1)}: some positive constant. It must exceed the engine's
 * comparison tolerance (1e-9), so that n^{2-Ω(1)} counts as strictly faster than n^2.
 */
export const TINY = 1e-6;

/**
 * The factor that o(·) puts on its argument (an upper bound: o(x) is eventually below any positive multiple of x), so
 * small that exponents never notice it: n^{1+o(1)} is N^1, while n^{o(1)} is N^{o(1)} and 2^{o(n)} is 2^{o(n)} rather
 * than a constant. Classes at most this far from 0 count as 0.
 */
export const INFINITESIMAL = 1e-12;

function checkRep(g: Growth): Growth {
  // Messages are built only on failure: this runs for every growth created (hot path).
  switch (g.kind) {
    case 'const':
      if (!(g.value === null || Number.isFinite(g.value))) fail(`const value must be finite: ${g.value}`);
      break;
    case 'log':
      if (!(g.pow >= 0)) fail(`log pow must be in [0, inf]: ${g.pow}`);
      if (!(g.coef === null || (g.pow > 0 && g.pow < Infinity && Number.isFinite(g.coef) && g.coef !== 0))) fail(`bad log coef ${g.coef} for pow ${g.pow}`);
      break;
    case 'qpoly':
      if (!(g.pow > 0 && Number.isFinite(g.pow))) fail(`qpoly pow must be finite and positive: ${g.pow}`);
      if (!(g.coef >= 0 && Number.isFinite(g.coef) && (g.pow !== 1 || g.coef === 0))) fail(`bad qpoly coef ${g.coef} for pow ${g.pow}`);
      break;
    case 'poly':
      if (!(Number.isFinite(g.exp) && g.exp !== 0)) fail(`poly exponent must be finite and nonzero: ${g.exp}`);
      break;
    case 'polyUnknown':
    case 'super':
      break;
  }
  return g;
}

function fail(message: string): never {
  assert(false, message);
}

/**
 * The canonical form of a power: rounded to 12 decimals, so that powers computed in different ways are equal exactly
 * (0.1·3 and 0.3), and 1 within 1e-9 (sums of powers such as 0.1 + 0.9 may miss it by a rounding error).
 */
function canonicalPow(p: number): number {
  if (!Number.isFinite(p)) return p;
  const r = Math.round(p * 1e12) / 1e12;
  return Math.abs(r - 1) < 1e-9 ? 1 : r;
}

// ---- constructors ----

/**
 * Θ(1), with value `value` if known.
 * @throws EvalError if `value` is infinite or NaN (overflow in constant arithmetic, e.g. 10^{400})
 */
export function constant(value: number | null): Growth {
  if (value !== null && !Number.isFinite(value)) throw new EvalError(`constant overflow (${value})`);
  return checkRep({ kind: 'const', value });
}

/** Θ(L^pow); `coef` = the coefficient c in c·L^pow, kept for 0 < pow < ∞ (a zero coefficient gives the constant 0). */
export function logClass(pow = 1, coef: number | null = null): Growth {
  const p = canonicalPow(pow);
  const finite = p > 0 && p < Infinity;
  if (coef === 0 && finite) return constant(0);
  if (coef !== null && !Number.isFinite(coef)) throw new EvalError(`coefficient overflow (${coef})`);
  return checkRep({ kind: 'log', pow: p, coef: finite ? coef : null });
}

/** N^{o(1)}: sub-polynomial of unknown order, i.e. 2^{o(L)}. */
export const SUBPOLY: Growth = checkRep({ kind: 'qpoly', pow: 1, coef: 0 });

/** N^{exp}; exp = 0 gives N^{o(1)}. */
export function poly(exp: number): Growth {
  if (!Number.isFinite(exp)) throw new EvalError(`non-finite exponent ${exp}`);
  if (Math.abs(exp) <= INFINITESIMAL) return SUBPOLY;
  return checkRep({ kind: 'poly', exp });
}

/**
 * 2^{coef·L^pow} (L = log2 N), e.g. 2^{0.5·n^{0.75}} for n = L: pow 1 is poly(coef); a negative coefficient gives a
 * vanishing quantity, bounded by a constant.
 * @throws EvalError if pow is not finite and positive or coef is not finite
 */
export function qpoly(pow: number, coef: number): Growth {
  const p = canonicalPow(pow);
  if (!(pow > 0 && Number.isFinite(p)) || !Number.isFinite(coef)) throw new EvalError(`no class 2^{${coef}·log^${pow} N}`);
  if (p === 0) return POLYLOG; // (a power below 5e-13: 2^{c·L^{o(1)}}, of rate zero)
  if (p === 1) return poly(coef);
  if (coef < -1e-12) return constant(null);
  return checkRep({ kind: 'qpoly', pow: p, coef: coef <= INFINITESIMAL ? 0 : coef });
}

export const POLY_UNKNOWN: Growth = checkRep({ kind: 'polyUnknown' });
export const SUPER: Growth = checkRep({ kind: 'super' });
/** Rate zero of unknown order, e.g. (log N)^{O(1)}: 2^{o(L^a)} for every a > 0. */
export const POLYLOG: Growth = logClass(Infinity);

// ---- queries ----

export function isConst(g: Growth): g is Extract<Growth, { kind: 'const' }> {
  return g.kind === 'const';
}

/** The known numeric value of a constant growth, or null. */
export function constValue(g: Growth): number | null {
  return g.kind === 'const' ? g.value : null;
}

/**
 * The exponent e such that g = N^{e ± o(1)}.
 * @throws EvalError for polyUnknown (the exponent depends on an unspecified constant).
 * @returns 0 for sub-polynomial classes, +Infinity for super-polynomial ones.
 */
export function exponentOf(g: Growth): number {
  switch (g.kind) {
    case 'poly':
      return g.exp;
    case 'const':
    case 'log':
      return 0;
    case 'qpoly':
      return g.pow > 1 ? Infinity : 0;
    case 'super':
      return Infinity;
    case 'polyUnknown':
      throw new EvalError('the exponent depends on an unspecified constant (e.g. n^{O(1)})');
  }
}

/**
 * Rank of the coarse magnitude order on the real line:
 * negative log quantity < negative constant < 0 < poly(<0) < positive constant < log < [qpoly, poly(>0), polyUnknown]
 * < super. (Negative quantities only occur as exponents of 2, e.g. i·log2(1/4).) The classes of rank 3 are ordered by
 * rateKey.
 */
function rank(g: Growth): number {
  switch (g.kind) {
    case 'poly':
      return g.exp < 0 ? 0 : 3;
    case 'const':
      return g.value === null || g.value > 0 ? 1 : g.value === 0 ? -1 : -2;
    case 'log':
      return g.coef !== null && g.coef < 0 ? -3 : 2;
    case 'qpoly':
    case 'polyUnknown':
      return 3;
    case 'super':
      return 5;
  }
}

/** (a, c) of a class 2^{c·L^a} of rank 3 (poly(e) is (1, e)); null for polyUnknown. */
function rateKey(g: Growth): readonly [number, number] | null {
  if (g.kind === 'poly') return [1, g.exp];
  if (g.kind === 'qpoly') return [g.pow, g.coef];
  return null;
}

/** Both constants, or both c·L^p quantities with the same p and known coefficients: exact arithmetic applies. */
function exactPair(a: Growth, b: Growth): boolean {
  if (a.kind === 'const' && b.kind === 'const') return true;
  return a.kind === 'log' && b.kind === 'log' && a.pow === b.pow && a.coef !== null && b.coef !== null;
}

/**
 * Asymptotic comparison.
 * @returns -1 if a = o(b), 1 if b = o(a), 0 if same class (Θ, up to the precision of the representation),
 *          null if incomparable (polyUnknown vs a positive polynomial).
 */
export function compare(a: Growth, b: Growth): -1 | 0 | 1 | null {
  const ra = rank(a);
  const rb = rank(b);
  if (ra !== rb) return ra < rb ? -1 : 1;
  if (ra === 3) {
    const ka = rateKey(a);
    const kb = rateKey(b);
    if (ka === null && kb === null) return 0;
    if (ka === null || kb === null) {
      // N^{O(1)} is below every class with a power above 1 (even 2^{o(L^a)}, which contains every polynomial), above
      // every 2^{o(L)} class, and incomparable with N^{e}, e > 0.
      const [p, c] = (ka ?? kb)!;
      const unknownAbove: -1 | 1 | null = p > 1 ? -1 : p < 1 || c === 0 ? 1 : null;
      if (unknownAbove === null) return null;
      return ka === null ? unknownAbove : (-unknownAbove as -1 | 1);
    }
    if (ka[0] !== kb[0]) return ka[0] < kb[0] ? -1 : 1;
    return ka[1] === kb[1] ? 0 : ka[1] < kb[1] ? -1 : 1;
  }
  if (a.kind === 'poly' && b.kind === 'poly') return a.exp === b.exp ? 0 : a.exp < b.exp ? -1 : 1;
  if (a.kind === 'log' && b.kind === 'log') {
    if (a.pow !== b.pow) {
      const s = a.pow < b.pow ? -1 : 1;
      return ra === -3 ? (-s as -1 | 1) : s; // (−L is below −√L)
    }
    return 0;
  }
  return 0;
}

// ---- arithmetic ----

/** Sum, maximum or minimum of two classes of the same order (compare gave 0, or an exact pair). */
function combineSame(a: Growth, b: Growth, op: 'add' | 'max' | 'min'): Growth {
  if (a.kind === 'const' && b.kind === 'const') {
    if (a.value === null || b.value === null) {
      if (op === 'min') return a.value === null ? b : a;
      return constant(null);
    }
    return constant(op === 'add' ? a.value + b.value : op === 'max' ? Math.max(a.value, b.value) : Math.min(a.value, b.value));
  }
  if (a.kind === 'log' && b.kind === 'log') {
    // same pow (else compare() would have decided)
    if (a.pow > 0 && a.pow < Infinity) {
      if (a.coef === null || b.coef === null) {
        if (op === 'min') return a.coef === null ? b : a;
        return logClass(a.pow, null);
      }
      const c = op === 'add' ? a.coef + b.coef : op === 'max' ? Math.max(a.coef, b.coef) : Math.min(a.coef, b.coef);
      return logClass(a.pow, c);
    }
    return a;
  }
  return a; // poly/poly and qpoly/qpoly with equal keys, polyUnknown/polyUnknown, super/super
}

/** Class of a + b (both nonnegative quantities, or exponents for const/log). */
export function add(a: Growth, b: Growth): Growth {
  if (exactPair(a, b)) return combineSame(a, b, 'add');
  const c = compare(a, b);
  if (c === null) return POLY_UNKNOWN;
  if (c < 0) return b;
  if (c > 0) return a;
  return combineSame(a, b, 'add');
}

/** Class of max(a, b). */
export function max(a: Growth, b: Growth): Growth {
  if (exactPair(a, b)) return combineSame(a, b, 'max');
  const c = compare(a, b);
  if (c === null) return POLY_UNKNOWN;
  if (c < 0) return b;
  if (c > 0) return a;
  return combineSame(a, b, 'max');
}

/** Class of min(a, b) (an upper bound on the minimum: a known bound is preferred over an unknown one). */
export function min(a: Growth, b: Growth): Growth {
  if (exactPair(a, b)) return combineSame(a, b, 'min');
  const c = compare(a, b);
  if (c === null) return a.kind === 'polyUnknown' ? b : a;
  if (c < 0) return a;
  if (c > 0) return b;
  return combineSame(a, b, 'min');
}

/**
 * Class of a − b.
 * Exact for constants and for c·L^p quantities with known coefficients; if b is of strictly lower order the result is
 * a; if both are of the same polynomial order the difference is assumed to stay Θ(a) (sheet formulas such as 2n − 1).
 * @throws EvalError if b is of strictly higher order than a (the difference would be negative).
 */
export function sub(a: Growth, b: Growth): Growth {
  if (a.kind === 'const' && b.kind === 'const') {
    return a.value === null || b.value === null ? constant(null) : constant(a.value - b.value);
  }
  // Subtracting a negative quantity (an exponent-like log quantity, e.g. n·log(1/2)) adds its absolute value.
  if ((b.kind === 'log' && b.coef !== null && b.coef < 0) || (b.kind === 'const' && b.value !== null && b.value < 0)) {
    if (!exactPair(a, b)) return add(a, negate(b));
  }
  if (exactPair(a, b)) {
    const la = a as Extract<Growth, { kind: 'log' }>;
    return logClass(la.pow, la.coef! - (b as { coef: number }).coef);
  }
  const c = compare(a, b);
  if (c === null) return POLY_UNKNOWN;
  if (c > 0) return a;
  if (c < 0) {
    if (a.kind === 'const' && a.value !== null && b.kind === 'poly' && b.exp < 0) return a;
    throw new EvalError('a difference is dominated by its subtracted term (negative quantity)');
  }
  return a;
}

/** Class of −a (only meaningful for constants and exponent-like log quantities). */
export function negate(a: Growth): Growth {
  if (a.kind === 'const') return constant(a.value === null ? null : -a.value);
  if (a.kind === 'log' && a.coef !== null) return logClass(a.pow, -a.coef);
  throw new EvalError('cannot negate a growing quantity');
}

/** Class of a · b. */
export function mul(a: Growth, b: Growth): Growth {
  if (constValue(a) === 0 || constValue(b) === 0) return constant(0);
  if (a.kind === 'super' || b.kind === 'super') return SUPER;
  if (a.kind === 'qpoly' && b.kind === 'qpoly') {
    if (a.pow === b.pow) return qpoly(a.pow, a.coef + b.coef);
    return a.pow > b.pow ? a : b;
  }
  // 2^{c·L^a} with a > 1 absorbs every polynomial factor, and 2^{c·L^a} with a ≤ 1 is absorbed by any polynomial.
  if (a.kind === 'qpoly' && a.pow > 1) return a;
  if (b.kind === 'qpoly' && b.pow > 1) return b;
  if (a.kind === 'polyUnknown' || b.kind === 'polyUnknown') return POLY_UNKNOWN;
  if (a.kind === 'poly' && b.kind === 'poly') return poly(a.exp + b.exp);
  if (a.kind === 'poly') return a;
  if (b.kind === 'poly') return b;
  // Factors of rate zero (constants, log classes) do not change a qpoly class.
  if (a.kind === 'qpoly') return a;
  if (b.kind === 'qpoly') return b;
  if (a.kind === 'const' && b.kind === 'const') {
    return constant(a.value === null || b.value === null ? null : a.value * b.value);
  }
  if (a.kind === 'const' || b.kind === 'const') {
    const k = (a.kind === 'const' ? a : b) as Extract<Growth, { kind: 'const' }>;
    const l = (a.kind === 'log' ? a : b) as Extract<Growth, { kind: 'log' }>;
    if (l.coef === null) {
      if (k.value !== null && k.value < 0 && l.pow !== 1) throw new EvalError('negative multiple of a polylogarithm');
      return l;
    }
    return logClass(l.pow, k.value === null ? null : k.value * l.coef);
  }
  // log × log
  const la = a as Extract<Growth, { kind: 'log' }>;
  const lb = b as Extract<Growth, { kind: 'log' }>;
  if ((la.coef ?? 1) < 0 || (lb.coef ?? 1) < 0) throw new EvalError('product of negative logarithmic quantities');
  return logClass(la.pow + lb.pow, la.coef !== null && lb.coef !== null ? la.coef * lb.coef : null);
}

/** Class of 1/a. */
export function inv(a: Growth): Growth {
  switch (a.kind) {
    case 'poly':
      return poly(-a.exp);
    case 'const':
      if (a.value === 0) throw new EvalError('division by zero');
      return constant(a.value === null ? null : 1 / a.value);
    case 'log':
      if (a.coef !== null && a.coef < 0) throw new EvalError('division by a negative quantity');
      return constant(null); // o(1) ⊆ O(1)
    case 'qpoly':
    case 'polyUnknown':
    case 'super':
      return constant(null);
  }
}

/** Class of a / b. */
export function div(a: Growth, b: Growth): Growth {
  return mul(a, inv(b));
}

/** Class of 2^x. */
export function exp2(x: Growth): Growth {
  switch (x.kind) {
    case 'const':
      return constant(x.value === null ? null : guardFinite(2 ** x.value));
    case 'log':
      if (x.pow === 1) return x.coef === null ? POLY_UNKNOWN : poly(x.coef);
      if (x.pow === 0) return POLYLOG; // 2^{L^{o(1)}}: rate zero
      if (x.pow === Infinity) return SUPER;
      if (x.coef === null) return x.pow < 1 ? SUBPOLY : SUPER; // 2^{O(L^p)}
      return qpoly(x.pow, x.coef);
    case 'poly':
      return x.exp > 0 ? SUPER : constant(1);
    case 'qpoly':
    case 'polyUnknown':
    case 'super':
      return SUPER;
  }
}

function guardFinite(v: number): number {
  if (!Number.isFinite(v)) throw new EvalError('constant overflow');
  return v;
}

/** Class of log2(x). */
export function log2(x: Growth): Growth {
  switch (x.kind) {
    case 'const':
      if (x.value === null) return constant(null);
      if (x.value <= 0) throw new EvalError('logarithm of a nonpositive constant');
      return constant(Math.log2(x.value));
    case 'log':
      if (x.coef !== null && x.coef < 0) throw new EvalError('logarithm of a negative quantity');
      return logClass(0);
    case 'qpoly':
      // log2 of 2^{o(L^a)} is o(L^a) ⊆ O(L^a)
      return logClass(x.pow, x.coef > 0 ? x.coef : null);
    case 'poly':
      return logClass(1, x.exp);
    case 'polyUnknown':
      return logClass(1, null);
    case 'super':
      throw new EvalError('logarithm of a superpolynomial quantity');
  }
}

/**
 * Class of a^k for an exponent class k.
 * Constant exponents scale; a constant base b > 0 with a growing exponent gives exp2(k · log2 b), and so does a
 * polynomial base N^e with an exponent c·L^p (N^{e·c·L^p} = 2^{e·c·L^{p+1}}); other growing bases with growing exponents
 * are superpolynomial.
 */
export function power(a: Growth, k: Growth): Growth {
  if (k.kind === 'const') {
    const v = k.value;
    if (v === 0) return constant(1);
    if (v === null) {
      switch (a.kind) {
        case 'poly':
          return a.exp > 0 ? POLY_UNKNOWN : constant(null);
        case 'const':
          return constant(null);
        case 'log':
          return POLYLOG;
        case 'qpoly':
          return a.pow > 1 ? SUPER : SUBPOLY; // 2^{O(L^a)}
        case 'polyUnknown':
          return POLY_UNKNOWN;
        case 'super':
          return SUPER;
      }
    }
    switch (a.kind) {
      case 'poly':
        return poly(a.exp * v);
      case 'const':
        if (a.value === null) return constant(null);
        if (a.value === 0 && v < 0) throw new EvalError('division by zero');
        if (a.value < 0 && !Number.isInteger(v)) throw new EvalError('fractional power of a negative constant');
        return constant(guardFinite(a.value ** v));
      case 'log':
        if (v < 0) return constant(null);
        if (a.coef !== null && a.coef < 0) throw new EvalError('power of a negative quantity');
        return logClass(a.pow * v, a.coef === null ? null : guardFinite(a.coef ** v));
      case 'qpoly':
        return v > 0 ? qpoly(a.pow, a.coef * v) : constant(null);
      case 'polyUnknown':
        return v > 0 ? POLY_UNKNOWN : constant(null);
      case 'super':
        return v > 0 ? SUPER : constant(null);
    }
  }
  // growing (or polyUnknown/super) exponent
  if (a.kind === 'const') {
    if (a.value === null) return exp2(mul(k, constant(null)));
    if (a.value <= 0) throw new EvalError('nonpositive base with a growing exponent');
    return exp2(mul(k, constant(Math.log2(a.value))));
  }
  if (a.kind === 'poly' && a.exp < 0) return constant(null);
  if (k.kind === 'log' && k.coef !== null && k.coef < 0) return constant(null);
  if (a.kind === 'poly' && k.kind === 'log' && k.coef !== null) return exp2(logClass(k.pow + 1, a.exp * k.coef));
  return SUPER;
}

/** Class of ⌈a⌉: exact on known constants; 1 for vanishing quantities (N^{-e}); otherwise a. */
export function ceil(a: Growth): Growth {
  if (a.kind === 'const' && a.value !== null) return constant(Math.ceil(a.value - 1e-12));
  if (a.kind === 'poly' && a.exp < 0) return constant(1);
  return a;
}

/** Class of ⌊a⌋: exact on known constants; 0 for vanishing quantities (N^{-e}); otherwise a. */
export function floor(a: Growth): Growth {
  if (a.kind === 'const' && a.value !== null) return constant(Math.floor(a.value + 1e-12));
  if (a.kind === 'poly' && a.exp < 0) return constant(0);
  return a;
}

/** Class of binom(a, b): exact for known constants, a^b for a constant b. */
export function binom(a: Growth, b: Growth): Growth {
  const bv = constValue(b);
  if (b.kind !== 'const') throw new EvalError('binomial with a growing lower index');
  const av = constValue(a);
  if (av !== null && bv !== null && Number.isInteger(bv) && bv >= 0) {
    let r = 1;
    for (let i = 0; i < bv; i++) r = (r * (av - i)) / (i + 1);
    return constant(r);
  }
  return power(a, b);
}

/** Class of the inverse Ackermann function α(a). */
export function inverseAckermann(a: Growth): Growth {
  return a.kind === 'const' ? constant(null) : logClass(0);
}

/** Human-readable description, e.g. "N^1.5", "Θ(log N)", "2.5", "2^{0.5·log₂^0.75 N}". */
export function describe(g: Growth): string {
  switch (g.kind) {
    case 'const':
      return g.value === null ? 'Θ(1)' : formatNumber(g.value);
    case 'log':
      if (g.pow === 0) return 'Θ(log log N)-like';
      if (g.pow === Infinity) return 'polylog(N)';
      if (g.pow === 1) return g.coef === null ? 'Θ(log N)' : `${formatNumber(g.coef)}·log₂N`;
      return g.coef === null ? `Θ(log^${formatNumber(g.pow)} N)` : `${formatNumber(g.coef)}·log₂^${formatNumber(g.pow)} N`;
    case 'qpoly':
      if (g.pow === 1) return 'N^{o(1)}';
      return g.coef === 0 ? `2^{o(log₂^${formatNumber(g.pow)} N)}` : `2^{${formatNumber(g.coef)}·log₂^${formatNumber(g.pow)} N}`;
    case 'poly':
      return `N^${formatNumber(g.exp)}`;
    case 'polyUnknown':
      return 'N^{O(1)}';
    case 'super':
      return 'N^{ω(1)}';
  }
}

/** A number in plain decimal notation, exactly as stored (never exponential notation such as 5e-7). */
export function plainNumber(x: number): string {
  const s = String(x);
  return /e/i.test(s) && Number.isFinite(x) ? x.toFixed(20).replace(/\.?0+$/, '') : s;
}

/** Number formatting with up to 4 decimals and no trailing zeros. */
export function formatNumber(x: number, decimals = 4): string {
  if (!Number.isFinite(x)) return x > 0 ? '∞' : x < 0 ? '−∞' : 'NaN';
  const s = x.toFixed(decimals);
  return s.includes('.') ? s.replace(/\.?0+$/, '') : s;
}

// ---- rates of running times ----

/**
 * The rate of a running time relative to a scale N (SPEC §2.4): time 2^{(exponent ± o(1))·L^power}, L = log2 N; power
 * 1 is time N^{exponent ± o(1)}. The rate zero (power 0, exponent 0) stands for times 2^{o(L^a)} for every a > 0
 * (constant, polylogarithmic); a time without useful bound has power and exponent Infinity.
 *
 * Rates are ordered lexicographically (power first): a larger power is a faster-growing time whatever the exponents.
 */
export interface Rate {
  readonly power: number;
  readonly exponent: number;
}

export const RATE_ZERO: Rate = Object.freeze({ power: 0, exponent: 0 });
export const RATE_NONE: Rate = Object.freeze({ power: Infinity, exponent: Infinity });

/** Powers closer than this are equal (powers come from knobs and are carried along exactly, up to rounding). */
export const POWER_TOL = 1e-9;

/**
 * The rate of a time of class `g` (upper-bound semantics).
 * @throws EvalError for polyUnknown (the exponent depends on an unspecified constant)
 */
export function rateOf(g: Growth): Rate {
  switch (g.kind) {
    case 'const':
    case 'log':
      return RATE_ZERO;
    case 'poly':
      return g.exp > 0 ? { power: 1, exponent: g.exp } : RATE_ZERO;
    case 'qpoly':
      return { power: g.pow, exponent: g.coef };
    case 'polyUnknown':
      throw new EvalError('the exponent depends on an unspecified constant (e.g. n^{O(1)})');
    case 'super':
      return RATE_NONE;
  }
}

/** The class of T(M) for a time T of rate r and an instance of scale M = N^scale (scale > 0): 2^{e·(scale·L)^a}. */
export function rateGrowth(r: Rate, scale: number): Growth {
  if (r.power === 0) return POLYLOG;
  if (!Number.isFinite(r.power) || !Number.isFinite(r.exponent)) return SUPER;
  if (r.power === 1) return poly(r.exponent * scale);
  return qpoly(r.power, r.exponent * scale ** r.power);
}

/** Whether two powers are the same (within POWER_TOL). */
export function samePower(a: number, b: number): boolean {
  return a === b || Math.abs(a - b) <= POWER_TOL;
}

/**
 * Lexicographic comparison of rates: power first (within POWER_TOL), then the exponent within `tol`.
 * @returns -1 if x grows slower, 1 if faster, 0 if they are the same within the tolerances
 */
export function compareRates(x: Rate, y: Rate, tol: number): -1 | 0 | 1 {
  if (!samePower(x.power, y.power)) return x.power < y.power ? -1 : 1;
  if (x.exponent < y.exponent - tol) return -1;
  if (x.exponent > y.exponent + tol) return 1;
  return 0;
}

/** The larger of two rates (lexicographic, exact). */
export function maxRate(x: Rate, y: Rate): Rate {
  return compareRates(x, y, 0) >= 0 ? x : y;
}

/** Whether a rate is a bound at all (finite power and exponent). */
export function finiteRate(r: Rate): boolean {
  return Number.isFinite(r.power) && Number.isFinite(r.exponent);
}

/**
 * The exponent of `g` as a rate at power `power`: rateOf(g).exponent if g has that power, +Infinity if it grows faster
 * (a larger power), and, if it grows slower, 0 (or exponentOf(g) for power 1, which may be negative for vanishing
 * quantities). For power 1 this is exponentOf(g).
 * @throws EvalError for polyUnknown
 */
export function exponentAtPower(g: Growth, power: number): number {
  if (power === 1) return exponentOf(g);
  const r = rateOf(g);
  if (samePower(r.power, power)) return r.exponent;
  return r.power > power ? Infinity : 0;
}

/** Plain-text description of a rate in terms of N, e.g. "N^2", "2^(0.5·log^0.75 N)", "polylog(N)". */
export function describeRate(r: Rate, decimals = 4): string {
  if (r.power === 0) return 'polylog(N)';
  if (!Number.isFinite(r.power)) return 'superpolynomial';
  if (r.power === 1) return `N^${formatNumber(r.exponent, decimals)}`;
  return `2^(${formatNumber(r.exponent, decimals)}·log^${formatNumber(r.power, decimals)} N)`;
}
