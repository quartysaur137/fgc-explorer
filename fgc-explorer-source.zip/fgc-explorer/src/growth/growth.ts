/**
 * Growth algebra (SPEC §5): asymptotic classes of positive quantities f(N) as N → ∞, modulo constant factors and,
 * for polynomial classes, N^{o(1)} factors.
 *
 * Every operation returns a class that contains all possible results of the operation on members of its argument
 * classes ("upper-bound semantics"), or throws EvalError when no useful class exists. Nothing is silently mapped to 0.
 */

import { assert } from '../util/assert';

/** Failure to evaluate a quantity (unsupported or meaningless operation). Caught by the engine, never fatal. */
export class EvalError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'EvalError';
  }
}

/**
 * A growth class.
 *
 * AF:
 *   const(v)      = Θ(1); v is the exact value when known (v may be ≤ 0 only when used as an exponent).
 *   log(p, c)     = Θ((log N)^p) and ω(1), N^{o(1)}; p ∈ [0, ∞]: p = 0 means (log N)^{o(1)} (e.g. log log N),
 *                   p = ∞ means ω(polylog N) or a polylog of unknown degree; when p = 1 and c ≠ null the value is
 *                   c·log2(N)·(1 ± o(1)) (c < 0 only for quantities used as exponents of 2).
 *   poly(e)       = N^{e ± o(1)}, e ≠ 0.
 *   polyUnknown   = N^{Θ(1)} with an unknown (nonnegative) exponent.
 *   super         = N^{ω(1)}.
 * RI: poly.exp finite and ≠ 0; log.pow ∈ [0, ∞]; log.coef === null unless pow === 1; const.value finite or null.
 * SRE: all fields are readonly primitives (enforced by the type); no operation mutates a growth after creation.
 */
export type Growth =
  | { readonly kind: 'const'; readonly value: number | null }
  | { readonly kind: 'log'; readonly pow: number; readonly coef: number | null }
  | { readonly kind: 'poly'; readonly exp: number }
  | { readonly kind: 'polyUnknown' }
  | { readonly kind: 'super' };

/**
 * Exponent used for Ω(1) in exponents such as n^{2-Ω(1)}: some positive constant. It must exceed the engine's
 * comparison tolerance (1e-9), so that n^{2-Ω(1)} counts as strictly faster than n^2.
 */
export const TINY = 1e-6;

function checkRep(g: Growth): Growth {
  // Messages are built only on failure: this runs for every growth created (hot path).
  switch (g.kind) {
    case 'const':
      if (!(g.value === null || Number.isFinite(g.value))) fail(`const value must be finite: ${g.value}`);
      break;
    case 'log':
      if (!(g.pow >= 0)) fail(`log pow must be in [0, inf]: ${g.pow}`);
      if (!(g.coef === null || (g.pow === 1 && Number.isFinite(g.coef)))) fail(`log coef only for pow 1: ${g.coef}`);
      break;
    case 'poly':
      if (!(Number.isFinite(g.exp) && g.exp !== 0)) fail(`poly exponent must be finite and nonzero: ${g.exp}`);
      break;
    case 'polyUnknown':
    case 'super':
      break;
  }
  return g;
}

function fail(message: string): never {
  assert(false, message);
}

// ---- constructors ----

/**
 * Θ(1), with value `value` if known.
 * @throws EvalError if `value` is infinite or NaN (overflow in constant arithmetic, e.g. 10^{400})
 */
export function constant(value: number | null): Growth {
  if (value !== null && !Number.isFinite(value)) throw new EvalError(`constant overflow (${value})`);
  return checkRep({ kind: 'const', value });
}

/** Θ((log N)^pow); `coef` = coefficient of log2 N, kept only when pow === 1. */
export function logClass(pow = 1, coef: number | null = null): Growth {
  if (coef === 0 && pow === 1) return constant(0);
  return checkRep({ kind: 'log', pow, coef: pow === 1 ? coef : null });
}

/** N^{exp}; exp = 0 gives N^{o(1)} (represented as log(∞)). */
export function poly(exp: number): Growth {
  if (!Number.isFinite(exp)) throw new EvalError(`non-finite exponent ${exp}`);
  if (Math.abs(exp) < 1e-12) return logClass(Infinity);
  return checkRep({ kind: 'poly', exp });
}

export const POLY_UNKNOWN: Growth = checkRep({ kind: 'polyUnknown' });
export const SUPER: Growth = checkRep({ kind: 'super' });
/** N^{o(1)}: subpolynomial of unknown order. */
export const SUBPOLY: Growth = logClass(Infinity);

// ---- queries ----

export function isConst(g: Growth): g is Extract<Growth, { kind: 'const' }> {
  return g.kind === 'const';
}

/** The known numeric value of a constant growth, or null. */
export function constValue(g: Growth): number | null {
  return g.kind === 'const' ? g.value : null;
}

/**
 * The exponent e such that g = N^{e ± o(1)}.
 * @throws EvalError for polyUnknown (the exponent depends on an unspecified constant).
 * @returns +Infinity for super.
 */
export function exponentOf(g: Growth): number {
  switch (g.kind) {
    case 'poly':
      return g.exp;
    case 'const':
    case 'log':
      return 0;
    case 'super':
      return Infinity;
    case 'polyUnknown':
      throw new EvalError('the exponent depends on an unspecified constant (e.g. n^{O(1)})');
  }
}

/**
 * Rank of the coarse magnitude order on the real line:
 * negative log quantity < negative constant < 0 < poly(<0) < positive constant < log < poly(>0) < polyUnknown < super.
 * (Negative quantities only occur as exponents of 2, e.g. i·log2(1/4).)
 */
function rank(g: Growth): number {
  switch (g.kind) {
    case 'poly':
      return g.exp < 0 ? 0 : 3;
    case 'const':
      return g.value === null || g.value > 0 ? 1 : g.value === 0 ? -1 : -2;
    case 'log':
      return g.coef !== null && g.coef < 0 ? -3 : 2;
    case 'polyUnknown':
      return 4;
    case 'super':
      return 5;
  }
}

/** Both constants, or both Θ(log N) quantities with known coefficients: exact arithmetic applies. */
function exactPair(a: Growth, b: Growth): boolean {
  if (a.kind === 'const' && b.kind === 'const') return true;
  return a.kind === 'log' && b.kind === 'log' && a.pow === 1 && b.pow === 1 && a.coef !== null && b.coef !== null;
}

/**
 * Asymptotic comparison.
 * @returns -1 if a = o(b), 1 if b = o(a), 0 if same class (Θ, up to the precision of the representation),
 *          null if incomparable (polyUnknown vs a positive polynomial).
 */
export function compare(a: Growth, b: Growth): -1 | 0 | 1 | null {
  if ((a.kind === 'polyUnknown' && b.kind === 'poly' && b.exp > 0) || (b.kind === 'polyUnknown' && a.kind === 'poly' && a.exp > 0)) {
    return null;
  }
  const ra = rank(a);
  const rb = rank(b);
  if (ra !== rb) return ra < rb ? -1 : 1;
  if (a.kind === 'poly' && b.kind === 'poly') return a.exp === b.exp ? 0 : a.exp < b.exp ? -1 : 1;
  if (a.kind === 'log' && b.kind === 'log') {
    if (a.pow !== b.pow) return a.pow < b.pow ? -1 : 1;
    return 0;
  }
  return 0;
}

// ---- arithmetic ----

/** Sum (or maximum when `isMax`) of two classes of the same rank-order position. */
function combineSame(a: Growth, b: Growth, op: 'add' | 'max' | 'min'): Growth {
  if (a.kind === 'const' && b.kind === 'const') {
    if (a.value === null || b.value === null) {
      if (op === 'min') return a.value === null ? b : a;
      return constant(null);
    }
    return constant(op === 'add' ? a.value + b.value : op === 'max' ? Math.max(a.value, b.value) : Math.min(a.value, b.value));
  }
  if (a.kind === 'log' && b.kind === 'log') {
    // same pow (else compare() would have decided)
    if (a.pow === 1) {
      if (a.coef === null || b.coef === null) {
        if (op === 'min') return a.coef === null ? b : a;
        return logClass(1, null);
      }
      const c = op === 'add' ? a.coef + b.coef : op === 'max' ? Math.max(a.coef, b.coef) : Math.min(a.coef, b.coef);
      return logClass(1, c);
    }
    return a;
  }
  if (a.kind === 'poly' && b.kind === 'poly') return a; // equal exponents
  return a; // polyUnknown/polyUnknown, super/super
}

/** Class of a + b (both nonnegative quantities, or exponents for const/log). */
export function add(a: Growth, b: Growth): Growth {
  if (exactPair(a, b)) return combineSame(a, b, 'add');
  const c = compare(a, b);
  if (c === null) return POLY_UNKNOWN;
  if (c < 0) return b;
  if (c > 0) return a;
  return combineSame(a, b, 'add');
}

/** Class of max(a, b). */
export function max(a: Growth, b: Growth): Growth {
  if (exactPair(a, b)) return combineSame(a, b, 'max');
  const c = compare(a, b);
  if (c === null) return POLY_UNKNOWN;
  if (c < 0) return b;
  if (c > 0) return a;
  return combineSame(a, b, 'max');
}

/** Class of min(a, b) (an upper bound on the minimum: a known bound is preferred over an unknown one). */
export function min(a: Growth, b: Growth): Growth {
  if (exactPair(a, b)) return combineSame(a, b, 'min');
  const c = compare(a, b);
  if (c === null) return a.kind === 'polyUnknown' ? b : a;
  if (c < 0) return a;
  if (c > 0) return b;
  return combineSame(a, b, 'min');
}

/**
 * Class of a − b.
 * Exact for constants and for Θ(log N) with known coefficients; if b is of strictly lower order the result is a;
 * if both are of the same polynomial order the difference is assumed to stay Θ(a) (sheet formulas such as 2n − 1).
 * @throws EvalError if b is of strictly higher order than a (the difference would be negative).
 */
export function sub(a: Growth, b: Growth): Growth {
  if (a.kind === 'const' && b.kind === 'const') {
    return a.value === null || b.value === null ? constant(null) : constant(a.value - b.value);
  }
  if (exactPair(a, b)) return logClass(1, (a as { coef: number }).coef - (b as { coef: number }).coef);
  const c = compare(a, b);
  if (c === null) return POLY_UNKNOWN;
  if (c > 0) return a;
  if (c < 0) {
    if (a.kind === 'const' && a.value !== null && b.kind === 'poly' && b.exp < 0) return a;
    throw new EvalError('a difference is dominated by its subtracted term (negative quantity)');
  }
  if (a.kind === 'const' && b.kind === 'const') {
    return a.value === null || b.value === null ? constant(null) : constant(a.value - b.value);
  }
  if (a.kind === 'log' && b.kind === 'log' && a.pow === 1 && a.coef !== null && b.coef !== null) {
    return logClass(1, a.coef - b.coef);
  }
  return a;
}

/** Class of −a (only meaningful for constants and exponent-like log quantities). */
export function negate(a: Growth): Growth {
  if (a.kind === 'const') return constant(a.value === null ? null : -a.value);
  if (a.kind === 'log' && a.pow === 1 && a.coef !== null) return logClass(1, -a.coef);
  throw new EvalError('cannot negate a growing quantity');
}

/** Class of a · b. */
export function mul(a: Growth, b: Growth): Growth {
  if (constValue(a) === 0 || constValue(b) === 0) return constant(0);
  if (a.kind === 'super' || b.kind === 'super') return SUPER;
  if (a.kind === 'polyUnknown' || b.kind === 'polyUnknown') return POLY_UNKNOWN;
  if (a.kind === 'poly' && b.kind === 'poly') return poly(a.exp + b.exp);
  if (a.kind === 'poly') return a;
  if (b.kind === 'poly') return b;
  if (a.kind === 'const' && b.kind === 'const') {
    return constant(a.value === null || b.value === null ? null : a.value * b.value);
  }
  if (a.kind === 'const' || b.kind === 'const') {
    const k = (a.kind === 'const' ? a : b) as Extract<Growth, { kind: 'const' }>;
    const l = (a.kind === 'log' ? a : b) as Extract<Growth, { kind: 'log' }>;
    if (k.value !== null && k.value < 0 && l.pow !== 1) throw new EvalError('negative multiple of a polylogarithm');
    if (l.pow !== 1) return l;
    return logClass(1, k.value === null || l.coef === null ? null : k.value * l.coef);
  }
  // log × log
  const la = a as Extract<Growth, { kind: 'log' }>;
  const lb = b as Extract<Growth, { kind: 'log' }>;
  if ((la.coef ?? 1) < 0 || (lb.coef ?? 1) < 0) throw new EvalError('product of negative logarithmic quantities');
  return logClass(la.pow + lb.pow, null);
}

/** Class of 1/a. */
export function inv(a: Growth): Growth {
  switch (a.kind) {
    case 'poly':
      return poly(-a.exp);
    case 'const':
      if (a.value === 0) throw new EvalError('division by zero');
      return constant(a.value === null ? null : 1 / a.value);
    case 'log':
      if (a.coef !== null && a.coef < 0) throw new EvalError('division by a negative quantity');
      return constant(null); // o(1) ⊆ O(1)
    case 'polyUnknown':
    case 'super':
      return constant(null);
  }
}

/** Class of a / b. */
export function div(a: Growth, b: Growth): Growth {
  return mul(a, inv(b));
}

/** Class of 2^x. */
export function exp2(x: Growth): Growth {
  switch (x.kind) {
    case 'const':
      return constant(x.value === null ? null : guardFinite(2 ** x.value));
    case 'log':
      if (x.pow === 1) return x.coef === null ? POLY_UNKNOWN : poly(x.coef);
      return x.pow < 1 ? SUBPOLY : SUPER;
    case 'poly':
      return x.exp > 0 ? SUPER : constant(1);
    case 'polyUnknown':
    case 'super':
      return SUPER;
  }
}

function guardFinite(v: number): number {
  if (!Number.isFinite(v)) throw new EvalError('constant overflow');
  return v;
}

/** Class of log2(x). */
export function log2(x: Growth): Growth {
  switch (x.kind) {
    case 'const':
      if (x.value === null) return constant(null);
      if (x.value <= 0) throw new EvalError('logarithm of a nonpositive constant');
      return constant(Math.log2(x.value));
    case 'log':
      if (x.coef !== null && x.coef < 0) throw new EvalError('logarithm of a negative quantity');
      return logClass(0);
    case 'poly':
      return logClass(1, x.exp);
    case 'polyUnknown':
      return logClass(1, null);
    case 'super':
      throw new EvalError('logarithm of a superpolynomial quantity');
  }
}

/**
 * Class of a^k for an exponent class k.
 * Constant exponents scale; a constant base b > 0 with a growing exponent gives exp2(k · log2 b); a growing base with a
 * growing exponent is superpolynomial.
 */
export function power(a: Growth, k: Growth): Growth {
  if (k.kind === 'const') {
    const v = k.value;
    if (v === 0) return constant(1);
    if (v === null) {
      switch (a.kind) {
        case 'poly':
          return a.exp > 0 ? POLY_UNKNOWN : constant(null);
        case 'const':
          return constant(null);
        case 'log':
          return SUBPOLY;
        case 'polyUnknown':
          return POLY_UNKNOWN;
        case 'super':
          return SUPER;
      }
    }
    switch (a.kind) {
      case 'poly':
        return poly(a.exp * v);
      case 'const':
        if (a.value === null) return constant(null);
        if (a.value === 0 && v < 0) throw new EvalError('division by zero');
        if (a.value < 0 && !Number.isInteger(v)) throw new EvalError('fractional power of a negative constant');
        return constant(guardFinite(a.value ** v));
      case 'log':
        if (v < 0) return constant(null);
        if (a.coef !== null && a.coef < 0) throw new EvalError('power of a negative quantity');
        return logClass(a.pow * v, a.pow === 1 && v === 1 ? a.coef : null);
      case 'polyUnknown':
        return v > 0 ? POLY_UNKNOWN : constant(null);
      case 'super':
        return v > 0 ? SUPER : constant(null);
    }
  }
  // growing (or polyUnknown/super) exponent
  if (a.kind === 'const') {
    if (a.value === null) return exp2(mul(k, constant(null)));
    if (a.value <= 0) throw new EvalError('nonpositive base with a growing exponent');
    return exp2(mul(k, constant(Math.log2(a.value))));
  }
  if (a.kind === 'poly' && a.exp < 0) return constant(null);
  if (k.kind === 'log' && k.coef !== null && k.coef < 0) return constant(null);
  return SUPER;
}

/** Class of ⌈a⌉: exact on known constants; 1 for vanishing quantities (N^{-e}); otherwise a. */
export function ceil(a: Growth): Growth {
  if (a.kind === 'const' && a.value !== null) return constant(Math.ceil(a.value - 1e-12));
  if (a.kind === 'poly' && a.exp < 0) return constant(1);
  return a;
}

/** Class of ⌊a⌋: exact on known constants; 0 for vanishing quantities (N^{-e}); otherwise a. */
export function floor(a: Growth): Growth {
  if (a.kind === 'const' && a.value !== null) return constant(Math.floor(a.value + 1e-12));
  if (a.kind === 'poly' && a.exp < 0) return constant(0);
  return a;
}

/** Class of binom(a, b): exact for known constants, a^b for a constant b. */
export function binom(a: Growth, b: Growth): Growth {
  const bv = constValue(b);
  if (b.kind !== 'const') throw new EvalError('binomial with a growing lower index');
  const av = constValue(a);
  if (av !== null && bv !== null && Number.isInteger(bv) && bv >= 0) {
    let r = 1;
    for (let i = 0; i < bv; i++) r = (r * (av - i)) / (i + 1);
    return constant(r);
  }
  return power(a, b);
}

/** Class of the inverse Ackermann function α(a). */
export function inverseAckermann(a: Growth): Growth {
  return a.kind === 'const' ? constant(null) : logClass(0);
}

/** Human-readable description, e.g. "N^{1.5}", "Θ(log N)", "2.5". */
export function describe(g: Growth): string {
  switch (g.kind) {
    case 'const':
      return g.value === null ? 'Θ(1)' : formatNumber(g.value);
    case 'log':
      if (g.pow === 1) return g.coef === null ? 'Θ(log N)' : `${formatNumber(g.coef)}·log₂N`;
      if (g.pow === 0) return 'Θ(log log N)-like';
      if (g.pow === Infinity) return 'N^{o(1)}';
      return `Θ(log^${formatNumber(g.pow)} N)`;
    case 'poly':
      return `N^${formatNumber(g.exp)}`;
    case 'polyUnknown':
      return 'N^{O(1)}';
    case 'super':
      return 'N^{ω(1)}';
  }
}

/** Number formatting with up to 4 decimals and no trailing zeros. */
export function formatNumber(x: number, decimals = 4): string {
  if (!Number.isFinite(x)) return x > 0 ? '∞' : x < 0 ? '−∞' : 'NaN';
  const s = x.toFixed(decimals);
  return s.includes('.') ? s.replace(/\.?0+$/, '') : s;
}
