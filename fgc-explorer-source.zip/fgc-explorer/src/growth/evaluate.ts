/**
 * Evaluation of formula expressions to growth classes (SPEC §4.2, §6.4).
 */

import { Expr, Formula } from '../math/ast';
import * as G from './growth';
import { EvalError, Growth } from './growth';

/** Handler for oracle calls: given the function name and the classes of the arguments, the class of the call. */
export type CallHandler = (fn: string, args: readonly Growth[]) => Growth;

export interface EvalContext {
  /** Identifiers in scope and their classes. */
  readonly env: ReadonlyMap<string, Growth>;
  /** Value of oracle calls. Required if the expression contains calls. */
  readonly onCall?: CallHandler;
  /** Number of sample points for sums over logarithmic ranges (default 9). */
  readonly sumGridPoints?: number;
}

/** Upper end used for \sum_{i=0}^{O(\log N)} when the constant is unknown (i ≤ C·log2 N). */
export const UNKNOWN_LOG_RANGE = 8;

/**
 * Halving rounds of the local search for the largest term of a sum over a logarithmic range (precision ≈ 2^-30 of the
 * grid step). An underestimate here is the only numerical error that is not one-sided, so it must stay far below the
 * conflict tolerance (analysis.ts).
 */
const SUM_REFINE_ROUNDS = 30;

/** Functions that may be applied by name, as in \alpha(n). */
const NAMED_FUNCTIONS: ReadonlyMap<string, (g: Growth) => Growth> = new Map([['alpha', G.inverseAckermann]]);

/** True iff `name` is a function usable in `name(args)` position when it is not a variable. */
export function isNamedFunction(name: string): boolean {
  return NAMED_FUNCTIONS.has(name);
}

/**
 * Evaluate `e`.
 * @throws EvalError if the expression has no useful class (unknown symbol, unbounded sum, \deg, overflow, ...).
 */
export function evaluate(e: Expr, ctx: EvalContext): Growth {
  switch (e.type) {
    case 'num':
      return G.constant(e.value);
    case 'var': {
      const g = ctx.env.get(e.name);
      if (g === undefined) throw new EvalError(`unknown symbol ${e.name}`);
      return g;
    }
    case 'add': {
      let acc: Growth | null = null;
      for (const t of e.terms) {
        if (t.sign === 1) {
          const g = evaluate(t.expr, ctx);
          acc = acc === null ? g : G.add(acc, g);
        }
      }
      for (const t of e.terms) {
        if (t.sign === -1) {
          const g = evaluate(t.expr, ctx);
          acc = acc === null ? G.negate(g) : G.sub(acc, g);
        }
      }
      return acc!;
    }
    case 'neg':
      return G.negate(evaluate(e.arg, ctx));
    case 'mul':
      return e.factors.map((f) => evaluate(f, ctx)).reduce(G.mul);
    case 'div':
      return G.div(evaluate(e.num, ctx), evaluate(e.den, ctx));
    case 'pow':
      return G.power(evaluate(e.base, ctx), evaluate(e.exp, ctx));
    case 'call': {
      if (!ctx.onCall) throw new EvalError(`oracle call ${e.fn}(...) not allowed here`);
      const args = e.args.map((a) => evaluate(a, ctx));
      return ctx.onCall(e.fn, args);
    }
    case 'apply': {
      if (e.name === 'omega') {
        // \omega(1) usually means little-omega, but \omega is also the matrix multiplication constant.
        throw new EvalError('ambiguous \\omega(...): write \\omega \\cdot (...) for the constant (little-omega is not supported)');
      }
      const g = ctx.env.get(e.name);
      if (g !== undefined) {
        // \alpha(n) where α is also a parameter (arboricity, a free parameter): the product or the inverse Ackermann
        // function? Neither reading is safe, so say so.
        if (NAMED_FUNCTIONS.has(e.name)) {
          throw new EvalError(`ambiguous \\${e.name}(...): ${e.name} is a parameter here, so write \\${e.name} \\cdot (...) for the product (\\${e.name}(n) is the inverse Ackermann function only where ${e.name} is not a parameter)`);
        }
        // x(y) with x a variable: a product.
        return e.args.map((a) => evaluate(a, ctx)).reduce(G.mul, g);
      }
      const f = NAMED_FUNCTIONS.get(e.name);
      if (f === undefined) throw new EvalError(`unknown function ${e.name}`);
      if (e.args.length !== 1) throw new EvalError(`${e.name}(...) takes one argument`);
      return f(evaluate(e.args[0]!, ctx));
    }
    case 'func':
      return evaluateFunc(e, ctx);
    case 'bound':
      return evaluateBound(e, ctx);
    case 'sum':
      return evaluateSum(e, ctx);
  }
}

function evaluateFunc(e: Extract<Expr, { type: 'func' }>, ctx: EvalContext): Growth {
  const args = (): Growth[] => e.args.map((a) => evaluate(a, ctx));
  const one = (): Growth => evaluate(e.args[0]!, ctx);
  switch (e.fn) {
    case 'log': {
      const x = log2Of(one());
      if (e.args.length < 2) return x;
      const b = G.constValue(evaluate(e.args[1]!, ctx));
      if (b === null || b <= 1) throw new EvalError('logarithm base must be a known constant > 1');
      return G.mul(x, G.constant(1 / Math.log2(b)));
    }
    case 'sqrt':
      return G.power(one(), G.constant(0.5));
    case 'root': {
      const k = G.constValue(evaluate(e.args[1]!, ctx));
      if (k === null || k === 0) throw new EvalError('root index must be a known nonzero constant');
      return G.power(one(), G.constant(1 / k));
    }
    case 'ceil':
      return G.ceil(one());
    case 'floor':
      return G.floor(one());
    case 'abs': {
      const x = one();
      if (x.kind === 'const' && x.value !== null) return G.constant(Math.abs(x.value));
      if (x.kind === 'log' && x.coef !== null) return G.logClass(x.pow, Math.abs(x.coef));
      return x;
    }
    case 'max':
      return args().reduce(G.max);
    case 'min':
      return args().reduce(G.min);
    case 'binom': {
      const [a, b] = args();
      return G.binom(a!, b!);
    }
    case 'deg':
      throw new EvalError('\\deg(v) depends on the input graph');
    case 'poly':
      return G.power(one(), G.constant(null));
    case 'polylog':
      return G.power(log2Of(one()), G.constant(null));
    case 'exp':
      return G.exp2(G.mul(one(), G.constant(Math.LOG2E)));
  }
}

/** log2 of a size: sizes below 1 are treated as constants (log of O(1) is O(1)). */
function log2Of(x: Growth): Growth {
  if (x.kind === 'poly' && x.exp < 0) return G.constant(null);
  return G.log2(x);
}

function evaluateBound(e: Extract<Expr, { type: 'bound' }>, ctx: EvalContext): Growth {
  switch (e.kind) {
    case 'O':
    case 'Osub':
    case 'Theta': {
      // O(·) hides a constant factor, which is invisible except for constants and the coefficients of c·log^p N:
      // O(1) is an unknown constant (n^{O(1)}, 2^{O(k)}) and O(log n) has an unknown coefficient (2^{O(log n)}).
      const x = evaluate(e.arg, ctx);
      if (x.kind === 'const') return G.constant(x.value === 0 ? 0 : null); // O(0) = 0 (e.g. O(γ) with γ → 0)
      if (x.kind === 'log' && x.coef !== null) return G.logClass(x.pow, null);
      return x;
    }
    case 'softO':
    case 'softTheta':
      // (polylogarithmic factors: of rate zero, so that Õ(2^{0.5 n^{0.75}}) keeps its rate)
      return G.mul(evaluate(e.arg, ctx), G.POLYLOG);
    case 'Omega':
    case 'softOmega': {
      const x = evaluate(e.arg, ctx);
      if (x.kind === 'const' && x.value !== null && x.value > 0) return G.constant(x.value * G.TINY);
      throw new EvalError('\\Omega(...) is only supported for positive constants, as in n^{2-\\Omega(1)}');
    }
    case 'o': {
      // An infinitesimal multiple of the argument (see INFINITESIMAL): n^{1+o(1)} is N^1, n^{o(1)} is N^{o(1)}, and at
      // CNF-SAT's scale 2^{o(n)} is 2^{o(n)} and 2^{o(n^{0.75})} is 2^{o(n^{0.75})}.
      const x = evaluate(e.arg, ctx);
      if (x.kind === 'const') return G.constant(x.value === 0 ? 0 : Math.abs(x.value ?? 1) * G.INFINITESIMAL);
      if (x.kind === 'log' && x.pow > 0 && x.pow < Infinity && (x.coef === null || x.coef > 0)) return G.logClass(x.pow, (x.coef ?? 1) * G.INFINITESIMAL);
      throw new EvalError('o(...) is only supported for constants and logarithmic quantities, as in n^{1+o(1)} or 2^{o(n)} with n = log N');
    }
  }
}

/**
 * \sum_{i=lo}^{hi} body (SPEC §6.4).
 * Exact for a known constant range of at most 64 integers. For hi = Θ(log N) the sum has O(log N) terms, so its class is
 * the largest term (times a log factor); terms are sampled at i = θ·log2 N for θ on a grid over [0, c] plus a local
 * refinement around the best sample.
 */
function evaluateSum(e: Extract<Expr, { type: 'sum' }>, ctx: EvalContext): Growth {
  if (e.index === null || e.hi === null) throw new EvalError('sum without an explicit range');
  const index = e.index;
  const lo = e.lo === null ? G.constant(0) : evaluate(e.lo, ctx);
  const hi = evaluate(e.hi, ctx);
  const withIndex = (i: Growth): Growth => {
    const env = new Map(ctx.env);
    env.set(index, i);
    return evaluate(e.body, { ...ctx, env });
  };
  const loV = G.constValue(lo);
  const hiV = G.constValue(hi);
  if (lo.kind !== 'const') throw new EvalError('sum with a growing lower limit');
  if (hi.kind === 'const') {
    if (loV === null || hiV === null) throw new EvalError('sum over an unknown constant range');
    const a = Math.ceil(loV - 1e-9);
    const b = Math.floor(hiV + 1e-9);
    if (b - a + 1 > 64) throw new EvalError('sum over more than 64 constant indices');
    let acc: Growth | null = null;
    for (let i = a; i <= b; i++) {
      const g = withIndex(G.constant(i));
      acc = acc === null ? g : G.add(acc, g);
    }
    if (acc === null) throw new EvalError('empty sum');
    return acc;
  }
  if (hi.kind !== 'log' || hi.pow !== 1) throw new EvalError('sum with a polynomial or unknown number of terms');
  const unknownRange = hi.coef === null;
  const thetaMax = unknownRange ? UNKNOWN_LOG_RANGE : hi.coef!;
  if (thetaMax <= 0) throw new EvalError('sum with a nonpositive range');
  const at = (theta: number): Growth => withIndex(theta <= 0 ? G.constant(loV ?? 0) : G.logClass(1, theta));
  const keyAt = (theta: number): TermKey => termKey(at(theta));
  const points = Math.max(3, ctx.sumGridPoints ?? 9);
  let bestTheta = 0;
  let best: TermKey | null = null;
  for (let j = 0; j < points; j++) {
    const theta = (thetaMax * j) / (points - 1);
    const x = keyAt(theta);
    if (best === null || compareKeys(x, best, 0) > 0) {
      best = x;
      bestTheta = theta;
    }
  }
  // Local refinement (the term exponent is piecewise linear in θ; its maximum may sit between grid points).
  let step = thetaMax / (points - 1);
  for (let round = 0; round < SUM_REFINE_ROUNDS; round++) {
    for (const d of [-step / 2, step / 2]) {
      const theta = Math.min(thetaMax, Math.max(0, bestTheta + d));
      const x = keyAt(theta);
      if (compareKeys(x, best!, 1e-12) > 0) {
        best = x;
        bestTheta = theta;
      }
    }
    step /= 2;
  }
  // (Only the rate matters here: terms of rate zero may keep growing with the hidden constant.)
  if (unknownRange && compareKeys(keyAt(thetaMax), keyAt(thetaMax / 2), 1e-9, RATE_DEPTH) > 0) {
    throw new EvalError('sum over O(log n) terms whose largest term depends on the hidden constant');
  }
  return G.mul(at(bestTheta), G.logClass(1, null));
}

/**
 * The order of the terms of a sum: [tier, exponent, power, coefficient, log power, log coefficient]. Tier 1 holds the
 * classes up to polynomial, ordered by their exponent (negative for vanishing terms) and, among those of exponent 0, by
 * the rate of the sub-polynomial ones (2^{c·L^a}, a ≤ 1), then those of rate zero by their order c·L^p (constants
 * below every L^p); tier 2 the classes 2^{c·L^a} with a > 1; tier 3 those without bound. The first RATE_DEPTH
 * components determine the rate.
 * @throws EvalError for polyUnknown
 */
type TermKey = readonly [number, number, number, number, number, number];

const RATE_DEPTH = 4;

function termKey(g: Growth): TermKey {
  if (g.kind === 'super') return [3, 0, 0, 0, 0, 0];
  if (g.kind === 'qpoly' && g.pow > 1) return [2, 0, g.pow, g.coef, 0, 0];
  const e = G.exponentOf(g);
  if (g.kind === 'qpoly') return [1, e, g.pow, g.coef, 0, 0];
  if (g.kind === 'log') return [1, e, 0, 0, g.pow, g.coef ?? 1];
  if (g.kind === 'const') return [1, e, 0, 0, -1, g.value ?? 1];
  return [1, e, 0, 0, 0, 0];
}

/** Lexicographic comparison of the first `depth` components of term keys, with tolerance `tol` on each. */
function compareKeys(a: TermKey, b: TermKey, tol: number, depth: number = a.length): number {
  for (let i = 0; i < depth; i++) {
    if (a[i]! > b[i]! + tol) return 1;
    if (a[i]! < b[i]! - tol) return -1;
  }
  return 0;
}

/** Result of evaluating a formula: the class of the first alternative that evaluates, and its index. */
export interface FormulaValue {
  readonly value: Growth;
  readonly alternative: number;
}

/**
 * Evaluate the alternatives of `f` in order and return the first that succeeds.
 * @throws EvalError (the last alternative's error, mentioning the others) if none evaluates.
 */
export function evaluateFormula(f: Formula, ctx: EvalContext): FormulaValue {
  const errors: string[] = [];
  for (let i = 0; i < f.alternatives.length; i++) {
    try {
      return { value: evaluate(f.alternatives[i]!, ctx), alternative: i };
    } catch (err) {
      if (!(err instanceof EvalError)) throw err;
      errors.push(err.message);
    }
  }
  throw new EvalError(errors.length === 1 ? errors[0]! : `no alternative evaluates: ${errors.join('; ')}`);
}
