/**
 * The bounds CSV that encodes the config's initial knobs (used by write-initial-bounds.ts and by its test).
 */

import { writeBoundsCsv } from '../src/model/boundsCsv';
import { initialScenario, validateConfig } from '../src/model/config';
import { buildModel } from '../src/model/model';
import { CsvTable } from '../src/util/csv';

/** @returns the bounds CSV of the initial scenario of `configJson` (problem names spelled as in `sheetCsv`). */
export function initialBoundsCsv(sheetCsv: string, configJson: string): string {
  const config = validateConfig(JSON.parse(configJson)).value;
  const model = buildModel(CsvTable.fromText(sheetCsv).table, config);
  const scenario = initialScenario(config);
  return writeBoundsCsv(scenario.knobs, model, scenario.problems);
}
