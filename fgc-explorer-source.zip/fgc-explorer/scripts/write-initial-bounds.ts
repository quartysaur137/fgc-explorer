/**
 * Writes data/initial-bounds.csv: the initial hypotheses and algorithms of data/default-config.json as a bounds CSV
 * (SPEC §3.5), i.e. what "Export" in the app gives right after "Restore initial settings".
 * Run after changing `initialKnobs` in the config: `npm run bounds-sample` (a test checks that the file is current).
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { initialBoundsCsv } from './initialBounds';

const root = new URL('..', import.meta.url);
const out = new URL('data/initial-bounds.csv', root);
writeFileSync(out, initialBoundsCsv(readFileSync(new URL('data/FGC_Reductions_filled.csv', root), 'utf8'), readFileSync(new URL('data/default-config.json', root), 'utf8')));
console.log(`wrote ${out.pathname}`);
