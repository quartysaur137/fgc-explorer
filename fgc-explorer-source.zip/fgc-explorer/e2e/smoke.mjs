// End-to-end smoke test of the built single-file app (run `npm run build` first).
//
// Needs Playwright: `npm install --no-save playwright && npx playwright install chromium`, or set CHROMIUM_PATH to a
// Chromium/Chrome binary and install `playwright-core` instead.
//
// Checks: the page loads offline without console errors, renders every problem, shows the default bounds and the
// initial-settings note, keeps labels readable-sized at "fit" (larger with the panels hidden), lists the bounds in one
// box per problem and reacts to a knob change through the UI, imports the sample bounds CSV, the header's buttons
// (grouped by what they act on) download their files and load an exported scenario back, Shift-click selects several
// problems (one inspector section each), the focus modes dim what they should (bound derivations: a problem whose
// bounds come from its own knobs stands alone), and the inspector renders a problem and a reduction.

import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const file = join(root, 'dist', 'fgc-explorer.html');
if (!existsSync(file)) {
  console.error('dist/fgc-explorer.html not found: run `npm run build` first');
  process.exit(2);
}

let chromium;
try {
  ({ chromium } = await import('playwright'));
} catch {
  try {
    ({ chromium } = await import('playwright-core'));
  } catch {
    console.error('Playwright is not installed (see the comment at the top of e2e/smoke.mjs)');
    process.exit(2);
  }
}

const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
const page = await browser.newPage({ viewport: { width: 1500, height: 950 } });
const problems = [];
page.on('console', (m) => {
  if (m.type() === 'error') problems.push(`console error: ${m.text()}`);
});
page.on('pageerror', (e) => problems.push(`page error: ${e.message}`));
// The app must not need the network.
await page.route(/^https?:/, (route) => {
  problems.push(`network request: ${route.request().url()}`);
  return route.abort();
});

const ready = () => page.waitForFunction(() => window.fgcExplorer && !window.fgcExplorer.store.busy, null, { timeout: 60000 });
await page.goto(pathToFileURL(file).href);
await page.evaluate(() => localStorage.clear());
await page.reload();
await ready();

const label = (id) => page.evaluate((x) => window.fgcExplorer.graph.labelOf(x), id);
const count = await page.evaluate(() => window.fgcExplorer.graph.problemCount);
assert.ok(count > 200, `only ${count} problems rendered`);
assert.match(await label('Orthogonal Vectors / OV'), /≥\sn\^2/);
assert.match(await label('Graph Triangle Problems / Negative Triangle Detection'), /≥\sn\^3/);

// The compact layout keeps labels reasonably large when the whole graph is shown, and more so with the panels hidden.
const px = () => page.evaluate(() => window.fgcExplorer.graph.labelPixels);
const shown = await px();
assert.ok(shown > 3, `labels at fit: ${shown.toFixed(2)} px`);
await page.click('#btn-panel-all');
await page.waitForFunction((before) => window.fgcExplorer.graph.labelPixels > before * 1.3, shown, { timeout: 5000 });
await page.click('#btn-panel-all');
await page.waitForFunction(() => !document.querySelector('main').classList.contains('hide-left'));

// The initial knobs are listed in the inspector, some of them start switched off (compact rows), and the left panel
// has one box per problem.
assert.equal(await page.locator('#initial-settings .initial-groups > li').count() >= 8, true);
assert.equal(await page.locator('#left .knob.disabled').count() >= 5, true);
assert.equal(await page.locator('#left .box').count() >= 20, true);
assert.match(await page.textContent('#left .box[data-problem="3SUM / 3SUM"] .box-bounds'), /≥\sn\^2/);

// Move the 3SUM hypothesis to 1.5 through its number input.
const changed = await page.evaluate(() => {
  const card = [...document.querySelectorAll('#left .box[data-problem="3SUM / 3SUM"] .knob')].find((c) => c.querySelector('.kind')?.textContent === 'LB');
  if (!card) return false;
  const input = card.querySelector('input.num');
  input.value = '1.5';
  input.dispatchEvent(new Event('change'));
  return true;
});
assert.ok(changed, '3SUM knob not found');
await page.waitForTimeout(100);
await ready();
assert.match(await label('Geometric Base / GeomBase'), /≥\sn\^1\.5/);

// Bounds CSV: importing the sample (the initial settings) with "Replace" gives the initial knobs again.
const initialKnobs = await page.evaluate(() => window.fgcExplorer.store.get().scenario.knobs.length);
const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.click('#left .panel-actions button:has-text("Import")')]);
await chooser.setFiles(join(root, 'data', 'initial-bounds.csv'));
await page.waitForSelector('.modal .import-modes');
await page.click('.modal-foot .primary');
await ready();
assert.equal(await page.evaluate(() => window.fgcExplorer.store.get().scenario.knobs.length), initialKnobs);
assert.match(await label('Geometric Base / GeomBase'), /≥\sn\^2/, 'the 3SUM hypothesis is back at 2');

// Header: one segment per thing acted on, each button named after its visible verb and the segment ("Load…" in
// "Reductions" is "Load reductions sheet"); the exports download their files and an exported scenario loads back.
const segments = await page.evaluate(() =>
  [...document.querySelectorAll('header .seg')].map((seg) => ({
    name: document.getElementById(seg.getAttribute('aria-labelledby'))?.textContent,
    buttons: [...seg.querySelectorAll('button')].map((b) => [b.textContent.replace(/[＋…]/g, '').trim(), b.getAttribute('aria-label') ?? '']),
  })),
);
assert.deepEqual(
  segments.map((seg) => seg.name),
  ['Reductions', 'Scenario', 'Config'],
);
for (const seg of segments) {
  for (const [text, name] of seg.buttons) assert.ok(name.startsWith(text), `header button "${text}" is named "${name}"`);
}
const downloads = {};
for (const id of ['#btn-export-sheet', '#btn-export-scenario', '#btn-export-config']) {
  const [download] = await Promise.all([page.waitForEvent('download'), page.click(id)]);
  downloads[id] = { name: download.suggestedFilename(), path: await download.path() };
}
assert.deepEqual(
  Object.values(downloads).map((d) => d.name),
  ['FGC_Reductions_edited.csv', 'fgc-scenario.json', 'fgc-engine-config.json'],
);
const knobsBefore = await page.evaluate(() => JSON.stringify(window.fgcExplorer.store.get().scenario));
const [scenarioChooser] = await Promise.all([page.waitForEvent('filechooser'), page.click('#btn-load-scenario')]);
await scenarioChooser.setFiles(downloads['#btn-export-scenario'].path);
await page.waitForSelector('.toast:has-text("loaded")');
await ready();
assert.equal(await page.evaluate(() => JSON.stringify(window.fgcExplorer.store.get().scenario)), knobsBefore);

// Selection: a click selects one problem, Shift-click in the table adds another; the inspector has a section for each.
const selection = () => page.evaluate(() => window.fgcExplorer.store.get().selection.map((x) => x.id));
await page.click('#left .box[data-problem="3SUM / 3SUM"] .box-name');
await page.fill('#search', 'GeomBase');
await page.click('#bottom-body tr.clickable:has-text("GeomBase")', { modifiers: ['Shift'] });
await page.fill('#search', '');
assert.deepEqual(await selection(), ['3SUM / 3SUM', 'Geometric Base / GeomBase']);
assert.equal(await page.locator('#right details.item').count(), 2);

// Focus modes: everything, ancestors and descendants, neighbours, and the derivations of the best bounds.
const undimmed = async (mode) => {
  await page.selectOption('#opt-focus', mode);
  return page.evaluate(() => window.fgcExplorer.graph.undimmedProblems);
};
const all = await undimmed('off');
const lineage = await undimmed('lineage');
const neighbours = await undimmed('neighbours');
assert.ok(all > lineage && lineage > neighbours && neighbours > 2, `${all} > ${lineage} > ${neighbours} > 2`);
const derived = await undimmed('derivations');
assert.ok(derived >= 2 && derived < neighbours, String(derived));
await page.click('#left .box[data-problem="3SUM / 3SUM"] .box-name');
assert.equal(await undimmed('derivations'), 1, "3SUM's bounds come from its own knobs");
const marks = await page.evaluate(() => window.fgcExplorer.graph.marksOf({ kind: 'problem', id: '3SUM / 3SUM' }));
assert.deepEqual(marks.sort(), ['path-lb', 'path-ub', 'selected']);
await page.selectOption('#opt-focus', 'off');

// Inspector: a problem and a reduction.
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'problem', id: '3SUM / 3SUM' }] })));
await page.waitForSelector('#right .regime-row');
await page.click('#right .regime-row');
await page.waitForSelector('#right .derivations');
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'row', id: '2' }] })));
await page.waitForSelector('#right .engine');

// Help dialog opens and closes.
await page.click('#btn-help');
await page.waitForSelector('.modal');
await page.keyboard.press('Escape');

await browser.close();
assert.deepEqual(problems, []);
console.log(`e2e smoke test passed (${count} problems)`);
