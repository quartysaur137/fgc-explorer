// End-to-end smoke test of the built single-file app (run `npm run build` first).
//
// Needs Playwright: `npm install --no-save playwright && npx playwright install chromium`, or set CHROMIUM_PATH to a
// Chromium/Chrome binary and install `playwright-core` instead.
//
// Checks: the page loads offline without console errors or warnings, renders every problem, shows the default bounds and the
// initial-settings note, starts without family boxes (the toggle draws them), keeps labels readable-sized at "fit" (larger with the panels hidden), lists the bounds in one
// box per problem and reacts to a knob change through the UI, imports the sample bounds CSV, the header's buttons
// (grouped by what they act on) download their files and load an exported scenario back, Shift-click selects several
// problems (one inspector section each), the focus modes dim what they should (bound derivations: a problem whose
// bounds come from its own knobs stands alone), pointing at a problem's name or a reduction's ID in a panel
// highlights it in the graph, the light/dark toggle switches the page's colors and back, and the inspector renders a
// problem (with a derivation and, when opened, what each reduction from it gives) and a reduction; the settings have
// the "UB detours" limit and no limit on lower-bound derivations; the knob of an exponential-time problem has a power
// (running times 2^{c·n^a}); the search (above the graph) filters the left panel's boxes by problem name, Bound ID or
// note, and Enter goes to what it found; Bound IDs in the inspector show their bounds in the left panel; a problem's
// limits of parameters are listed, and a pinned regime beyond them shows the regime it stands for. And (November 2026)
// the Help dialog keeps the focus; files of the other kind are refused; settings changes keep the section open and the
// panel in place; number fields refuse values out of range (a decimal comma is a point); a formula bound comes back
// from "n^c"; group switches switch their knobs, and keep the inspector's scroll position, the focus and open lists of
// knobs; narrow windows show the inspector after the graph; saved panel sizes fit the window; another tab's save stops
// this tab's saving.

import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(dirname(fileURLToPath(import.meta.url)));
const file = join(root, 'dist', 'fgc-explorer.html');
if (!existsSync(file)) {
  console.error('dist/fgc-explorer.html not found: run `npm run build` first');
  process.exit(2);
}

let chromium;
try {
  ({ chromium } = await import('playwright'));
} catch {
  try {
    ({ chromium } = await import('playwright-core'));
  } catch {
    console.error('Playwright is not installed (see the comment at the top of e2e/smoke.mjs)');
    process.exit(2);
  }
}

const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
const page = await browser.newPage({ viewport: { width: 1500, height: 950 } });
const problems = [];
page.on('console', (m) => {
  // (warnings too: Cytoscape used to warn about the custom wheel sensitivity on every page load)
  if (m.type() === 'error' || m.type() === 'warning') problems.push(`console ${m.type()}: ${m.text()}`);
});
page.on('pageerror', (e) => problems.push(`page error: ${e.message}`));
// The app must not need the network.
await page.route(/^https?:/, (route) => {
  problems.push(`network request: ${route.request().url()}`);
  return route.abort();
});

// (settled: no analysis pending, and the upper bounds of every regime computed: see Store.scheduleCompletion)
const ready = () => page.waitForFunction(() => window.fgcExplorer && window.fgcExplorer.store.settled, null, { timeout: 60000 });
await page.goto(pathToFileURL(file).href);
await page.evaluate(() => localStorage.clear());
await page.reload();
await ready();

const label = (id) => page.evaluate((x) => window.fgcExplorer.graph.labelOf(x), id);
const count = await page.evaluate(() => window.fgcExplorer.graph.problemCount);
assert.ok(count > 200, `only ${count} problems rendered`);
assert.match(await label('Orthogonal Vectors / OV'), /≥\sn\^2/);
assert.match(await label('Graph Triangle Problems / Negative Triangle Detection'), /≥\sn\^3/);
// A constant parameter in the exponent (k): the bounds as functions of k, or the status at each k, not those of k = 3.
assert.match(await label('Orthogonal Vectors / k-OV'), /≥\sn\^k\s+≤\sn\^k/);
// (Zero-Weight k-Clique: n^3 at every k through the rows from k to k + 1, n^k above; k-AP Detection: n at k = 3, n^2 above)
assert.match(await label('Clique / Zero-Weight k-Clique'), /≥\sn\^3\s+≤\sn\^k/);
assert.match(await label('k-AP Detection'), /k=3–6\sUB/);
// A reduction from a problem to itself (from k to k + 1) is drawn, as a loop.
assert.deepEqual(await page.evaluate(() => window.fgcExplorer.graph.marksOf({ kind: 'row', id: 'R463' })), []);
assert.ok(await page.evaluate(() => ['R463', 'R464', 'R465'].every((id) => window.fgcExplorer.graph.loopShows(id))), 'the loops show above their nodes');

// The family boxes are off by default (with them, a drag that starts inside a box moves the box instead of panning);
// the toggle draws them and takes them away again, keeping every problem.
const families = () => page.evaluate(() => window.fgcExplorer.graph.familyBoxCount);
assert.equal(await page.isChecked('#opt-group'), false);
assert.equal(await families(), 0);
await page.check('#opt-group');
await page.waitForFunction(() => window.fgcExplorer.graph.familyBoxCount > 10, null, { timeout: 5000 });
assert.equal(await page.evaluate(() => window.fgcExplorer.graph.problemCount), count);
await page.uncheck('#opt-group');
await page.waitForFunction(() => window.fgcExplorer.graph.familyBoxCount === 0, null, { timeout: 5000 });

// The compact layout keeps labels reasonably large when the whole graph is shown, and more so with the panels hidden
// (about 3 px at fit for the ~240 problems of the sheet, depending on the seed of the layout; a plain force layout
// gives about 1 px).
const px = () => page.evaluate(() => window.fgcExplorer.graph.labelPixels);
const shown = await px();
assert.ok(shown > 2.5, `labels at fit: ${shown.toFixed(2)} px`);
await page.click('#btn-panel-all');
await page.waitForFunction((before) => window.fgcExplorer.graph.labelPixels > before * 1.3, shown, { timeout: 5000 });
await page.click('#btn-panel-all');
await page.waitForFunction(() => !document.querySelector('main').classList.contains('hide-left'));

// The initial knobs are listed in the inspector, some of them start switched off (compact rows), and the left panel
// has one box per problem.
assert.equal(await page.locator('#initial-settings .initial-groups > li').count() >= 8, true);
assert.equal(await page.locator('#left .knob.disabled').count() >= 5, true);
assert.equal(await page.locator('#left .box').count() >= 20, true);
assert.match(await page.textContent('#left .box[data-problem="3SUM / 3SUM"] .box-bounds'), /≥\sn\^2/);

// Move the 3SUM hypothesis to 1.5 through its number input.
const changed = await page.evaluate(() => {
  const card = [...document.querySelectorAll('#left .box[data-problem="3SUM / 3SUM"] .knob')].find((c) => c.querySelector('.kind')?.textContent === 'LB');
  if (!card) return false;
  const input = card.querySelector('input.num');
  input.value = '1.5';
  input.dispatchEvent(new Event('change'));
  return true;
});
assert.ok(changed, '3SUM knob not found');
await page.waitForTimeout(100);
await ready();
assert.match(await label('Geometric Base / GeomBase'), /≥\sn\^1\.5/);

// CNF-SAT is an exponential-time problem: its Satisfiability Hypothesis knob (L1) also has a power, here set to 2^{0.5 n^{0.75}} through the
// number inputs; MAX-CNF-SAT gets the same lower bound.
const sat = '#left .box[data-problem="Boolean Satisfiability / CNF-SAT"]';
assert.equal(await page.locator(`${sat} .knob[data-knob="L1"] .knob-power`).count(), 1);
assert.equal(await page.locator('#left .box[data-problem="3SUM / 3SUM"] .knob-power').count(), 0);
await page.evaluate((sel) => {
  const card = document.querySelector(`${sel} .knob[data-knob="L1"]`);
  for (const [name, v] of [['exponent of bound L1', '0.5'], ['power of bound L1', '0.75']]) {
    const input = card.querySelector(`input[aria-label="${name}"]`);
    input.value = v;
    input.dispatchEvent(new Event('change'));
  }
}, sat);
await page.waitForTimeout(100);
await ready();
assert.match(await page.textContent(`${sat} .box-bounds`), /≥ 2\^\(0\.5n\^0\.75\)/);
assert.match(await label('Boolean Satisfiability / MAX-CNF-SAT'), /≥\s2\^\(0\.5n\^0\.75\)/);

// Bounds CSV: importing the sample (the initial settings) with "Replace" gives the initial knobs again.
const initialKnobs = await page.evaluate(() => window.fgcExplorer.store.get().scenario.knobs.length);
const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.click('#left .panel-actions button:has-text("Import")')]);
await chooser.setFiles(join(root, 'data', 'initial-bounds.csv'));
await page.waitForSelector('.modal .import-modes');
await page.click('.modal-foot .primary');
await ready();
assert.equal(await page.evaluate(() => window.fgcExplorer.store.get().scenario.knobs.length), initialKnobs);
assert.match(await label('Geometric Base / GeomBase'), /≥\sn\^2/, 'the 3SUM hypothesis is back at 2');

// Header: one segment per thing acted on, each button named after its visible verb and the segment ("Load…" in
// "Reductions" is "Load reductions sheet"); the exports download their files and an exported scenario loads back.
const segments = await page.evaluate(() =>
  [...document.querySelectorAll('header .seg')].map((seg) => ({
    name: document.getElementById(seg.getAttribute('aria-labelledby'))?.textContent,
    buttons: [...seg.querySelectorAll('button')].map((b) => [b.textContent.replace(/[＋…]/g, '').trim(), b.getAttribute('aria-label') ?? '']),
  })),
);
assert.deepEqual(
  segments.map((seg) => seg.name),
  ['Reductions', 'Scenario', 'Config'],
);
for (const seg of segments) {
  for (const [text, name] of seg.buttons) assert.ok(name.startsWith(text), `header button "${text}" is named "${name}"`);
}
const downloads = {};
for (const id of ['#btn-export-sheet', '#btn-export-scenario', '#btn-export-config']) {
  const [download] = await Promise.all([page.waitForEvent('download'), page.click(id)]);
  downloads[id] = { name: download.suggestedFilename(), path: await download.path() };
}
assert.deepEqual(
  Object.values(downloads).map((d) => d.name),
  ['FGC_Reductions_edited.csv', 'fgc-scenario.json', 'fgc-engine-config.json'],
);
const knobsBefore = await page.evaluate(() => JSON.stringify(window.fgcExplorer.store.get().scenario));
const [scenarioChooser] = await Promise.all([page.waitForEvent('filechooser'), page.click('#btn-load-scenario')]);
await scenarioChooser.setFiles(downloads['#btn-export-scenario'].path);
await page.waitForSelector('.toast:has-text("loaded")');
await ready();
assert.equal(await page.evaluate(() => JSON.stringify(window.fgcExplorer.store.get().scenario)), knobsBefore);

// Selection: a click selects one problem, Shift-click in the table adds another; the inspector has a section for each.
const selection = () => page.evaluate(() => window.fgcExplorer.store.get().selection.map((x) => x.id));
await page.click('#left .box[data-problem="3SUM / 3SUM"] .box-name');
await page.fill('#search', 'GeomBase');
await page.click('#bottom-body tr.clickable:has-text("GeomBase")', { modifiers: ['Shift'] });
await page.fill('#search', '');
assert.deepEqual(await selection(), ['3SUM / 3SUM', 'Geometric Base / GeomBase']);
assert.equal(await page.locator('#right details.item').count(), 2);

// Focus modes: everything, ancestors and descendants, neighbours, and the derivations of the best bounds.
const undimmed = async (mode) => {
  await page.selectOption('#opt-focus', mode);
  return page.evaluate(() => window.fgcExplorer.graph.undimmedProblems);
};
const all = await undimmed('off');
const lineage = await undimmed('lineage');
const neighbours = await undimmed('neighbours');
assert.ok(all > lineage && lineage > neighbours && neighbours > 2, `${all} > ${lineage} > ${neighbours} > 2`);
// The view zooms to what the focus mode keeps (an animation of 250 ms).
await page.waitForFunction(() => window.fgcExplorer.graph.undimmedOutOfView === 0, null, { timeout: 3000 });
const derived = await undimmed('derivations');
assert.ok(derived >= 2 && derived < neighbours, String(derived));
await page.click('#left .box[data-problem="3SUM / 3SUM"] .box-name');
assert.equal(await undimmed('derivations'), 1, "3SUM's bounds come from its own knobs");
const marks = await page.evaluate(() => window.fgcExplorer.graph.marksOf({ kind: 'problem', id: '3SUM / 3SUM' }));
// (the pointer is still on 3SUM's name, so it is also highlighted as pointed at)
assert.deepEqual(marks.sort(), ['hover', 'path-lb', 'path-ub', 'selected']);
await page.selectOption('#opt-focus', 'off');

// Pointing at a problem's name (left panel) or a reduction's ID (inspector) highlights it in the graph.
const hovered = () => page.evaluate(() => window.fgcExplorer.graph.cy.elements('.hover').map((e) => e.id()));
await page.hover('#left .box[data-problem="Orthogonal Vectors / OV"] .box-name');
assert.deepEqual(await hovered(), ['p:Orthogonal Vectors / OV']);
await page.hover('#right .rowlist a[data-ref-row="R13"]');
assert.deepEqual(await hovered(), ['r:R13']);
await page.hover('#search');
assert.deepEqual(await hovered(), []);

// Light / dark mode: the toggle shows the other look (the page's background changes), and the second click returns to
// following the system.
const look = () => page.evaluate(() => [document.documentElement.dataset.theme ?? 'system', getComputedStyle(document.body).backgroundColor]);
const [theme0, bg0] = await look();
await page.click('#btn-theme');
const [theme1, bg1] = await look();
await page.click('#btn-theme');
assert.equal(theme0, 'system');
assert.ok(theme1 === 'dark' || theme1 === 'light', theme1);
assert.notEqual(bg1, bg0);
assert.deepEqual(await look(), [theme0, bg0]);

// Inspector: a problem and a reduction.
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'problem', id: '3SUM / 3SUM' }] })));
await page.waitForSelector('#right .regime-row');
await page.click('#right .regime-row');
await page.waitForSelector('#right .derivations');
// Both derivations are numbered lists (3SUM's bounds come from its own knobs: one item each).
assert.deepEqual(await page.locator('#right .derivations ol.chain').evaluateAll((ls) => ls.map((l) => l.children.length)), [1, 1]);
// The list of what each reduction from 3SUM gives for its upper bound, opened (3SUM's own knob gives the bound).
await page.click('#right details.why:last-of-type > summary');
await page.waitForSelector('#right .why-list li');
const why = await page.locator('#right details.why[open] .why-list li').allInnerTexts();
assert.ok(why.length >= 10, String(why.length));
assert.ok(why.some((t) => /gives ≤/.test(t)), why.join('\n'));
assert.ok(why.every((t) => /^R\d+ → /.test(t)), why.join('\n'));
// Settings: a limit for upper-bound detours only.
const settingNames = await page.locator('#left details.settings .field > span').allTextContents();
assert.ok(settingNames.includes('UB detours'), settingNames.join(', '));
assert.ok(!settingNames.some((t) => /hops|depth/i.test(t)), settingNames.join(', '));
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'row', id: 'R2' }] })));
await page.waitForSelector('#right .engine');
// Limits of parameters: Triangle Listing lists its four; a pinned regime beyond them shows the regime it stands for.
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'problem', id: 'Graph Triangle Problems / Triangle Listing' }] })));
await page.waitForSelector('#right .limits');
assert.equal(await page.locator('#right .limits .limit').count(), 4);
await page.fill('#right .pin input', 'n=1, m=1.5, alpha=1, t=4');
await page.click('#right .pin button:has-text("Pin")');
await page.waitForSelector('#right .pin li');
assert.match(await page.locator('#right .pin li').first().innerText(), /→\s*n=1, m=1\.5, alpha=0\.75, t=2\.25/);
await page.click('#right .pin li button[title="unpin"]');
await page.waitForFunction(() => document.querySelectorAll('#right .pin li').length === 0);

// Search (above the graph; the left panel has none of its own): a Bound ID leaves the box of its problem, the bound
// marked; Enter selects that problem and shows the bound; the left panel's Clear ends the search. A word of the notes
// finds bounds in several boxes, and the graph marks the same problems. A reduction's ID selects it on Enter, and a
// name the problem that it names best (a whole word of its name, the first box among those).
assert.equal(await page.locator('#left input[type="search"]').count(), 0);
const shownBoxes = () => page.locator('#left .box:not([hidden])').evaluateAll((bs) => bs.map((b) => b.dataset.problem));
const allBoxes = (await shownBoxes()).length;
const u12Box = await page.evaluate(() => document.querySelector('#left .knob[data-knob="U12"]').closest('.box').dataset.problem);
await page.fill('#search', 'U12');
assert.deepEqual(await shownBoxes(), [u12Box]);
assert.deepEqual(await page.locator('#left .knob.match').evaluateAll((ks) => ks.map((k) => k.dataset.knob)), ['U12']);
await page.press('#search', 'Enter');
assert.deepEqual(await selection(), [u12Box]);
await page.click('#left .boxes-head button:has-text("Clear")');
assert.equal(await page.inputValue('#search'), '');
assert.equal(await page.evaluate(() => document.activeElement.id), 'search', 'Clear gives the focus to the search field');
assert.equal((await shownBoxes()).length, allBoxes);
await page.fill('#search', 'Williams');
const found = await shownBoxes();
assert.ok(found.length > 5 && found.length < allBoxes, String(found.length));
assert.ok((await page.locator('#left .knob.match').count()) >= found.length, 'no problem is named Williams: each box shown has a bound found');
assert.deepEqual(await page.evaluate(() => window.fgcExplorer.graph.cy.nodes('.match').map((n) => n.data('problem')).sort()), [...found].sort());
await page.fill('#search', 'R13');
await page.press('#search', 'Enter');
assert.deepEqual(await selection(), ['R13']);
await page.fill('#search', 'apsp');
await page.press('#search', 'Enter');
assert.deepEqual(await selection(), ['All-Pairs Shortest Paths (APSP) / Directed, Weighted APSP']);
await page.fill('#search', '');

// Bound IDs in the inspector (the problem's list of bounds, and derivations) show the bound in the left panel: its box
// opens if collapsed, and the bound scrolls into view.
const inView = (id) =>
  page.waitForFunction(
    (x) => {
      const k = document.querySelector(`#left .knob[data-knob="${x}"]`);
      const panel = document.querySelector('#left').getBoundingClientRect();
      const r = k.getBoundingClientRect();
      return !k.closest('.box').classList.contains('collapsed') && r.top >= panel.top && r.bottom <= panel.bottom;
    },
    id,
    { timeout: 5000 },
  );
assert.equal(await page.textContent('#left .boxes-toggle'), 'Collapse all');
await page.click('#left .boxes-toggle');
assert.equal(await page.locator('#left .box:not(.collapsed)').count(), 0);
assert.equal(await page.textContent('#left .boxes-toggle'), 'Expand all');
const far = await page.evaluate(() => {
  const box = [...document.querySelectorAll('#left .box')].reverse().find((b) => b.querySelector('a.box-name') && b.querySelector('.knob'));
  return { problem: box.dataset.problem, knob: box.querySelector('.knob').dataset.knob };
});
await page.evaluate((p) => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'problem', id: p }] })), far.problem);
await page.click(`#right .knob-list a.knob-link:text-is("${far.knob}")`);
await inView(far.knob);
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [{ kind: 'problem', id: 'Geometric Base / GeomBase' }] })));
await page.click('#right .regime-row');
await page.click('#right .derivations .knob-ref a.knob-link:text-is("L2")');
await inView('L2');

// Help dialog opens with the focus in it, and gives it back when it closes.
await page.focus('#btn-help');
await page.click('#btn-help');
await page.waitForSelector('.modal[aria-modal="true"]');
assert.ok(await page.evaluate(() => document.querySelector('.modal').contains(document.activeElement)), 'the focus is in the dialog');
await page.keyboard.press('Escape');
assert.equal(await page.evaluate(() => document.activeElement.id), 'btn-help', 'the focus is back');

// A file of the other kind is refused: a config loaded as a scenario, a scenario as a config; nothing changes.
const scenarioNow = () => page.evaluate(() => JSON.stringify(window.fgcExplorer.store.get().scenario));
const configNow = () => page.evaluate(() => JSON.stringify(window.fgcExplorer.store.get().config));
const [sBefore, cBefore] = [await scenarioNow(), await configNow()];
const [asScenario] = await Promise.all([page.waitForEvent('filechooser'), page.click('#btn-load-scenario')]);
await asScenario.setFiles(downloads['#btn-export-config'].path);
await page.waitForSelector('.toast:has-text("this is an engine config")');
const [asConfig] = await Promise.all([page.waitForEvent('filechooser'), page.click('#btn-load-config')]);
await asConfig.setFiles(downloads['#btn-export-scenario'].path);
await page.waitForSelector('.toast:has-text("this is a scenario")');
assert.equal(await scenarioNow(), sBefore);
assert.equal(await configNow(), cBefore);

// Settings: a change keeps the section open and the panel scrolled where it was; a value out of range is refused
// with a message beside the field, which shows the current value again.
const detours = '#left details.settings input[aria-label="UB detours"]';
await page.evaluate(() => {
  const d = document.querySelector('#left details.settings');
  d.open = true;
  d.scrollIntoView();
});
const setField = (selector, value) =>
  page.evaluate(
    ([sel, v]) => {
      const input = document.querySelector(sel);
      input.value = v;
      input.dispatchEvent(new Event('change'));
    },
    [selector, value],
  );
const scrolled = await page.evaluate(() => document.querySelector('#left').scrollTop);
await setField(detours, '4');
await ready();
assert.equal(await page.evaluate(() => window.fgcExplorer.store.get().scenario.settings.maxDepthUB), 4);
assert.ok(await page.evaluate(() => document.querySelector('#left details.settings').open), 'the settings stay open');
assert.ok(Math.abs((await page.evaluate(() => document.querySelector('#left').scrollTop)) - scrolled) < 2, 'the panel stays where it was');
await setField(detours, '9');
assert.equal(await page.inputValue(detours), '4');
assert.match(await page.textContent('#left details.settings .field-error:not([hidden])'), /whole number from 0 to 5/);
await setField(detours, '3');
await ready();
// (ω: a decimal comma is a point; outside [2, 3] refused)
const omega = '#left .constants input.num';
await setField(omega, '2,5');
await ready();
assert.equal(await page.evaluate(() => window.fgcExplorer.store.get().scenario.constants.omega), 2.5);
await setField(omega, '1.5');
assert.equal(await page.inputValue(omega), '2.5');
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, scenario: { ...s.scenario, constants: {} } })));
await ready();

// A formula bound shown as a plain exponent ("n^c") gets its formula back with "ƒ(n)".
const u5 = () => page.evaluate(() => window.fgcExplorer.store.get().scenario.knobs.find((k) => k.id === 'U5'));
const formula = (await u5()).formula;
assert.ok(formula);
// (the boxes were collapsed above: open U5's)
await page.evaluate(() => {
  const box = document.querySelector('#left .knob[data-knob="U5"]').closest('.box');
  if (box.classList.contains('collapsed')) box.querySelector('.box-toggle').click();
  box.querySelector('.knob[data-knob="U5"]').scrollIntoView();
});
await page.click('#left .knob[data-knob="U5"] button.mode');
assert.equal((await u5()).formula, undefined);
await page.click('#left .knob[data-knob="U5"] button.mode');
assert.equal((await u5()).formula, formula);
await ready();

// The switch of an initial group (Initial settings, in the inspector with nothing selected) switches all its knobs.
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, selection: [] })));
const known = '#initial-settings .initial-groups > li:has(b:text-is("Known algorithms")) button.onoff';
const knownOn = () => page.evaluate(() => window.fgcExplorer.store.get().scenario.knobs.filter((k) => /^U([1-9]|1[0-6])$/.test(k.id)).map((k) => k.enabled));
assert.ok((await knownOn()).every((x) => x));
await page.click(known);
await ready();
assert.ok((await knownOn()).every((x) => !x), 'all off');
await page.click(known);
await ready();
assert.ok((await knownOn()).every((x) => x), 'all on again');
// A switch far down the list keeps the inspector where it is scrolled to and the focus on itself (the new analysis
// rebuilds the view; removing the focused switch used to let scroll anchoring move the panel up), and a group's open
// list of knobs stays open.
const kClique = '#initial-settings .initial-groups > li:has(> b:text-is("k-Clique hypothesis"))';
await page.click(`${kClique} > details > summary`);
await page.locator(`${kClique} > button.onoff`).evaluate((b) => {
  const r = document.querySelector('#right');
  r.scrollTop += b.getBoundingClientRect().top - r.getBoundingClientRect().top - r.clientHeight / 2;
});
const rightTop = () => page.evaluate(() => document.querySelector('#right').scrollTop);
const scrolledTo = await rightTop();
assert.ok(scrolledTo > 300, `the inspector is scrolled down (${scrolledTo})`);
for (const state of ['on', 'off']) {
  await page.click(`${kClique} > button.onoff`);
  await page.waitForSelector(`${kClique} > button.onoff.${state}`);
  await ready();
  assert.equal(await rightTop(), scrolledTo, `the inspector stays where it was (switched ${state})`);
  assert.match(await page.evaluate(() => document.activeElement?.getAttribute('aria-label') ?? ''), new RegExp(`^k-Clique hypothesis: ${state};`));
  assert.ok(await page.locator(`${kClique} > details`).evaluate((d) => d.open), 'its list of knobs stays open');
}

// Narrow windows: the inspector comes right after the graph. Saved panel sizes too large for a window shrink in it.
await page.setViewportSize({ width: 1000, height: 800 });
assert.ok(await page.evaluate(() => document.querySelector('#right').getBoundingClientRect().top < document.querySelector('#left').getBoundingClientRect().top));
await page.setViewportSize({ width: 1280, height: 800 });
await page.evaluate(() => window.fgcExplorer.store.update((s) => ({ ...s, prefs: { ...s.prefs, panels: { ...s.prefs.panels, left: { open: true, size: 1020 } } } })));
await page.waitForTimeout(100);
assert.ok((await page.evaluate(() => document.querySelector('#graph').clientWidth)) >= 300, 'the graph keeps its room');
await page.setViewportSize({ width: 1500, height: 950 });

// Another tab saved over this one's data: this tab stops saving and says so.
await page.evaluate(() => window.dispatchEvent(new StorageEvent('storage', { key: 'fgc-explorer.v1' })));
await page.waitForSelector('.stale-banner');

await browser.close();
assert.deepEqual(problems, []);
console.log(`e2e smoke test passed (${count} problems)`);
