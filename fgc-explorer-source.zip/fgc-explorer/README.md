# FGC Reductions Explorer

An interactive map of the fine-grained reductions sheet. Set hypotheses (lower-bound exponents such as SETH, 3SUM or
APSP) and algorithms (upper-bound exponents or runtime formulas), and see what they imply for every problem that the
reductions connect, with a derivation for each number. The design is described in [SPEC.md](SPEC.md).

## Run it

Open `dist/fgc-explorer.html` in a recent Chrome, Edge, Firefox or Safari (double-click it, or drag it into a browser
window). It is a single self-contained file: the sheet, the engine config, the code and the styles are all inside it, and
it never uses the network. Your scenario and edits are remembered by that browser; **Reset…** forgets them.

If a browser refuses to remember things for `file://` pages (the app still works, it just starts fresh each time), serve
the folder instead, e.g. `python3 -m http.server 8000 -d dist` and open `http://localhost:8000/fgc-explorer.html`.

## Use it

* **Left panel.** Hypotheses (lower bounds) and algorithms (upper bounds), each with an on/off checkbox. It starts with
  SETH, the 3SUM and APSP hypotheses and textbook algorithms switched on, and further hypotheses (OV, Min-Weight
  k-Clique, k-Clique, combinatorial BMM) and the October 2026 algorithms of Alman and Vassilevska Williams
  (arXiv:2610.06783) switched off. Hypotheses are conjectures: change or switch them off freely. The inspector lists these
  initial settings when nothing is selected (also via the **Initial settings** link), with **Restore initial settings**.
  Each knob has a regime (how the problem's parameters grow) and an exponent (slider, or type any number of decimals)
  or a runtime formula. Examples of regimes: `n=1, m=2, M=poly` (dense graphs), `n=1, d=polylog` (OV), `n=log,
  m=polylog` (CNF-SAT, time 2^{cn}), `k=const:[3,4,5]` (one regime per k). Formulas are LaTeX in the problem's
  parameters, e.g. `n^2 d` or `\min(n^{\omega}, m^{2\omega/(\omega+1)})`; the constant ω has its own slider.
* **Panels.** Drag the bars between the panels to resize them (double-click a bar for its default size). The buttons
  at the start of the header show or hide the left, bottom and right panels; the fourth shows the graph alone (click
  it again to bring the panels back). Sizes are remembered.
* **Graph.** Scroll to zoom and drag to pan; the toolbar's − / 100% / + / Fit buttons do the same (100% shows labels at
  full size, Fit the whole graph). Click a problem or reduction to inspect it (double-click also opens the inspector if
  hidden). Families are packed in boxes; **Re-layout** arranges them anew. Node color: red conflict (upper < lower,
  detected down to differences of 10⁻⁷, so e.g. 3SUM in n^1.9992 against the 3SUM hypothesis shows), green tight,
  yellow gap, orange lower bound only, blue upper bound only, grey none; dashed nodes are dynamic problems (shown, not
  propagated). Node text shows the bounds at the problem's main regime. Edge color shows which reductions the displayed
  bounds use (orange LB, blue UB, purple both; dashed = not usable by the engine).
* **Inspector (right).** For a problem: all regimes with their bounds; click one for the derivation chain/tree, to pin
  it, or to add a knob there. For a reduction: all sheet fields, how the engine reads the formulas (alternatives, free
  parameters, abbreviations), a probe of the produced instances, and **Edit row**.
* **Tables (bottom).** Sortable problems table, all reductions with their status (why a row is not used), diagnostics.

## Change the data

* The header groups the file buttons by what they act on: **Reductions** (the sheet), **Scenario** and **Config**,
  each with **Load…** (replaces it) and **Export** (downloads it).
* **Edit or add a reduction** in the app (inspector **Edit row**, or **Reductions ＋ Add**), then **Reductions Export**
  to get the CSV back. **Reductions Load…** accepts any CSV export of the sheet with the usual column headers (order
  does not matter).
* **Hypotheses and algorithms from a spreadsheet:** in the left panel, **Bounds CSV: Import…** reads a CSV with the
  columns `Problem`, `Variation`, `Bound ID`, `Upper or Lower`, `Runtime` (any order; optional `Regime`, `Enabled`,
  `Note`; other columns are ignored) and lets you replace the current knobs or add to them (same Bound ID: replaced).
  Bound IDs are numbers, like Reduction IDs (each knob card shows its `#`). A plain number in `Runtime` is an exponent
  (a slider), anything else a LaTeX runtime such as `n^2 d`. **Export** writes the current knobs in the same format;
  `data/initial-bounds.csv` is the initial settings in this format, numbered 1–33 (a template to start from).
  SPEC.md §3.5 has the details.
* Free parameters that the sheet states in prose ("$k \ge 2$ free integer parameter") are declared in the row's
  annotation (JSON) in the row editor, e.g.
  `{"free": [{"name": "k", "type": "int", "values": [2, 3, 4]}]}` or
  `{"free": [{"name": "t", "type": "size", "base": "n", "min": 0, "max": 1}]}`.
  Abbreviations written in the legend as `$X = ...$` are picked up automatically. The editor also stores which problems
  the annotation is for (`"match"`), so that if a newer export of the sheet renumbers its rows, an annotation that no
  longer fits its row is ignored (with a warning in **Diagnostics**) instead of being applied to the wrong reduction.
  **Config Export** saves all annotations, problem settings and initial knobs as JSON (`data/default-config.json` has the
  same format; SPEC.md §3.3 documents every field).

## Develop

Requires Node.js 18 or newer.

```sh
npm install          # dev dependencies (TypeScript, esbuild, mocha, Cytoscape, KaTeX)
npm test             # unit + integration tests (mocha, ~15 s)
npm run typecheck    # tsc --noEmit (strict)
npm run build        # writes dist/fgc-explorer.html, embedding data/FGC_Reductions_filled.csv and data/default-config.json
npm run bounds-sample  # rewrites data/initial-bounds.csv (run after changing initialKnobs in the config)
npm run e2e          # optional browser smoke test of dist/fgc-explorer.html; needs Playwright, see below
```

For the browser test: `npm install --no-save playwright && npx playwright install chromium && npm run e2e` (or install
`playwright-core` and set `CHROMIUM_PATH` to an existing Chrome/Chromium binary).

To change the built-in data, replace `data/FGC_Reductions_filled.csv` and/or edit `data/default-config.json`, then run
`npm test && npm run build`.

```
src/util     CSV parsing, assertions
src/math     LaTeX lexer, parser, expression AST, cell helpers
src/growth   growth-class algebra and expression evaluation
src/model    config/scenario validation, regimes, model construction (problems, compiled rows)
src/engine   free parameters, row evaluation, lower-bound propagation, upper-bound search, analysis
src/ui       browser app (store, graph, panels, dialogs, styles)
test         mocha tests (unit tests per module + integration tests on the real sheet)
scripts      write-initial-bounds.ts (npm run bounds-sample)
e2e          Playwright smoke test of the built file
```
