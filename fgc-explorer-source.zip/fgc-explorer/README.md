# FGC Reductions Explorer

An interactive map of the fine-grained reductions sheet. Set hypotheses (lower-bound exponents such as SETH for
CNF-SAT, 3SUM or APSP) and algorithms (upper-bound exponents or runtime formulas), and see what they imply for every problem that the
reductions connect, with a derivation for each number. The design is described in [SPEC.md](SPEC.md).

## Run it

Open `dist/fgc-explorer.html` in a recent Chrome, Edge, Firefox or Safari (double-click it, or drag it into a browser
window). It is a single self-contained file: the sheet, the engine config, the code and the styles are all inside it, and
it never uses the network. Your scenario and edits are remembered by that browser; **Reset…** forgets them.

If a browser refuses to remember things for `file://` pages (the app still works, it just starts fresh each time), serve
the folder instead, e.g. `python3 -m http.server 8000 -d dist` and open `http://localhost:8000/fgc-explorer.html`.

## Use it

* **Left panel.** One box per problem, holding its lower bounds (hypotheses) and algorithms (upper bounds), each with an
  on/off checkbox; the box's header shows the problem's current bounds (colored by status; click the name to select the
  problem). **＋** in a box adds a bound for its problem (lower bound or algorithm, at a regime), **×** removes a bound or
  the whole box, **＋ Problem** below the boxes adds a box, and boxes collapse with ▾ (or all at once). It starts with the Satisfiability
  Hypothesis (SETH for CNF-SAT with poly(n) clauses; the group was called SETH until November 2026, when a 2^{o(n)}
  algorithm for k-SAT was announced), the 3SUM and APSP hypotheses, textbook algorithms, and a trivial and the best
  known algorithms for most problems (with their sources in the notes; SPEC.md §3.6) switched on, and further hypotheses
  (OV, Min-Weight k-Clique, k-Clique, combinatorial BMM, OMv, Hitting Set, ∀∀∃-OV, 3-uniform hyperclique, k-AP,
  Zero-Weight k-Clique), the non-combinatorial algorithms (Valiant's CFG parser, transitive closure by matrix
  multiplication) and the October 2026 algorithms of Alman and Vassilevska Williams (arXiv:2610.06783, including their
  lopsided-triangle algorithm, which gives Exact Triangle in n^2.99825 through R453) and of Saha and Ye
  (arXiv:2610.20297: (min,+)-product and APSP in Õ(n^2.9963432)) switched off. Reductions have IDs R1, R2, …
  (R320–R365 were added in October 2026: OMv and dynamic problems, parsing, regular expressions, tree edit distance,
  k-dominating set, Hitting Set, polyline simplification, attention, closest pair, Klee's measure problem, bottleneck
  paths, Dyck reachability, MAX-2-SAT; R366–R431 are trivial or very easy reductions between problems already in the
  sheet, such as special cases, negations and Nešetřil–Poljak, filled from the definitions without sources; R432–R465,
  added in November 2026, are Fischer's k-AP replacement for 3SUM in geometry (k-AP Detection, k-GeomBase for k ≥ 4
  and the geometric problems of his Theorem 1.4, with Stabbing and Avoiding Segments, Double-Wedge Intersection and two
  covering problems of Gajentaan–Overmars) and the problems of Figure 1 of Alman and Vassilevska Williams (Lopsided
  All-Edges Sparse Triangle, #Exact Triangle, Zero-Weight k-Clique), with the trivial reductions that tie them to the
  sheet, and the reductions from k to k + 1 (R463–R465) that carry the cubic lower bounds of Min- and Zero-Weight
  k-Clique and Min-Weight k-Cycle from k = 3 to larger k); bounds L1, L2, … (lower) and
  U1, U2, … (upper). Problems that belong to no family (a blank Problem column in the sheet) are named by their
  variation alone and drawn without a family box.
  Hypotheses are conjectures: change or switch them off freely. The inspector lists these initial settings when nothing
  is selected (also via the **Initial settings** link), with **Restore initial settings**. Each bound has a regime (how
  the problem's parameters grow) and an exponent (slider, or type any number of decimals) or a runtime formula. Examples
  of regimes: `n=1, m=2, M=poly` (dense graphs), `n=1, d=polylog` (OV), `n=log, m=polylog` (CNF-SAT, time 2^{cn}),
  `k=const:[3,4,5]` (one regime per k). Formulas are LaTeX in the problem's parameters, e.g. `n^2 d` or
  `\min(n^{\omega}, m^{2\omega/(\omega+1)})`; the constant ω has its own slider.
* **Limits of parameters.** A regime stands for the instances whose parameters grow at most as fast as it says, and
  parameters have limits that every instance satisfies: a graph has at most n² edges, an arboricity α ≤ √m (and at
  least m/n) and at most m·α triangles (so at most n³), a set at most U elements, a queried intersection at most s, a
  pattern is no longer than its text, and so on (130 problems; the inspector lists a problem's limits, SPEC §3.7 all of
  them with their reasons). Every regime is clipped to them, which names the same instances: so no regime stands for
  instances that cannot exist (Triangle Listing had regimes with t = n^4 triangles), and a reduction whose formula
  claims such instances is read where its instances are. A regime you pin or give a bound that gets clipped says so.
* **Search.** The field above the graph searches problems and bounds. Type a problem's name (`APSP`, `k-clique`), a
  Bound ID (`U12`: exactly that bound), or a word from the bounds' notes or formulas (an author such as `Williams`,
  `omega`): the left panel keeps only the boxes found, with the bounds found highlighted (collapsed boxes holding them
  open up) and the count at its top (which stays there while the panel scrolls), the graph outlines the same problems
  and the problems table lists only them. **Enter** selects the problem whose name the query matches best (its name
  equal to it, then having it as a whole word, …; the first box among equals); for a Bound ID it selects its problem
  and scrolls the left panel to the bound, for a reduction's ID (`R12`) it selects that reduction. **Esc** (or Clear
  at the top of the left panel) clears the search and keeps the box you were looking at in view.
* **Times 2^{c·n^a}.** A bound of an exponential-time problem (CNF-SAT, MAX-CNF-SAT) has a second slider for the
  *power* a of n in the exponent: SETH is 2^{1·n^1}; set it to, say, 2^{0.5·n^0.75} or 2^{n^0.99} (the line under the
  regime shows the time). A formula such as `2^{0.5 n^{0.75}} \cdot m` works for any bound, and at polynomial regimes
  gives sub- or quasi-polynomial times (`2^{\sqrt{\log n}}`, `n^{\log n}`). Times are compared power first (every
  2^{c·n^0.99} is below 2^{0.01·n}), and a lower bound of power below 1 passes only through reductions that are
  themselves faster than it: from CNF-SAT, none is (split and list takes 2^{n/2}, the reduction to Subset Sum
  2^{εn} for some ε > 0), so such a bound stays with CNF-SAT and MAX-CNF-SAT.
* **Panels.** Drag the bars between the panels to resize them (double-click a bar for its default size). The buttons
  at the start of the header show or hide the left, bottom and right panels; the fourth shows the graph alone (click
  it again to bring the panels back). Sizes are remembered.
* **Light / dark mode.** The moon button after them switches between light and dark mode. The app starts out following
  your system's setting; a choice is remembered, and switching back to what your system shows follows it again.
* **Graph.** Scroll to zoom and drag to pan; the toolbar's − / 100% / + / Fit buttons do the same (100% shows labels at
  full size, Fit the whole graph). Click a problem or reduction to inspect it (double-click also opens the inspector if
  hidden); **Shift-click** (or Ctrl/⌘-click) adds it to the selection or removes it, here, in the tables and in the
  inspector. Pointing at a problem or reduction, here or at its name or ID (R12) in a panel (e.g. in a derivation in the
  inspector), highlights it in the graph; a label at the edge of the graph points toward it when it is out of view.
  **Focus** dims everything except the selection and: its *neighbours*, all its *ancestors & descendants*
  (problems with a path of reductions to or from it), or its *bound derivations*: the reductions that the best lower
  bound (orange) and upper bound (blue; purple: both) of each selected problem come from, drawn thick (a bound from a
  knob on the problem itself marks only the problem; the regime is the one on the node, or the one opened in the
  inspector). Each family's problems are packed together; **family boxes** (off by default, since a drag that starts
  inside a box moves the box rather than the view) draws a box around them, and **Re-layout** arranges them anew. Node color: red conflict (upper < lower,
  detected down to differences of 10⁻⁷, so e.g. 3SUM in n^1.9992 against the 3SUM hypothesis shows), green tight,
  yellow gap, orange lower bound only, blue upper bound only, grey none; dashed nodes are dynamic problems (shown, not
  propagated). Node color and text show the bounds at the problem's first regime: one with a conflict wherever there is
  one, else a pinned one, else among the nice ones (whole-number exponents such as m = n² or m = n, or simple fractions
  such as n^{3/2}) the one whose bounds say the most, whole numbers first among equals. A problem with a constant
  parameter in the exponent (k-Clique's k, k-OV's k, Klee's d) shows its bounds as functions of it when every listed
  value gives the same simple formula (`≥ n^k  ≤ n^k`, `≤ n^(ωk/3)`), and otherwise the status at each value
  (`k=3 tight · 4–6 UB`) rather than the bounds of one k; the box headers and the problems table do the same, and the
  inspector lists the bounds at each value. Edge color shows which
  reductions the listed bounds use (orange LB, blue UB, purple both; dashed = not usable by the engine).
* **Inspector (right).** For a problem: its regimes with their bounds, the one the graph shows first; regimes with
  unusual exponents (n^{10/11}, which free parameters of reductions produce by the dozen) that no other problem's listed
  bound is derived through are left out (**show all** adds them). Click a regime for its derivations, as numbered lists
  (each bound, then the bounds it comes from; an upper bound whose reduction makes several calls names their items;
  also drawn in the graph's *bound derivations* focus; of the derivations giving the best bound, the one with the
  fewest reductions), to pin it, or to add a bound there. Under each derivation, **Reductions to / from this problem here**
  lists what every reduction gives for that bound at that regime, or why it gives nothing (no bound on the other side,
  the reduction itself is too slow, its calls land in another regime, …). Below the regimes, the problem's own
  hypotheses and algorithms (its box on the left). **Bound IDs** there and in derivations (e.g. "L2 (LB knob; 3SUM
  hypothesis)") are links: a click scrolls the left panel to that bound, opening its box if it is collapsed, and
  highlights it for a moment. For a reduction: all sheet
  fields, how the engine reads the formulas (alternatives, free parameters, abbreviations), a probe of the produced
  instances, and **Edit row**. With several items selected, each gets a collapsible section (× removes it from the
  selection).
* **Tables (bottom).** Sortable problems table (filtered by the search), all reductions with their status (why a row is
  not used), diagnostics.
  Selected problems and reductions are highlighted; click (or Shift-click) a row to select it.

### How bounds are derived

Each problem has one best lower and one best upper bound per regime, the same wherever it is used: in its own box, and
inside the derivation of any other problem. Derivations can be as long as needed (Superadditivity Testing gets 3SUM's
n^1.9992 algorithm through six reductions); among derivations of the same bound, the one with the fewest reductions is
shown. When going around a cycle of reductions improves a bound every time, the bound is the limit of repeating it: a
fixed point, or ∞ for a lower bound that grows without limit (e.g. a 3SUM hypothesis above n^2, through Exact Weight
3-Star Detection and back); the derivation shows the cycle and one lap, and **Diagnostics** lists such cycles. One
limit remains, for upper bounds only: from the regimes it starts from (configured for each problem, of its algorithms,
or pinned), the search passes through at most **UB detours** (Settings, 3 by default) other regimes in a row, because
free parameters create very many of them; pin a regime to start a search there.

## Change the data

* The header groups the file buttons by what they act on: **Reductions** (the sheet), **Scenario** and **Config**,
  each with **Load…** (replaces it) and **Export** (downloads it).
* **Edit or add a reduction** in the app (inspector **Edit row**, or **Reductions ＋ Add**), then **Reductions Export**
  to get the CSV back. **Reductions Load…** accepts any CSV export of the sheet with the usual column headers (order
  does not matter).
* **Hypotheses and algorithms from a spreadsheet:** in the left panel, **Bounds CSV: Import…** reads a CSV with one row
  per bound and the columns `Problem`, `Variation`, `Bound ID`, `Upper or Lower`, `Runtime` (any order; optional
  `Power`, `Regime`, `Enabled`, `Note`; other columns are ignored) and lets you replace the current problems and bounds
  or add to them (same Bound ID: replaced). The boxes follow the order in which the problems first appear; a row with only
  `Problem` and `Variation` (no `Upper or Lower`, no `Runtime`) lists a problem without bounds. Bound IDs are L1, L2, …
  for lower bounds and U1, U2, … for upper bounds (each bound shows its ID); the bare numbers of files from earlier
  versions are read as the IDs those bounds have now (1–9 → L1–L9, 10–33 → U1–U24). A plain number in `Runtime` is an
  exponent (a slider; `Power` is its power, 1 if empty), anything else a LaTeX runtime such as `n^2 d`. **Export**
  writes the boxes in the same format, problem by problem; `data/initial-bounds.csv` is the initial settings in this
  format (Bound IDs L1–L15 and U1–U441, a template to start from).
  SPEC.md §3.5 has the details.
* Free parameters that the sheet states in prose ("$k \ge 2$ free integer parameter") are declared in the row's
  annotation (JSON) in the row editor, e.g.
  `{"free": [{"name": "k", "type": "int", "values": [2, 3, 4]}]}` or
  `{"free": [{"name": "t", "type": "size", "base": "n", "min": 0, "max": 1}]}`.
  Abbreviations written in the legend as `$X = ...$` are picked up automatically. The editor also stores which problems
  the annotation is for (`"match"`), so that if a newer export of the sheet renumbers its rows, an annotation that no
  longer fits its row is ignored (with a warning in **Diagnostics**) instead of being applied to the wrong reduction.
  **Config Export** saves all annotations, problem settings and initial knobs as JSON (`data/default-config.json` has the
  same format; SPEC.md §3.3 documents every field).

## Develop

Requires Node.js 18 or newer.

```sh
npm install          # dev dependencies (TypeScript, esbuild, mocha, Cytoscape, KaTeX)
npm test             # unit + integration tests (mocha, ~45 s)
npm run typecheck    # tsc --noEmit (strict)
npm run build        # writes dist/fgc-explorer.html, embedding data/FGC_Reductions_filled.csv and data/default-config.json
npm run bounds-sample  # rewrites data/initial-bounds.csv (run after changing initialKnobs in the config)
npm run e2e          # optional browser smoke test of dist/fgc-explorer.html; needs Playwright, see below
```

For the browser test: `npm install --no-save playwright && npx playwright install chromium && npm run e2e` (or install
`playwright-core` and set `CHROMIUM_PATH` to an existing Chrome/Chromium binary).

To change the built-in data, replace `data/FGC_Reductions_filled.csv` and/or edit `data/default-config.json`, then run
`npm test && npm run build`.

```
src/util     CSV parsing, assertions
src/math     LaTeX lexer, parser, expression AST, cell helpers
src/growth   growth-class algebra and expression evaluation
src/model    config/scenario validation, regimes, model construction (problems, compiled rows), boxes, bounds CSV
src/engine   free parameters, row evaluation, lower-bound propagation, upper-bound search, analysis, derivations
src/ui       browser app (store, selection, focus modes, graph, panels, dialogs, styles)
test         mocha tests (unit tests per module + integration tests on the real sheet)
scripts      write-initial-bounds.ts (npm run bounds-sample)
e2e          Playwright smoke test of the built file
```
