# FGC Reductions Explorer

An interactive map of the fine-grained reductions sheet. Set hypotheses (lower-bound exponents such as SETH, 3SUM or
APSP) and algorithms (upper-bound exponents or runtime formulas), and see what they imply for every problem that the
reductions connect, with a derivation for each number. The design is described in [SPEC.md](SPEC.md).

## Run it

Open `dist/fgc-explorer.html` in a recent Chrome, Edge, Firefox or Safari (double-click it, or drag it into a browser
window). It is a single self-contained file: the sheet, the engine config, the code and the styles are all inside it, and
it never uses the network. Your scenario and edits are remembered by that browser; **Reset…** forgets them.

If a browser refuses to remember things for `file://` pages (the app still works, it just starts fresh each time), serve
the folder instead, e.g. `python3 -m http.server 8000 -d dist` and open `http://localhost:8000/fgc-explorer.html`.

## Use it

* **Left panel.** One box per problem, holding its lower bounds (hypotheses) and algorithms (upper bounds), each with an
  on/off checkbox; the box's header shows the problem's current bounds (colored by status; click the name to select the
  problem). **＋** in a box adds a bound for its problem (lower bound or algorithm, at a regime), **×** removes a bound or
  the whole box, **＋ Problem** below the boxes adds a box, and boxes collapse with ▾. It starts with SETH, the 3SUM and
  APSP hypotheses and textbook algorithms switched on, and further hypotheses (OV, Min-Weight k-Clique, k-Clique,
  combinatorial BMM) and the October 2026 algorithms of Alman and Vassilevska Williams (arXiv:2610.06783) switched off.
  Hypotheses are conjectures: change or switch them off freely. The inspector lists these initial settings when nothing
  is selected (also via the **Initial settings** link), with **Restore initial settings**. Each bound has a regime (how
  the problem's parameters grow) and an exponent (slider, or type any number of decimals) or a runtime formula. Examples
  of regimes: `n=1, m=2, M=poly` (dense graphs), `n=1, d=polylog` (OV), `n=log, m=polylog` (CNF-SAT, time 2^{cn}),
  `k=const:[3,4,5]` (one regime per k). Formulas are LaTeX in the problem's parameters, e.g. `n^2 d` or
  `\min(n^{\omega}, m^{2\omega/(\omega+1)})`; the constant ω has its own slider.
* **Times 2^{c·n^a}.** A bound of an exponential-time problem (CNF-SAT, MAX-CNF-SAT) has a second slider for the
  *power* a of n in the exponent: SETH is 2^{1·n^1}; set it to, say, 2^{0.5·n^0.75} or 2^{n^0.99} (the line under the
  regime shows the time). A formula such as `2^{0.5 n^{0.75}} \cdot m` works for any bound, and at polynomial regimes
  gives sub- or quasi-polynomial times (`2^{\sqrt{\log n}}`, `n^{\log n}`). Times are compared power first (every
  2^{c·n^0.99} is below 2^{0.01·n}), and a lower bound of power below 1 passes only through reductions that are
  themselves faster than it: from CNF-SAT, none is (split and list takes 2^{n/2}, the reduction to Subset Sum
  2^{εn} for some ε > 0), so such a bound stays with CNF-SAT and MAX-CNF-SAT.
* **Panels.** Drag the bars between the panels to resize them (double-click a bar for its default size). The buttons
  at the start of the header show or hide the left, bottom and right panels; the fourth shows the graph alone (click
  it again to bring the panels back). Sizes are remembered.
* **Light / dark mode.** The moon button after them switches between light and dark mode. The app starts out following
  your system's setting; a choice is remembered, and switching back to what your system shows follows it again.
* **Graph.** Scroll to zoom and drag to pan; the toolbar's − / 100% / + / Fit buttons do the same (100% shows labels at
  full size, Fit the whole graph). Click a problem or reduction to inspect it (double-click also opens the inspector if
  hidden); **Shift-click** (or Ctrl/⌘-click) adds it to the selection or removes it, here, in the tables and in the
  inspector. Pointing at a problem or reduction, here or at its name or #ID in a panel (e.g. in a derivation in the
  inspector), highlights it in the graph; a label at the edge of the graph points toward it when it is out of view.
  **Focus** dims everything except the selection and: its *neighbours*, all its *ancestors & descendants*
  (problems with a path of reductions to or from it), or its *bound derivations*: the reductions that the best lower
  bound (orange) and upper bound (blue; purple: both) of each selected problem come from, drawn thick (a bound from a
  knob on the problem itself marks only the problem; the regime is the one on the node, or the one opened in the
  inspector). Families are packed in boxes; **Re-layout** arranges them anew. Node color: red conflict (upper < lower,
  detected down to differences of 10⁻⁷, so e.g. 3SUM in n^1.9992 against the 3SUM hypothesis shows), green tight,
  yellow gap, orange lower bound only, blue upper bound only, grey none; dashed nodes are dynamic problems (shown, not
  propagated). Node text shows the bounds at the problem's main regime. Edge color shows which reductions the displayed
  bounds use (orange LB, blue UB, purple both; dashed = not usable by the engine).
* **Inspector (right).** For a problem: all regimes with their bounds; click one for its derivations, as numbered lists
  (each bound, then the bounds it comes from; an upper bound whose reduction makes several calls names their items;
  also drawn in the graph's *bound derivations* focus; of the derivations giving the best bound, the one with the
  fewest reductions), to pin it, or to add a bound there. Under each derivation, **Reductions to / from this problem here**
  lists what every reduction gives for that bound at that regime, or why it gives nothing (no bound on the other side,
  the reduction itself is too slow, its calls land in another regime, …). For a reduction: all sheet
  fields, how the engine reads the formulas (alternatives, free parameters, abbreviations), a probe of the produced
  instances, and **Edit row**. With several items selected, each gets a collapsible section (× removes it from the
  selection).
* **Tables (bottom).** Sortable problems table, all reductions with their status (why a row is not used), diagnostics.
  Selected problems and reductions are highlighted; click (or Shift-click) a row to select it.

### How bounds are derived

Each problem has one best lower and one best upper bound per regime, the same wherever it is used: in its own box, and
inside the derivation of any other problem. Derivations can be as long as needed (Superadditivity Testing gets 3SUM's
n^1.9992 algorithm through six reductions); among derivations of the same bound, the one with the fewest reductions is
shown. When going around a cycle of reductions improves a bound every time, the bound is the limit of repeating it: a
fixed point, or ∞ for a lower bound that grows without limit (e.g. a 3SUM hypothesis above n^2, through Exact Weight
3-Star Detection and back); the derivation shows the cycle and one lap, and **Diagnostics** lists such cycles. One
limit remains, for upper bounds only: from the regimes listed for each problem, the search passes through at most
**UB detours** (Settings, 3 by default) regimes in a row that are not listed, because free parameters create very many
of them; pin a regime to list it.

## Change the data

* The header groups the file buttons by what they act on: **Reductions** (the sheet), **Scenario** and **Config**,
  each with **Load…** (replaces it) and **Export** (downloads it).
* **Edit or add a reduction** in the app (inspector **Edit row**, or **Reductions ＋ Add**), then **Reductions Export**
  to get the CSV back. **Reductions Load…** accepts any CSV export of the sheet with the usual column headers (order
  does not matter).
* **Hypotheses and algorithms from a spreadsheet:** in the left panel, **Bounds CSV: Import…** reads a CSV with one row
  per bound and the columns `Problem`, `Variation`, `Bound ID`, `Upper or Lower`, `Runtime` (any order; optional
  `Power`, `Regime`, `Enabled`, `Note`; other columns are ignored) and lets you replace the current problems and bounds
  or add to them (same Bound ID: replaced). The boxes follow the order in which the problems first appear; a row with only
  `Problem` and `Variation` (no `Upper or Lower`, no `Runtime`) lists a problem without bounds. Bound IDs are numbers,
  like Reduction IDs (each bound shows its `#`). A plain number in `Runtime` is an exponent (a slider; `Power` is its
  power, 1 if empty), anything else a LaTeX runtime such as `n^2 d`. **Export** writes the boxes in the same format, problem by problem;
  `data/initial-bounds.csv` is the initial settings in this format (Bound IDs 1–33, a template to start from).
  SPEC.md §3.5 has the details.
* Free parameters that the sheet states in prose ("$k \ge 2$ free integer parameter") are declared in the row's
  annotation (JSON) in the row editor, e.g.
  `{"free": [{"name": "k", "type": "int", "values": [2, 3, 4]}]}` or
  `{"free": [{"name": "t", "type": "size", "base": "n", "min": 0, "max": 1}]}`.
  Abbreviations written in the legend as `$X = ...$` are picked up automatically. The editor also stores which problems
  the annotation is for (`"match"`), so that if a newer export of the sheet renumbers its rows, an annotation that no
  longer fits its row is ignored (with a warning in **Diagnostics**) instead of being applied to the wrong reduction.
  **Config Export** saves all annotations, problem settings and initial knobs as JSON (`data/default-config.json` has the
  same format; SPEC.md §3.3 documents every field).

## Develop

Requires Node.js 18 or newer.

```sh
npm install          # dev dependencies (TypeScript, esbuild, mocha, Cytoscape, KaTeX)
npm test             # unit + integration tests (mocha, ~45 s)
npm run typecheck    # tsc --noEmit (strict)
npm run build        # writes dist/fgc-explorer.html, embedding data/FGC_Reductions_filled.csv and data/default-config.json
npm run bounds-sample  # rewrites data/initial-bounds.csv (run after changing initialKnobs in the config)
npm run e2e          # optional browser smoke test of dist/fgc-explorer.html; needs Playwright, see below
```

For the browser test: `npm install --no-save playwright && npx playwright install chromium && npm run e2e` (or install
`playwright-core` and set `CHROMIUM_PATH` to an existing Chrome/Chromium binary).

To change the built-in data, replace `data/FGC_Reductions_filled.csv` and/or edit `data/default-config.json`, then run
`npm test && npm run build`.

```
src/util     CSV parsing, assertions
src/math     LaTeX lexer, parser, expression AST, cell helpers
src/growth   growth-class algebra and expression evaluation
src/model    config/scenario validation, regimes, model construction (problems, compiled rows), boxes, bounds CSV
src/engine   free parameters, row evaluation, lower-bound propagation, upper-bound search, analysis, derivations
src/ui       browser app (store, selection, focus modes, graph, panels, dialogs, styles)
test         mocha tests (unit tests per module + integration tests on the real sheet)
scripts      write-initial-bounds.ts (npm run bounds-sample)
e2e          Playwright smoke test of the built file
```
