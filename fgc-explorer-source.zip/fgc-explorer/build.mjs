// Builds dist/fgc-explorer.html: one self-contained file (code, styles, the sheet and the default config inlined).
//
// Usage: node build.mjs [--dev]   (--dev: no minification, inline source map)

import { build } from 'esbuild';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const dev = process.argv.includes('--dev');

const result = await build({
  entryPoints: [join(root, 'src/ui/main.ts')],
  bundle: true,
  write: false,
  format: 'iife',
  target: ['es2020'],
  minify: !dev,
  sourcemap: dev ? 'inline' : false,
  loader: { '.csv': 'text', '.json': 'json' },
  legalComments: 'eof',
  logLevel: 'warning',
});

const js = result.outputFiles[0].text
  // A literal "</script" inside the inlined code would end the script element early.
  .replace(/<\/script/gi, '<\\/script');
const css = readFileSync(join(root, 'src/ui/styles.css'), 'utf8');
const template = readFileSync(join(root, 'src/ui/index.html'), 'utf8');
if (!template.includes('/*STYLE*/') || !template.includes('/*SCRIPT*/')) throw new Error('template placeholders missing');
// Function replacements: "$" in the inlined code must not be read as a replacement pattern.
const html = template.replace('/*STYLE*/', () => css).replace('/*SCRIPT*/', () => js);

mkdirSync(join(root, 'dist'), { recursive: true });
const out = join(root, 'dist/fgc-explorer.html');
writeFileSync(out, html);
console.log(`wrote ${out} (${(html.length / 1024).toFixed(0)} KiB)`);
